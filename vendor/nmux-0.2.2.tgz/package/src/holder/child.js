'use strict';
// @ts-check
const fs = require('node:fs');
const os = require('node:os');
const { EventEmitter } = require('node:events');
const pty = require('node-pty');
const { ttyctl } = require('../platform/native.js');
const procinfo = require('../platform/procinfo.js');
const { lflagToWire } = require('../wire/holder-wire.js');

const READ_BYTES = 65536;
const TAIL_MAX_BYTES = 4194304;

/** @param {number|null|undefined} sig */
function signalName(sig) {
  if (!sig) return null;
  for (const [name, num] of Object.entries(os.constants.signals)) if (num === sig) return name;
  return String(sig);
}

/**
 * The program on the pty. Events: 'data'(Buffer), 'lflag'(wire message, on change), 'exit'(wire message, once).
 * Its exit is detected by node-pty or by the process-table backstop, whichever comes first.
 */
class PtyChild extends EventEmitter {
  /** @param {{spec: any, clock: import('../base/types').Clock, timers: any, log: any}} o */
  constructor({ spec, clock, timers, log }) {
    super();
    this.clock = clock;
    this.timers = timers;
    this.log = log;
    /** @type {any} node-pty's typings leave out fd, ptsName and destroy */
    const term = pty.spawn(spec.argv[0], spec.argv.slice(1), { name: spec.term || 'xterm-256color', cols: spec.cols, rows: spec.rows, cwd: spec.cwd, env: spec.env, encoding: null });
    this.term = term;
    this.pid = term.pid;
    this.masterFd = term.fd;
    this.ptsName = term.ptsName;
    this.start = procinfo.procStart(this.pid);
    this.size = { cols: spec.cols, rows: spec.rows };
    /** @type {null|{t: 'EXIT', code: number|null, signal: string|null, at: string, shuttingDown: boolean, detectedBy: 'pty'|'proc', error?: string}} */
    this.exit = null;
    this.shuttingDown = false;
    /** @type {string|null} */
    this.leaderError = null;
    this.lastLflag = '';
    /** @type {any} */ this.lflagTimer = null;
    /** @type {any} */ this.procTimer = null;
    /** @type {any} */ this.graceTimer = null;
    this.hangingUp = false;
    term.onData((/** @type {any} */ data) => this.emit('data', Buffer.isBuffer(data) ? data : Buffer.from(data)));
    this._readTheTail(term._socket);
    term.onExit((/** @type {{exitCode: number, signal?: number}} */ { exitCode, signal }) => this._exited(exitCode, signalName(signal), 'pty'));
  }

  /**
   * node-pty destroys its socket 200 ms after the child exits, whatever is still unread, because something else may hold the
   * pty open and it would otherwise never close. On a busy machine that throws away the end of the output, which is the part
   * that says what went wrong. So everything still readable is read first, with no timing to race against.
   * @param {any} socket
   */
  _readTheTail(socket) {
    if (!socket) return;
    const destroy = socket.destroy.bind(socket);
    socket.destroy = (/** @type {any[]} */ ...args) => {
      if (!this.hangingUp) this._drain(socket);
      return destroy(...args);
    };
  }

  /** @param {any} socket */
  _drain(socket) {
    if (!socket || socket.destroyed) return;
    while (socket.read() !== null);                                                    // read while paused; each one goes out as 'data'
    const buf = Buffer.allocUnsafe(READ_BYTES);
    for (let total = 0; total < TAIL_MAX_BYTES;) {                                     // what something left behind writes has no end
      let n = 0;
      try { n = fs.readSync(this.masterFd, buf, 0, READ_BYTES, null); } catch { return; }   // EAGAIN: empty. EIO: closed
      if (n === 0) return;
      this.emit('data', Buffer.from(buf.subarray(0, n)));
      total += n;
    }
  }

  /** The child must be its own session leader: job control and the foreground check depend on it. */
  async becomeLeader() {
    const deadline = this.clock.now() + 1000;
    const isLeader = () => procinfo.pgid(this.pid) === this.pid && procinfo.procSid(this.pid) === this.pid;
    while (this.clock.now() < deadline && procinfo.procState(this.pid) === 'alive' && !isLeader()) await new Promise((r) => setTimeout(r, 5));
    this.start = procinfo.procStart(this.pid) || this.start;
    if (procinfo.procState(this.pid) === 'alive' && !isLeader()) {
      this.leaderError = 'NOT_SESSION_LEADER';
      this.log.error('spawn.not_session_leader', { pid: this.pid });
      try { process.kill(this.pid, 'SIGTERM'); } catch { /* gone */ }
    }
  }

  /** Starts the terminal-flags poll and the exit backstop. */
  watch() {
    this._pollLflag();
    this.procTimer = this.clock.setTimeout(() => this._pollProc(), this.timers.procPollMs);
  }

  /** The foreground process group tells the child apart from anything it started. */
  _pollLflag() {
    this.lflagTimer = null;
    if (this.exit) return;
    try {
      const l = ttyctl.lflag(this.masterFd);                                          // TCGETS on the master returns the slave's termios
      const fg = ttyctl.tcgetpgrp(this.masterFd);
      const fgIsChild = fg === this.pid;                                              // the child leads its session: pgid === pid
      const msg = lflagToWire({ icanon: l.icanon, isig: l.isig, echo: l.echo, fgIsChild, fg });
      const key = JSON.stringify(msg);
      if (key !== this.lastLflag) { this.lastLflag = key; this.emit('lflag', msg); }
    } catch { /* master closed */ }
    this.lflagTimer = this.clock.setTimeout(() => this._pollLflag(), this.timers.lflagPollMs);
  }

  _pollProc() {
    this.procTimer = null;
    if (this.exit) return;
    if (procinfo.procState(this.pid) !== 'alive') {
      // node-pty reports the real code within ~200 ms of reaping (its socket-close timeout): wait that long before nulls
      if (this.graceTimer === null) this.graceTimer = this.clock.setTimeout(() => { this.graceTimer = null; this._exited(null, null, 'proc'); }, this.timers.exitGraceMs);
      return;
    }
    this.procTimer = this.clock.setTimeout(() => this._pollProc(), this.timers.procPollMs);
  }

  /** @param {number|null} code @param {string|null} signal @param {'pty'|'proc'} by */
  _exited(code, signal, by) {
    if (this.exit) return;
    this.stopTimers();
    if (by === 'proc') this._drain(this.term._socket);                                 // node-pty has not got that far yet
    this.exit = { t: 'EXIT', code, signal, at: new Date().toISOString(), shuttingDown: this.shuttingDown, detectedBy: by };
    if (this.leaderError) this.exit.error = this.leaderError;
    this.log.info('child.exit', { code, signal, by, shuttingDown: this.shuttingDown });
    this.emit('exit', this.exit);
  }

  stopTimers() {
    for (const k of /** @type {const} */ (['lflagTimer', 'procTimer', 'graceTimer'])) if (this[k] !== null) { this.clock.clearTimeout(this[k]); this[k] = null; }
  }

  /** @param {Buffer} bytes */
  write(bytes) { if (!this.exit) this.term.write(/** @type {any} */ (bytes)); }

  /** Stops reading the pty: the kernel buffer fills and the child blocks in write(), as on a slow terminal. */
  pause() { this.term.pause(); }
  resume() { this.term.resume(); }

  /** @param {number} cols @param {number} rows */
  resize(cols, rows) {
    this.term.resize(cols, rows);
    this.size = { cols, rows };
  }

  /** @param {string} sig */
  signal(sig) {
    if (!this.exit && procinfo.procStart(this.pid) === this.start) {
      try { process.kill(this.pid, sig); this.log.info('signal', { sig }); } catch { /* gone */ }
    }
  }

  /** Closes the master: EIO and SIGHUP for the child. */
  hangUp() { if (!this.exit) { this.log.info('close_master'); this.destroy(); } }
  destroy() { this.hangingUp = true; try { this.term.destroy(); } catch { /* closed */ } }

  /** bytes node-pty accepted from write() but has not handed to the kernel yet (its EAGAIN queue) */
  backlog() {
    const q = /** @type {any} */ (this.term)._writeStream?._writeQueue || [];
    let n = 0;
    for (const t of q) n += t.buffer.length - t.offset;
    return n;
  }

  dropBacklog() {
    const q = /** @type {any} */ (this.term)._writeStream?._writeQueue;
    if (q && q.length) q.splice(q[0].offset > 0 ? 1 : 0);
  }
}

module.exports = { PtyChild };
