'use strict';
// @ts-check
/**
 * Cell serializer. Turns emulator buffer rows into byte strings that recreate the same cells when
 * written at column 1 of a line with default attributes. Every row starts from SGR 0 and ends with SGR 0 if it changed
 * attributes, so rows are independent. Color modes are preserved (16-color stays `3x`, 256 stays `38;5`, RGB stays `38;2`).
 * Never-written cells (chars '') are skipped with CUF so they stay empty; empty cells with a visible background are
 * recreated with ECH (which erases with the current background) + CUF. Trailing empty default cells are trimmed.
 */

const CM_MASK = 0x3000000, CM_P16 = 0x1000000, CM_P256 = 0x2000000, CM_RGB = 0x3000000;

/** @param {number} mode @param {number} color @param {boolean} fg */
function colorSgr(mode, color, fg) {
  switch (mode & CM_MASK) {
    case CM_P16: return color < 8 ? `${(fg ? 30 : 40) + color}` : `${(fg ? 90 : 100) + color - 8}`;
    case CM_P256: return `${fg ? 38 : 48};5;${color}`;
    case CM_RGB: return `${fg ? 38 : 48};2;${(color >> 16) & 255};${(color >> 8) & 255};${color & 255}`;
    default: return '';
  }
}

/** @param {any} c IBufferCell @returns {string} canonical SGR parameters ('' = default attributes) */
function attrKey(c) {
  const p = [];
  if (c.isBold()) p.push('1');
  if (c.isDim()) p.push('2');
  if (c.isItalic()) p.push('3');
  if (c.isUnderline()) p.push('4');
  if (c.isBlink()) p.push('5');
  if (c.isInverse()) p.push('7');
  if (c.isInvisible()) p.push('8');
  if (c.isStrikethrough()) p.push('9');
  if (c.isOverline()) p.push('53');
  const fg = colorSgr(c.getFgColorMode(), c.getFgColor(), true);
  if (fg) p.push(fg);
  const bg = colorSgr(c.getBgColorMode(), c.getBgColor(), false);
  if (bg) p.push(bg);
  return p.join(';');
}

/** Last column of a row that must be written, or -1. @param {any} line @param {number} width @param {any} cell */
function lastUsedColumn(line, width, cell) {
  for (let x = width - 1; x >= 0; x--) {
    line.getCell(x, cell);
    if (cell.getWidth() === 0) continue;
    if (cell.getChars() !== '' || attrKey(cell) !== '') return x + Math.max(1, cell.getWidth()) - 1;
  }
  return -1;
}

/** First line in [0, limit) with any visible text, or `limit`. @param {any} buffer @param {number} limit */
function firstWrittenLine(buffer, limit) {
  for (let i = 0; i < limit; i++) {
    const l = buffer.getLine(i);
    if (l && l.translateToString(true) !== '') return i;
  }
  return limit;
}

/** Whether a row is really continued by the next: full to its last column, as xterm leaves a row it wrapped. @param {any} buffer @param {number} y @param {number} cols */
function continues(buffer, y, cols) {
  const next = buffer.getLine(y + 1);
  if (!next || !next.isWrapped) return false;
  const cell = buffer.getNullCell();
  next.getCell(0, cell);
  if (cell.getChars() === '') return false;                  // only a character wraps: a cursor move would leave it pending
  const wideNext = cell.getWidth() === 2;
  const line = buffer.getLine(y);
  const last = lastUsedColumn(line, cols, cell);
  if (last < 0) return false;
  line.getCell(last, cell);
  if (cell.getWidth() === 0) line.getCell(last - 1, cell);
  if (cell.getChars() === '') return false;                  // a blank is drawn by erasing, which leaves no wrap pending
  return last >= cols - 1 || (last === cols - 2 && wideNext);   // a wide character that did not fit
}

/**
 * Rows as one stream: a row its neighbour continues has no line break, so the terminal wraps them itself and can reflow
 * them later. Breaks are CRLF.
 * @param {any} buffer @param {number} from @param {number} to @param {number} cols
 */
function serializeFlow(buffer, from, to, cols) {
  const rows = serializeRows(buffer, from, to);
  let out = '';
  for (let i = 0; i < rows.length; i++) {
    out += rows[i];
    if (i + 1 < rows.length && !continues(buffer, from + i, cols)) out += '\r\n';
  }
  return out;
}

/**
 * Rows as whole lines, however they wrapped.
 * @param {any} buffer @param {number} from @param {number} to @param {{ansi?: boolean}} [o] @returns {string[]}
 */
function logicalLines(buffer, from, to, { ansi = false } = {}) {
  /** @type {string[]} */
  const out = [];
  const rows = ansi ? serializeRows(buffer, from, to) : null;
  for (let y = from; y < to; y++) {
    const line = buffer.getLine(y);
    const text = rows ? rows[y - from] : (line ? line.translateToString(true) : '');
    if (line && line.isWrapped && out.length) out[out.length - 1] += text;
    else out.push(text);
  }
  return out;
}

/**
 * @param {any} buffer IBuffer (normal or alternate) of @xterm/headless
 * @param {number} from first line index (inclusive)
 * @param {number} to last line index (exclusive)
 * @param {{maxCols?: number}} [opts] maxCols truncates each row
 * @returns {string[]}
 */
function serializeRows(buffer, from, to, opts = {}) {
  const out = [];
  const cell = buffer.getNullCell();
  for (let y = from; y < to; y++) {
    const line = buffer.getLine(y);
    if (!line) { out.push(''); continue; }
    const width = Math.min(line.length, opts.maxCols ?? line.length);
    const last = lastUsedColumn(line, width, cell);
    let s = '';
    let cur = '';
    let skip = 0;                                            // run of default empty cells, crossed with CUF
    for (let x = 0; x <= last && x < width; x++) {
      line.getCell(x, cell);
      const w = cell.getWidth();
      if (w === 0) continue;                                 // right half of a wide character
      if (w === 2 && x + 1 >= width) break;                  // a wide character cut by maxCols is dropped
      const key = attrKey(cell);
      const chars = cell.getChars();
      if (chars === '' && key === '') { skip += 1; continue; }
      if (skip) { s += `\x1b[${skip}C`; skip = 0; }
      if (key !== cur) { s += `\x1b[0${key ? ';' + key : ''}m`; cur = key; }
      s += chars === '' ? '\x1b[X\x1b[C' : chars;
    }
    if (cur !== '') s += '\x1b[0m';
    out.push(s);
  }
  return out;
}

module.exports = { serializeRows, serializeFlow, logicalLines, firstWrittenLine, attrKey };
