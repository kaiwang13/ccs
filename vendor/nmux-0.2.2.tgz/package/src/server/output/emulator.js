'use strict';
// @ts-check
const { Terminal } = require('@xterm/headless');
const { Unicode11Addon } = require('@xterm/addon-unicode11');
const { rewriteRow } = require('./adapter');
const { logicalLines, firstWrittenLine } = require('./cells');

/** @typedef {import('./pipeline').AnnotatedChunk} AnnotatedChunk */

/** xterm refuses anything narrower. */
const MIN_COLS = 2;

/** How much xterm parses between chances for anything else to run. */
const WRITE_SLICE = 65536;

/**
 * Snapshot emulator, in one of two geometries.
 *
 * Tracking: the emulator is the pty's size and is resized at the stream offset the pty was, so what wrapped or scrolled
 * in the terminal wrapped and scrolled here too. Live bytes never pass through it; it serves joins, capture and CPR.
 *
 * Fixed: one 240×150 xterm with Unicode 11, aligned ONCE so the PTY screen is its bottom rows, never resized, and fed
 * through the same Δ row rewrite as a client that is 150 rows tall. For a program that repaints its whole screen, which
 * survives no resize reflow.
 *
 * Chunks queue and are parsed a batch at a time, so a program printing a line at a time costs what the bytes cost rather
 * than a timer tick each. `onParsed` reports how far parsing has reached: that is what the holder's flow control runs on.
 */
class Emulator {
  /** @param {{cols?: number, rows?: number, scrollback?: number, tracking?: boolean}} [o] */
  constructor({ cols = 240, rows = 150, scrollback = 10000, tracking = false } = {}) {
    this.cols = cols;
    this.rows = rows;
    this.tracking = tracking;
    this.term = new Terminal({ cols, rows, scrollback, allowProposedApi: true });
    this.term.loadAddon(new Unicode11Addon());
    this.term.unicode.activeVersion = '11';
    /**
     * DECSC slots per buffer, recorded exactly as xterm stores them: x column and y ABSOLUTE line (baseY + cursorY), so a
     * later scroll moves the saved position with the content (xterm's restoreCursor subtracts the current ybase).
     * @type {{normal: {x: number, y: number}|null, alternate: {x: number, y: number}|null}}
     */
    this.saved = { normal: null, alternate: null };
    /** stream offset up to which xterm has parsed */
    this.processedOffset = 0;
    /** @type {Map<number, {x: number, y: number, alt: boolean}>} cursor at each CPR query, keyed by the query's end offset */
    this.cprAt = new Map();
    /** @type {AnnotatedChunk[]} */
    this.queue = [];
    this.draining = false;
    /** @type {Promise<void>} resolves when every chunk fed so far has been parsed */
    this.tail = Promise.resolve();
    /** @type {(offset: number) => void} */
    this.onParsed = () => {};
  }

  /** @param {string|Buffer} data @returns {Promise<void>} */
  _write(data) {
    if (data.length <= WRITE_SLICE) return new Promise((resolve) => this.term.write(data, () => resolve(undefined)));
    const bytes = Buffer.isBuffer(data) ? data : Buffer.from(data);
    let at = 0;
    for (; at + WRITE_SLICE < bytes.length; at += WRITE_SLICE) this.term.write(bytes.subarray(at, at + WRITE_SLICE));
    return new Promise((resolve) => this.term.write(bytes.subarray(at), () => resolve(undefined)));
  }

  /**
   * Call exactly once. Fixed: aligns the PTY screen with the bottom `ptyRows` rows. Tracking: takes the pty's size and
   * gives the buffer blank history, as any real terminal has, because that decides where text lands when a resize reflows it.
   * @param {number} ptyRows @param {number} [ptyCols]
   */
  async init(ptyRows, ptyCols = this.cols) {
    if (!this.tracking) { await this._write('\r\n'.repeat(this.rows - ptyRows)); return; }
    this._resize(ptyCols, ptyRows);
    await this._write(`${'\r\n'.repeat(ptyRows)}\x1b[H`);
  }

  /** Takes this size, with everything fed so far parsed at the old one. @param {number} cols @param {number} rows */
  resizeTo(cols, rows) { if (cols !== this.cols || rows !== this.rows) this._resize(cols, rows); }

  /** @param {number} cols @param {number} rows */
  _resize(cols, rows) {
    this.term.resize(Math.max(MIN_COLS, cols), rows);
    this.cols = this.term.cols;
    this.rows = this.term.rows;
  }

  /** @param {AnnotatedChunk} chunk @returns {Promise<void>} resolves when xterm has parsed the chunk */
  feed(chunk) {
    this.queue.push(chunk);
    if (!this.draining) { this.draining = true; this.tail = this._drain(); }
    return this.tail;
  }

  async _drain() {
    while (this.queue.length) {
      const batch = this.queue;
      this.queue = [];
      await this._parse(batch);
      this.processedOffset = batch[batch.length - 1].endOffset;
      this.onParsed(this.processedOffset);
    }
    this.draining = false;
  }

  /** @param {AnnotatedChunk[]} batch */
  async _parse(batch) {
    /** @type {Buffer[]} */
    const parts = [];
    const flush = async () => { await this._write(Buffer.concat(parts)); parts.length = 0; };
    for (const chunk of batch) {
      let pos = 0;
      for (const e of chunk.edits) {
        parts.push(chunk.bytes.subarray(pos, e.start));
        pos = e.end;
        if (e.kind === 'resize') {
          await flush();
          this._resize(/** @type {number} */ (e.cols), /** @type {number} */ (e.rows));
          continue;
        }
        if (e.kind === 'drop') {
          if (e.query === 'CPR' || e.query === 'DECXCPR') {                    // record the cursor exactly where the query was
            await flush();
            const b = this.term.buffer.active;
            this.cprAt.set(chunk.startOffset + e.end, { x: b.cursorX, y: b.cursorY, alt: b.type === 'alternate' });
            if (this.cprAt.size > 64) this.cprAt.delete(/** @type {number} */ (this.cprAt.keys().next().value));
          }
          continue;
        }
        if (e.kind === 'row') {
          const d = Math.max(0, this.rows - /** @type {number} */ (e.renderRows));
          parts.push(d ? rewriteRow(e, /** @type {number} */ (e.row) + d) : e.raw);
          continue;
        }
        if (e.kind === 'decsc' || (e.kind === 'alt-enter' && (e.modes || []).includes(1049))) {
          // ?1049h and ESC 7 save the cursor of the buffer active BEFORE the token: parse up to it, then record
          await flush();
          const b = this.term.buffer.active;
          this.saved[b.type === 'alternate' ? 'alternate' : 'normal'] = { x: b.cursorX, y: b.baseY + b.cursorY };
        }
        parts.push(e.raw);                                    // alt-exit, title, clipboard and the rest: unchanged
      }
      parts.push(chunk.bytes.subarray(pos));
    }
    await flush();
  }

  /** The active buffer's scroll margins, 0-based and inclusive. xterm has no public way to read them. */
  margins() {
    const b = /** @type {any} */ (this.term)._core.buffer;
    return { top: b.scrollTop, bottom: b.scrollBottom };
  }

  /** Rows of the buffer below which the PTY screen starts. @param {number} screenRows */
  _above(screenRows) { return this.tracking ? 0 : this.rows - screenRows; }

  /**
   * Scrollback and screen as text, whole lines however they wrapped; the active screen stands in for the normal one
   * while a program is on the alternate screen.
   * @param {{lines?: number|null, ansi?: boolean}} [o] @returns {string}
   */
  capture({ lines = null, ansi = false } = {}) {
    const { normal, active } = this.term.buffer;
    const history = logicalLines(normal, firstWrittenLine(normal, normal.baseY), normal.baseY, { ansi });
    const screen = logicalLines(active, active.type === 'alternate' ? 0 : active.baseY, (active.type === 'alternate' ? 0 : active.baseY) + this.rows, { ansi });
    while (screen.length && screen[screen.length - 1] === '') screen.pop();
    const all = [...history, ...screen];
    const wanted = lines === null ? all : all.slice(-lines);
    return wanted.length ? `${wanted.join('\n')}\n` : '';
  }

  /** Text of the PTY screen: the bottom `screenRows` rows of the viewport (top rows when alt is active). */
  screenText(screenRows) {
    const b = this.term.buffer.active;
    const first = b.type === 'alternate' ? 0 : b.baseY + this._above(screenRows);
    const lines = [];
    const count = this.tracking ? this.rows : screenRows;
    for (let i = first; i < first + count; i++) { const l = b.getLine(i); lines.push(l ? l.translateToString(true) : ''); }
    return lines.join('\n');
  }

  /**
   * The cursor position report the PTY would get: at the query's end offset when given and recorded, else now.
   * @param {number} screenRows @param {{decx?: boolean, offset?: number}} [o] @returns {Buffer}
   */
  cpr(screenRows, { decx = false, offset } = {}) {
    let pos = offset !== undefined ? this.cprAt.get(offset) : undefined;
    if (offset !== undefined) this.cprAt.delete(offset);
    if (!pos) { const b = this.term.buffer.active; pos = { x: b.cursorX, y: b.cursorY, alt: b.type === 'alternate' }; }
    const row = pos.alt ? pos.y + 1 : pos.y - this._above(screenRows) + 1;
    return Buffer.from(`\x1b[${decx ? '?' : ''}${Math.max(1, row)};${pos.x + 1}R`);
  }
}

module.exports = { Emulator };
