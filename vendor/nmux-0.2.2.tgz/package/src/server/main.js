'use strict';
// @ts-check
const fs = require('node:fs');
const { spawn } = require('node:child_process');
const { ensureRuntime } = require('../platform/runtime');
const { createLogger } = require('../base/log');
const { writeAtomic } = require('../base/atomic');
const { tryLock } = require('../platform/locks');
const { realClock } = require('../base/clock');
const procinfo = require('../platform/procinfo');
const { sessionLayout } = require('../wire/layout');
const { connectHolder } = require('./session/holderclient');
const { Session } = require('./session/session');
const { Controller } = require('./session/controller');
const { ClientHub } = require('./clients/hub');
const { Arbiter } = require('./clients/arbiter');
const { ControlServer } = require('./control/control');
const { InputRouter } = require('./input/input');
const { DEFAULT_MESSAGES } = require('./messages');
const { DEFAULTS } = require('./config');

const HOLDER_MAIN = require.resolve('../holder/main.js');
const FIRST_CLIENT_WAIT_MS = 5000;
const CONTROLLER_WAIT_MS = 1000;
const CONTROLLER_MAX_WAIT_MS = 60000;
const LAST_JOIN_WAIT_MS = 1000;
const LAST_RECORD_WAIT_MS = 2000;

/**
 * @typedef {{spec: import('./session/session').SessionSpec & {runtimeDir: string, holderEnv?: Record<string, string>},
 *   config?: any, messages?: import('./messages').Messages, recover?: boolean, sessiondArgv?: string[],
 *   clock?: import('../base/types').Clock, timers?: object, holderTimers?: object, stateWriter?: (file: string, st: object) => (void|Promise<void>),
 *   initialState?: object|null, controller?: (log: any) => Controller, waitForClient?: boolean, firstClientWaitMs?: number}} StartOptions
 */

/**
 * Keeps a managed session's controller alive, with nothing else having to: if none is connected, it is started. It is one
 * process for many sessions, so one that is already running simply finds this session and connects; a second one exits.
 * @param {{controller: any, spec: any, clock: import('../base/types').Clock, log: any}} o @returns {() => void} stops watching
 */
function watchController({ controller, spec, clock, log }) {
  const command = spec.managed && spec.managed.command;
  if (!command) return () => {};
  let waitMs = CONTROLLER_WAIT_MS;
  /** @type {any} */
  let timer = null;
  const check = () => {
    if (controller.connected) waitMs = CONTROLLER_WAIT_MS;
    else {
      try {
        const child = spawn(command.argv[0], command.argv.slice(1), { detached: true, stdio: 'ignore', cwd: '/', env: { ...process.env, ...command.env } });
        child.on('error', (e) => log.warn('controller.spawn_failed', { error: e.message }));
        child.unref();
      } catch (e) { log.warn('controller.spawn_failed', { error: String(/** @type {Error} */ (e).message) }); }
      waitMs = Math.min(waitMs * 2, CONTROLLER_MAX_WAIT_MS);
    }
    timer = clock.setTimeout(check, waitMs);
  };
  timer = clock.setTimeout(check, CONTROLLER_WAIT_MS);
  return () => clock.clearTimeout(timer);
}

/**
 * Builds and starts one session: ctl.sock, session (holder + child), clients, arbiter, input router. Resolves once the
 * holder is connected; `done` resolves when the session stopped.
 *   sessiondArgv: the argv that started this server (default process.argv); with any --recover removed and --recover
 *   appended it becomes the holder's sessiondCmd.
 *   timers/holderTimers shorten internal timers in tests only.
 *   initialState: the persisted record for this session, if any.
 *   controller: builds what this session's program adds to it; a plain session without one.
 *   waitForClient: a terminal is about to attach, so the program starts when it arrives, or after firstClientWaitMs.
 * @param {StartOptions} o
 */
async function startSession({ spec, config = DEFAULTS, messages = DEFAULT_MESSAGES, recover = false, sessiondArgv = [process.execPath, ...process.argv.slice(1)], clock = realClock, timers = {}, holderTimers, stateWriter, initialState, controller: makeController = () => new Controller(), waitForClient = false, firstClientWaitMs = FIRST_CLIENT_WAIT_MS }) {
  const layout = sessionLayout(spec.runtimeDir);
  ensureRuntime(layout);
  fs.mkdirSync(layout.sessionDir(spec.id), { recursive: true, mode: 0o700 });
  const log = createLogger({ file: layout.logFile(spec.id, 'sessiond'), comp: 'sessiond', session: spec.id });
  const lock = tryLock(layout.sessiondLock(spec.id));
  if (!lock) throw Object.assign(new Error(`a sessiond already runs for ${spec.id}`), { code: 'SESSIOND_LOCKED' });
  // Biases the OOM killer away from this process where the concept exists.
  if (procinfo.oomScoreAdjPath) { try { fs.writeFileSync(procinfo.oomScoreAdjPath, '300'); } catch { /* raising it needs no privilege; ignore if refused */ } }
  /** the holder re-runs exactly this after the server dies */
  const sessiondCmd = [...sessiondArgv.filter((a) => a !== '--recover'), '--recover'];

  const startHolder = async (/** @type {{gen: number, argv: string[], cols: number, rows: number}} */ { gen, argv, cols, rows }) => {
    const file = layout.holderSpec(spec.id, gen);
    writeAtomic(file, { schema: 'nmux.holderspec/1', id: spec.id, argv, env: spec.child.env, cwd: spec.child.cwd, cols, rows,
      ringBytes: config.holder.ringBytes, sessiondCmd, gen, runtimeDir: spec.runtimeDir, termColors: spec.termColors || null, term: spec.term,
      ...(holderTimers ? { timers: holderTimers } : {}) });
    const child = spawn(process.execPath, [HOLDER_MAIN, '--spec', file], { detached: true, stdio: 'ignore', cwd: '/', env: { ...process.env, ...spec.holderEnv } });
    child.on('error', (e) => log.error('holder.spawn_failed', { error: e.message }));
    child.unref();
    log.info('holder.spawn', { gen, pid: child.pid });
  };

  /** @type {ClientHub|null} */
  let registryRef = null;
  const controller = makeController(log);
  const session = new Session({ spec, config, clock, log, layout, controller, messages, recover, startHolder, timers, ...(stateWriter ? { stateWriter } : {}), ...(initialState ? { initialState } : {}),
    connectHolder: (sockPath) => connectHolder(sockPath), clientsInfo: () => (registryRef ? registryRef.info() : []) });
  const registry = new ClientHub({ config, clock, log, session, messages });
  registryRef = registry;
  const arbiter = new Arbiter({ config, clock, clients: () => registry.adapters(), pty: () => session.pty,
    apply: (cols, rows) => {
      session.resize(cols, rows);
      const narrowest = registry.clients.filter((c) => !c.adapter.stalled && c.adapter.phase !== 'PAUSED').sort((a, b) => a.adapter.cols - b.adapter.cols)[0];
      registry.noticeAll('info', 'SIZE', `${cols}x${rows}${narrowest ? ` — limited by ${narrowest.label}` : ''}`);
      arbiter.onChange('applied');
    } });
  const router = new InputRouter({ config, clock, messages,
    policy: { forwardFocus: () => session.tracker.modes.raw(1004) === 1, ...controller.inputPolicy() },
    holder: { write: (bytes, opts) => session.write(bytes, opts) }, writtenTotal: () => session.writes.total,
    gates: () => session.gates(),
    onDetachRequest: (c) => registry.bye(c, 'USER', false, ''),
    notice: (client, level, code, text) => { if (client) client.adapter.notice(level, code, text); else registry.noticeAll(level, code, text); } });
  registry.router = router;
  registry.arbiter = arbiter;
  session.on('holderErr', (m) => { if (m.code === 'WRITE_OVERFLOW') router.onWriteOverflow(); if (m.code === 'ESC_HOLD_EXPIRED') router.onEscHoldExpired(); });
  const control = new ControlServer({ sockPath: layout.ctlSock(spec.id), config, clock, log, id: spec.id, nestEnv: spec.nestEnv || null, registry, session, messages });
  await control.listen();
  const stopWatching = watchController({ controller, spec, clock, log });

  /** @type {() => void} */
  let finished = () => {};
  const done = new Promise((resolve) => { finished = () => resolve(undefined); });
  let ended = false;
  const end = () => {
    if (ended) return;
    ended = true;
    stopWatching();
    arbiter.dispose();
    router.dispose();
    control.close();
    session.dispose();
    lock.release();
    log.info('sessiond.exit', { lifecycle: session.lifecycle });
    finished();
  };
  session.on('stopped', () => {
    const e = session.lastExit;
    registry.joinsDone(LAST_JOIN_WAIT_MS).then(() => {
      if (e && e.cause === 'host-shutdown') registry.byeAll('HOST_SHUTDOWN', false, messages.hostShutdown);
      else if (session.machine.stopRequested || !e) registry.byeAll('SESSION_ENDING', false, messages.sessionStopped(session.name));
      else registry.byeAll('SESSION_ENDING', false, '', { ended: e.signal || e.code });
      return /** @type {any} */ (controller).finish ? /** @type {any} */ (controller).finish(LAST_RECORD_WAIT_MS) : undefined;
    }).then(() => setTimeout(end, 100));
  });
  try {
    // A program that is being watched from the start must not finish before anyone arrives to see it.
    if (waitForClient && !recover) await Promise.race([registry.whenClient(firstClientWaitMs), new Promise((r) => { session.once('stopped', r); })]);
    if (session.lifecycle !== 'STOPPED') await session.start();
  } catch (e) {
    log.error('start.failed', { error: String(/** @type {Error} */ (e).message) });
    end();
    throw e;
  }
  log.info('sessiond.started', { recover, gen: session.gen });

  return {
    spec, layout, config, log, session, registry, arbiter, router, control, done,
    /** Leaves the child and the holder running; clients get BYE{autoRejoin} and the holder respawns the server. */
    async shutdown() {
      registry.byeAll('SESSION_ENDING', true, messages.restarting);
      await new Promise((r) => setTimeout(r, 50));
      session.detach();
      end();
    },
  };
}

/**
 * startSession as the body of a process. SIGHUP is ignored (a closed controlling terminal must never end a session) and
 * SIGTERM sends BYE{SESSION_ENDING, autoRejoin} and exits 0, leaving the child to the holder, which respawns the server.
 * @param {StartOptions} o @returns {Promise<import('./session/session').Session>} resolves when the session stopped
 */
async function runSession(o) {
  process.on('SIGHUP', () => {});
  const s = await startSession(o);
  process.on('SIGTERM', () => { s.shutdown().then(() => process.exit(0)); });
  await s.done;
  return s.session;
}

module.exports = { runSession, startSession };
