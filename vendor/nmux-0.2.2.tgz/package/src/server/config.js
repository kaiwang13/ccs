'use strict';
// @ts-check
const fs = require('node:fs');

/** What the server needs to know, with its defaults. An embedding program merges its own values over these. */
const DEFAULTS = Object.freeze({
  size: Object.freeze({
    floorCols: 2, hardMinCols: 2, floorRows: 1, maxCols: 500, maxRows: 500, defaultCols: 120, defaultRows: 40,
    shrinkDebounceMs: 50, shrinkMaxWaitMs: 200, growDebounceMs: 50, growMinCols: 1, growMinRows: 1,
    joinRepaintWaitMs: 400, growResetCheckMs: 300,
  }),
  snapshot: Object.freeze({ scrollback: 10000, joinHistory: 'all', snapshotTimeoutMs: 30000, chunkBytes: 65536 }),
  clients: Object.freeze({
    pingMs: 5000, stallMs: 20000, dropMs: Infinity, queueCapBytes: 1048576,
    rejoinMax: 3, rejoinWindowMs: 300000, osc52: 'last-typist', dsrProbe: true,
  }),
  input: Object.freeze({ escFlushMs: 40, escHoldMs: 60, escHoldMaxMs: 1500, crossClientEscMs: 800, answerCollisionMs: 1000, pasteIdleCloseMs: 1500 }),
  stop: Object.freeze({ hangupWaitMs: 30000, termWaitMs: 60000 }),
  holder: Object.freeze({ ringBytes: 8388608 }),
  notices: Object.freeze({ bellOnAttention: true }),
  stream: Object.freeze({ repaint: false }),
  keys: Object.freeze({ leader: 'C-\\', bindings: Object.freeze({ d: 'detach', c: 'clients', '?': 'help' }), direct: Object.freeze({}) }),
});

/**
 * The user's config file over the defaults, one section at a time. A missing file is the normal case, and a broken one
 * must never stop a session from starting.
 * @param {string|undefined|null} file @returns {typeof DEFAULTS}
 */
function loadConfig(file) {
  /** @type {any} */
  let user = {};
  try { user = JSON.parse(fs.readFileSync(/** @type {string} */ (file), 'utf8')); } catch { return DEFAULTS; }
  /** @type {any} */
  const out = {};
  for (const [section, values] of Object.entries(DEFAULTS)) out[section] = { ...values, ...(user && user[section]) };
  return out;
}

module.exports = { DEFAULTS, loadConfig };
