'use strict';
// @ts-check
/**
 * Everything the attach client prints, in one table. An embedding program replaces entries to speak in its own name.
 * @typedef {{
 *   brand: string, nestEnv: string, insideMultiplexer: string,
 *   refuseNested: (id: string) => string,
 *   detachLine: (a: {kind: 'detached'|'client-exit'|'kicked'|'ended'|'lost'|'gave-up', name: string, others: number, at: Date, reason?: string}) => string,
 *   floorMessage: (a: {code: string, cols: number, rows: number, need: {cols?: number, rows?: number}, name: string, shrink: boolean, hardMinCols: number}) => string,
 *   help: (a: {name: string, keys: {leader?: string|null, bindings?: Record<string, string>}}) => string[],
 *   whoIsAttached: (a: {name: string, clients: Array<{id: string, label: string, cols: number, rows: number, view?: boolean}>}) => string[],
 * }} ClientText
 */

/** @param {Date} d */
function hhmm(d) { return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; }

/** @type {Record<string, string>} */
const ACTION_TEXT = { detach: 'detach', clients: 'who is attached', help: 'this help' };

/** `C-\\` as a person writes it. @param {string} key */
const spoken = (key) => (key.startsWith('C-') ? `Ctrl+${key.slice(2)}` : key);

/** @type {ClientText} */
const DEFAULT_TEXT = Object.freeze({
  brand: 'nmux',
  nestEnv: 'NMUX_ID',
  insideMultiplexer: 'nmux: warning: running inside tmux/screen — its own scrollback handling may hide history\n',
  refuseNested: (id) => `nmux: refusing to attach from inside a session (NMUX_ID=${id}) — that would nest one session inside another; detach first`,
  detachLine({ kind, name, others, at, reason }) {
    const t = hhmm(at);
    /** @type {Record<string, string>} */
    const line = {
      detached: `── nmux · detached from ${name} ${t} · still running${others > 0 ? ` (${others} other client${others === 1 ? '' : 's'})` : ''} · nmux a ${name} ──`,
      kicked: `── nmux · detached from ${name} ${t}${reason ? ` by ${reason}` : ''} · still running · nmux a ${name} ──`,
      'client-exit': `── nmux · detached from ${name} ${t} · the session keeps running ──`,
      ended: `── nmux · ${name} ended ${t}${reason ? ` (${reason})` : ''} ──`,
      'gave-up': `── nmux · disconnected from ${name} ${t}${reason ? ` · ${reason}` : ''} ──`,
      lost: `── nmux · lost connection to ${name} ${t} ──`,
    };
    return `\x1b[2m${line[kind]}\x1b[0m\r\n`;
  },
  floorMessage({ code, cols, rows, need }) {
    const what = code === 'TOO_SHORT' ? `${need.rows}-row` : `${need.cols}-column`;
    return `nmux: this terminal is ${cols}x${rows} — below the ${what} floor for shared sessions\r\n     resize it (I will attach automatically)\r\n     (Ctrl+C gives up)\r\n`;
  },
  help({ name, keys }) {
    const leader = spoken(keys.leader || '');
    const actions = Object.entries(keys.bindings || {}).map(([k, a]) => `  ${leader} ${spoken(k).padEnd(8)}${ACTION_TEXT[a] || a}`);
    return [`nmux · ${name}`, '', ...actions, `  ${leader} ${leader.padEnd(8)}send a literal ${leader}`, '', 'Any key to go back.'];
  },
  whoIsAttached({ name, clients }) {
    return [`nmux · ${name}`, '', ...clients.map((c) => `  ${c.id.padEnd(5)}${c.label}  ${c.cols}x${c.rows}${c.view ? '  view only' : ''}`), '', 'Any key to go back.'];
  },
});

module.exports = { DEFAULT_TEXT, hhmm };
