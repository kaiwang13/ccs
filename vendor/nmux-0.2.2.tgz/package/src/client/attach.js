'use strict';
// @ts-check
/**
 * Attach client.
 *
 * Byte transparency: OUTPUT frames are written to the terminal unchanged. Node's raw mode (libuv
 * UV_TTY_MODE_RAW) keeps OPOST|ONLCR on, so a bare LF would become CRLF — harmless here, because every
 * byte the child writes already passed ONLCR on the holder's pty (an existing CRLF becomes CR CR LF, which
 * renders identically).
 *
 * Native scrollback is the product. This client therefore NEVER writes RIS (ESC c), ED2 (CSI 2J),
 * ED3 (CSI 3J) or ED0 (CSI J): each of those wipes or truncates the user's history in some terminal. The
 * detach teardown only resets modes, moves to the last row and prints one dim line.
 *
 * Keys go through the KeyTable first, so a detach works even while the host is hung; everything else is sent as
 * INPUT and filtered authoritatively by the server.
 *
 * Overlays (help, who is attached) live on the alternate screen, so leaving one restores the main screen exactly and
 * nothing can reach scrollback. Output arriving meanwhile is held. If there is too much of it, or the session is on the
 * alternate screen itself so the overlay has drawn over it, the server redraws instead, and whatever was already on the
 * way is ignored until it starts: RESYNC_BEGIN marks the place in the stream.
 */
const { InputTokenizer } = require('../vt/inputtok.js');
const { realClock } = require('../base/clock.js');
const { nameOfState } = require('../wire/holder-wire.js');
const platform = require('../platform/index.js');
const { KeyTable } = require('./keytable.js');
const { ReconnectPolicy, RejoinPolicy } = require('./reconnect.js');
const { SessionLink } = require('./link.js');
const { TerminalDriver, KittyTracker, detachBytes, parseCpr } = require('./terminal.js');
const { DEFAULT_TEXT, hhmm } = require('./text.js');

const SILENCE_MS = 15000;
const SILENCE_CHECK_MS = 1000;
const PENDING_INPUT_CAP = 65536;
const OVERLAY_HOLD_CAP = 1048576;
const REDRAW_WAIT_MS = 3000;
/** XTWINOPS: the terminal's title stack. A terminal without one ignores both. */
const TITLE_SAVE = '\x1b[22;2t';
const TITLE_RESTORE = '\x1b[23;2t';

/** @param {Record<string, string|undefined>} env @param {string|null} ttyPath */
function labelFor(env, ttyPath) {
  const m = /^\/dev\/(pts\/\d+)$/.exec(ttyPath || '');
  const short = m ? m[1] : (ttyPath ? ttyPath.replace(/^\/dev\//, '') : 'tty');
  return `${env.TERM_PROGRAM === 'vscode' ? 'vscode' : 'ssh'} ${short}`;
}

/** Refusal conditions checked before anything else. @param {{stdin: any, stdout: any, env: Record<string, string|undefined>}} io
 *  @param {import('./text.js').ClientText} [text]
 *  @returns {{code: number, message: string}|null} */
function attachPrecheck({ stdin, stdout, env }, text = DEFAULT_TEXT) {
  if (!stdin.isTTY || !stdout.isTTY) return { code: 2, message: `${text.brand}: attach needs an interactive terminal (stdin and stdout must both be a TTY)` };
  const nested = env[text.nestEnv];
  if (nested) return { code: 2, message: text.refuseNested(nested) };
  return null;
}

class AttachClient {
  /** @param {{sockPath: string, name: string, flags: {shrink?: boolean, allowSetup?: boolean, view?: boolean}, io: {stdin: any, stdout: any, stderr: any, env: Record<string, string|undefined>}, config: any, text?: import('./text.js').ClientText, keys?: import('./keytable.js').KeySpec}} o */
  constructor({ sockPath, name, flags, io, config, text = DEFAULT_TEXT, keys = {} }) {
    this.name = name; this.flags = flags; this.io = io; this.config = config; this.text = text;
    this.phase = 'init'; // init | measuring | connecting | joining | live | refused | reconnecting | done
    /** @type {Buffer[]} */ this.pendingInput = [];
    this.pendingBytes = 0;
    this.others = 0;
    this.joinedOnce = false;
    /** @type {any[]} */ this.notices = [];
    this.rejoin = new RejoinPolicy({ max: config.clients.rejoinMax, windowMs: config.clients.rejoinWindowMs });
    this.reconnect = new ReconnectPolicy();
    this.keySpec = keys;
    this.keys = new KeyTable(keys);
    /** @type {any[]} */ this.attached = [];
    /** @type {null|{held: Buffer[], bytes: number, overAlt: boolean, skipped: number}} */ this.overlay = null;
    this.awaitingRedraw = false;
    this.tokenizer = new InputTokenizer({ clock: realClock, escFlushMs: config.input.escFlushMs, pasteIdleCloseMs: config.input.pasteIdleCloseMs, onTimerTokens: (toks) => this.onTokens(toks) });
    this.link = new SessionLink({ sockPath, onControl: (msg) => this.onControl(msg), onOutput: (b) => this.onOutput(b), onLost: () => this.onSocketLost() });
    this.terminal = new TerminalDriver({ io, onBytes: (b) => this.onTokens(this.tokenizer.feed(b)),
      onEnd: () => this.detach('detached'), onWinch: () => this.onResize(), onHangup: () => this.detach('detached') });
    /** @type {any} */ this.reconnectTimer = null;
    /** @type {any} */ this.redrawTimer = null;
    /** @type {any} */ this.silenceTimer = null;
    this.silenceMs = SILENCE_MS;
    this.lastSilenceCheck = realClock.now();
    this.lastRefusedSize = '';
    this.titleSaved = false;
    /** @type {(code: number) => void} */ this.resolveExit = () => {};
  }

  /** @returns {Promise<number>} */
  run() {
    return new Promise((resolve) => {
      this.resolveExit = resolve;
      const { env } = this.io;
      if (env.TMUX || env.STY) this.io.stderr.write(this.text.insideMultiplexer);
      this.terminal.open();
      this.silenceTimer = setInterval(() => this.checkSilence(), SILENCE_CHECK_MS);
      this.phase = 'measuring';
      this.terminal.measureCursor().then((row) => this.connect(row));
    });
  }

  /** Local detach check, then forward. @param {Array<{kind: string, bytes: Buffer, seq: string}>} toks */
  onTokens(toks) {
    if (this.phase === 'done') return;
    if (this.overlay) { if (toks.length) this.closeOverlay(); return; }
    /** @type {Buffer[]} */
    const forward = [];
    for (const tok of toks) {
      if (this.phase === 'refused' && this.keys.isInterrupt(tok)) {
        this.finish(1, 'gave-up', 'gave up waiting for a larger terminal');
        return;
      }
      const action = this.keys.actionFor(tok);
      if (action === 'ignore') continue;
      if (action === null || action === 'literal') { forward.push(tok.bytes); continue; }
      if (forward.length) this.sendInput(Buffer.concat(forward));
      forward.length = 0;
      this.keyAction(action);
      if (this.phase === 'done' || this.overlay) return;
    }
    if (forward.length) this.sendInput(Buffer.concat(forward));
  }

  /** @param {string} action */
  keyAction(action) {
    if (action === 'detach') this.detach('detached');
    else if (action === 'help') this.openOverlay(this.text.help({ name: this.name, keys: this.keySpec }));
    else if (action === 'clients') this.openOverlay(this.text.whoIsAttached({ name: this.name, clients: this.attached }));
  }

  /** @param {string[]} lines */
  openOverlay(lines) {
    if (this.phase !== 'live') return;
    this.overlay = { held: [], bytes: 0, overAlt: this.terminal.alt, skipped: 0 };
    this.terminal.write(`\x1b[?1049h\x1b[H\x1b[2J${lines.join('\r\n')}`);
  }

  closeOverlay() {
    const o = this.overlay;
    this.overlay = null;
    if (!o) return;
    this.terminal.leaveOverlay();
    if (!o.overAlt && o.skipped === 0) { for (const b of o.held) this.terminal.output(b); return; }
    this.awaitingRedraw = true;
    this.redrawTimer = setTimeout(() => this.redrawArrived(), REDRAW_WAIT_MS);         // a server that never answers must not silence this terminal
    this.link.sendControl({ t: 'RESYNC', alt: false, skipped: o.skipped });
  }

  redrawArrived() {
    this.awaitingRedraw = false;
    clearTimeout(this.redrawTimer);
  }

  restoreTitle() {
    if (this.titleSaved) { this.titleSaved = false; this.terminal.write(TITLE_RESTORE); }
  }

  /** @param {Buffer} bytes */
  onOutput(bytes) {
    if (this.awaitingRedraw) return;
    const o = this.overlay;
    if (!o) { this.terminal.output(bytes); return; }
    if (o.overAlt) return;                                                             // redrawn on the way out
    o.bytes += bytes.length;
    if (o.bytes <= OVERLAY_HOLD_CAP) { o.held.push(bytes); return; }
    o.held = [];
    o.skipped = o.bytes;
  }

  /** @param {Buffer} bytes */
  sendInput(bytes) {
    if (this.phase === 'live' && this.link.connected) this.link.sendInput(bytes);
    else if ((this.phase === 'measuring' || this.phase === 'connecting' || this.phase === 'joining') && this.pendingBytes + bytes.length <= PENDING_INPUT_CAP) {
      this.pendingInput.push(bytes); // typed while a join is on its way: delivered after SNAPSHOT_END
      this.pendingBytes += bytes.length;
    }
    // while disconnected or refused, input is dropped: never replay a stale draft into a fresh join
  }

  /** @param {number|null} cursorRow */
  connect(cursorRow) {
    if (this.phase === 'done') return;
    this.phase = 'connecting';
    const { env } = this.io;
    let tty = null;
    try { tty = platform.selfTty(); } catch { /* no controlling terminal */ }
    this.link.connect(() => ({
      cols: this.terminal.cols, rows: this.terminal.rows, cursorRow: cursorRow === null ? this.terminal.rows : cursorRow, focus: true, tty, pid: process.pid,
      label: labelFor(env, tty), termProgram: env.TERM_PROGRAM || null,
      flags: { shrink: !!this.flags.shrink, allowGated: !!this.flags.allowSetup, allowSetup: !!this.flags.allowSetup, view: !!this.flags.view },
    }));
  }

  /** @param {any} msg */
  onControl(msg) {
    switch (msg.t) {
      case 'WELCOME':
        this.phase = 'joining';
        if (msg.name) this.name = msg.name;
        // host silence limit: never shorter than 3 host ping intervals (clients.pingMs is configurable up to 60 s)
        this.silenceMs = Math.max(SILENCE_MS, 3 * ((msg.ping && msg.ping.intervalMs) || 0));
        break;
      case 'REFUSE':
        if (msg.code === 'BELOW_FLOOR' || msg.code === 'TOO_SHORT') this.onRefusedSize(msg.code, msg.need || {});
        else this.finish(1, 'gave-up', msg.text || `refused: ${msg.code}`);
        break;
      case 'RESYNC_BEGIN':
        this.redrawArrived();
        break;
      case 'SNAPSHOT_BEGIN':
        this.phase = 'joining';
        this.redrawArrived();
        this.joinedOnce = true;
        this.restoreTitle();                                                          // before the join: it may set a newer one
        break;
      case 'SNAPSHOT_END':
        this.phase = 'live';
        this.reconnect.reset();
        this.rejoin.onSnapshotEnd();
        if (this.pendingInput.length) this.link.sendInput(Buffer.concat(this.pendingInput));
        this.pendingInput = [];
        this.pendingBytes = 0;
        break;
      case 'STATE': {
        if (Array.isArray(msg.clients)) { this.attached = msg.clients; this.others = Math.max(0, msg.clients.length - 1); }
        const name = nameOfState(msg);
        if (name) this.name = name;
        break;
      }
      case 'NOTICE':
        if (this.notices.length < 50) this.notices.push(msg);
        break;
      case 'PING':
        this.link.sendControl({ t: 'PONG', seq: msg.seq });
        break;
      case 'BYE':
        this.onBye(msg);
        break;
      case 'ERR':
        this.finish(1, 'gave-up', `host error ${msg.code || ''}`.trim());
        break;
      default:
        break; // unknown control types are ignored for forward compatibility
    }
  }

  /** @param {any} msg */
  onBye(msg) {
    const reason = String(msg.reason || '');
    this.link.drop();
    if (reason === 'CLIENT_EXIT') { this.finish(0, 'client-exit', null, msg.text || null); return; }
    if (reason === 'KICKED') { this.finish(0, 'kicked', typeof msg.by === 'string' && msg.by ? msg.by : null); return; }
    if (reason === 'BELOW_FLOOR') {
      this.restoreModes();
      this.onRefusedSize('BELOW_FLOOR', msg.need || { cols: this.config.size.floorCols, rows: this.config.size.floorRows });
      return;
    }
    if (reason === 'OVERFLOW') {
      if (this.rejoin.allowOverflow()) { this.scheduleReconnect(true); return; }
      this.finish(1, 'gave-up', `this terminal fell behind ${this.rejoin.max} times in ${Math.round(this.rejoin.windowMs / 60000)} minutes`);
      return;
    }
    if (reason === 'SNAPSHOT_TIMEOUT') {
      if (this.rejoin.allowSnapshotTimeout()) { this.scheduleReconnect(true); return; }
      this.finish(1, 'gave-up', `the join snapshot timed out ${this.rejoin.snapshotTimeoutMax} times in a row`);
      return;
    }
    if (msg.autoRejoin) { this.scheduleReconnect(false); return; }
    if ('ended' in msg) { this.finish(0, 'ended', msg.ended === 0 ? null : (typeof msg.ended === 'number' ? `exit ${msg.ended}` : msg.ended), msg.text || null); return; }
    this.finish(0, 'ended', reason ? reason.toLowerCase().replace(/_/g, ' ') : null, msg.text || null);
  }

  /** @param {string} code @param {{cols?: number, rows?: number}} need */
  onRefusedSize(code, need) {
    this.link.drop();
    this.phase = 'refused';
    this.restoreTitle();
    if (this.joinedOnce) { this.pendingInput = []; this.pendingBytes = 0; }           // it may be a long time before this joins
    const { cols, rows } = this.terminal;
    const size = `${cols}x${rows}`;
    if (!this.lastRefusedSize) {
      this.terminal.write(this.text.floorMessage({ code, cols, rows, need: { cols: need.cols || this.config.size.floorCols, rows: need.rows || this.config.size.floorRows }, name: this.name, shrink: !!this.flags.shrink, hardMinCols: this.config.size.hardMinCols }));
    } else if (size !== this.lastRefusedSize) {
      this.terminal.write(`${this.text.brand}: now ${size} — still too small; waiting\r\n`);
    }
    this.lastRefusedSize = size;
  }

  onResize() {
    if (this.phase === 'refused') { this.connect(this.terminal.rows); return; }
    if (this.phase === 'joining' || this.phase === 'live') this.link.sendControl({ t: 'RESIZE', cols: this.terminal.cols, rows: this.terminal.rows });
  }

  onSocketLost() {
    if (this.phase === 'done' || this.phase === 'refused') return;
    this.scheduleReconnect(false);
  }

  /** @param {boolean} immediate */
  scheduleReconnect(immediate) {
    if (this.phase === 'done') return;
    const delay = this.reconnect.next(immediate);
    if (delay === null) { this.finish(1, 'lost', null); return; }
    if (this.joinedOnce) { this.pendingInput = []; this.pendingBytes = 0; }           // typed into a connection that did not last
    if (this.overlay) { this.overlay = null; this.terminal.leaveOverlay(); }           // the join redraws everything
    this.phase = 'reconnecting';
    if (!this.titleSaved) { this.titleSaved = true; this.terminal.write(TITLE_SAVE); }
    this.terminal.write(`\x1b]0;${this.text.brand}: reconnecting…\x07`);
    clearTimeout(this.reconnectTimer);
    // A rejoin pushes the whole visible screen into scrollback (cursorRow = rows) before the snapshot.
    this.reconnectTimer = setTimeout(() => this.connect(this.terminal.rows), delay);
  }

  checkSilence() {
    const now = realClock.now();
    const late = now - this.lastSilenceCheck > 3 * SILENCE_CHECK_MS;
    this.lastSilenceCheck = now;
    if (late) { this.link.heard(); return; }                                        // this process was the one not running
    if (this.link.connected && (this.phase === 'joining' || this.phase === 'live') && this.link.silentMs > this.silenceMs) {
      this.link.drop();
      this.scheduleReconnect(false);
    }
  }

  restoreModes() { if (this.joinedOnce) this.terminal.restore(); }

  /** User-initiated detach (key, SIGHUP, SIGTERM, stdin EOF). @param {'detached'} kind */
  detach(kind) {
    if (this.phase === 'done') return;
    try { this.link.sendControl({ t: 'DETACH' }); } catch { /* ignore */ }
    this.finish(0, kind, null);
  }

  /**
   * @param {number} code
   * @param {'detached'|'client-exit'|'kicked'|'ended'|'lost'|'gave-up'} kind
   * @param {string|null} reason
   * @param {string|null} [text]
   */
  finish(code, kind, reason, text = null) {
    if (this.phase === 'done') return;
    const wasRefused = this.phase === 'refused';
    this.phase = 'done';
    if (this.overlay) { this.overlay = null; this.terminal.leaveOverlay(); }
    this.restoreTitle();
    clearTimeout(this.reconnectTimer);
    clearInterval(this.silenceTimer);
    this.redrawArrived();
    this.terminal.finishMeasure(null);
    this.link.drop();
    if (this.joinedOnce && !wasRefused) this.restoreModes();
    else this.terminal.write('\r\n');
    this.terminal.write(this.text.detachLine({ kind, name: this.name, others: this.others, at: new Date(), reason: reason || undefined }));
    if (text) this.terminal.write(`${String(text).replace(/\r?\n/g, '\r\n')}\r\n`);
    let lastCode = '';
    for (const n of this.notices) {
      if (n.code === lastCode) continue;
      lastCode = n.code;
      this.terminal.write(`${this.text.brand}: ${n.level === 'warn' ? 'warning' : 'note'} ${n.code}: ${n.text}\r\n`);
    }
    this.terminal.close();
    this.tokenizer.close();
    this.resolveExit(code);
  }
}

/**
 * @param {{sockPath: string, name: string, config: any, flags?: {shrink?: boolean, allowSetup?: boolean, view?: boolean}, text?: import('./text.js').ClientText,
 *          keys?: import('./keytable.js').KeySpec, io?: {stdin?: any, stdout?: any, stderr?: any, env?: Record<string, string|undefined>}}} a
 * @returns {Promise<number>}
 */
async function attach({ sockPath, name, config, flags = {}, text = DEFAULT_TEXT, keys = {}, io = {} }) {
  const full = { stdin: io.stdin || process.stdin, stdout: io.stdout || process.stdout, stderr: io.stderr || process.stderr, env: io.env || process.env };
  const refused = attachPrecheck(full, text);
  if (refused) { full.stderr.write(`${refused.message}\n`); return refused.code; }
  return new AttachClient({ sockPath, name, flags, io: full, config, text, keys }).run();
}

module.exports = { attach, attachPrecheck, labelFor, parseCpr, detachBytes, hhmm, KittyTracker, RejoinPolicy, AttachClient, DEFAULT_TEXT };
