'use strict';
// @ts-check
const MEASURE_TIMEOUT_MS = 300;
const ALT_MODES = ['47', '1047', '1049'];

/** Find a cursor position report `CSI row ; col R` in latin1 text. @param {string} text */
function parseCpr(text) {
  const m = /\x1b\[(\d+);(\d+)R/.exec(text);
  return m ? { row: Number(m[1]), col: Number(m[2]), index: m.index, length: m[0].length } : null;
}

/**
 * Terminal-state restore. Order matters: margins are reset with ESC 7 / ESC[r / ESC 8 before leaving the alternate
 * screen, then the cursor goes to the last row and one CRLF scrolls a fresh line into view. No RIS / ED2 / ED0, ever.
 * @param {{rows: number, alt: boolean, kittyDepth: number}} a
 */
function detachBytes({ rows, alt, kittyDepth }) {
  let s = '\x1b[?2026l';
  s += '\x1b[?2004l\x1b[?1004l\x1b[?2031l';
  s += '\x1b[?1000l\x1b[?1002l\x1b[?1003l\x1b[?1005l\x1b[?1006l\x1b[?1015l\x1b[?1016l';
  s += '\x1b[?25h\x1b[0m';
  s += '\x1b7\x1b[r\x1b8';
  if (alt) s += '\x1b[?1049l';
  if (kittyDepth > 0) s += kittyDepth === 1 ? '\x1b[<u' : `\x1b[<${kittyDepth}u`;
  s += `\x1b[${Math.max(1, rows)};1H\r\n`;
  return s;
}

/** Tracks kitty keyboard-protocol pushes (CSI > flags u) and pops (CSI < n u) in relayed output, so detach
 *  pops only what was pushed (the vscode profile normally pushes nothing). */
class KittyTracker {
  constructor() { this.depth = 0; this.carry = ''; }
  /** @param {Buffer} buf */
  feed(buf) {
    const s = this.carry + buf.toString('latin1');
    const re = /\x1b\[([<>])(\d*)u/g;
    let m;
    while ((m = re.exec(s))) {
      if (m[1] === '>') this.depth++;
      else this.depth = Math.max(0, this.depth - (m[2] ? Number(m[2]) : 1));
    }
    const lastEsc = s.lastIndexOf('\x1b');
    this.carry = lastEsc >= 0 && s.length - lastEsc < 12 && !/u/.test(s.slice(lastEsc)) ? s.slice(lastEsc) : '';
  }
}

/**
 * Whether the output so far left the terminal on the alternate screen. Read from the bytes themselves, because the only
 * thing that decides what state a terminal is in is what was written to it.
 */
class AltTracker {
  constructor() { this.alt = false; this.carry = ''; }
  /** @param {Buffer} buf */
  feed(buf) {
    const s = this.carry + buf.toString('latin1');
    const re = /\x1b(?:\[\?([\d;]+)([hl])|c)/g;
    let m;
    while ((m = re.exec(s))) {
      if (m[1] === undefined) this.alt = false;                                       // RIS
      else if (m[1].split(';').some((p) => ALT_MODES.includes(p))) this.alt = m[2] === 'h';
    }
    const esc = s.lastIndexOf('\x1b');
    this.carry = esc >= 0 && /^\x1b(?:\[\??[\d;]*)?$/.test(s.slice(esc)) ? s.slice(esc) : '';
  }
}

/** The user's terminal: raw mode, keys, size, and everything this process may write to it. */
class TerminalDriver {
  /**
   * @param {{io: {stdin: any, stdout: any}, onBytes: (b: Buffer) => void, onEnd: () => void, onWinch: () => void, onHangup: () => void}} o
   */
  constructor({ io, onBytes, onEnd, onWinch, onHangup }) {
    this.io = io;
    this.onBytes = onBytes;
    /** @type {{buf: Buffer, resolve: (row: number|null) => void, timer: any}|null} */ this.measure = null;
    this.gone = false;
    this.kitty = new KittyTracker();
    this.screen = new AltTracker();
    this.onStdinData = (/** @type {Buffer} */ b) => this.onStdin(b);
    this.onStdinEnd = onEnd;
    this.onWinch = onWinch;
    this.onHup = () => { this.gone = true; onHangup(); };
    this.onTerm = onHangup;
  }

  get cols() { return this.io.stdout.columns; }
  /** Whether the session's output left this terminal on the alternate screen. */
  get alt() { return this.screen.alt; }
  get rows() { return this.io.stdout.rows; }

  open() {
    const { stdin } = this.io;
    stdin.setRawMode(true);
    stdin.on('data', this.onStdinData);
    stdin.on('end', this.onStdinEnd);
    stdin.resume();
    process.on('SIGWINCH', this.onWinch);
    process.on('SIGHUP', this.onHup);
    process.on('SIGTERM', this.onTerm);
  }

  close() {
    const { stdin } = this.io;
    try { stdin.setRawMode(false); } catch { /* terminal gone */ }
    stdin.off('data', this.onStdinData);
    stdin.off('end', this.onStdinEnd);
    stdin.pause();
    process.off('SIGWINCH', this.onWinch);
    process.off('SIGHUP', this.onHup);
    process.off('SIGTERM', this.onTerm);
  }

  /** Ask the terminal where the cursor is (CSI 6n), ≤300 ms, buffering other input. @returns {Promise<number|null>} */
  measureCursor() {
    return new Promise((resolve) => {
      this.measure = {
        buf: Buffer.alloc(0),
        resolve: (row) => resolve(row),
        timer: setTimeout(() => this.finishMeasure(null), MEASURE_TIMEOUT_MS),
      };
      this.write('\x1b[6n');
    });
  }

  /** @param {number|null} row */
  finishMeasure(row) {
    const m = this.measure;
    if (!m) return;
    this.measure = null;
    clearTimeout(m.timer);
    m.resolve(row);
  }

  /** @param {Buffer} b */
  onStdin(b) {
    if (this.measure) {
      const m = this.measure;
      m.buf = Buffer.concat([m.buf, b]);
      const cpr = parseCpr(m.buf.toString('latin1'));
      if (cpr) {
        const rest = Buffer.concat([m.buf.subarray(0, cpr.index), m.buf.subarray(cpr.index + cpr.length)]);
        this.finishMeasure(cpr.row);
        if (rest.length) this.onBytes(rest);
      }
      return;
    }
    this.onBytes(b);
  }

  /** Output from the session, unchanged. @param {Buffer} bytes */
  output(bytes) {
    this.kitty.feed(bytes);
    this.screen.feed(bytes);
    this.write(bytes);
  }

  /** Leaves an overlay: what was on the alternate screen, the overlay replaced. */
  leaveOverlay() {
    this.write('\x1b[?1049l');
    this.screen.alt = false;
  }

  restore() {
    this.write(detachBytes({ rows: this.rows || 24, alt: this.screen.alt, kittyDepth: this.kitty.depth }));
    this.kitty.depth = 0;
    this.screen.alt = false;
  }

  /** @param {string|Buffer} data */
  write(data) {
    if (this.gone) return;
    try { this.io.stdout.write(data); } catch { /* EIO after SIGHUP */ }
  }
}

module.exports = { TerminalDriver, KittyTracker, AltTracker, detachBytes, parseCpr };
