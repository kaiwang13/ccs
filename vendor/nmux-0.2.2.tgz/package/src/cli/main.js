'use strict';
// @ts-check
/** The `nmux` command. Thin on purpose: every decision about a session is made by the session's own server. */
const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline');
const { loadConfig } = require('../server/config');
const { attach, attachPrecheck } = require('../client/attach');
const { controlRequest, CtlError } = require('../wire/ctlclient');
const { isLocked } = require('../platform/locks');
const { ensureRuntime } = require('../platform/runtime');
const { commandLine, cwdOf } = require('../platform/procinfo');
const sessions = require('./sessions');
const sdk = require('../sdk');
const { printTable, stateText, age, shortPath } = require('./format');
const { doctor } = require('./doctor');

const SHELL_ARG = '-l';
const STOP_WAIT_MS = 120000;
const STOP_RETRY_MS = 50;
const SERVER_GRACE_MS = 300;
const SEND_MAX_BYTES = 48000;

const USAGE = `nmux: terminal sessions that survive anything, with your terminal's own scrollback

  nmux                                attach, create or pick
  nmux new [NAME] [-d] [--cwd DIR] [--size CxR] [-- CMD…]
  nmux a [NAME] [--view]              attach; --view is read-only and never affects the size
  nmux ls [--json]
  nmux stop NAME|--all
  nmux restart NAME
  nmux rm NAME
  nmux rename [OLD] NEW
  nmux clients [NAME] [--json]        who is attached
  nmux kick [NAME] ID…|--others       detach them
  nmux send NAME [--no-enter] [--] TEXT…   type into a session
  nmux capture [NAME] [--lines N] [--ansi]
  nmux events [NAME]                  what happens in a session, as JSON lines
  nmux doctor

Inside a session the keys belong to the program, except Ctrl+\\ then: d detach, c who is attached, ? help,
Ctrl+\\ a literal Ctrl+\\. Inside a session NAME defaults to that session.
`;

class UsageError extends Error {}

/** What is in a session's foreground. Asked here, not of the server: this can take a while, and a session must not wait for it.
 *  @param {{foregroundPid?: number|null, child?: {pid: number|null}}} status */
function foregroundOf(status) {
  for (const pid of [status.foregroundPid, status.child && status.child.pid]) {        // the holder's answer can be a moment old
    const command = pid ? commandLine(pid) : null;
    if (pid && command) return { pid, command, cwd: cwdOf(pid) };
  }
  return null;
}

const version = () => JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', 'package.json'), 'utf8')).version;

/**
 * @param {string[]} args @param {{flags?: string[], options?: string[]}} [known]
 * @returns {{flags: Set<string>, options: Record<string, string>, rest: string[], command: string[]}}
 */
function parseArgs(args, { flags = [], options = [] } = {}) {
  const out = { flags: new Set(/** @type {string[]} */ ([])), options: /** @type {Record<string, string>} */ ({}), rest: /** @type {string[]} */ ([]), command: /** @type {string[]} */ ([]) };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--') { out.command = args.slice(i + 1); break; }
    if (flags.includes(a)) out.flags.add(a);
    else if (options.includes(a)) {
      if (i + 1 >= args.length) throw new UsageError(`${a} needs a value`);
      out.options[a] = args[++i];
    } else if (a.startsWith('-') && a !== '-') throw new UsageError(`unknown option ${a}`);
    else out.rest.push(a);
  }
  return out;
}

/** The directory's project, as a session name. @param {string} cwd */
function nameForDirectory(cwd) {
  let root = cwd;
  for (let d = cwd; ; d = path.dirname(d)) {
    if (fs.existsSync(path.join(d, '.git'))) { root = d; break; }
    if (d === path.dirname(d)) break;
  }
  const name = path.basename(root).replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^[^A-Za-z0-9]+/, '').slice(0, 64);
  return name || 'shell';
}

/** @typedef {{stdin: any, stdout: any, stderr: any, env: Record<string, string|undefined>, cwd: string}} Io */

class Cli {
  /** @param {Io} io */
  constructor(io) {
    this.io = io;
    this.paths = sessions.resolvePaths(io.env);
    this.config = loadConfig(this.paths.configFile);
  }

  /** @param {string} s */
  say(s) { this.io.stdout.write(`${s}\n`); }

  get current() { return this.io.env.NMUX_ID || null; }

  /** A named session, or the one this shell is running in. @param {string|undefined} name */
  resolve(name) {
    const all = sessions.listSessions(this.paths);
    const s = name !== undefined ? all.find((x) => x.name === name) : all.find((x) => x.id === this.current);
    if (s) return s;
    if (name === undefined) throw new UsageError('name a session (or run this inside one)');
    const known = all.map((x) => x.name);
    throw new Error(`no session named '${name}'${known.length ? ` (there is ${known.join(', ')})` : ''}`);
  }

  /** A session that can be talked to. A holder that gave up on its server gets a new one. @param {any} s */
  async live(s) {
    if (!s.alive) throw new Error(`session '${s.name}' has ended: nmux restart ${s.name}, or nmux rm ${s.name}`);
    if (!isLocked(this.paths.sessiondLock(s.id))) {
      await new Promise((r) => setTimeout(r, SERVER_GRACE_MS));                        // it may be on its way already
      const orphan = isLocked(this.paths.holderLock(s.id)) && !isLocked(this.paths.sessiondLock(s.id));   // no holder: it is still being created
      if (orphan) sessions.startServer(this.paths, s.id, { recover: true });
      await sessions.waitRunning(this.paths, s.id);
    }
    return s;
  }

  /** @param {any} s @param {string} op @param {object} [args] @param {number} [timeoutMs] */
  async request(s, op, args = {}, timeoutMs = 5000) {
    const r = await controlRequest(this.paths.ctlSock(s.id), op, args, { timeoutMs, label: 'nmux' });
    if (!r.ok) throw new Error(`session '${s.name}': ${r.error}`);
    return r;
  }

  /** @param {any} s @param {string} op @param {object} [args] @param {number} [timeoutMs] */
  async ask(s, op, args, timeoutMs) { return (await this.request(s, op, args, timeoutMs)).data; }

  /** @param {any} s @param {{view?: boolean}} [flags] */
  async enter(s, flags = {}) {
    return attach({ sockPath: this.paths.ctlSock(s.id), name: s.name, config: this.config, keys: this.config.keys, flags, io: this.io });
  }

  size() {
    const { columns, rows } = this.io.stdout;
    return columns && rows ? { cols: columns, rows } : { cols: this.config.size.defaultCols, rows: this.config.size.defaultRows };
  }

  /** @param {{name: string|null, argv?: string[], cwd?: string, size?: {cols: number, rows: number}, attaching?: boolean}} o */
  async create({ name, argv, cwd = this.io.cwd, size = this.size(), attaching = false }) {
    const { env } = this.io;
    const command = argv && argv.length ? argv : [env.SHELL || '/bin/sh', SHELL_ARG];
    if (!fs.existsSync(cwd)) throw new Error(`no such directory: ${cwd}`);
    return sessions.createSession(this.paths, { name, base: nameForDirectory(cwd), argv: command, cwd, env, ...size, term: env.TERM || 'xterm-256color', attaching });
  }

  // ---- commands ----------------------------------------------------------------------------------------------------
  /** Attach, create or pick. */
  async bare() {
    const live = sessions.listSessions(this.paths).filter((s) => s.alive);
    if (live.length === 0) return this.startAndAttach(null);
    if (live.length === 1) return this.enter(await this.live(live[0]));
    return this.pick(live);
  }

  /** @param {any[]} live @param {{view?: boolean}} [flags] */
  async pick(live, flags = {}) {
    const { stdin, stdout } = this.io;
    if (!stdin.isTTY) throw new UsageError(`several sessions: name one of ${live.map((s) => s.name).join(', ')}`);
    live.forEach((s, i) => stdout.write(`  ${i + 1}  ${s.name}\n`));
    const rl = readline.createInterface({ input: stdin, output: stdout });
    const line = await new Promise((resolve) => { rl.question('Session (Enter for 1): ', resolve); rl.once('close', () => resolve('q')); });
    rl.close();
    if (/^q/i.test(line)) return 0;
    const chosen = live[line.trim() === '' ? 0 : Number(line) - 1] || live.find((s) => s.name === line.trim());
    if (!chosen) throw new Error(`no such session: ${line}`);
    return this.enter(await this.live(chosen), flags);
  }

  /** @param {string|null} name @param {Partial<Parameters<Cli['create']>[0]>} [o] */
  async startAndAttach(name, o = {}) {
    const refused = attachPrecheck(this.io);
    if (refused) { this.io.stderr.write(`${refused.message}\n`); return refused.code; }
    const s = await this.create({ name, ...o, attaching: true });
    return this.enter({ id: s.id, name: s.name });
  }

  /** @param {string[]} args */
  async new(args) {
    const a = parseArgs(args, { flags: ['-d'], options: ['--cwd', '--size'] });
    if (a.rest.length > 1) throw new UsageError('nmux new takes one name');
    const name = a.rest[0] ?? null;
    if (name !== null && !sessions.validName(name)) throw new UsageError(`bad session name '${name}': letters, digits, '.', '_' and '-'`);
    const cwd = a.options['--cwd'] ? path.resolve(this.io.cwd, a.options['--cwd']) : this.io.cwd;
    const m = a.options['--size'] ? /^(\d+)x(\d+)$/.exec(a.options['--size']) : null;
    if (a.options['--size'] && !m) throw new UsageError('--size takes COLSxROWS');
    const size = m ? { cols: Number(m[1]), rows: Number(m[2]) } : this.size();
    if (a.flags.has('-d')) {
      const s = await this.create({ name, argv: a.command, cwd, size });
      this.say(s.name);
      return 0;
    }
    return this.startAndAttach(name, { argv: a.command, cwd, size });
  }

  /** @param {string[]} args */
  async a(args) {
    const a = parseArgs(args, { flags: ['--view'] });
    const flags = a.flags.has('--view') ? { view: true } : {};
    if (a.rest.length) return this.enter(await this.live(this.resolve(a.rest[0])), flags);
    const live = sessions.listSessions(this.paths).filter((s) => s.alive);
    if (live.length === 0) throw new Error('no sessions; nmux new starts one');
    return live.length === 1 ? this.enter(await this.live(live[0]), flags) : this.pick(live, flags);
  }

  /** @param {string[]} args */
  async ls(args) {
    const a = parseArgs(args, { flags: ['--json'] });
    const rows = await Promise.all(sessions.listSessions(this.paths).map(async (s) => ({ s, status: s.alive ? await sessions.statusOf(this.paths, s.id) : null })));
    for (const { status } of rows) if (status) { status.foreground = foregroundOf(status); status.cwd = status.foreground && status.foreground.cwd; }
    if (a.flags.has('--json')) {
      this.say(JSON.stringify(rows.map(({ s, status }) => ({ id: s.id, name: s.name, alive: s.alive, createdAt: s.spec.createdAt, status, lastExit: s.state?.restarts?.lastExit ?? null }))));
      return 0;
    }
    if (rows.length === 0) { this.say('no sessions'); return 0; }
    const table = rows.map(({ s, status }) => [`${s.id === this.current ? '*' : ' '} ${s.name}`, stateText(s, status), String(status ? status.clients.length || '–' : '–'),
      age(s.spec.createdAt), shortPath(status?.cwd || s.spec.child.cwd, this.io.env.HOME)]);
    printTable(this.io.stdout, ['  NAME', 'STATE', 'CLIENTS', 'AGE', 'CWD'], table);
    return 0;
  }

  /** @param {string[]} args */
  async stop(args) {
    const a = parseArgs(args, { flags: ['--all'] });
    const targets = a.flags.has('--all') ? sessions.listSessions(this.paths) : [this.resolve(a.rest[0])];
    await Promise.all(targets.map((s) => this.stopOne(s)));
    return 0;
  }

  /** Asks until the session has gone: a server that is restarting will be back within moments. @param {any} s */
  async stopOne(s) {
    if (!s.alive) { sessions.removeSession(this.paths, s.id); return; }
    const running = () => sessions.isAlive(this.paths, s.id);
    const deadline = Date.now() + STOP_WAIT_MS;
    while (running() && Date.now() < deadline) {
      try { await this.ask(s, 'STOP', {}, STOP_WAIT_MS); } catch (e) {
        if (!(e instanceof CtlError)) throw e;                                         // the connection went, which it does as a session ends
      }
      await new Promise((r) => setTimeout(r, STOP_RETRY_MS));
    }
    if (running()) throw new Error(`session '${s.name}' did not stop`);
    sessions.removeSession(this.paths, s.id);
  }

  /** @param {string[]} args */
  async restart(args) {
    const s = this.resolve(parseArgs(args).rest[0]);
    if (s.alive) { await this.ask(s, 'RESTART', {}, STOP_WAIT_MS); return 0; }
    sessions.startServer(this.paths, s.id);
    await sessions.waitRunning(this.paths, s.id);
    return 0;
  }

  /** @param {string[]} args */
  async rm(args) {
    const s = this.resolve(parseArgs(args).rest[0]);
    if (s.alive) throw new Error(`session '${s.name}' is running: nmux stop ${s.name}`);
    sessions.removeSession(this.paths, s.id);
    return 0;
  }

  /** @param {string[]} args */
  async rename(args) {
    const { rest } = parseArgs(args);
    if (rest.length < 1 || rest.length > 2) throw new UsageError('nmux rename [OLD] NEW');
    const to = rest[rest.length - 1];
    if (!sessions.validName(to)) throw new UsageError(`bad session name '${to}': letters, digits, '.', '_' and '-'`);
    const s = this.resolve(rest.length === 2 ? rest[0] : undefined);
    await sessions.renameSession(this.paths, s.id, to);
    if (s.alive) await this.ask(s, 'RENAME', { name: to });
    return 0;
  }

  /** @param {string[]} args */
  async clients(args) {
    const a = parseArgs(args, { flags: ['--json'] });
    const s = await this.live(this.resolve(a.rest[0]));
    const { clients } = await this.ask(s, 'CLIENTS');
    if (a.flags.has('--json')) { this.say(JSON.stringify(clients)); return 0; }
    if (clients.length === 0) { this.say(`nobody is attached to ${s.name}`); return 0; }
    printTable(this.io.stdout, ['ID', 'LABEL', 'SIZE', 'ATTACHED', 'IDLE'], clients.map((/** @type {any} */ c) => [c.id + (c.view ? ' (view)' : ''), c.label, `${c.cols}x${c.rows}`,
      age(Date.now() - c.attachedMs), c.idleMs === null ? '–' : age(Date.now() - c.idleMs)]));
    return 0;
  }

  /** @param {string[]} args */
  async kick(args) {
    const a = parseArgs(args, { flags: ['--others'] });
    const all = sessions.listSessions(this.paths);
    const named = a.rest.length && all.find((x) => x.name === a.rest[0]);
    const s = await this.live(named || this.resolve(undefined));
    const ids = named ? a.rest.slice(1) : a.rest;
    const others = a.flags.has('--others');
    if (others === (ids.length > 0)) throw new UsageError('nmux kick [NAME] ID…|--others');
    const data = await this.ask(s, 'KICK', others ? { allExcept: [await this.ownClient(s)], by: 'nmux kick' } : { clients: ids, by: 'nmux kick' });
    for (const c of data.kicked) this.say(`detached ${c.id} (${c.label})`);
    for (const id of data.unknown) this.io.stderr.write(`nmux: no client ${id} on ${s.name}\n`);
    return data.unknown.length ? 1 : 0;
  }

  /**
   * The terminal this command was typed in, which is the one that typed last. Only a shell inside the session can say that
   * of itself: from anywhere else there is no telling, so --others is refused rather than guessed.
   * @param {any} s @returns {Promise<string>}
   */
  async ownClient(s) {
    if (this.current !== s.id) throw new Error(`--others keeps your own terminal, which only a command typed inside '${s.name}' can tell: name the clients (nmux clients ${s.name})`);
    const { clients } = await this.ask(s, 'CLIENTS');
    const typed = clients.filter((/** @type {any} */ c) => c.idleMs !== null).sort((/** @type {any} */ a, /** @type {any} */ b) => a.idleMs - b.idleMs)[0];
    if (!typed) throw new Error('nobody has typed yet, so there is no telling which terminal is yours');
    return typed.id;
  }

  /** @param {string[]} args */
  async send(args) {
    const [name, ...words] = args;                                                     // the text is the caller's: nothing in it is an option
    const enter = words[0] !== '--no-enter';
    if (!enter) words.shift();
    if (words[0] === '--') words.shift();
    if (name === undefined || words.length === 0) throw new UsageError('nmux send NAME [--no-enter] [--] TEXT…');
    const text = words.join(' ');
    if (Buffer.byteLength(text, 'utf8') > SEND_MAX_BYTES) throw new Error(`that is too much to type at once: the limit is ${SEND_MAX_BYTES} bytes`);
    await this.ask(await this.live(this.resolve(name)), 'SEND', { text, enter });
    return 0;
  }

  /** @param {string[]} args */
  async capture(args) {
    const a = parseArgs(args, { flags: ['--ansi'], options: ['--lines'] });
    const s = await this.live(this.resolve(a.rest[0]));
    const { output } = await this.request(s, 'CAPTURE', { lines: a.options['--lines'] ? Number(a.options['--lines']) : null, ansi: a.flags.has('--ansi') });
    this.io.stdout.write(output);
    return 0;
  }

  /** Follows a session until it ends. @param {string[]} args */
  async events(args) {
    const s = await this.live(this.resolve(parseArgs(args).rest[0]));
    const client = new sdk.SessionClient({ sockPath: this.paths.ctlSock(s.id), label: 'nmux events', subscribe: { events: EVENTS } });
    await new Promise((resolve) => {
      client.on('event', (e) => {
        this.say(JSON.stringify({ at: new Date().toISOString(), ...e }));
        if (e.event === 'stopped') resolve(undefined);
      });
      client.on('down', () => { if (!sessions.isAlive(this.paths, s.id)) resolve(undefined); });
      client.open();
    });
    client.close();
    return 0;
  }

  async doctor() { return doctor(this.paths, this.io); }
}

const EVENTS = ['lifecycle', 'notice', 'stopped', 'holder', 'attached', 'tty', 'match', 'exit', 'respawned'];
const COMMANDS = { events: 'events', new: 'new', a: 'a', attach: 'a', ls: 'ls', list: 'ls', stop: 'stop', restart: 'restart', rm: 'rm', rename: 'rename', clients: 'clients', kick: 'kick', send: 'send', capture: 'capture', doctor: 'doctor' };

/**
 * @param {string[]} argv @param {Partial<Io>} [partial] @returns {Promise<number>} the exit code
 */
async function main(argv, partial = {}) {
  const io = { stdin: process.stdin, stdout: process.stdout, stderr: process.stderr, env: process.env, cwd: process.cwd(), ...partial };
  const [cmd, ...args] = argv;
  if (cmd === 'help' || cmd === '--help' || cmd === '-h') { io.stdout.write(USAGE); return 0; }
  if (cmd === '--version' || cmd === '-V') { io.stdout.write(`nmux ${version()}\n`); return 0; }
  const cli = new Cli(io);
  try {
    if (cmd !== 'doctor') ensureRuntime(cli.paths);                                     // doctor is how a bad one gets explained
    if (cmd === undefined) return await cli.bare();
    const method = /** @type {Record<string, string>} */ (COMMANDS)[cmd];
    if (!method) throw new UsageError(`unknown command '${cmd}'`);
    return await /** @type {any} */ (cli)[method](args);
  } catch (e) {
    const err = /** @type {Error} */ (e);
    io.stderr.write(`nmux: ${err.message}\n`);
    if (err instanceof UsageError) { io.stderr.write(`try 'nmux help'\n`); return 2; }
    return 1;
  }
}

module.exports = { main, parseArgs, nameForDirectory };
