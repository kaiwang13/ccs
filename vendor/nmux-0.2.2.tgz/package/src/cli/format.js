'use strict';
// @ts-check
/** How the command shows things to a person. `--json` never comes through here. */

const SHELLS = new Set(['bash', 'zsh', 'fish', 'sh', 'dash', 'ksh', 'tcsh', 'csh', 'nu', 'elvish', 'xonsh']);
const COMMAND_WIDTH = 36;

/** @param {number} ms */
function duration(ms) {
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 48) return `${h}h`;
  return `${Math.floor(h / 24)}d`;
}

/** @param {string|number|undefined|null} at an ISO time or a Unix time in ms */
function age(at) {
  if (at === undefined || at === null) return '–';
  const t = typeof at === 'string' ? Date.parse(at) : at;
  return Number.isNaN(t) ? '–' : duration(Math.max(0, Date.now() - t));
}

/** @param {string|null|undefined} p @param {string|undefined} home */
function shortPath(p, home) {
  if (!p) return '–';
  return home && (p === home || p.startsWith(`${home}/`)) ? `~${p.slice(home.length)}` : p;
}

/** @param {string} command */
function brief(command) {
  return command.length > COMMAND_WIDTH ? `${command.slice(0, COMMAND_WIDTH - 1)}…` : command;
}

/** The shell of a command line, if that is what it runs. @param {string|null|undefined} command */
function isShell(command) {
  if (!command || /\s-c\s/.test(command)) return false;
  const first = command.trim().split(/\s+/)[0].replace(/^-/, '');
  return SHELLS.has(first.slice(first.lastIndexOf('/') + 1));
}

/** The STATE column. @param {{alive: boolean, state: any}} s @param {any} status what the session answered, or null */
function stateText(s, status) {
  if (!s.alive) {
    const e = s.state && s.state.restarts && s.state.restarts.lastExit;
    if (!e) return 'gone';
    return `exited (${e.code ?? e.signal ?? '?'}) ${e.at ? `${age(e.at)} ago` : ''}`.trimEnd();
  }
  if (!status) return 'not answering';
  if (status.lifecycle !== 'RUNNING') return status.lifecycle.toLowerCase();
  const command = status.foreground && status.foreground.command;
  if (command && !isShell(command)) return `running: ${brief(command)}`;
  return status.idleMs === null || status.idleMs === undefined ? 'idle' : `idle ${duration(status.idleMs)}`;
}

/** Text from a process or a filename, made safe to print: it must not be able to drive the terminal. @param {string} s */
const printable = (s) => s.replace(/[\x00-\x1f\x7f-\x9f]/g, '?');

/** @param {{write: (s: string) => void}} out @param {string[]} head @param {string[][]} rows */
function printTable(out, head, rows) {
  const safe = rows.map((r) => r.map(printable));
  const widths = head.map((h, i) => Math.max(h.length, ...safe.map((r) => r[i].length)));
  const line = (/** @type {string[]} */ r) => r.map((c, i) => (i === r.length - 1 ? c : c.padEnd(widths[i]))).join('  ');
  out.write(`${line(head)}\n`);
  for (const r of safe) out.write(`${line(r)}\n`);
}

module.exports = { duration, age, shortPath, brief, isShell, stateText, printTable, printable };
