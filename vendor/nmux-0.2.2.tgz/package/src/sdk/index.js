'use strict';
// @ts-check
/**
 * The way to embed nmux. A program starts sessions, connects to them, and attaches terminals to them through this, and
 * nothing it does depends on how a session runs, so that can change underneath it.
 */
/**
 * @typedef {import('../client/text').ClientText} ClientText
 * @typedef {import('../wire/layout').Layout} Layout
 */
const { SessionClient } = require('./client');
const { createSession, startServer } = require('./host');
const { controlRequest, probeSocket, CtlError } = require('../wire/ctlclient');
const { sessionLayout, segment } = require('../wire/layout');
const { attach, attachPrecheck, labelFor, DEFAULT_TEXT } = require('../client/attach');
const { hhmm } = require('../client/text');
const { queryTermColors } = require('../client/termcolors');
const { DEFAULTS: HOST_DEFAULTS } = require('../server/config');

module.exports = { HOST_DEFAULTS, segment, SessionClient, createSession, startServer, controlRequest, probeSocket, CtlError, sessionLayout, attach, attachPrecheck, labelFor, DEFAULT_TEXT, hhmm, queryTermColors };
