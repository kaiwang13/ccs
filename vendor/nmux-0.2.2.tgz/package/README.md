# nmux

Terminal sessions that outlive your connection and your upgrades, shown in your terminal's own scrollback.

`nmux` keeps shells and other programs running on a machine and lets any number of terminals attach to them. It stays out
of the way: scrolling, search, selection, links and images are your terminal's, with no prefix to scroll, no copy mode and
no status bar. Every key belongs to the program except one.

"mux" here means several terminals sharing one session. `nmux` has no split panes, because a terminal has one scrollback
and two panes cannot both have it. Use your terminal's own splits and tabs, with an `nmux a` in each.

```console
$ nmux                      # no sessions: starts one named after this repo or directory, and attaches
$ nmux new api              # a named shell, in this directory
$ nmux new logs -- tail -F /var/log/app.log    # any program, not only a shell
$ nmux new build -d -- make # start it and stay here
$ nmux a api                # attach; another terminal can attach at the same time
$ nmux a api --view         # read-only, and never affects the size

$ nmux ls
  NAME   STATE                CLIENTS  AGE  CWD
  api    idle 2m              2        1d   ~/src/api
  build  running: make        –        3m   ~/src/app
  old    exited (1) 40m ago   –        2d   ~/src/old
```

When a program exits its session ends and attached terminals return to their own shell, as from a plain ssh login. A
session that ends cleanly leaves nothing behind; one that failed stays listed until `nmux rm` or `nmux restart`. Its output
goes with it: `nmux capture` reads a running session, so start something detached only if you will look before it ends.

## What it does that others do not combine

- **Sessions survive `nmux` itself.** The program's pty lives in a tiny holder process, so a crash or upgrade of everything
  else loses nothing. A terminal attached at the time reconnects by itself.
- **No output is lost.** A program printing faster than `nmux` can parse is slowed down, as it would be by a slow terminal.
  A slow terminal slows nobody: it skips ahead in place and is told what it missed.
- **Joining shows what a terminal attached throughout would show.** The screen, colours, modes and cursor. Long lines stay
  one line, so your terminal can reflow them.
- **Terminals share a session properly.** The size follows the smallest, viewers do not count, `nmux clients` shows who is
  there and `nmux kick` detaches them.

## Commands

| Command | Does |
|---|---|
| `nmux` | Attach, create or pick |
| `nmux new [NAME] [-d] [--cwd DIR] [--size CxR] [-- CMD…]` | Create and attach; `-d` stays detached |
| `nmux a [NAME] [--view]` | Attach |
| `nmux ls [--json]` | List sessions |
| `nmux stop NAME\|--all` | End a session |
| `nmux restart NAME` | A new program in the same session; attached terminals stay |
| `nmux rm NAME` | Forget a session that has ended |
| `nmux rename [OLD] NEW` | Rename |
| `nmux clients [NAME] [--json]` | Who is attached |
| `nmux kick [NAME] ID…\|--others` | Detach them |
| `nmux send NAME [--no-enter] [--] TEXT…` | Type into a session; several lines go in as one paste when the program supports it |
| `nmux capture [NAME] [--lines N] [--ansi]` | The screen and history as text |
| `nmux events [NAME]` | What happens in a session, as JSON lines, until it ends |
| `nmux doctor` | Check the environment |

Inside a session, `NAME` defaults to that session.

## Keys

Ctrl+C, Ctrl+Z and every other key go to the program. `nmux` takes one leader, `Ctrl+\`:

| Keys | Action |
|---|---|
| `Ctrl+\ d` | Detach |
| `Ctrl+\ c` | Who is attached |
| `Ctrl+\ ?` | Help |
| `Ctrl+\ Ctrl+\` | Send a literal `Ctrl+\` |

Detaching is handled in the client, so it works even if the session's server has hung.

## Configuration

`~/.config/nmux/config.json`, every key optional. For example, to use another leader and keep more history:

```json
{ "keys": { "leader": "C-b" }, "snapshot": { "scrollback": 50000 } }
```

`src/server/config.js` lists everything. Sessions live in `/tmp/nmux-<uid>` (`NMUX_RUNTIME_DIR` overrides it): sockets are
`0600` in a `0700` directory, and there are no TCP listeners. `$XDG_RUNTIME_DIR` is not used because logging out removes it
while the sessions in it keep running.

## Building on it

`require('nmux/sdk')` is the way in, and `src/sdk/` says what it offers: start a session, attach a terminal, or connect and
watch. A program that understands what a session is running can be its controller: it subscribes to what happens, and answers
with phases, gates, attributes, a new program, and its share of a stop. What must happen on every keystroke is declared in the
session spec instead (`managed`, see `src/server/session/remote.js`), so it holds whether the controller is there or not.
`nmux/internal/*` exists for tests and is not a promise.

## Status

Early, and not yet published. It runs on Node 24.14.1 and costs about 115 MB of memory per session; a native port is planned
once the behaviour has settled. It is tested on Linux. macOS code exists and CI will run it once this is pushed, but it has
not been run yet.

```sh
npm install
npm test
npm link      # puts `nmux` on your PATH
```

`npm test` includes the conformance suite, which plays real shell, `vim` and `less` sessions through `nmux` and through a plain
terminal and requires the same screen, colours, cursor, modes and scrollback.
