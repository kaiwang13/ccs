'use strict';
// @ts-check
/** Times as a person reads them, on a clock in a given time zone: what history, search and the picture behind a session all show. */

const DAY_MS = 86400000;
const HOUR_MS = 3600000;

/** Making a formatter costs a hundred times what using one does, and a history is read a line at a time. @type {Map<string, Intl.DateTimeFormat>} */
const formatters = new Map();

/** @param {string} timeZone @param {'wall'|'month'|'mon'|'label'} kind @returns {Intl.DateTimeFormat} */
function formatter(timeZone, kind) {
  const key = `${kind} ${timeZone}`;
  let f = formatters.get(key);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', kind === 'wall'
      ? { timeZone, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', weekday: 'long' }
      : kind === 'month' || kind === 'mon' ? { timeZone, month: kind === 'month' ? 'long' : 'short' } : { timeZone, timeZoneName: 'short' });
    formatters.set(key, f);
  }
  return f;
}

/**
 * The parts of a time as they are on a clock in `timeZone`.
 * @param {number} ms @param {string} timeZone
 */
function wall(ms, timeZone) {
  const parts = formatter(timeZone, 'wall').formatToParts(ms);
  /** @type {Record<string, string>} */
  const p = {};
  for (const { type, value } of parts) p[type] = value;
  return { year: Number(p.year), month: Number(p.month), day: Number(p.day), hour: Number(p.hour), minute: Number(p.minute), second: Number(p.second), weekday: p.weekday };
}

/** `2026-11-01 14:03:22`, on a clock in `timeZone`. @param {number} ms @param {string} timeZone */
function stamp(ms, timeZone) {
  const w = wall(ms, timeZone);
  const two = (/** @type {number} */ n) => String(n).padStart(2, '0');
  return `${w.year}-${two(w.month)}-${two(w.day)} ${two(w.hour)}:${two(w.minute)}:${two(w.second)}`;
}

/** The day `ms` is in, on a clock in `timeZone`, as a key and as a person says it. @param {number} ms @param {string} timeZone */
function dayOf(ms, timeZone) {
  const w = wall(ms, timeZone);
  const month = formatter(timeZone, 'month').format(ms);
  return { key: `${w.year}-${w.month}-${w.day}`, words: `${w.weekday} ${w.day} ${month} ${w.year}` };
}

/** The moment a clock in `timeZone` shows this. @param {number} y @param {number} mo @param {number} d @param {number} h @param {number} mi @param {number} s @param {string} timeZone */
function fromWall(y, mo, d, h, mi, s, timeZone) {
  const asUtc = Date.UTC(y, mo - 1, d, h, mi, s);
  let guess = asUtc;
  for (let i = 0; i < 3; i++) {                                                          // the offset can differ either side of a change of clocks
    const w = wall(guess, timeZone);
    guess += asUtc - Date.UTC(w.year, w.month - 1, w.day, w.hour, w.minute, w.second);
  }
  return guess;
}

/**
 * A time as a person might write it: `2026-11-01`, `2026-11-01 14:00`, `14:00` (today), `yesterday`, `today`, or how long ago (`90m`, `2h`, `3d`).
 * @param {string} text @param {number} now @param {string} timeZone @returns {number|null} ms since the epoch
 */
function parseWhen(text, now, timeZone) {
  const t = text.trim().toLowerCase();
  const ago = /^(\d+(?:\.\d+)?)\s*(s|m|h|d)(?:\s+ago)?$/.exec(t);
  if (ago) return now - Number(ago[1]) * { s: 1000, m: 60000, h: 3600000, d: DAY_MS }[/** @type {'s'|'m'|'h'|'d'} */ (ago[2])];
  const today = wall(now, timeZone);
  if (t === 'today' || t === 'yesterday') {
    const midnight = startOfDay(today.year, today.month, today.day, timeZone);
    return t === 'today' ? midnight : startOfDay(...ymd(midnight - HOUR_MS, timeZone), timeZone);
  }
  const m = /^(?:(\d{4})-(\d{1,2})-(\d{1,2}))?(?:[ t]?(\d{1,2}):(\d{2})(?::(\d{2}))?)?$/.exec(t);
  if (!m || (!m[1] && !m[4])) return null;
  const [y, mo, d] = m[1] ? [Number(m[1]), Number(m[2]), Number(m[3])] : [today.year, today.month, today.day];
  const [h, mi, sec] = [Number(m[4] || 0), Number(m[5] || 0), Number(m[6] || 0)];
  if (mo < 1 || mo > 12 || d < 1 || d > new Date(Date.UTC(y, mo, 0)).getUTCDate() || h > 23 || mi > 59 || sec > 59) return null;   // 2026-02-30, 25:99
  return h === 0 && mi === 0 && sec === 0 ? startOfDay(y, mo, d, timeZone) : fromWall(y, mo, d, h, mi, sec, timeZone);
}

/**
 * When a day begins on a clock in `timeZone`: midnight, or where a zone whose clocks go forward at midnight skips it, the first
 * moment that is that day. @param {number} y @param {number} mo @param {number} d @param {string} timeZone
 */
function startOfDay(y, mo, d, timeZone) {
  let t = fromWall(y, mo, d, 0, 0, 0, timeZone);
  for (let i = 0; i < 16; i++) {                                                         // no zone skips more than a few hours
    const [wy, wm, wd] = ymd(t, timeZone);
    if (wy > y || (wy === y && (wm > mo || (wm === mo && wd >= d)))) break;
    t += HOUR_MS / 4;
  }
  return t;
}

/** @param {number} ms @param {string} timeZone @returns {[number, number, number]} */
function ymd(ms, timeZone) {
  const w = wall(ms, timeZone);
  return [w.year, w.month, w.day];
}

/**
 * The time zone to show times in: the one asked for, or this process's. `TZ` may be written as the C library takes it
 * (`:America/New_York`, `/usr/share/zoneinfo/Europe/Paris`, `:/etc/localtime`, `EST5EDT,M3.2.0,M11.1.0`), which `Intl` does not:
 * a name it knows in there is used, and anything else means this process's zone. @param {string|undefined|null} [asked]
 */
function zone(asked) {
  const own = () => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch { return 'UTC'; } };
  if (!asked) return own();
  const name = asked.replace(/^:/, '').replace(/^.*\/zoneinfo\//, '');
  try {
    formatter(name, 'wall');
    return name;
  } catch {
    return own();
  }
}

/** `PST`, `CET`: the zone as a clock in it is labelled at that moment. @param {number} ms @param {string} timeZone */
function zoneLabel(ms, timeZone) {
  const part = formatter(timeZone, 'label').formatToParts(ms).find((p) => p.type === 'timeZoneName');
  return part ? part.value : timeZone;
}

/** `Nov`: the month on a clock in `timeZone`, short. @param {number} ms @param {string} timeZone */
const monthShort = (ms, timeZone) => formatter(timeZone, 'mon').format(ms);

module.exports = { wall, stamp, dayOf, parseWhen, zone, zoneLabel, monthShort, DAY_MS };
