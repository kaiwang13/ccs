'use strict';
// @ts-check
const { T } = require('../../wire/proto');
const { serializeRows, serializeFlow, firstWrittenLine, attrKey } = require('./cells');
const { MOUSE_PROTOCOL, MOUSE_ENCODING } = require('../../vt/modes');

/** @param {number} row 1-based @param {number} col 1-based */
const cup = (row, col) => `\x1b[${row};${col}H`;
/** @param {string} text */
const dim = (text) => `\x1b[2m${text}\x1b[0m`;
const PRELUDE_MODES = [2004, 1004, 2031, 9, 1000, 1002, 1003, 1006, 1016];
/** Every mode a program may set and expect to find still set. Origin mode moves the cursor, so it has a place of its own. */
const ALL_MODES = [1, 7, 12, 45, 66, 1005, 1015, ...PRELUDE_MODES];
const ORIGIN_MODE = 6;
const WRAP_MODE = 7;
const MOUSE = [...MOUSE_PROTOCOL, ...MOUSE_ENCODING];
/** A terminal back at its defaults: DECSTR, then the same things by name for one that lacks it. */
const DEFAULTS_NOW = `\x1b[!p\x1b[?${WRAP_MODE}h\x1b[?${ORIGIN_MODE}l\x1b[4l\x1b>\x1b(B`;

/**
 * The modes a program set, as a terminal has to be told them. xterm reports the mouse one way at a time, and turning any of those
 * modes off turns the mouse off, so every mode that is off goes first and only the ones that are on come after.
 * @param {import('../../vt/modes').ModeState} m @param {number[]} modes
 * @param {boolean} every say every mode, not only those the program set or reset: the terminal is in no known state
 */
function modeBytes(m, modes, every) {
  let off = '';
  let on = '';
  for (const mode of modes) {
    const r = m.raw(mode);
    const mouse = MOUSE.includes(mode);
    if (mouse ? m.state(mode) === 1 : r === 1) on += `\x1b[?${mode}h`;
    else if (r !== 0 || (every && mode !== WRAP_MODE)) off += `\x1b[?${mode}l`;
  }
  return off + on;
}

/**
 * The first history row a join sends. @param {any} b @param {number} scr first row of the screen @param {number|'all'} limit
 * @param {number} from what the terminal has up to, when it has been here before
 */
function firstHistoryRow(b, scr, limit, from) {
  return Math.min(scr, Math.max(firstWrittenLine(b, scr), limit === 'all' ? 0 : scr - limit, from));
}

/**
 * Join geometry: Rp = tracker.screenRows, Δe = 150 − Rp; scr = first PTY-screen line of the
 * emulator's normal buffer; h0 = first history line to send.
 * @param {{emulator: import('./emulator').Emulator, tracker: import('./tracker').Tracker, historyLimit: number|'all', historyFrom?: number}} o
 */
function joinGeometry({ emulator, tracker, historyLimit, historyFrom = 0 }) {
  const b = emulator.term.buffer.normal;
  const Rp = tracker.screenRows;
  const De = emulator.rows - Rp;
  const top = b.length - emulator.rows;
  const scr = top + De;
  const h0 = firstHistoryRow(b, scr, historyLimit, historyFrom);
  return { b, Rp, De, top, scr, h0 };
}

/**
 * Join bytes. Rc = client rows, Δc = Rc − Rp.
 * 1. Hide the cursor, SGR 0, reset margins BEFORE any positioning.
 * 2. Pre-roll: go to the client's last row and emit one LF per shell row in use (cursorRow): the shell's screen scrolls
 *    into the client's own scrollback. Never ED2/RIS: those erase or clear scrollback on some terminals.
 * 3. A dim separator line, then the history rows with CRLF: they scroll naturally into native scrollback.
 * 4. CRLF × (Rc − 1 − Δc): guarantees the last history row sits at or above row Δc even if history lines wrapped.
 * 5. Each PTY-screen row placed with an explicit CUP at row Δc+1+i after EL2: exact bottom alignment.
 * 6. Alt buffer and DECSC slots replayed; cursor; prelude of tracked modes, title, SGR 0 then the current pen
 *    (a quiescent point can still fall inside a frame drawn with a colour), cursor visibility.
 * @param {JoinOptions} o @returns {Buffer}
 */
function buildJoinBytes(o) {
  return o.emulator.tracking ? buildTrackingJoin(o) : buildFixedJoin(o);
}

/**
 * @typedef {{emulator: import('./emulator').Emulator, tracker: import('./tracker').Tracker, banner?: (lines: number) => string|null,
 *   client: {rows: number, cols: number, cursorRow?: number|null, alt?: boolean, keepMain?: boolean, overScreen?: boolean}, historyLimit: number|'all', historyFrom?: number}} JoinOptions
 */

/** @param {JoinOptions} o @returns {Buffer} */
function buildFixedJoin({ emulator, tracker, banner = () => null, client, historyLimit, historyFrom }) {
  const { b, Rp, De, scr, h0 } = joinGeometry({ emulator, tracker, historyLimit, historyFrom });
  const Rc = client.rows;
  const Dc = Rc - Rp;
  const skip = Math.max(0, -Dc);                           // a client shorter than the screen gets its top rows as history
  const above = Math.max(0, Dc);                           // client rows above the screen
  const clampRow = (/** @type {number} */ r) => Math.min(Rc, Math.max(1, r));
  let o = client.alt === undefined ? '' : `\x1b[?2026l${client.alt ? '\x1b[?1049l' : ''}`;   // in place: see buildTrackingJoin
  o += '\x1b[?25l\x1b[0m\x1b[r';
  o += cup(Rc, 1) + '\n'.repeat(client.cursorRow ?? Rc);
  const line = banner(scr - h0);
  o += cup(1, 1) + (line ? `${dim(line)}\r\n` : '');
  const hist = serializeRows(b, h0, scr + skip);
  if (hist.length) o += hist.join('\r\n') + '\r\n';
  o += '\r\n'.repeat(Math.max(0, Rc - 1 - above));
  const screen = serializeRows(b, scr + skip, scr + Rp, { maxCols: client.cols });
  for (let i = 0; i < screen.length; i++) o += cup(above + 1 + i, 1) + '\x1b[2K' + screen[i];
  /** absolute emulator line -> client row */
  const toClientRow = (/** @type {number} */ absY) => clampRow((absY - b.baseY) - De + Dc + 1);
  if (emulator.term.buffer.active.type === 'alternate') {
    const alt = emulator.term.buffer.alternate;
    const sn = emulator.saved.normal ?? { x: b.cursorX, y: b.baseY + b.cursorY };
    o += cup(toClientRow(sn.y), sn.x + 1) + '\x1b[?1049h';                  // ?1049h saves THIS position in the normal slot
    const altRows = serializeRows(alt, alt.baseY, alt.baseY + Math.min(Rp, Rc), { maxCols: client.cols });   // it gains history when rows shrink
    for (let i = 0; i < altRows.length; i++) o += cup(i + 1, 1) + '\x1b[2K' + altRows[i];   // alt is top-aligned: no Δ
    if (emulator.saved.alternate) o += cup(clampRow(emulator.saved.alternate.y - alt.baseY + 1), emulator.saved.alternate.x + 1) + '\x1b7';
    o += cup(clampRow(alt.cursorY + 1), alt.cursorX + 1);
  } else {
    if (emulator.saved.normal) o += cup(toClientRow(emulator.saved.normal.y), emulator.saved.normal.x + 1) + '\x1b7';   // the nested ?1049l window
    o += cup(toClientRow(b.baseY + b.cursorY), b.cursorX + 1);
  }
  const m = tracker.modes;
  o += modeBytes(m, PRELUDE_MODES, false);
  if (m.cursorStyle !== null) o += `\x1b[${m.cursorStyle} q`;
  o += `\x1b]0;${tracker.title}\x07\x1b[0m`;
  for (const p of tracker.pen) o += `\x1b[${p}m`;                          // the pen the child is drawing with at S
  o += m.raw(25) === 2 ? '\x1b[?25l' : '\x1b[?25h';
  return Buffer.from(o, 'utf8');
}

/**
 * A join for an emulator the pty's size. History and screen go out as one stream, so the terminal wraps long lines itself:
 * they stay single lines in its scrollback and it can reflow them. When the client is a different width the rows it has
 * to show are placed one by one instead, and only the history reflows.
 *   - Rc client rows, Rp screen rows. The screen always ends on the client's last row.
 *   - A client shorter than the screen sees as much of it as fits with the cursor in view. Only a viewer can be that short.
 *   - In place (`client.alt` known): the terminal is in whatever state the output left it, so it starts by going back to
 *     defaults, and every mode is then stated rather than only those the session set. `client.keepMain` says its main screen
 *     is whole, so a program's alternate screen is all that needs drawing.
 *   - Over its screen (`client.overScreen`): the terminal still shows the screen it had when the history it holds ends, so the rows
 *     from `historyFrom` are written over it from its top, and what does not fit scrolls into its scrollback as it would have.
 * @param {JoinOptions} o @returns {Buffer}
 */
function buildTrackingJoin({ emulator, tracker, banner = () => null, client, historyLimit, historyFrom = 0 }) {
  const b = emulator.term.buffer.normal;
  const Rc = client.rows;
  const Rp = emulator.rows;
  const Cp = emulator.cols;
  const Dc = Rc - Rp;
  const scr = b.baseY;
  const h0 = firstHistoryRow(b, scr, historyLimit, historyFrom);
  const same = client.cols === Cp;
  const skip = Math.min(Math.max(0, -Dc), Math.max(0, b.cursorY + 1 - Rc));   // rows off the top, which become history
  const shownEnd = scr + skip + Math.min(Rp, Rc);
  const line = banner(scr - h0);
  const inPlace = client.alt !== undefined;
  const alt = emulator.term.buffer.active.type === 'alternate';
  const drawMain = !(client.keepMain && alt);
  const overScreen = client.overScreen === true && same && Rc === Rp && !alt;
  let o = '\x1b[?2026l';                                    // a connection can die in the middle of a synchronized frame
  if (inPlace) o += `${client.alt ? '\x1b[?1049l' : ''}${DEFAULTS_NOW}`;
  o += '\x1b[?25l\x1b[0m\x1b[r';
  if (overScreen) o += `${cup(1, 1)}\x1b[J`;                                // below the cursor only: the scrollback is never touched
  else if (drawMain) o += cup(Rc, 1) + '\n'.repeat(client.cursorRow ?? Rc) + cup(1, 1);
  if (drawMain && !overScreen && line) o += `${dim(line)}\r\n`;
  if (!drawMain) {
    // the terminal's main screen stays exactly as it is
  } else if (same) {
    const pad = overScreen ? 0 : Rc - (line ? 1 : 0) - (shownEnd - h0);
    o += '\r\n'.repeat(Math.max(0, pad)) + serializeFlow(b, h0, shownEnd, Cp);
  } else {
    if (scr + skip > h0) o += `${serializeFlow(b, h0, scr + skip, Cp)}\r\n`;
    o += '\r\n'.repeat(Math.max(0, Rc - 1 - Math.max(0, Dc)));
    const screen = serializeRows(b, scr + skip, shownEnd, { maxCols: client.cols });
    for (let i = 0; i < screen.length; i++) o += cup(Math.max(0, Dc) + 1 + i, 1) + '\x1b[2K' + screen[i];
  }
  const clampRow = (/** @type {number} */ r) => Math.min(Rc, Math.max(1, r));
  /** absolute emulator line -> client row */
  const toClientRow = (/** @type {number} */ absY) => clampRow(absY - scr - skip + Math.max(0, Dc) + 1);
  const m = tracker.modes;
  const { top, bottom } = emulator.margins();
  const margined = top !== 0 || bottom !== Rp - 1;
  const shift = alt ? 0 : Math.max(0, Dc);
  const origin = m.raw(ORIGIN_MODE) === 1;
  /** A client row, as a cursor move has to say it: origin mode counts from the top margin. @param {number} row */
  const moveRow = (row) => (origin && margined ? Math.max(1, row - (top + shift)) : row);
  /** Where the cursor goes. @param {number} row @param {number} col */
  const place = (row, col) => {
    let s = '';
    if (margined) s += `\x1b[${top + 1 + shift};${bottom + 1 + shift}r`;
    if (origin) s += `\x1b[?${ORIGIN_MODE}h`;
    return s + cup(moveRow(row), col);
  };
  if (alt) {
    const a = emulator.term.buffer.alternate;
    const sn = emulator.saved.normal ?? { x: b.cursorX, y: b.baseY + b.cursorY };
    o += cup(toClientRow(sn.y), Math.min(sn.x, Cp - 1) + 1) + '\x1b[?1049h';    // ?1049h saves THIS position in the normal slot
    const altRows = serializeRows(a, a.baseY, a.baseY + Math.min(Rp, Rc), { maxCols: client.cols });   // it gains history when rows shrink
    for (let i = 0; i < altRows.length; i++) o += cup(i + 1, 1) + '\x1b[2K' + altRows[i];   // alt is top-aligned: no Δ
    if (emulator.saved.alternate) o += cup(clampRow(emulator.saved.alternate.y - a.baseY + 1), emulator.saved.alternate.x + 1) + '\x1b7';
    o += place(clampRow(a.cursorY + 1), Math.min(a.cursorX, Cp - 1) + 1);
    o += pendingWrap(a, a.cursorX, a.cursorY, Cp, moveRow(clampRow(a.cursorY + 1)));
  } else {
    if (emulator.saved.normal) o += cup(toClientRow(emulator.saved.normal.y), Math.min(emulator.saved.normal.x, Cp - 1) + 1) + '\x1b7';   // the nested ?1049l window
    const row = toClientRow(b.baseY + b.cursorY);
    o += place(row, Math.min(b.cursorX, Cp - 1) + 1);
    if (same) o += pendingWrap(b, b.cursorX, b.baseY + b.cursorY, Cp, moveRow(row));
  }
  o += modeBytes(m, ALL_MODES, inPlace);
  if (m.keypad) o += '\x1b=';
  if (m.cursorStyle !== null) o += `\x1b[${m.cursorStyle} q`;
  if (tracker.title) o += `\x1b]0;${tracker.title}\x07`;
  o += '\x1b[0m';
  for (const p of tracker.pen) o += `\x1b[${p}m`;
  o += m.raw(25) === 2 ? '\x1b[?25l' : '\x1b[?25h';
  return Buffer.from(o, 'utf8');
}

/**
 * Where the main screen starts in the emulator's buffer, and where the cursor is on it, for a terminal exactly the pty's size.
 * @param {import('./emulator').Emulator} emulator @param {import('./tracker').Tracker} tracker
 */
function mainScreen(emulator, tracker) {
  const b = emulator.term.buffer.normal;
  const top = emulator.tracking ? b.baseY : b.length - emulator.rows + (emulator.rows - tracker.screenRows);
  return { b, top, rows: tracker.screenRows, cursorRow: b.baseY + b.cursorY - top, cursorCol: b.cursorX };
}

/**
 * What puts the cursor, the pen and the cursor's visibility back as they were, after something of nmux's own has been drawn.
 * @param {import('./emulator').Emulator} emulator @param {import('./tracker').Tracker} tracker
 */
function putBack(emulator, tracker) {
  const { cursorRow, cursorCol } = mainScreen(emulator, tracker);
  let o = '\x1b[0m';
  for (const p of tracker.pen) o += `\x1b[${p}m`;
  o += cup(cursorRow + 1, cursorCol + 1);
  return o + (tracker.modes.raw(25) === 2 ? '' : '\x1b[?25h');
}

/**
 * The main screen written over where it is, for a terminal that shows it already and is exactly its size. Nothing reaches the terminal's
 * scrollback except `lineAbove`, which goes in by scrolling once, as a line of its own above the screen.
 * @param {{emulator: import('./emulator').Emulator, tracker: import('./tracker').Tracker, lineAbove?: string|null}} o @returns {Buffer}
 */
function buildRedraw({ emulator, tracker, lineAbove = null }) {
  const { b, top, rows } = mainScreen(emulator, tracker);
  let o = '\x1b[?25l\x1b[0m';
  if (lineAbove) o += `${cup(1, 1)}\x1b[2K${dim(lineAbove)}${cup(rows, 1)}\n`;
  const screen = serializeRows(b, top, top + rows);
  for (let i = 0; i < screen.length; i++) o += `${cup(i + 1, 1)}\x1b[2K${screen[i]}`;
  return Buffer.from(o + putBack(emulator, tracker), 'utf8');
}

/**
 * A cursor just past the last column means the next character wraps. No cursor movement can say that, so the last cell
 * is written again, which puts the terminal in the same state.
 * @param {any} buffer @param {number} x cursor column @param {number} y line of the cursor @param {number} cols @param {number} row client row
 */
function pendingWrap(buffer, x, y, cols, row) {
  if (x < cols) return '';
  const line = buffer.getLine(y);
  if (!line) return '';
  const cell = buffer.getNullCell();
  line.getCell(cols - 1, cell);
  const wide = cell.getWidth() === 0;
  if (wide) line.getCell(cols - 2, cell);
  return `${cup(row, wide ? cols - 1 : cols)}\x1b[0${attrKey(cell) ? `;${attrKey(cell)}` : ''}m${cell.getChars() || ' '}\x1b[0m`;
}

/**
 * Sends a join snapshot with flow control instead of the live queue cap : SNAPSHOT_BEGIN, the bytes in
 * chunkBytes pieces awaiting drain, SNAPSHOT_END; 'timeout' if not done within timeoutMs.
 * An in-place resync (`framed: false`) goes out as plain output with no time limit: the client never left.
 * @param {{client: {send: (type: number, payload: Buffer|object) => void, writableLength: () => number, drained: () => Promise<void>},
 *   bytes: Buffer, chunkBytes: number, timeoutMs: number, clock: import('../../base/types').Clock, lines?: number, truncatedBefore?: number|null, framed?: boolean}} o
 * @returns {Promise<'ok'|'timeout'>}
 */
function sendSnapshot({ client, bytes, chunkBytes, timeoutMs, clock, lines = 0, truncatedBefore = null, framed = true }) {
  return new Promise((resolve) => {
    let done = false;
    const timer = framed ? clock.setTimeout(() => { if (!done) { done = true; resolve('timeout'); } }, timeoutMs) : null;
    (async () => {
      if (framed) client.send(T.CONTROL, { t: 'SNAPSHOT_BEGIN', lines, truncatedBefore });
      for (let i = 0; i < bytes.length && !done; i += chunkBytes) {
        client.send(T.OUTPUT, bytes.subarray(i, i + chunkBytes));
        if (client.writableLength() >= chunkBytes) await client.drained();
      }
      if (done) return;
      if (framed) client.send(T.CONTROL, { t: 'SNAPSHOT_END' });
      done = true;
      if (timer !== null) clock.clearTimeout(timer);
      resolve('ok');
    })();
  });
}

module.exports = { buildJoinBytes, buildRedraw, mainScreen, putBack, sendSnapshot, joinGeometry, modeBytes };
