'use strict';
// @ts-check
/** @typedef {{now(): number, setTimeout(fn: () => void, ms: number): any, clearTimeout(h: any): void}} Clock */
module.exports = {};
