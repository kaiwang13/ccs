'use strict';
// @ts-check
const { Lexer } = require('../vt/lexer.js');
const { ModeState } = require('../vt/modes.js');
const { Ring } = require('./ring');
const { Responder } = require('./responder');

/** The child's output as the holder keeps it: the ring, the resize log, and answers to terminal queries. */
class Feed {
  /**
   * @param {{ringBytes: number, size: {cols: number, rows: number}, colors: any, clock: import('../base/types').Clock,
   *   write: (b: Buffer) => void, forward: (kind: string, offset: number) => Promise<Buffer|null>}} o
   */
  constructor({ ringBytes, size, colors, clock, write, forward }) {
    this.ring = new Ring(ringBytes);
    this.modes = new ModeState();
    this.lexer = new Lexer();
    this.responder = new Responder({ modes: this.modes, clock, colors, write, forward });
    /** @type {Array<{offset: number, cols: number, rows: number}>} the spawn size plus the last 63 resizes */
    this.resizeLog = [{ offset: 0, cols: size.cols, rows: size.rows }];
  }

  /** @param {Buffer} buf */
  push(buf) {
    this.ring.push(buf);
    for (const tok of this.lexer.feed(buf).tokens) { this.modes.apply(tok); this.responder.onToken(tok); }
  }

  /** @param {number} cols @param {number} rows @returns {{offset: number, cols: number, rows: number}} */
  noteResize(cols, rows) {
    const entry = { offset: this.ring.end, cols, rows };
    this.resizeLog.push(entry);
    if (this.resizeLog.length > 64) this.resizeLog.splice(1, 1);                     // keep the spawn entry
    return entry;
  }
}

module.exports = { Feed };
