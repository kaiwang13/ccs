'use strict';
// @ts-check
const fs = require('node:fs');
const net = require('node:net');
const { spawn } = require('node:child_process');
const { ttyctl } = require('../platform/native.js');
const procinfo = require('../platform/procinfo.js');
const { T, HOLDER_PROTO, encodeData, decodeWrite, FramedSocket } = require('../wire/proto.js');
const { helloToWire } = require('../wire/holder-wire.js');

const HOLDER_VERSION = '0.2.0';
const DATA_CHUNK = 256 * 1024;
const SOCK_HIGH_WATER = 4 * 1024 * 1024;
/** What this holder can do beyond the base protocol. A server opts in when it attaches, so older ones keep working. */
const CAPS = Object.freeze(['flow']);
/** How often a paused holder looks for the child having gone: node-pty gives up on the pty 200 ms after that. */
const PAUSED_WATCH_MS = 40;

/**
 * pty.sock: one server at a time, same uid only. Also keeps a server around: starts one when nobody is connected, and
 * ends one that stops answering.
 *
 * Flow control: the server acknowledges what it has parsed, and the holder stops reading the pty once `flowHighBytes` are
 * unacknowledged, so a slow server slows the child down instead of losing output. The same limit covers the moments with
 * no server at all, at startup and during a restart, because those are when output would otherwise be overwritten unread.
 * Only a server can do that, never a client, and never for long: no ACK for `drainAfterMs` and the holder drains into the
 * ring as if flow control did not exist. A dead server can never hang the child. A server from an older release does not
 * ask for flow control when it attaches, and gets none.
 */
class HolderServer {
  /**
   * @param {{spec: any, sockPath: string, clock: import('../base/types').Clock, timers: any, log: any, child: import('./child').PtyChild,
   *   feed: import('./feed').Feed, queue: import('./writequeue').WriteQueue, onRelease: () => void}} o
   */
  constructor({ spec, sockPath, clock, timers, log, child, feed, queue, onRelease }) {
    this.spec = spec;
    this.sockPath = sockPath;
    this.clock = clock;
    this.timers = timers;
    this.log = log;
    this.child = child;
    this.feed = feed;
    this.queue = queue;
    this.onRelease = onRelease;
    /** @type {FramedSocket|null} */
    this.conn = null;
    this.connPid = 0;
    /** @type {string|null} */
    this.connStart = null;
    this.attached = false;
    this.sentOffset = 0;
    /** cleared only by a server that attached without asking for flow control */
    this.flow = true;
    /** everything before this offset has been parsed */
    this.ackedOffset = 0;
    this.lastAckAt = clock.now();
    /** reading from the pty is paused */
    this.paused = false;
    /** the server went quiet while paused: nothing pauses again until it acknowledges something */
    this.draining = false;
    this.exitSent = false;
    /** @type {any} */ this.flowTimer = null;
    this.lastPongAt = clock.now();
    this.pingSeq = 0;
    this.pingDue = clock.now();
    /** set once SIGTERM arrived: no new server is started from here on */
    this.closing = false;
    /** @type {any} */ this.stuckTimer = null;
    /** @type {any} */ this.noConnTimer = null;
    /** @type {any} */ this.orphanTimer = null;
    /** @type {any} */ this.pingTimer = null;
    /** @type {number[]} */
    this.spawnTimes = [];
    this.spawnIndex = 0;
    this.gaveUp = false;
    this.connectedAt = clock.now();
    this.shortLived = 0;
    this.pausedAt = 0;
    this.queryId = 0;
    /** @type {Map<number, (b: Buffer|null) => void>} */
    this.pendingQueries = new Map();
    /** @type {net.Server|null} */
    this.server = null;
  }

  /** @param {object} obj */
  send(obj) { if (this.conn) this.conn.sendControl(obj); }

  /** Asks the attached server to answer a terminal query. @param {string} kind @param {number} offset @returns {Promise<Buffer|null>} */
  forwardQuery(kind, offset) {
    return new Promise((resolve) => {
      if (!this.conn || !this.attached) { resolve(null); return; }
      const id = ++this.queryId;
      this.pendingQueries.set(id, resolve);
      this.clock.setTimeout(() => { if (this.pendingQueries.delete(id)) resolve(null); }, 1000);
      this.send({ t: 'QUERY_FWD', id, kind, offset });
    });
  }

  /** Sends what the attached server has not seen yet, then the child's exit: that must not overtake its last output. */
  pump() {
    const { conn } = this;
    const { ring } = this.feed;
    if (!conn || !this.attached) { this._flow(); return; }
    while (this.sentOffset < ring.end && conn.writableLength < SOCK_HIGH_WATER) {
      const r = ring.readFrom(this.sentOffset, DATA_CHUNK);
      if (r.gap) this.send({ t: 'GAP', from: r.gap.from, to: r.gap.to });
      conn.send(T.DATA, encodeData(r.offset, r.bytes));
      this.sentOffset = r.offset + r.bytes.length;
    }
    if (conn.writableLength >= SOCK_HIGH_WATER) {
      if (this.stuckTimer === null) this.stuckTimer = this.clock.setTimeout(() => {
        this.stuckTimer = null;
        if (this.conn && this.conn.writableLength >= SOCK_HIGH_WATER) { this.log.warn('sessiond.stuck'); this._endServer(); }
      }, this.timers.stuckMs);
    } else if (this.stuckTimer !== null) { this.clock.clearTimeout(this.stuckTimer); this.stuckTimer = null; }
    if (this.child.exit && !this.exitSent && this.sentOffset >= ring.end) { this.exitSent = true; conn.sendControl(this.child.exit); }
    this._flow();
  }

  // ---- flow control ------------------------------------------------------------------------------------------------
  _flow() {
    const { high, low } = this.flowLimits();
    const unparsed = this.feed.ring.end - this.ackedOffset;
    if (!this.flow || this.draining || this.child.exit) { this._resumeChild(); return; }
    if (!this.paused && unparsed >= high) this._pauseChild();
    else if (this.paused && unparsed <= low) this._resumeChild();
  }

  flowLimits() {
    const high = Math.min(this.timers.flowHighBytes, Math.floor(this.feed.ring.capacity / 2));
    return { high, low: Math.floor(high / 2) };
  }

  _pauseChild() {
    this.paused = true;
    this.pausedAt = this.clock.now();
    this.child.pause();
    this._armFlowTimer();
  }

  _resumeChild() {
    if (!this.paused) return;
    this.paused = false;
    this.child.resume();
    if (this.flowTimer !== null) { this.clock.clearTimeout(this.flowTimer); this.flowTimer = null; }
  }

  _armFlowTimer() {
    this.flowTimer = this.clock.setTimeout(() => {
      this.flowTimer = null;
      if (!this.paused) return;
      if (procinfo.procState(this.child.pid) !== 'alive') { this._resumeChild(); return; }   // read what it left behind
      if (this.clock.now() - Math.max(this.lastAckAt, this.pausedAt) >= this.timers.drainAfterMs) {
        this.log.warn('flow.server_quiet', { unparsed: this.feed.ring.end - this.ackedOffset });
        this.draining = true;
        this._resumeChild();
        return;
      }
      this._armFlowTimer();
    }, PAUSED_WATCH_MS);
  }

  // ---- keeping a server around -------------------------------------------------------------------------------------
  /** @param {number} ms */
  _armNoConn(ms) {
    if (this.noConnTimer !== null) this.clock.clearTimeout(this.noConnTimer);
    this.noConnTimer = this.clock.setTimeout(() => { this.noConnTimer = null; if (!this.conn) this._spawnServer(); }, ms);
  }

  _spawnServer() {
    const { clock, timers, log } = this;
    const cmd = this.spec.sessiondCmd;
    if (this.gaveUp || this.conn || this.closing || cmd.length === 0) return;
    const now = clock.now();
    this.spawnTimes = this.spawnTimes.filter((t) => now - t < timers.giveUpWindowMs);
    if (this.spawnTimes.length >= timers.giveUpCount) { this.gaveUp = true; log.error('SESSIOND_GAVE_UP', { spawns: this.spawnTimes.length }); return; }
    this.spawnTimes.push(now);
    try {
      const child = spawn(cmd[0], cmd.slice(1), { detached: true, stdio: 'ignore', env: process.env, cwd: '/' });
      child.on('error', (e) => log.warn('sessiond.spawn_error', { error: e.message }));
      child.unref();
      log.info('sessiond.spawn', { pid: child.pid, attempt: this.spawnTimes.length });
    } catch (e) { log.warn('sessiond.spawn_error', { error: String(/** @type {Error} */ (e).message) }); }
    this._armNoConn(timers.backoffMs[Math.min(this.spawnIndex, timers.backoffMs.length - 1)]);   // still nobody after the backoff: again
    this.spawnIndex++;
  }

  _endServer() {
    if (this.connPid > 0 && this.connStart && procinfo.procStart(this.connPid) === this.connStart) {
      try { process.kill(this.connPid, 'SIGTERM'); } catch { /* gone */ }
    }
    if (this.conn) this.conn.destroy();
  }

  /** The child is gone: nobody may be left waiting for a server that will never come. */
  armOrphanTimer() {
    if (this.orphanTimer !== null) { this.clock.clearTimeout(this.orphanTimer); this.orphanTimer = null; }
    if (this.child.exit && !this.conn) this.orphanTimer = this.clock.setTimeout(() => { this.log.info('exit.orphaned'); this.onRelease(); }, this.timers.orphanExitMs);
  }

  // ---- pty.sock ----------------------------------------------------------------------------------------------------
  async listen() {
    try { fs.unlinkSync(this.sockPath); } catch { /* not there */ }
    const server = net.createServer((sock) => this._accept(sock));
    this.server = server;
    await new Promise((resolve, reject) => { server.once('error', reject); server.listen(this.sockPath, () => resolve(undefined)); });
    fs.chmodSync(this.sockPath, 0o600);
    this._armNoConn(this.timers.noConnMs);
    this.pingDue = this.clock.now() + this.timers.pingMs;
    this.pingTimer = this.clock.setTimeout(() => this._heartbeat(), this.timers.pingMs);
  }

  _heartbeat() {
    this.lastPongAt += Math.max(0, this.clock.now() - this.pingDue);                   // time this process lost is not the server's silence
    this.pingDue = this.clock.now() + this.timers.pingMs;
    this.pingTimer = this.clock.setTimeout(() => this._heartbeat(), this.timers.pingMs);
    if (!this.conn) return;
    if (this.clock.now() - this.lastPongAt > this.timers.pongTimeoutMs) { this.log.warn('sessiond.pong_timeout'); this._endServer(); return; }
    this.conn.sendControl({ t: 'PING', seq: ++this.pingSeq });
  }

  /** @param {net.Socket} sock */
  _accept(sock) {
    const { clock, child, feed } = this;
    const fsock = new FramedSocket(sock);
    fsock.on('error', () => {});
    let uid = -1;
    try { uid = ttyctl.peerUid(fsock.fd); } catch { /* treated as foreign */ }
    if (uid !== /** @type {() => number} */ (process.getuid)()) { fsock.sendControl({ t: 'ERR', code: 'FORBIDDEN' }); fsock.end(); return; }
    if (this.conn) { fsock.sendControl({ t: 'ERR', code: 'BUSY' }); fsock.end(); return; }
    this.conn = fsock; this.attached = false; this.connPid = 0; this.connStart = null; this.lastPongAt = clock.now();
    this.connectedAt = clock.now();
    this.gaveUp = false;
    if (this.noConnTimer !== null) { clock.clearTimeout(this.noConnTimer); this.noConnTimer = null; }
    if (this.orphanTimer !== null) { clock.clearTimeout(this.orphanTimer); this.orphanTimer = null; }
    this.spawnIndex = 0;
    fsock.sendControl(helloToWire({ t: 'H_HELLO', proto: HOLDER_PROTO, holderVersion: HOLDER_VERSION, gen: this.spec.gen, pid: process.pid, procStart: procinfo.procStart(process.pid),
      child: { pid: child.pid, procStart: child.start }, pty: child.size, ring: { start: feed.ring.start, end: feed.ring.end }, resizeLog: feed.resizeLog, exited: child.exit, ptsName: child.ptsName, caps: CAPS }));
    if (child.lastLflag) fsock.sendControl(JSON.parse(child.lastLflag));
    sock.on('drain', () => this.pump());
    fsock.on('frame', (/** @type {{type: number, payload: any}} */ f) => {
      if (f.type === T.WRITE) { const w = decodeWrite(f.payload); this.queue.enqueue(Buffer.from(w.bytes), { loneEsc: w.loneEsc, watchId: w.watchId }); return; }
      if (f.type === T.CONTROL) this._control(fsock, f.payload);
    });
    fsock.on('close', () => {
      if (this.conn !== fsock) return;
      const lived = clock.now() - this.connectedAt;
      this.conn = null; this.attached = false;
      this._flow();
      for (const [, r] of this.pendingQueries) r(null);
      this.pendingQueries.clear();
      this.log.info('sessiond.disconnected');
      this.shortLived = lived >= this.timers.stableMs ? 0 : this.shortLived + 1;
      if (!this.closing) this._armNoConn(this.shortLived > 1 ? this.timers.noConnMs : this.timers.respawnMs);   // one that keeps crashing is no emergency
      this.armOrphanTimer();
    });
  }

  /** @param {FramedSocket} fsock @param {any} m */
  _control(fsock, m) {
    const { child } = this;
    switch (m.t) {
      case 'ATTACH':
        this.connPid = Number(m.pid) || 0;
        this.connStart = this.connPid ? procinfo.procStart(this.connPid) : null;
        this.sentOffset = Math.max(0, Number(m.fromOffset) || 0);
        this.flow = m.flow === true;
        this.ackedOffset = Math.max(this.sentOffset, this.feed.ring.start);
        this.lastAckAt = this.clock.now();
        this.draining = false;
        this.exitSent = false;
        this.attached = true;
        this.pump();
        break;
      case 'ACK': {
        const offset = Number(m.offset) || 0;
        if (offset > this.ackedOffset) this.ackedOffset = offset;
        this.lastAckAt = this.clock.now();
        this.draining = false;
        this._flow();
        break;
      }
      case 'RESIZE': {
        if (child.exit || child.hangingUp) break;                                           // its master is closed: there is no size to set
        const cols = Math.max(1, Math.min(500, Number(m.cols) | 0));
        const rows = Math.max(1, Math.min(500, Number(m.rows) | 0));
        child.resize(cols, rows);
        fsock.sendControl({ t: 'RESIZED', ...this.feed.noteResize(cols, rows) });
        break;
      }
      case 'SIGNAL':
        if (m.sig !== 'SIGCONT' && m.sig !== 'SIGTERM') { fsock.sendControl({ t: 'ERR', code: 'FORBIDDEN', sig: m.sig }); break; }
        child.signal(m.sig);
        break;
      case 'CLOSE_MASTER': child.hangUp(); break;
      case 'RELEASE': if (child.exit) this.onRelease(); break;
      case 'QUERY_REPLY': {
        const r = this.pendingQueries.get(m.id);
        if (r) { this.pendingQueries.delete(m.id); r(typeof m.bytes === 'string' && m.bytes ? Buffer.from(m.bytes, 'base64') : null); }
        break;
      }
      case 'PING': fsock.sendControl({ t: 'PONG', seq: m.seq }); break;
      case 'PONG': this.lastPongAt = this.clock.now(); break;
      default: break;
    }
  }

  /** Stops listening at once, so nothing can connect to a holder on its way out. */
  close() {
    try { if (this.server) this.server.close(); } catch { /* already closed */ }
    for (const t of [this.pingTimer, this.noConnTimer, this.orphanTimer, this.stuckTimer, this.flowTimer]) if (t !== null) this.clock.clearTimeout(t);
  }
}

module.exports = { HolderServer };
