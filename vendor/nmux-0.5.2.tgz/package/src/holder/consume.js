'use strict';
// @ts-check
const { ttyctl } = require('../platform/native.js');

/**
 * Tells when bytes written to the child have been read by it. TIOCINQ reads 0 on the master, so this needs a slave fd,
 * held only while something is being watched.
 */
class ConsumeWatcher {
  /**
   * @param {{child: import('./child').PtyChild, written: () => number, clock: import('../base/types').Clock, pollMs: number, log: any,
   *   onConsumed: (watchId: number) => void, onEscConsumed: () => void}} o
   */
  constructor({ child, written, clock, pollMs, log, onConsumed, onEscConsumed }) {
    this.child = child;
    this.written = written;
    this.clock = clock;
    this.pollMs = pollMs;
    this.log = log;
    this.onConsumed = onConsumed;
    this.onEscConsumed = onEscConsumed;
    /** @type {Array<{id: number, end: number, esc: boolean}>} */
    this.watches = [];
    this.slaveFd = -1;
    /** @type {any} */
    this.timer = null;
  }

  /** @param {number} watchId 0 for none @param {number} end stream end after the write @param {boolean} loneEsc */
  add(watchId, end, loneEsc) {
    if (watchId) this.watches.push({ id: watchId, end, esc: false });
    if (loneEsc) this.watches.push({ id: 0, end, esc: true });
    if ((watchId || loneEsc) && this.timer === null) this.timer = this.clock.setTimeout(() => this._poll(), 0);
  }

  _poll() {
    this.timer = null;
    try {
      if (this.watches.length === 0 || this.child.exit) return;
      if (this.slaveFd < 0) this.slaveFd = ttyctl.openSlave(this.child.ptsName);
      const consumed = this.written() - this.child.backlog() - ttyctl.inq(this.slaveFd);
      const still = [];
      for (const w of this.watches) {
        if (w.end <= consumed) { if (w.esc) this.onEscConsumed(); else this.onConsumed(w.id); }
        else still.push(w);
      }
      this.watches = still;
    } catch (e) {
      this.log.warn('watch.poll_failed', { error: String(e && /** @type {Error} */ (e).message) });
    } finally {
      if (this.watches.length === 0 || this.child.exit) this._closeSlave();          // never hold the slave fd past its need
      else this.timer = this.clock.setTimeout(() => this._poll(), this.pollMs);
    }
  }

  _closeSlave() {
    if (this.slaveFd >= 0) { try { ttyctl.closeFd(this.slaveFd); } catch { /* already closed */ } this.slaveFd = -1; }
  }

  stop() {
    this.watches = [];
    if (this.timer !== null) { this.clock.clearTimeout(this.timer); this.timer = null; }
    this._closeSlave();
  }
}

module.exports = { ConsumeWatcher };
