'use strict';
// @ts-check
const fs = require('node:fs');
const path = require('node:path');
const { sessionLayout } = require('../wire/layout.js');
const { tryLock } = require('../platform/locks.js');
const { createLogger } = require('../base/log.js');
const { realClock } = require('../base/clock.js');
const procinfo = require('../platform/procinfo.js');
const platform = require('../platform/index.js');
const { WriteQueue } = require('./writequeue');
const { PtyChild } = require('./child');
const { ConsumeWatcher } = require('./consume');
const { Feed } = require('./feed');
const { HolderServer } = require('./server');

const DEFAULT_TIMERS = Object.freeze({
  noConnMs: 5000, respawnMs: 250, stableMs: 10000, pingMs: 5000, pongTimeoutMs: 30000, stuckMs: 30000, termWaitMs: 20000, orphanExitMs: 600000,
  backoffMs: [1000, 2000, 5000, 10000, 30000, 60000], giveUpCount: 10, giveUpWindowMs: 600000,
  lflagPollMs: 250, watchPollMs: 10, procPollMs: 200, exitGraceMs: 220,
  flowHighBytes: 2097152, drainAfterMs: 5000,
});

/** @param {any} o parsed holder spec @returns {any} */
function validateHolderSpec(o) {
  if (!o || o.schema !== 'nmux.holderspec/1') throw new Error('holder spec: schema must be "nmux.holderspec/1"');
  for (const k of ['id', 'cwd', 'runtimeDir']) if (typeof o[k] !== 'string' || !o[k]) throw new Error(`holder spec: ${k}`);
  if (!Array.isArray(o.argv) || o.argv.length === 0 || o.argv.some((a) => typeof a !== 'string')) throw new Error('holder spec: argv');
  if (!Array.isArray(o.sessiondCmd)) throw new Error('holder spec: sessiondCmd');
  if (!o.env || typeof o.env !== 'object') throw new Error('holder spec: env');
  for (const k of ['cols', 'rows', 'ringBytes', 'gen']) if (!Number.isInteger(o[k]) || o[k] < 0) throw new Error(`holder spec: ${k}`);
  return o;
}

/**
 * Independent evidence of a host shutdown: a bare SIGTERM is not enough.
 * Delegates to the platform seam: systemd on Linux, always-false on macOS. See the note there.
 * @param {{scheduledPath?: string, systemctl?: string}} [o]
 */
function shutdownCorroborated(o) {
  return platform.shutdownCorroborated(o);
}

/**
 * Runs the PTY holder for one child process. Resolves when the holder is done (the child exited and was released,
 * orphaned for too long, or SIGTERM); sets process.exitCode.
 * @param {string} specPath
 */
async function runHolder(specPath) {
  const spec = validateHolderSpec(JSON.parse(fs.readFileSync(specPath, 'utf8')));
  const timers = { ...DEFAULT_TIMERS, ...(spec.timers || {}) };
  const clock = realClock;
  const layout = sessionLayout(spec.runtimeDir);
  fs.mkdirSync(layout.sessionDir(spec.id), { recursive: true, mode: 0o700 });
  const taken = tryLock(layout.holderLock(spec.id));
  if (!taken) { process.exitCode = 3; return; }
  const lock = taken;
  const log = createLogger({ file: layout.logFile(spec.id, 'holder'), comp: 'holder', session: spec.id });
  process.on('SIGHUP', () => {});                                                      // ignored: a hangup must never end a session
  process.on('SIGINT', () => {});

  /** @type {() => void} */
  let done = () => {};
  const finished = new Promise((r) => { done = () => r(undefined); });

  const child = new PtyChild({ spec, clock, timers, log });
  /** @type {HolderServer} */
  let server;
  const consume = new ConsumeWatcher({ child, written: () => queue.writtenTotal, clock, pollMs: timers.watchPollMs, log,
    onConsumed: (watchId) => server.send({ t: 'CONSUMED', watchId }), onEscConsumed: () => queue.onConsumed() });
  const queue = new WriteQueue({
    clock,
    write: (b) => child.write(b),
    onOverflow: () => { log.warn('write.overflow'); server.send({ t: 'ERR', code: 'WRITE_OVERFLOW' }); },
    onEscHoldExpired: () => { log.warn('write.esc_hold_expired'); server.send({ t: 'ERR', code: 'ESC_HOLD_EXPIRED' }); },
    onWritten: (watchId, end, loneEsc) => consume.add(watchId, end, loneEsc),
    backlog: () => child.backlog(),
    dropBacklog: () => child.dropBacklog(),
  });
  const feed = new Feed({ ringBytes: spec.ringBytes, size: child.size, colors: spec.termColors || null, clock,
    write: (b) => queue.enqueue(b), forward: (kind, offset) => server.forwardQuery(kind, offset) });
  server = new HolderServer({ spec, sockPath: layout.ptySock(spec.id), clock, timers, log, child, feed, queue, onRelease: () => finish() });

  child.on('data', (buf) => { feed.push(buf); server.pump(); });
  child.on('lflag', (msg) => server.send(msg));
  child.on('exit', () => {
    consume.stop();
    server.pump();
    if (server.closing) { finish(); return; }
    server.armOrphanTimer();
  });

  await child.becomeLeader();
  fs.writeFileSync(layout.holderJson(spec.id), JSON.stringify({ schema: 'nmux.holder/1', pid: process.pid, procStart: procinfo.procStart(process.pid),
    child: { pid: child.pid, procStart: child.start }, ptsName: child.ptsName, gen: spec.gen }), { mode: 0o600 });
  log.info('spawn', { pid: child.pid, ptsName: child.ptsName, cols: spec.cols, rows: spec.rows, gen: spec.gen });
  child.watch();
  await server.listen();

  // SIGTERM: corroborate before believing it is a shutdown.
  process.on('SIGTERM', () => {
    if (server.closing) return;
    server.closing = true;
    child.shuttingDown = shutdownCorroborated();
    log.info('sigterm', { shuttingDown: child.shuttingDown });
    if (child.exit) { finish(); return; }
    clock.setTimeout(() => { log.warn('sigterm.child_still_alive'); finish(); }, timers.termWaitMs);
  });

  let finishing = false;
  function finish() {
    if (finishing) return;
    finishing = true;
    server.close();
    child.stopTimers();
    consume.stop();
    const end = () => {
      try { fs.unlinkSync(layout.ptySock(spec.id)); } catch { /* gone */ }
      if (!child.exit) child.destroy();
      lock.release();
      done();
    };
    if (server.conn) { server.conn.end(); clock.setTimeout(end, 50); } else end();
  }
  await finished;
}

module.exports = { runHolder, holderProcess, validateHolderSpec, shutdownCorroborated, DEFAULT_TIMERS };

/** The holder as the body of a process: `node src/holder/main.js --spec FILE`, or `nmux __holder --spec FILE`. @param {string[]} argv */
function holderProcess(argv) {
  const i = argv.indexOf('--spec');
  if (i < 0 || !argv[i + 1]) { process.stderr.write('usage: nmux __holder --spec <holder-spec.json>\n'); process.exit(2); }
  runHolder(path.resolve(argv[i + 1])).then(
    () => process.exit(process.exitCode ?? 0),
    (e) => { process.stderr.write(`holder: ${e && e.stack}\n`); process.exit(1); },
  );
}

if (require.main === module) holderProcess(process.argv.slice(2));
