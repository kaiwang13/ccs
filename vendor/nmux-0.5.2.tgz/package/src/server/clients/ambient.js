'use strict';
// @ts-check
const path = require('node:path');
const { barLine } = require('../output/bar');
const { buildRedraw, drawBar } = require('../output/snapshot');
const { dayOf, zone } = require('../../base/time');
const { commandLine } = require('../../platform/procinfo');

const TICK_MS = 1000;
/** A day line is drawn only once the session has been quiet this long. */
const QUIET_MS = 1500;
/** How soon a bar that output may have written over is drawn again, and how long until another try while output goes on. */
const BAR_SOON_MS = 30;

/** @typedef {import('./hub').Client & {barShown?: string, barRedraw?: boolean, day?: string}} Client */

/**
 * What is drawn into terminals beside the session's own output: nmux's bar on the last row of a terminal that asked for one, and
 * a line in its scrollback when a new day starts. Neither is part of the session, and neither ends up in a terminal's scrollback
 * by accident: the bar's row is below the scroll region, and a day line goes in above a screen that is then written over.
 *
 * The bar is drawn again when what it says changes, when output may have written over it, and when the terminal has changed size.
 * It is drawn where the emulator has got to everything sent to the terminal, so that what the program had set can be put back after
 * it exactly; while output goes on, that is tried again a moment later.
 */
class Ambient {
  /**
   * @param {{hub: import('./hub').ClientHub, config: any, clock: import('../../base/types').Clock, wallNow?: () => number}} o
   */
  constructor({ hub, config, clock, wallNow = Date.now }) {
    this.hub = hub;
    this.overlay = config.overlay || {};
    this.keys = config.keys;
    this.clock = clock;
    this.wallNow = wallNow;
    this.timeZone = zone(this.overlay.timeZone || process.env.TZ);
    /** @type {Set<Client>} terminals whose bar is to be drawn again */
    this.due = new Set();
    /** @type {any} */
    this.soon = null;
    this.drawing = false;
    /** @type {{pid: number|null, name: string|null}} what the terminal's foreground process was called, when it was asked */
    this.foreground = { pid: null, name: null };
    /** @type {any} */
    this.timer = null;
    this._schedule();
  }

  _schedule() {
    this.timer = this.clock.setTimeout(() => {
      this.tick()
        .catch((e) => this.hub.log.warn('ambient.failed', { error: String(e && e.message) }))   // a bar is never worth a session
        .finally(() => { if (this.timer !== null) this._schedule(); });
    }, TICK_MS);
  }

  dispose() {
    if (this.timer !== null) this.clock.clearTimeout(this.timer);
    if (this.soon !== null) this.clock.clearTimeout(this.soon);
    this.timer = null;
    this.soon = null;
  }

  /** Output may have written over this terminal's bar. @param {Client} c */
  barHit(c) {
    this.due.add(c);
    this._drawSoon(BAR_SOON_MS);
  }

  /**
   * The terminal changed size, or its bar came or went: the screen is written over once the sizes agree, so that the terminal shows
   * it where the emulator has it, and the bar is drawn under it if it has one. @param {Client} c @param {boolean} [toggled] the bar came or went
   */
  moved(c, toggled = false) {
    if (!c.adapter.bar && !toggled) return;
    c.barRedraw = true;
    this.barHit(c);
  }

  /** What the program in front of the session's shell is called, or null when the shell itself is in front. */
  running() {
    const { session } = this.hub;
    const fg = session.fg;
    const child = session.hello ? session.hello.child.pid : null;
    if (!fg || fg === child) return null;
    if (this.foreground.pid !== fg) {
      const command = commandLine(fg);
      const first = command ? command.split(' ')[0] : '';
      this.foreground = { pid: fg, name: first ? path.basename(first).replace(/^-/, '') : null };
    }
    return this.foreground.name;
  }

  /** What a terminal's bar says now. @param {Client} c */
  barFor(c) {
    const { session } = this.hub;
    return barLine({ brand: this.hub.messages.brand, name: session.name, running: this.running(), clients: this.hub.clients.length, now: this.wallNow(),
      timeZone: this.timeZone, keys: { leader: this.keys.leader, bindings: this.keys.bindings || {}, direct: this.keys.direct || {} },
      truecolor: !!(c.hello.flags && c.hello.flags.truecolor) }, c.adapter.cols);
  }

  async tick() {
    for (const c of /** @type {Client[]} */ (this.hub.clients)) if (c.adapter.bar && this._live(c) && c.barShown !== this.barFor(c)) this.due.add(c);
    if (this.due.size) this._drawSoon(0);
    if (this.overlay.dayLines) await this._dayLines();
  }

  /** @param {Client} c */
  _live(c) { return !c.closed && !c.joining && c.adapter.phase === 'LIVE' && !c.adapter.behind; }

  /** @param {number} ms */
  _drawSoon(ms) {
    if (this.soon !== null) return;
    this.soon = this.clock.setTimeout(() => {
      this.soon = null;
      this._draw().catch((e) => this.hub.log.warn('ambient.failed', { error: String(e && e.message) }));
    }, ms);
  }

  /** The bars that are due, where the emulator has everything that went to the terminals. */
  async _draw() {
    if (this.drawing) return;
    this.drawing = true;
    try {
      const { session } = this.hub;
      const last = session.lastChunk;
      await session.emulator.tail;
      const settled = session.lastChunk === last && (!last || last.groundAfter) && (!session.pipeline || session.pipeline.quiescent);
      if (!settled) { this._drawSoon(BAR_SOON_MS); return; }
      let later = false;
      for (const c of [...this.due]) {
        if (c.closed || (!c.adapter.bar && !c.barRedraw)) { this.due.delete(c); continue; }
        if (!this._live(c)) continue;                                                    // a join draws it
        const a = c.adapter;
        const { tracking } = session.emulator;
        // no new size is coming for the pty, and the output has got to where it took the one it has
        const caughtUp = !(this.hub.arbiter && this.hub.arbiter.pending)
          && session.tracker.ptyCols === session.pty.cols && session.tracker.ptyRows === session.pty.rows
          && (!tracking || session.emulator.rows === session.pty.rows);
        if (c.barRedraw && !caughtUp) { later = true; continue; }
        // a terminal the pty's size is written over if the emulator tracks it; a program that repaints, which a fixed emulator is
        // for, repaints it itself, and a terminal of another size, one the session is limited below, cannot be written over
        const exact = a.cols === session.pty.cols && a.rows === session.pty.rows;
        const redraw = c.barRedraw && exact && tracking && !session.tracker.alt ? buildRedraw({ emulator: session.emulator, tracker: session.tracker }).toString('utf8') : '';
        const line = a.bar ? this.barFor(c) : '';
        a.underneath(Buffer.from(redraw + (a.bar ? drawBar({ emulator: session.emulator, tracker: session.tracker, rows: a.rows, cols: session.pty.cols, line }) : '')));
        c.barShown = line;
        c.barRedraw = false;
        this.due.delete(c);
      }
      if (later) this._drawSoon(BAR_SOON_MS * 4);
    } finally {
      this.drawing = false;
    }
  }

  /** A line above the screen of each terminal that has seen a day end, once the session is quiet. */
  async _dayLines() {
    const { session } = this.hub;
    if (this.clock.now() - session.lastOutputAt < QUIET_MS) return;
    await session.emulator.tail;
    if (this.clock.now() - session.lastOutputAt < QUIET_MS || !this._writable()) return;
    const day = dayOf(this.wallNow(), this.timeZone);
    for (const c of /** @type {Client[]} */ (this.hub.clients)) {
      const a = c.adapter;
      if (!this._live(c) || c.fsock.writableLength > 0 || a.cols !== session.pty.cols || a.rows !== session.pty.rows) continue;
      if (c.day && c.day !== day.key) {
        const lineAbove = `── ${day.words} · ${this.timeZone} · ${session.name} ──`.slice(0, a.cols - 1);
        let bytes = buildRedraw({ emulator: session.emulator, tracker: session.tracker, lineAbove }).toString('utf8');
        if (a.bar) bytes += drawBar({ emulator: session.emulator, tracker: session.tracker, rows: a.rows, cols: session.pty.cols, line: this.barFor(c) });
        a.underneath(Buffer.from(bytes));
      }
      c.day = day.key;
    }
  }

  /** Whether writing the screen over now does exactly that and nothing else. */
  _writable() {
    const { emulator, tracker, pipeline } = this.hub.session;
    if (tracker.alt || (pipeline && !pipeline.quiescent) || tracker.modes.raw(2026) === 1 || tracker.modes.raw(6) === 1) return false;
    if (/** @type {any} */ (emulator.term).modes.insertMode) return false;
    const { top, bottom } = emulator.margins();
    return !emulator.tracking || (top === 0 && bottom === emulator.rows - 1);
  }
}

module.exports = { Ambient, QUIET_MS };
