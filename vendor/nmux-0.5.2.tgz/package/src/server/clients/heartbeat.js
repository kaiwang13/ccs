'use strict';
// @ts-check
/**
 * PING every pingMs; no PONG for stallMs → stalled (excluded from arbitration); dropMs → BYE STALLED.
 * @param {import('./hub').ClientHub} hub @param {import('./hub').Client} c
 */
function armHeartbeat(hub, c) {
  const { pingMs, stallMs, dropMs } = hub.config.clients;
  c.pingTimer = hub.clock.setTimeout(() => {
    c.pingTimer = null;
    if (c.closed) return;
    const silent = hub.clock.now() - c.lastPongAt;
    if (silent > dropMs) { hub.bye(c, 'STALLED', true, 'no heartbeat from this terminal'); return; }
    if (silent > stallMs && !c.adapter.stalled) {
      c.adapter.stalled = true;
      hub.log.warn('client.stalled', { client: c.id });
      if (hub.arbiter) hub.arbiter.onChange('stall');
      for (const o of hub.clients) if (o !== c) o.adapter.notice('info', 'CLIENT_STALLED', `${c.label} is not responding and no longer limits the size`);
      hub.broadcastState();
    }
    c.pingSeq += 1;
    c.fsock.sendControl({ t: 'PING', seq: c.pingSeq });
    armHeartbeat(hub, c);
  }, pingMs);
}

module.exports = { armHeartbeat };
