'use strict';
// @ts-check
/**
 * One session as a process: `node run.js --spec <session.json> [--recover] [--wait-for-client]`, or the same after `nmux __server`. The holder
 * restarts exactly this command when the server dies, which is why everything it needs is in the spec file.
 */
const fs = require('node:fs');
const path = require('node:path');
const { DEFAULTS, loadConfig } = require('./config');
const { messagesFrom } = require('./messages');
const { RemoteController } = require('./session/remote');
const { runSession } = require('./main');

const TOUCH_MS = 3600000;

/** Nothing in /tmp is safe from an age-based cleaner unless it keeps looking used. @param {string} dir */
function touchAll(dir) {
  const now = new Date();
  for (const name of fs.readdirSync(dir)) {
    try { fs.lutimesSync(path.join(dir, name), now, now); } catch { /* gone, or a socket that refuses */ }
  }
}

/** @param {string} file @returns {object|null} */
function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; }
}

/** An exit nobody needs to look at leaves nothing behind. @param {any} session @returns {boolean} */
function nothingToKeep(session) {
  const e = session.lastExit;
  return !e || e.cause === 'stopped' || (e.cause === 'exited' && e.code === 0);
}

/** @param {string[]} argv */
async function main(argv) {
  const i = argv.indexOf('--spec');
  if (i < 0 || !argv[i + 1]) { process.stderr.write('usage: nmux __server --spec <session.json> [--recover] [--wait-for-client]\n'); return 2; }
  const specFile = path.resolve(argv[i + 1]);
  const spec = JSON.parse(fs.readFileSync(specFile, 'utf8'));
  const dir = path.dirname(specFile);
  const toucher = setInterval(() => touchAll(dir), TOUCH_MS);
  toucher.unref();
  const config = spec.config ? { ...DEFAULTS, ...spec.config } : loadConfig(spec.configFile);
  const session = await runSession({ spec, config, messages: messagesFrom(spec.messages), recover: argv.includes('--recover'), waitForClient: argv.includes('--wait-for-client'),
    ...(spec.managed ? { controller: () => new RemoteController(spec.managed) } : {}),
    ...(spec.timers ? { timers: spec.timers } : {}), ...(spec.holderTimers ? { holderTimers: spec.holderTimers } : {}),
    initialState: spec.stateFile ? readJson(spec.stateFile) : null });
  clearInterval(toucher);
  if (!spec.managed && nothingToKeep(session)) {                                       // what stays is for whoever manages it to say
    fs.rmSync(dir, { recursive: true, force: true });
    fs.rmSync(path.join(spec.runtimeDir, 'log', spec.id), { recursive: true, force: true });
  }
  return 0;
}

/** The server as the body of a process: `node src/server/run.js …`, or `nmux __server …`. @param {string[]} argv */
function serverProcess(argv) {
  main(argv).then((code) => process.exit(code), (e) => {
    process.stderr.write(`nmux server: ${e && e.stack}\n`);
    process.exit(1);
  });
}

if (require.main === module) serverProcess(process.argv.slice(2));

module.exports = { main, serverProcess, nothingToKeep };
