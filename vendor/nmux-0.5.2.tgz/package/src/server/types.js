'use strict';
// @ts-check
/** @typedef {'STARTING'|'RUNNING'|'EXITED'|'STOPPING'|'STOPPED'|'STOP_STUCK'|'BLOCKED'|'RECOVERING'|string} Lifecycle a controller may add phases of its own */
module.exports = {};
