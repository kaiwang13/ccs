'use strict';
// @ts-check
/**
 * What a program may add to a session that is running something it understands. This base class is a plain session:
 * it is running as soon as the holder answers, and nothing is gated, intercepted or claimed.
 *
 * Every hook is either a fact about the session or a question with a default answer, so a controller can be moved out
 * of this process: what it does in return is a call on the Session (capture, write, signal, setPhase, publish, rename).
 */
class Controller {
  constructor() {
    /** @type {import('./session').Session} set by bind(), before any hook runs */
    this.session = /** @type {any} */ (null);
  }

  /** @param {import('./session').Session} session */
  bind(session) { this.session = session; }

  /** A holder connected, before any of its frames flow. @param {any} _hello */
  onHolder(_hello) {}
  /** Attached and streaming. */
  onAttached() { this.session.setPhase('RUNNING', { from: ['STARTING'] }); }
  /** A recovered session caught up with the holder's ring. */
  onReplayed() { this.session.setPhase('RUNNING', { from: ['STARTING'] }); }
  /** @param {import('../output/pipeline').AnnotatedChunk} _chunk */
  onChunk(_chunk) {}
  /** @param {number} _watchId */
  onConsumed(_watchId) {}
  /** @param {{icanon: boolean, isig: boolean, echo: boolean, fgIsChild: boolean}} _lflag */
  onLflag(_lflag) {}
  /** The child is gone: stop anything that was watching it. */
  onChildExit() {}
  /** Its exit has been dealt with. @param {{code: number|null, signal: string|null, at: string}} _exit */
  onExited(_exit) {}
  /** A new child is about to take over. */
  onRespawned() {}

  /** Whether a session kept after its child exits says so to its clients. */
  get announcesExit() { return true; }

  /** Whether the session outlives its child: attached clients then stay, at EXITED, until something restarts it. */
  get staysAfterExit() { return false; }

  /**
   * Whether this exit belongs to one client, who is then detached while the child restarts for everyone else.
   * @param {{code: number|null, signal: string|null}} _exit @returns {string|null} the client's id
   */
  claimExit(_exit) { return null; }
  /** @returns {string[]} */
  respawnArgv() { return this.session.spec.child.argv; }
  get respawnDelayMs() { return 0; }

  /**
   * First step of a stop, before the hang-up.
   * @param {(ms: number) => Promise<boolean>} _waitExit resolves true when the child exited within ms
   * @returns {Promise<boolean>} true when the child has already exited
   */
  async beforeHangup(_waitExit) { return false; }

  /** Gates beyond the host's own, in priority order. @returns {string[]} */
  gates() { return []; }
  /** Which gates turn a control client's INPUT away, in the order they are reported. @returns {string[]} */
  blockingGates() { return []; }
  /** Hooks for the input router; see InputRouter. @returns {import('../input/input').InputPolicy} */
  inputPolicy() { return {}; }

  /** @param {any} status what STATUS reports @returns {any} */
  status(status) { return status; }
  /** Extra fields of a STATE push. @param {any} _status @returns {object} */
  stateFields(_status) { return {}; }
  /** The record as written to disk. @param {any} doc @returns {any} */
  persisted(doc) { return doc; }
  /** Extra fields of WELCOME. @returns {object} */
  welcomeFields() { return {}; }

  dispose() {}
}

module.exports = { Controller };
