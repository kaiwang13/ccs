'use strict';
// @ts-check
const { EventEmitter } = require('node:events');

/** Every record holds two pins, which cost something on each resize. */
const MAX_RECORDS = 128;
/** A line longer than this is not one anybody reads whole in a listing. */
const MAX_COMMAND = 4096;
/** A prompt can be redrawn at any moment. One that is still there after this means the line was not taken. */
const REFUSED_AFTER_MS = 300;
/** How long a finished run waits for its prompt. It usually comes, but a run should not depend on that. */
const PROMPT_BACK_MS = 3000;

/**
 * @typedef {{seq: number, command: string|null, cwd: string|null, startedAt: number|null, finishedAt: number|null, exit: number|null,
 *   run: number|null, partial: boolean, neverRan?: boolean, start: {row: number}, end: {row: number}|null, endChars: number, spoolStart: number|null, spoolEnd: number|null}} ShellCommand
 */

/**
 * Whether what a shell says it ran is what was typed. History can join lines and change how they are spaced, so this only
 * compares what is left of them, and of several lines bash may only name the first.
 * @param {string} said @param {string} typed
 */
function sameCommand(said, typed) {
  const words = (/** @type {string} */ s) => s.replace(/\\\n/g, '').replace(/[\s;]+/g, '');
  return typed.includes('\n') ? words(typed).startsWith(words(said)) : words(said) === words(typed);
}

/**
 * What the shell in a session has said about itself, from its marks: whether it is at a prompt, what it is running, and what
 * it ran. Rows are the emulator's, so the output of a command can be read back for as long as the emulator keeps it.
 * A record says only what the marks said. A server rebuilt from the holder's ring reads the same marks with no clock to
 * go with them, so those times are null, and a command whose marks have left the ring is not known at all.
 *
 * Events: 'prompt'(), 'command'({phase: 'start'|'end', ...}).
 */
class ShellTracker extends EventEmitter {
  /** @param {{emulator: import('../output/emulator').Emulator, clock: import('../../base/types').Clock, cancelLine: () => void, wallNow?: () => number}} o */
  constructor({ emulator, clock, cancelLine, wallNow = Date.now }) {
    super();
    this.emulator = emulator;
    this.clock = clock;
    this.cancelLine = cancelLine;
    this.wallNow = wallNow;
    /** @type {'unknown'|'prompt'|'running'} */
    this.state = 'unknown';
    /** @type {string|null} */
    this.cwd = null;
    /** @type {ShellCommand[]} oldest first */
    this.records = [];
    /** @type {ShellCommand|null} */
    this.current = null;
    this.seq = 0;
    /**
     * The prompt as drawn: the line up to where what is typed goes, and what the shell put to the right of that. A prompt can be drawn again
     * anywhere, so this is what it says rather than where it is. A shell also says where a prompt ends when it redraws one with a line in it,
     * so only the first time can what is on the right be its own.
     * @type {{left: string, right: string}|null}
     */
    this.promptEnd = null;
    /** the line already held something when the prompt was drawn */
    this.prefilled = false;
    /** the line editor is in vi mode, so plain keys may be commands to it */
    this.viMode = false;
    /** typed into the shell, and not seen to start yet. passedBy: what ran instead @type {{id: number, text: string, row: number, passedBy: ShellCommand|null}|null} */
    this.awaited = null;
    /** a run that has ended, unless more of it follows before the prompt @type {{rec: ShellCommand, timer: any}|null} */
    this.closing = null;
    /** the shell said it cannot do this */
    this.absent = false;
    /** what was read back starts part way through, so the first command to end may have started before it */
    this.midway = false;
  }

  /** The marks being read back do not start at the beginning. */
  joinedMidway() { this.midway = true; }

  /** @param {import('../../vt/marks').Mark} mark @param {{row: number, col: number}} at @param {boolean} live false for a mark read back from the ring */
  onMark(mark, at, live) {
    const now = live ? this.wallNow() : null;
    switch (mark.kind) {
      case 'B': {
        this.midway = false;
        const arrived = this.state !== 'prompt';
        this._finish(null, at, now, live);
        if (mark.typed && this.closing && this.closing.rec.neverRan) this._putBack();
        this._closed();
        this.state = 'prompt';
        this.promptEnd = { left: this.emulator.lineBeforeCursor(), right: arrived ? this.emulator.rightOfCursor() : '' };
        this.prefilled = !!mark.typed;
        if (live && this.awaited) this._watchForRefusal(this.awaited);
        else if (arrived && live) this.emit('prompt');
        break;
      }
      case 'C':                                                                        // several commands in one pasted text are still one line entered
        this.midway = false;
        if (this.closing) this._reopen();
        if (!this.current) this._start(mark.command, at.row, now, live);
        break;
      case 'D':
        this.absent = false;
        this.viMode = !!mark.vi;
        if (mark.cwd !== null) this.cwd = mark.cwd;
        if (this.midway && !this.current) this._start(null, this.emulator.index(0) + this.emulator.trimmed, null, live);   // how it ended, and as much of it as is left
        this.midway = false;
        if (!this.current && this.awaited && !this.awaited.passedBy) this._neverRan(this.awaited, mark, at, now, live);
        if (this.current) this._finish(mark.exit, at, now, live);
        if (this.state === 'prompt') this.state = 'unknown';
        break;
      case 'N':
        this.absent = true;
        if (this.awaited) this._start(this.awaited.text, this.awaited.row, now, live);  // it is running, with nothing left to say how it ends
        else this._finish(null, at, now, live);
        break;
      default:                                                                         // A: its end is what matters
        break;
    }
  }

  /**
   * Some shells keep a line they will not run in the editor, and draw the prompt again with no mark to say so. That line was
   * typed by us, and would be in the way of everything after it. The shell is at its prompt, so Ctrl+C only clears it.
   * If something else ran and nothing further came, that was this line, in the shell's own words: a shell may expand what it was
   * given before saying what it ran. There is no being sure, so whoever asked is told that too.
   * @param {{id: number, passedBy: ShellCommand|null}} awaited
   */
  _watchForRefusal(awaited) {
    this.clock.setTimeout(() => {
      if (this.awaited !== awaited) return;
      this.awaited = null;
      const ran = awaited.passedBy;
      if (ran && ran.end) {
        ran.run = awaited.id;
        this.emit('command', { phase: 'end', unsure: true, ...this.describe(ran) });
      } else {
        this.cancelLine();
        this.emit('command', { phase: 'refused', run: awaited.id, error: 'SYNTAX' });
      }
    }, REFUSED_AFTER_MS);
  }

  /**
   * The prompt is back with no command having started: the line would not parse, or held nothing to run. If nothing was
   * printed either it was the latter, and `$?` is still that of whatever came before.
   * @param {{text: string, row: number}} awaited @param {import('../../vt/marks').Mark} mark
   * @param {{row: number, col: number}} at @param {number|null} now @param {boolean} live
   */
  _neverRan(awaited, mark, at, now, live) {
    if (at.row <= awaited.row) mark.exit = 0;
    this._start(awaited.text, awaited.row, now, live);
    /** @type {ShellCommand} */ (this.current).neverRan = true;
  }

  /** The shell gave the line back to be looked at, as zsh does with hist_verify, so it did not run, and it is in the way. */
  _putBack() {
    const { rec, timer } = /** @type {{rec: ShellCommand, timer: any}} */ (this.closing);
    this.closing = null;
    this.clock.clearTimeout(timer);
    this.prefilled = false;
    this.cancelLine();
    this.emit('command', { phase: 'refused', run: rec.run, error: 'SYNTAX' });
  }

  /** @param {string|null} command @param {number} row @param {number|null} now @param {boolean} live */
  _start(command, row, now, live) {
    const { awaited } = this;
    // A person's line can get in ahead of what was typed for a run. The shell cannot always say what it ran, and then that is taken on trust.
    const mine = awaited && (command === null || command === '' || sameCommand(command, awaited.text)) ? awaited : null;
    if (mine) this.awaited = null;
    /** @type {ShellCommand} */
    const rec = { seq: ++this.seq, command: mine ? mine.text : (command ? command.slice(0, MAX_COMMAND) : null), cwd: this.cwd, startedAt: now, finishedAt: null, exit: null,
      run: mine ? mine.id : null, partial: this.midway, start: this.emulator.pin(row), end: null, endChars: 0, spoolStart: null, spoolEnd: null };
    if (awaited && !mine) awaited.passedBy = rec;
    this.current = rec;
    this.state = 'running';
    this.records.push(rec);
    if (this.records.length > MAX_RECORDS) this._forget(/** @type {ShellCommand} */ (this.records.shift()));
    if (live) this.emit('command', { phase: 'start', ...this.describe(rec) });
  }

  /** @param {number|null} exit @param {{row: number, col: number}} at @param {number|null} now @param {boolean} [live] */
  _finish(exit, at, now, live = false) {
    const rec = this.current;
    if (!rec) return;
    this.current = null;
    if (at.row < rec.start.row) rec.start.row = this.emulator.screenTop(0);            // it went back over what it had printed
    rec.end = this.emulator.pin(at.row);
    rec.endChars = at.col > 0 ? this.emulator.lineUpTo(at) : 0;
    rec.exit = exit;
    rec.finishedAt = now;
    this.state = 'unknown';
    if (!live) return;
    if (rec.run === null) this.emit('command', { phase: 'end', ...this.describe(rec) });
    else this.closing = { rec, timer: this.clock.setTimeout(() => this._closed(), PROMPT_BACK_MS) };
  }

  /** A run ends when the prompt is back: before bash 5.1 its hooks run between the lines of what was pasted, so a command ending is not enough. */
  _closed() {
    const { closing } = this;
    if (!closing) return;
    this.closing = null;
    this.clock.clearTimeout(closing.timer);
    this.emit('command', { phase: 'end', ...this.describe(closing.rec) });
  }

  /** There is more to a run that seemed to have ended. */
  _reopen() {
    const { rec, timer } = /** @type {{rec: ShellCommand, timer: any}} */ (this.closing);
    this.closing = null;
    this.clock.clearTimeout(timer);
    if (rec.end) this.emulator.unpin(rec.end);
    Object.assign(rec, { end: null, endChars: 0, exit: null, finishedAt: null });
    this.current = rec;
    this.state = 'running';
  }

  /** The screen was wiped, so what a command is printing starts again from there. @param {number} top */
  onErased(top) {
    const rec = this.current;
    if (!rec) return;
    rec.start.row = top;
    rec.spoolStart = null;
  }

  /**
   * Rows have gone to the spool, which has a numbering of its own. This is the moment to note where a command landed in it: rows
   * in memory can be renumbered by a reflow, and these cannot.
   * @param {number} from @param {number} to rows, `to` excluded @param {number} line the spool's number for `from`
   */
  spooled(from, to, line) {
    const inside = (/** @type {number} */ row) => row >= from && row < to;
    for (const rec of this.records) {
      if (rec.spoolStart === null && inside(rec.start.row)) rec.spoolStart = line + rec.start.row - from;
      if (rec.spoolEnd === null && rec.end && inside(rec.end.row)) rec.spoolEnd = line + rec.end.row - from;
    }
  }

  /** @param {ShellCommand} rec */
  _forget(rec) {
    this.emulator.unpin(rec.start);
    if (rec.end) this.emulator.unpin(rec.end);
  }

  /** Why nothing can be typed at the prompt right now, or null. @returns {'NO_INTEGRATION'|'BUSY'|'NOT_AT_PROMPT'|'TYPED'|null} */
  notReady() {
    if (this.absent) return 'NO_INTEGRATION';
    if (this.state === 'running' || this.awaited) return 'BUSY';
    if (this.state !== 'prompt' || !this.promptEnd || this.emulator.onAlternate) return 'NOT_AT_PROMPT';
    const { left, right } = this.promptEnd;
    return !this.prefilled && this.emulator.lineBeforeCursor() === left && !this.emulator.textAtCursor(right) ? null : 'TYPED';
  }

  /** Something is about to be typed at the prompt. @param {number} id @param {string} text */
  expect(id, text) { this.awaited = { id, text, row: this.emulator.cursorRow() + 1, passedBy: null }; }

  /**
   * Whoever typed this has stopped waiting, and it never started, so the shell is waiting for the rest of it. It would be in the way
   * of everything after it.
   * @param {number} id
   */
  abandon(id) {
    if (!this.awaited || this.awaited.id !== id || this.state !== 'prompt') return;
    this.awaited = null;
    this.cancelLine();
  }

  /** The shell was replaced: what it said is no longer true, and a run waiting for it will not get an answer. */
  reset() {
    if (this.closing) this._closed();
    const running = [this.awaited, this.current].map((r) => (r && 'run' in r ? r.run : r && r.id)).filter((id) => id !== null && id !== undefined);
    for (const rec of this.records) this._forget(rec);
    this.records = [];
    this.current = null;
    this.state = 'unknown';
    this.promptEnd = null;
    this.awaited = null;
    this.absent = false;
    for (const run of running) this.emit('command', { phase: 'refused', run, error: 'RESTARTED' });
  }

  /** @param {ShellCommand} rec */
  describe(rec) {
    const { seq, command, cwd, startedAt, finishedAt, exit, run } = rec;
    return { seq, command, cwd, startedAt, finishedAt, exit, run, durationMs: startedAt !== null && finishedAt !== null ? finishedAt - startedAt : null };
  }

  /** @returns {ShellCommand|undefined} */
  lastFinished() {
    for (let i = this.records.length - 1; i >= 0; i--) if (this.records[i].end) return this.records[i];
    return undefined;
  }

  /** @param {number} seq */
  find(seq) { return this.records.find((r) => r.seq === seq); }

  /**
   * What a command printed, as far as the emulator still has it.
   * @param {ShellCommand} rec @param {{ansi?: boolean, from?: number}} [o] from: start here, when what came before is known from elsewhere
   * @returns {{text: string, complete: boolean}}
   */
  output(rec, { from, ...o } = {}) {
    const { end, endChars } = rec;
    const unfinished = !!end && endChars > 0;
    const to = !end ? this.emulator.cursorRow() + 1 : (unfinished ? this.emulator.lineEnd(end.row) : end.row);
    const { lines, complete } = this.emulator.text(from ?? rec.start.row, to, { ...o, lastChars: unfinished ? endChars : null });
    return { text: lines.length ? `${lines.join('\n')}\n` : '', complete: complete && !rec.partial };
  }

  status() {
    const last = this.lastFinished();
    return { state: this.state, cwd: this.cwd, current: this.current ? this.describe(this.current) : null, last: last ? this.describe(last) : null };
  }
}

module.exports = { ShellTracker, sameCommand };
