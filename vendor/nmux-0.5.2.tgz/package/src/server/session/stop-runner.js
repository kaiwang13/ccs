'use strict';
// @ts-check
/** @param {import('../../base/types').Clock} clock @param {number} ms */
const sleep = (clock, ms) => new Promise((r) => clock.setTimeout(() => r(undefined), ms));

/**
 * The stop sequence: gate input → whatever the controller does first → hang up → SIGTERM → STOP_STUCK. Nothing stronger
 * than SIGTERM is ever sent.
 */
class StopRunner {
  /** @param {{session: import('./session').Session, clock: import('../../base/types').Clock, hangupWaitMs: number, termWaitMs: number}} o */
  constructor({ session, clock, hangupWaitMs, termWaitMs }) {
    this.session = session;
    this.clock = clock;
    this.hangupWaitMs = hangupWaitMs;
    this.termWaitMs = termWaitMs;
    /** @type {Promise<void>|null} */
    this.promise = null;
    /** @type {null|(() => void)} */
    this.waiter = null;
  }

  /** The session stopped: a running sequence has nothing left to do. */
  settled() { if (this.waiter) { const w = this.waiter; this.waiter = null; w(); } }

  /** @returns {Promise<void>} */
  run() {
    if (this.promise) return this.promise;
    const s = this.session;
    s.dispatch({ t: 'stop-requested' });
    this.promise = (async () => {
      if (s.starting) await s.started;                                               // a holder on its way must not be left without a server
      if (!s.holder || s.exited) { s.markStopped(); return; }
      s.dispatch({ t: 'stopping' });
      s.notify('info', 'STOPPING', s.messages.stopping(s.name));
      const exited = new Promise((resolve) => { this.waiter = () => resolve(true); });
      const waitExit = (/** @type {number} */ ms) => Promise.race([exited, sleep(this.clock, ms).then(() => false)]);
      if (await s.controller.beforeHangup(waitExit)) return;
      if (s.holder && !s.exited) s.holder.closeMaster();                         // EIO + SIGHUP
      if (await waitExit(this.hangupWaitMs)) return;
      if (s.holder && !s.exited) s.holder.signal('SIGTERM');
      if (await waitExit(this.termWaitMs)) return;
      s.dispatch({ t: 'stop-stuck' });
      s.notify('warn', 'STOP_STUCK', s.messages.stopStuck(s.hello ? s.hello.child.pid : '?'));
    })();
    return this.promise;
  }
}

module.exports = { StopRunner, sleep };
