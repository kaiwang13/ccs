'use strict';
// @ts-check
const { writeAtomic, readJson } = require('../../base/atomic');

/**
 * Default state writer: merge into the existing file, so keys written by others survive.
 * @param {string} file @param {object} st
 */
function defaultStateWriter(file, st) {
  const prev = readJson(file, { retries: 0 }) || {};
  writeAtomic(file, { ...prev, ...st });
}

/**
 * The session's record on disk: written at once on a lifecycle change, debounced otherwise. An embedding program may
 * pass an async writer (a record on NFS must never block this event loop); async writes never overlap, and while one
 * is in flight only the newest snapshot is kept, to be written when it settles.
 */
class StateStore {
  /**
   * @param {{file: string|null, write?: (file: string, st: object) => (void|Promise<void>), snapshot: () => object,
   *   clock: import('../../base/types').Clock, log: any, debounceMs: number}} o
   */
  constructor({ file, write = defaultStateWriter, snapshot, clock, log, debounceMs }) {
    this.file = file;
    this.writer = write;
    this.snapshot = snapshot;
    this.clock = clock;
    this.log = log;
    this.debounceMs = debounceMs;
    this.inFlight = false;
    /** @type {object|null} */
    this.pending = null;
    /** @type {any} */
    this.timer = null;
    this.closed = false;
  }

  /** @param {boolean} immediate */
  save(immediate) {
    if (!this.file || this.closed) return;
    if (!immediate) {
      if (this.timer === null) this.timer = this.clock.setTimeout(() => { this.timer = null; this.save(true); }, this.debounceMs);
      return;
    }
    this._cancel();
    this._write(this.snapshot());
  }

  /** @param {object} st */
  _write(st) {
    if (this.inFlight) { this.pending = st; return; }
    /** @type {any} */
    let r;
    try { r = this.writer(/** @type {string} */ (this.file), st); } catch (e) { this.log.warn('state.write_failed', { error: String(/** @type {Error} */ (e).message) }); return; }
    if (!r || typeof r.then !== 'function') return;
    this.inFlight = true;
    r.catch((/** @type {any} */ e) => this.log.warn('state.write_failed', { error: String(e && e.message) }))
      .finally(() => {
        this.inFlight = false;
        const next = this.pending;
        this.pending = null;
        // A snapshot queued before close() (including the final one) still reaches the writer. save() refuses to start
        // anything new once closed, so this cannot reopen the door to new writes.
        if (next) this._write(next);
      });
  }

  _cancel() { if (this.timer !== null) { this.clock.clearTimeout(this.timer); this.timer = null; } }

  close() { this._cancel(); this.closed = true; }
}

module.exports = { StateStore, defaultStateWriter };
