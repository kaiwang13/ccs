'use strict';
// @ts-check
/**
 * The session lifecycle as a pure function: reduce(state, event) returns the next state and the effects the
 * session must carry out, in order. Nothing here touches a clock, a socket or a process.
 *
 * @typedef {import('../types').Lifecycle} Lifecycle
 * @typedef {null|{code: number|null, signal: string|null, at: string, cause: string}} LastExit
 * @typedef {{lifecycle: Lifecycle, blockedCode: string|null, exited: boolean, stopRequested: boolean, restartRequested: boolean,
 *   lastExit: LastExit, attributed: number}} State
 * @typedef {{t: 'release'}|{t: 'stopped'}|{t: 'respawn-later'}|{t: 'client-exit', client: string}|
 *   {t: 'exit-notice', how: number|string}} Effect
 * @typedef {{t: 'adopted'}|{t: 'replayed'}|{t: 'phase', to: Lifecycle, from?: Lifecycle[]}|{t: 'blocked', code: string}|
 *   {t: 'exit-seen'}|{t: 'exit', code: number|null, signal: string|null, at: string, shuttingDown?: boolean, claimedBy: string|null, stays?: boolean, quiet?: boolean}|
 *   {t: 'orphaned'}|{t: 'respawning'}|{t: 'respawn-failed'}|{t: 'stop-requested'}|{t: 'restart-requested'}|{t: 'stopping'}|{t: 'stop-stuck'}|{t: 'stopped'}} Event
 */

/** @param {boolean} recover @returns {State} */
function initialState(recover) {
  return { lifecycle: recover ? 'RECOVERING' : 'STARTING', blockedCode: null, exited: false, stopRequested: false, restartRequested: false, lastExit: null, attributed: 0 };
}

/** Only BLOCKED carries a code. @param {State} s @param {Lifecycle} lifecycle @returns {State} */
function enter(s, lifecycle) {
  if (s.lifecycle === lifecycle) return s;
  return { ...s, lifecycle, blockedCode: lifecycle === 'BLOCKED' ? s.blockedCode : null };
}

/** @param {State} state @param {Effect[]} [effects] */
const result = (state, effects = []) => ({ state, effects });

/**
 * What a child's exit means. A stop that was asked for and a host going down both end the session, and a restart that was
 * asked for starts a new child; an exit a controller claims for one client restarts the child for everybody else. Any
 * other exit ends the session, as logging out ends an ssh connection, unless the controller keeps it at EXITED.
 * @param {State} s @param {Extract<Event, {t: 'exit'}>} e
 */
function onExit(s, e) {
  const { code, signal, at } = e;
  const ended = (/** @type {string} */ cause) => result({ ...s, lastExit: { code, signal, at, cause } }, [{ t: 'release' }, { t: 'stopped' }]);
  if (s.stopRequested) return ended('stopped');
  if (e.shuttingDown) return ended('host-shutdown');
  if (s.restartRequested) {
    return result(enter({ ...s, restartRequested: false, lastExit: { code, signal, at, cause: 'restart' } }, 'EXITED'), [{ t: 'release' }, { t: 'respawn-later' }]);
  }
  if (e.claimedBy) {
    const next = enter({ ...s, lastExit: { code, signal, at, cause: 'client-exit' }, attributed: s.attributed + 1 }, 'EXITED');
    return result(next, [{ t: 'client-exit', client: e.claimedBy }, { t: 'release' }, { t: 'respawn-later' }]);
  }
  if (!e.stays) return ended(signal === 'SIGTERM' ? 'terminated' : 'exited');
  const next = enter({ ...s, lastExit: { code, signal, at, cause: signal === 'SIGTERM' ? 'terminated' : 'unexpected' } }, 'EXITED');
  return result(next, e.quiet ? [{ t: 'release' }] : [{ t: 'release' }, { t: 'exit-notice', how: code ?? signal ?? 'unknown' }]);
}

/** @param {State} s @param {Event} e @returns {{state: State, effects: Effect[]}} */
function reduce(s, e) {
  switch (e.t) {
    case 'adopted': return result({ ...s, exited: false });
    case 'replayed': return result(s.lifecycle === 'RECOVERING' ? enter(s, 'STARTING') : s);
    case 'phase': return result(!e.from || e.from.includes(s.lifecycle) ? enter(s, e.to) : s);
    case 'blocked': return result(enter({ ...s, blockedCode: e.code }, 'BLOCKED'));
    case 'exit-seen': return result({ ...s, exited: true });
    case 'exit': return onExit(s, e);
    case 'orphaned': return result(enter({ ...s, exited: true, blockedCode: 'ORPHAN_ALIVE' }, 'BLOCKED'));
    case 'respawning': return result(enter(s, 'STARTING'));
    case 'respawn-failed': return result(enter(s, 'EXITED'));
    case 'stop-requested': return result({ ...s, stopRequested: true });
    case 'restart-requested': return result({ ...s, restartRequested: true });
    case 'stopping': return result(enter(s, 'STOPPING'));
    case 'stop-stuck': return result(enter(s, 'STOP_STUCK'));
    case 'stopped': return result(enter(s, 'STOPPED'));
    default: throw new Error(`unknown session event ${/** @type {any} */ (e).t}`);
  }
}

module.exports = { initialState, reduce };
