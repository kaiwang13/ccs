'use strict';
// @ts-check
const fs = require('node:fs');

const MAX_PATH = 1024;

/**
 * The name a session's programs know the ssh agent by. A long-lived shell keeps the SSH_AUTH_SOCK it started with, which stops
 * working when that connection ends, so it is given a link instead, and the link follows the newest terminal that has an agent.
 * A terminal without one changes nothing.
 */
class AgentLink {
  /** @param {{link: string, log: any}} o */
  constructor({ link, log }) {
    this.link = link;
    this.log = log;
    /** @type {Array<{id: string, target: string}>} oldest first */
    this.lenders = [];
  }

  /** @param {string} id @param {unknown} target the terminal's SSH_AUTH_SOCK */
  arrived(id, target) {
    if (typeof target !== 'string' || !target.startsWith('/') || target.length > MAX_PATH || target === this.link) return;
    this.lenders.push({ id, target });
    this._point(target);
  }

  /** The one before takes over. @param {string} id */
  left(id) {
    const newest = this.lenders[this.lenders.length - 1];
    this.lenders = this.lenders.filter((l) => l.id !== id);
    const next = this.lenders[this.lenders.length - 1];
    if (next && newest && newest.id === id) this._point(next.target);
  }

  /** Replaced in one step: anything connecting at this moment finds one agent or the other. @param {string} target */
  _point(target) {
    const tmp = `${this.link}.new`;
    try {
      fs.rmSync(tmp, { force: true });
      fs.symlinkSync(target, tmp);
      fs.renameSync(tmp, this.link);
    } catch (e) { this.log.warn('agent.link_failed', { error: String(/** @type {Error} */ (e).message) }); }
  }
}

module.exports = { AgentLink };
