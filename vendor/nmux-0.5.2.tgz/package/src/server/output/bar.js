'use strict';
// @ts-check
/**
 * The bar at the foot of a terminal that asked for one: nmux's name, the session's, what it is running and who else is on it,
 * the keys that matter most, and the date and time where the session keeps them. This is what it says and how it looks, for a
 * terminal `cols` wide; drawing it, and keeping the session's output off its row, is the server's. nmux-rs draws the same bytes.
 */
const { wall, monthShort, zoneLabel } = require('../../base/time');

/**
 * The bar's colours as SGR parameters: a deep slate bar, a teal tag for nmux, and text in lighter and softer greys. A terminal
 * that has said it shows any colour gets these exactly; any other the nearest of the 256.
 */
const PALETTES = Object.freeze({
  truecolor: Object.freeze({ bar: '48;2;30;41;59', tag: '48;2;20;184;166', tagText: '38;2;15;23;42', edge: '38;2;20;184;166', name: '38;2;248;250;252',
    soft: '38;2;148;163;184', dot: '38;2;100;116;139', key: '38;2;94;234;212', date: '38;2;203;213;225', time: '38;2;248;250;252' }),
  ansi256: Object.freeze({ bar: '48;5;236', tag: '48;5;37', tagText: '38;5;234', edge: '38;5;37', name: '38;5;255',
    soft: '38;5;247', dot: '38;5;243', key: '38;5;116', date: '38;5;252', time: '38;5;255' }),
});

/** What goes, in this order, when the terminal is too narrow for everything: how to leave is the last of the tips to go. */
const DROPPED_FIRST = /** @type {const} */ (['help', 'weekday', 'attached', 'tips', 'date', 'running', 'zone', 'time']);
const DOT = ' · ';

/** `C-\\` as the bar writes it: `^\\`. @param {string} key */
const keyLabel = (key) => (/^C-.$/.test(key) ? `^${key.slice(2).toUpperCase()}` : key);

/**
 * @typedef {{brand?: string, name: string, running: string|null, clients: number, now: number, timeZone: string,
 *   keys: {leader: string|null, bindings: Record<string, string>, direct?: Record<string, string>}, truecolor: boolean}} BarInfo
 *   brand: who is speaking, `nmux` or the program that embeds it. running: what the session's terminal is running in front of its
 *   shell, if anything. clients: terminals attached. keys: an action is shown with the leader and the key after it, or else with a
 *   key that does it at once.
 */

/**
 * What the bar shows on a terminal `cols` wide: SGR runs and text, filling the row with the bar's colour. The last column is
 * left for that fill, so writing the bar never leaves a wrap pending.
 * @param {BarInfo} info @param {number} cols @returns {string}
 */
function barLine(info, cols) {
  const p = info.truecolor ? PALETTES.truecolor : PALETTES.ansi256;
  /** @param {string[]} codes */
  const sgr = (...codes) => `\x1b[${['0', p.bar, ...codes].join(';')}m`;
  const fill = `${sgr()}\x1b[K\x1b[0m`;
  const width = cols - 1;
  if (width < 8) return fill;
  const w = wall(info.now, info.timeZone);
  const time = `${String(w.hour).padStart(2, '0')}:${String(w.minute).padStart(2, '0')}`;
  const day = `${w.day} ${monthShort(info.now, info.timeZone)}`;
  const zone = zoneLabel(info.now, info.timeZone);
  const running = info.running ? info.running.replace(/[^\x20-\x7e]/g, '?') : null;
  const { leader, bindings, direct = {} } = info.keys;
  /** @param {Record<string, string>} keys @param {string} action */
  const keyFor = (keys, action) => Object.keys(keys).find((k) => keys[k] === action);
  const tips = [['detach', 'detach'], ['help', 'help']].flatMap(([action, word]) => {
    const k = leader ? keyFor(bindings, action) : undefined;
    if (k !== undefined) return [{ key: `${keyLabel(/** @type {string} */ (leader))} ${k}`, word, action }];
    const now = keyFor(direct, action);
    return now === undefined ? [] : [{ key: keyLabel(now), word, action }];
  });
  const brand = ` ${info.brand || 'nmux'} `;
  const show = { help: true, weekday: true, attached: info.clients > 1, tips: tips.length > 0, date: true, running: running !== null, zone: true, time: true };
  let name = info.name;
  /** @returns {{left: Array<[string, string]>, center: Array<[string, string]>, right: Array<[string, string]>}} */
  const parts = () => ({
    left: [[sgr(p.edge), '▐'], [sgr(p.tag, p.tagText, '1'), brand], [sgr(p.edge), '▌'], [sgr(p.name, '1'), ` ${name}`],
      ...(show.running ? [[sgr(p.dot), DOT], [sgr(p.soft), /** @type {string} */ (running)]] : []),
      ...(show.attached ? [[sgr(p.dot), DOT], [sgr(p.soft), `${info.clients} attached`]] : [])].map((x) => /** @type {[string, string]} */ (x)),
    center: !show.tips ? [] : tips.filter((t) => show.help || t.action !== 'help')
      .flatMap((t, i) => [[sgr(p.key), `${i ? '  ' : ''}${t.key}`], [sgr(p.soft), ` ${t.word}`]]).map((x) => /** @type {[string, string]} */ (x)),
    right: !show.time ? [] : [...(show.date ? [[sgr(p.date), show.weekday ? `${w.weekday.slice(0, 3)} ${day}` : day], [sgr(p.dot), DOT]] : []),
      [sgr(p.time, '1'), time], ...(show.zone ? [[sgr(p.soft), ` ${zone}`]] : []), [sgr(), ' ']].map((x) => /** @type {[string, string]} */ (x)),
  });
  const len = (/** @type {Array<[string, string]>} */ segs) => segs.reduce((n, [, text]) => n + text.length, 0);
  let s = parts();
  for (const piece of DROPPED_FIRST) {
    if (len(s.left) + len(s.right) + 1 + (s.center.length ? len(s.center) + 4 : 0) <= width) break;
    show[piece] = false;
    s = parts();
  }
  const over = len(s.left) + len(s.right) + 1 - width;
  if (over > 0) {                                                                         // a name too long for even this much
    name = name.slice(0, Math.max(1, name.length - over));
    s = parts();
  }
  const [lw, cw, rw] = [len(s.left), len(s.center), len(s.right)];
  let gap1 = Math.max(1, width - lw - rw);
  let gap2 = 0;
  if (cw) {
    const at = Math.min(Math.max(Math.floor((width - cw) / 2), lw + 2), width - rw - 2 - cw);
    gap1 = at - lw;
    gap2 = width - rw - at - cw;
  }
  const run = (/** @type {Array<[string, string]>} */ segs) => segs.map(([style, text]) => style + text).join('');
  const out = run(s.left) + sgr() + ' '.repeat(gap1) + run(s.center) + sgr() + ' '.repeat(gap2) + run(s.right);
  return len(s.left) + gap1 + cw + gap2 + rw > width ? fill : out + fill;
}

module.exports = { barLine, keyLabel, PALETTES };
