'use strict';
// @ts-check
/**
 * What in xterm.js a program could stop a server with. ED1 in the last cell of a buffer with nothing above its screen throws, in a
 * timer, because xterm marks the line after the last one as not wrapped; and some counts are taken as they come, so that
 * `CSI 2147483647 S` loops that many times and `CSI 999999999 b` allocates gigabytes. A count past what can change the screen is
 * cut to that, which leaves the screen as it would have been, and that ED1 is done as the ED2 it is the same as there.
 */

/**
 * @param {any} params what a CSI handler is given: numbers, or arrays of them for subparameters
 * @returns {number} the first, or 0
 */
const first = (params) => (typeof params[0] === 'number' ? params[0] : 0);

/** @param {import('@xterm/headless').Terminal} term */
function guard(term) {
  const ih = /** @type {any} */ (term)._core._inputHandler;
  /** Calls xterm's own handler with a count it can take. @param {string} final @param {string} method @param {() => number} most */
  const capped = (final, method, most) => term.parser.registerCsiHandler({ final }, (params) => {
    if (params.length !== 1 || first(params) <= most()) return false;                    // as xterm would; `CSI … T` with five is not a scroll
    return ih[method]({ params: [most()], length: 1 });
  });
  capped('S', 'scrollUp', () => term.rows);
  capped('T', 'scrollDown', () => term.rows);
  capped('L', 'insertLines', () => term.rows);
  capped('M', 'deleteLines', () => term.rows);
  capped('b', 'repeatPrecedingCharacter', () => term.cols * term.rows);
  for (const selective of [false, true]) {
    term.parser.registerCsiHandler(selective ? { prefix: '?', final: 'J' } : { final: 'J' }, (params) => {
      const b = ih._activeBuffer;
      if (first(params) !== 1 || b.x + 1 < term.cols || b.lines.length > b.y + 1) return false;
      return ih.eraseInDisplay({ params: [2], length: 1 }, selective);                   // from the top to the last cell: everything
    });
  }
}

module.exports = { guard };
