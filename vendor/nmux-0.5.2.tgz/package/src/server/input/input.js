'use strict';
// @ts-check
const { InputTokenizer } = require('../../vt/inputtok');
const { decodeInputToken, classify } = require('../../vt/keys');
const { DEFAULT_MESSAGES } = require('../messages');

/** @typedef {import('../../vt/inputtok').InputToken} InputToken */
/**
 * How a controller takes part in input. All optional: without one, every gate drops input and everything else
 * reaches the child, because keys belong to the program.
 * @typedef {{
 *   detachKeys?: string[],
 *   forwardFocus?: () => boolean,
 *   gateEffect?: (gate: string, client: any) => 'drop'|'filter'|'open',
 *   offerSignalKey?: (cls: 'C'|'D', client: any) => void,
 *   guardsKey?: (cls: string) => boolean,
 *   onPaste?: () => void,
 *   onForwarded?: (clientId: string, tok: InputToken, cls: string, writtenTotal: number) => void,
 * }} InputPolicy
 */

/** Reply-shaped client input: a terminal answering a query on its own, never the child's business. */
const REPLY_SHAPED = [
  /^\x1b\[\?[\d;]*c$/, /^\x1b\[>[\d;]*c$/, /^\x1b\[\?[\d;]*\$y$/, /^\x1b\[\??\d+;\d+R$/, /^\x1b\[0n$/,
  /^\x1bP[\s\S]*\x1b\\$/, /^\x1b\](?:4|10|11|12);[\s\S]*(?:\x07|\x1b\\)$/, /^\x1b\[\?997;\d+n$/,
];
const FOCUS = /^\x1b\[[IO]$/;
/** c_cc bytes: in cooked mode 0x03 is SIGINT, 0x1a SIGTSTP, 0x1c SIGQUIT, 0x04 EOF, 0x11/0x13 XON/XOFF */
const CC_BYTES = new Set([0x03, 0x04, 0x1a, 0x1c, 0x11, 0x13]);
const SWALLOW_MS = 500;
const PASTE_HOLD_MS = 2000;
const OVERFLOW_GATE_MS = 1000;

/**
 * Input router. Per-client tokenizer → key decoder → policy → gates → holder write.
 * Policy order: the policy's detach keys, by class (never forwarded; release/repeat swallowed 500 ms) · ignored ·
 * reply-shaped · focus reports (only to a program that asked for them) · gates · Ctrl+C / Ctrl+D through the controller if
 * it asks (a win32 repeat is ONE press) · forward.
 */
class InputRouter {
  /**
   * @param {{config: any, clock: import('../../base/types').Clock, holder: {write: (b: Buffer, o?: {loneEsc?: boolean, watch?: boolean}) => number},
   *   policy?: InputPolicy, gates: () => string[], onDetachRequest: (client: any) => void,
   *   notice: (client: any|null, level: 'info'|'warn', code: string, text: string) => void, writtenTotal: () => number,
   *   messages?: import('../messages').Messages}} o
   */
  constructor({ config, clock, holder, policy = {}, gates, onDetachRequest, notice, writtenTotal, messages = DEFAULT_MESSAGES }) {
    this.config = config;
    this.clock = clock;
    this.holder = holder;
    this.policy = policy;
    this.gates = gates;
    this.messages = messages;
    this.onDetachRequest = onDetachRequest;
    this.notice = notice;
    this.writtenTotal = writtenTotal;
    /** @type {Map<any, {tok: InputTokenizer, hs: {highSurrogate: string}, swallowUntil: number}>} */
    this.state = new Map();
    /** @type {any} client inside a bracketed paste; other clients' tokens wait (≤ 2 s) so they cannot interleave */
    this.pasteOwner = null;
    /** @type {Array<{client: any, tok: InputToken}>} */
    this.held = [];
    this.heldTimer = null;
    this.dropUntil = -Infinity;
    /** @type {string|null} */
    this.lastTypist = null;
    /** @type {any} */
    this.lastEscClient = null;
  }

  /** @param {any} client an object with a string `id` */
  addClient(client) {
    const tok = new InputTokenizer({ clock: this.clock, escFlushMs: this.config.input.escFlushMs, pasteIdleCloseMs: this.config.input.pasteIdleCloseMs,
      onTimerTokens: (toks) => { for (const t of toks) this._route(client, t); } });
    this.state.set(client, { tok, hs: { highSurrogate: '' }, swallowUntil: -Infinity });
  }

  /** A client leaving mid-paste gets its paste closed (ESC[201~ is injected). @param {any} client */
  removeClient(client) {
    const st = this.state.get(client);
    if (!st) return;
    for (const t of st.tok.close()) this._route(client, t);
    this.state.delete(client);
    if (this.pasteOwner === client) this._endPaste();
    this.held = this.held.filter((h) => h.client !== client);
  }

  /** @param {any} client @param {Buffer} bytes */
  onInput(client, bytes) {
    const st = this.state.get(client);
    if (!st) return;
    for (const t of st.tok.feed(bytes)) this._route(client, t);
  }

  /** The holder dropped its write queue (the child is not reading): close input for 1 s and tell everyone. */
  onWriteOverflow() {
    this.dropUntil = this.clock.now() + OVERFLOW_GATE_MS;
    this.notice(null, 'warn', 'INPUT_DROPPED', this.messages.inputDropped);
  }

  /** The holder released writes held behind an unconsumed lone ESC. */
  onEscHoldExpired() {
    this.notice(this.lastEscClient, 'warn', 'ESC_HOLD_EXPIRED', this.messages.escHoldExpired);
  }

  /** @param {any} client @param {InputToken} tok */
  _route(client, tok) {
    if (this.pasteOwner !== null && this.pasteOwner !== client) {
      this.held.push({ client, tok });
      if (this.heldTimer === null) this.heldTimer = this.clock.setTimeout(() => { this.heldTimer = null; this._endPaste(); }, PASTE_HOLD_MS);
      return;
    }
    this._handle(client, tok);
  }

  _endPaste() {
    this.pasteOwner = null;
    if (this.heldTimer !== null) { this.clock.clearTimeout(this.heldTimer); this.heldTimer = null; }
    const held = this.held;
    this.held = [];
    for (const h of held) this._route(h.client, h.tok);
  }

  /** The strongest effect of every gate that applies. @param {any} client @returns {'drop'|'filter'|'open'} */
  _gate(client) {
    if (this.clock.now() < this.dropUntil) return 'drop';
    const effect = this.policy.gateEffect || (() => 'drop');
    const effects = this.gates().map((g) => effect(g, client));
    if (effects.includes('drop')) return 'drop';
    return effects.includes('filter') ? 'filter' : 'open';
  }

  /** @param {any} client @param {InputToken} tok */
  _handle(client, tok) {
    const st = this.state.get(client);
    if (tok.kind === 'paste-start' || tok.kind === 'paste-data' || tok.kind === 'paste-end') {
      if (tok.kind === 'paste-start') this.pasteOwner = client;
      const gate = this._gate(client);
      let bytes = tok.bytes;
      if (gate === 'filter') bytes = Buffer.from([...bytes].filter((b) => !CC_BYTES.has(b)));
      if (gate !== 'drop' && bytes.length) { this.holder.write(bytes); if (this.policy.onPaste) this.policy.onPaste(); this.lastTypist = client.id; }
      if (tok.kind === 'paste-end') this._endPaste();
      return;
    }
    const now = this.clock.now();
    const events = decodeInputToken(tok.seq, st ? st.hs : { highSurrogate: '' });
    const classes = events.map(classify);
    if (classes.some((c) => (this.policy.detachKeys || []).includes(c))) {           // 1. detach
      if (st) st.swallowUntil = now + SWALLOW_MS;
      this.onDetachRequest(client);
      return;
    }
    if (st && now < st.swallowUntil && events.every((e) => !e.name)) return;         //    its release/repeat events
    if (events.length === 0) return;                                               //    e.g. a win32 key-up: nothing for the child
    if (classes.includes('IGNORED')) return;                                       // 2. signal byte that decodes to nothing
    if (REPLY_SHAPED.some((re) => re.test(tok.seq))) return;                        // 3. reply-shaped
    if (FOCUS.test(tok.seq) && !(this.policy.forwardFocus && this.policy.forwardFocus())) return;   // 4. focus reports
    const gate = this._gate(client);                                               // 8. gates (before C/D: the policy's writes are gated too)
    if (gate === 'drop') return;
    const cd = classes.find((c) => c === 'C' || c === 'D');                        // 5. one offer per token
    if ((cd === 'C' || cd === 'D') && this.policy.offerSignalKey && (!this.policy.guardsKey || this.policy.guardsKey(cd))) {
      if (gate !== 'filter') this.policy.offerSignalKey(cd, client);
      return;
    }
    if (gate === 'filter' && tok.bytes.length === 1 && CC_BYTES.has(tok.bytes[0])) return;
    const loneEsc = tok.kind === 'lone-esc';                                       // 9. forward
    this.holder.write(tok.bytes, { loneEsc });
    if (loneEsc) this.lastEscClient = client;
    this.lastTypist = client.id;
    if (this.policy.onForwarded) this.policy.onForwarded(client.id, tok, classes[0], this.writtenTotal());
  }

  dispose() {
    if (this.heldTimer !== null) { this.clock.clearTimeout(this.heldTimer); this.heldTimer = null; }
    for (const [, st] of this.state) st.tok.close();
    this.state.clear();
  }
}

module.exports = { InputRouter, REPLY_SHAPED };
