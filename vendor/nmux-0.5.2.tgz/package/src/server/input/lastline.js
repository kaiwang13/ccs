'use strict';
// @ts-check
/**
 * The last line one client typed and submitted, so an exit can say what came just before it. It reads the raw bytes of
 * each forwarded token: a printable character appends, 0x7f/0x08 deletes one, \r or \n submits, and anything else (another
 * control byte, any escape sequence, a lone ESC, a paste) invalidates the line. Two clients typing into one line invalidate
 * it too. Deliberately narrow: what it reports is an unbroken typed run, and nothing else was written after it.
 */
const PRINTABLE_CHAR = /^[^\x00-\x1f\x7f]$/u;

class LastLine {
  constructor() {
    /** @type {{clientId: string|null, text: string}} */
    this.draft = { clientId: null, text: '' };
    /** @type {{clientId: string, text: string, atTotal: number}|null} */
    this.submitted = null;
  }

  /**
   * Every token forwarded to the program on a client's behalf.
   * @param {string} clientId @param {{kind: string, bytes: Buffer, seq: string}} tok
   * @param {number} writtenTotal the session's forwarded-byte total after this write
   */
  onForwarded(clientId, tok, writtenTotal) {
    if (this.submitted && this.submitted.atTotal !== writtenTotal) this.submitted = null;     // superseded by a later write
    if (tok.kind !== 'seq') { this._clear(); return; }
    if (this.draft.clientId !== null && this.draft.clientId !== clientId) { this._clear(); return; }   // interleaved
    const b = tok.bytes;
    if (b.length === 1 && (b[0] === 0x0d || b[0] === 0x0a)) {
      if (this.draft.clientId === clientId) this.submitted = { clientId, text: this.draft.text, atTotal: writtenTotal };
      this._clear();
      return;
    }
    if (b.length === 1 && (b[0] === 0x7f || b[0] === 0x08)) {
      if (this.draft.clientId === null) this.draft = { clientId, text: '' };
      this.draft.text = [...this.draft.text].slice(0, -1).join('');
      return;
    }
    if (PRINTABLE_CHAR.test(tok.seq) && b[0] !== 0x1b) {
      if (this.draft.clientId === null) this.draft = { clientId, text: '' };
      this.draft.text += tok.seq;
      return;
    }
    this._clear();                                                                     // arrows, history recall, any control
  }

  /** A bracketed paste was forwarded: pasted text is not a typed line. */
  onPaste() { this._clear(); }

  /** The line submitted last, if nothing else has been written since. @param {number} writtenTotal @returns {{client: string, text: string}|null} */
  take(writtenTotal) {
    const line = this.submitted;
    this.submitted = null;
    this._clear();
    return line && line.atTotal === writtenTotal ? { client: line.clientId, text: line.text } : null;
  }

  _clear() { this.draft = { clientId: null, text: '' }; }
}

module.exports = { LastLine };
