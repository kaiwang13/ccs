'use strict';
// @ts-check
/**
 * A key that must not take effect twice by accident. A press of a guarded class is forwarded only when the previous press
 * of that class was (1) read by the program, (2) followed by its output, and (3) at least marginMs ago after that output.
 * No wall-clock spacing is trusted: a stalled program never reads, so every further press is swallowed and the client is told.
 */
class KeyGuard {
  /**
   * @param {{clock: import('../../base/types').Clock, marginMs: number, keys: string[], write: (bytes: Buffer, opts: {watch: true}) => number,
   *   held: (client: any, cls: string) => void}} o
   */
  constructor({ clock, marginMs, keys, write, held }) {
    this.clock = clock;
    this.marginMs = marginMs;
    this.write = write;
    this.held = held;
    /** one state per class, shared by all clients */
    /** @type {Record<string, {state: 'idle'|'await-consume'|'await-output', watch: number, readyAt: number}>} */
    this.guard = Object.fromEntries(keys.map((k) => [k, { state: 'idle', watch: 0, readyAt: -Infinity }]));
  }

  /** @param {string} cls */
  covers(cls) { return cls in this.guard; }

  /** @param {'C'|'D'} cls @param {any} client */
  offer(cls, client) {
    const g = this.guard[cls];
    if (g.state !== 'idle' || this.clock.now() < g.readyAt) { this.held(client, cls); return; }
    g.state = 'await-consume';
    g.watch = this.write(Buffer.from(cls === 'C' ? '\x03' : '\x04'), { watch: true });
  }

  /** @param {number} watchId */
  onConsumed(watchId) {
    for (const g of Object.values(this.guard)) if (g.state === 'await-consume' && g.watch === watchId) g.state = 'await-output';
  }

  /** Every output chunk. Output after the press was read proves the program processed it. */
  onData() {
    for (const g of Object.values(this.guard)) {
      if (g.state === 'await-output') { g.state = 'idle'; g.readyAt = this.clock.now() + this.marginMs; }
    }
  }

  /** A new holder: outstanding watch ids belong to the old one. */
  reset() { for (const g of Object.values(this.guard)) { g.state = 'idle'; g.watch = 0; g.readyAt = -Infinity; } }
}

module.exports = { KeyGuard };
