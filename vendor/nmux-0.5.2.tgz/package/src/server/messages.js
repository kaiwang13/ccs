'use strict';
// @ts-check
/**
 * Everything the server says to a person, in one table. An embedding program replaces entries to speak in
 * its own name; the logic around them never changes.
 *
 * @typedef {{
 *   brand: string, attentionTitle: string, hostShutdown: string, restarting: string, defaultKickedBy: string,
 *   inputDropped: string, escHoldExpired: string,
 *   stopping: (name: string) => string, stopStuck: (pid: number|string) => string, orphanAlive: (pid: number) => string,
 *   childExited: (name: string, how: number|string) => {code: string, text: string}, respawnFailed: (name: string) => string,
 *   sessionStopped: (name: string) => string, clientExit: (name: string) => string, kicked: (who: string, name: string) => string,
 *   protoMismatch: (theirs: unknown, ours: number, name: string) => string, blocked: (name: string, code: string|null) => string,
 *   belowFloor: (name: string, cols: number, rows: number, floor: number, hardMin: number) => string,
 *   heldKey: (cls: string, name: string) => string,
 *   joinBanner: (name: string, lines: number) => string|null, away: (name: string, what: string) => string, skippedOutput: (bytes: number, name: string) => string, lostOutput: (bytes: number) => string,
 * }} Messages
 */

/** @param {number} bytes */
function amount(bytes) {
  if (bytes >= 1048576) return `${Math.round(bytes / 1048576)} MB`;
  return bytes >= 1024 ? `${Math.round(bytes / 1024)} KB` : `${bytes} bytes`;
}

/** @param {number} ms */
function span(ms) {
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 48) return `${h}h`;
  return `${Math.floor(h / 24)}d`;
}

/**
 * What happened while a terminal was away, in a line, or null if nothing did. Commands are what a shell typed back, and this goes
 * to a terminal, so they may not carry anything that would drive it.
 * @param {{finished: Array<{command: string|null, exit: number|null, durationMs: number|null}>, running: {command: string|null}|null, lines: number}} o
 * @returns {string|null}
 */
function awayText({ finished, running, lines }) {
  const named = (/** @type {string|null} */ c) => (c ? c.replace(/[\x00-\x1f\x7f-\x9f]/g, ' ').slice(0, 40) : 'a command');
  const exit = (/** @type {number|null} */ e) => (e === null ? 'exit unknown' : `exit ${e}`);
  const parts = [];
  const last = finished[finished.length - 1];
  if (finished.length === 1) parts.push(`${named(last.command)} finished: ${exit(last.exit)}${last.durationMs === null ? '' : ` after ${span(last.durationMs)}`}`);
  else if (finished.length > 1) parts.push(`${finished.length} commands finished, the last with ${exit(last.exit)}`);
  if (running) parts.push(`${named(running.command)} still running`);
  if (lines > 0) parts.push(`${lines.toLocaleString('en-US')} new line${lines === 1 ? '' : 's'}`);
  return parts.length ? parts.join(' · ') : null;
}

/** @type {Messages} */
const DEFAULT_MESSAGES = Object.freeze({
  brand: 'nmux',
  attentionTitle: '[needs you] ',
  /** @param {string} name */
  stopping: (name) => `stopping '${name}'`,
  /** @param {number|string} pid */
  stopStuck: (pid) => `child pid ${pid} did not exit; inspect it manually`,
  /** @param {number} pid */
  orphanAlive: (pid) => `child pid ${pid} outlived its holder; sending SIGTERM`,
  /** @param {string} _name @param {number|string} how */
  childExited: (_name, how) => ({ code: 'CHILD_EXITED', text: `the child exited (${how})` }),
  /** @param {string} _name */
  respawnFailed: (_name) => 'could not restart the child',
  /** @param {string} name */
  sessionStopped: (name) => `session '${name}' stopped`,
  hostShutdown: 'the host is shutting down',
  restarting: 'the server is restarting; reconnecting',
  /** @param {string} name */
  clientExit: (name) => `the session '${name}' keeps running`,
  defaultKickedBy: 'kick',
  /** @param {string} who @param {string} name */
  kicked: (who, name) => `${who} — the session '${name}' keeps running`,
  /** @param {unknown} theirs @param {number} ours @param {string} _name */
  protoMismatch: (theirs, ours, _name) => `protocol ${theirs} is not supported (this session speaks ${ours})`,
  /** @param {string} name @param {string|null} code */
  blocked: (name, code) => `session '${name}' is blocked (${code})`,
  /** @param {string} _name @param {number} cols @param {number} rows @param {number} floor @param {number} hardMin */
  belowFloor: (_name, cols, rows, floor, hardMin) => `this terminal is ${cols}x${rows} — below the ${floor}-column floor for shared sessions (minimum with shrink: ${hardMin})`,
  inputDropped: 'input dropped — the child is not reading',
  escHoldExpired: 'Esc was not read by the child in time; later keys were sent anyway',
  /** @param {string} cls @param {string} name */
  heldKey: (cls, name) => `repeated Ctrl+${cls} ignored — use 'nmux stop ${name}' to end the session`,
  joinBanner: () => null,
  /** @param {string} name @param {string} what */
  away: (name, what) => `── nmux · ${name} · ${what} ──`,
  /** @param {number} bytes @param {string} name */
  skippedOutput: (bytes, name) => `── nmux · skipped ${amount(bytes)} of output · nmux capture ${name} --lines 100000 ──`,
  /** @param {number} bytes */
  lostOutput: (bytes) => `── nmux · lost ${amount(bytes)} of output ──`,
});

/**
 * A session's own words, from its spec. A spec is a file, so its messages are text with `{name}`-style holes rather than
 * functions; `{amount}` fills in a byte count as a person would read it. Anything not given keeps its default.
 * @param {Record<string, string|{code: string, text: string}|null>} [table] @returns {Messages}
 */
function messagesFrom(table = {}) {
  /** @type {any} */
  const out = { ...DEFAULT_MESSAGES };
  for (const [key, template] of Object.entries(table)) {
    const args = ARGUMENTS[key];
    if (!args) { out[key] = template; continue; }
    /** @param {unknown[]} values */
    const fill = (text, values) => (text === null ? null : String(text).replace(/\{(\w+)\}/g, (hole, k) => {
      const i = args.indexOf(k);
      if (k === 'amount') return amount(Number(values[args.indexOf('bytes')]));
      return i < 0 ? hole : String(values[i]);
    }));
    out[key] = (/** @type {unknown[]} */ ...values) => (template && typeof template === 'object'
      ? { code: template.code, text: fill(template.text, values) } : fill(template, values));
  }
  return out;
}

/** The arguments of every message that takes any, by name, in order. */
const ARGUMENTS = Object.freeze({
  stopping: ['name'], stopStuck: ['pid'], orphanAlive: ['pid'], childExited: ['name', 'how'], respawnFailed: ['name'], sessionStopped: ['name'],
  clientExit: ['name'], kicked: ['who', 'name'], protoMismatch: ['theirs', 'ours', 'name'], blocked: ['name', 'code'],
  belowFloor: ['name', 'cols', 'rows', 'floor', 'hardMin'], heldKey: ['cls', 'name'], joinBanner: ['name', 'lines'],
  away: ['name', 'what'], skippedOutput: ['bytes', 'name'], lostOutput: ['bytes'],
});

module.exports = { DEFAULT_MESSAGES, amount, span, awayText, messagesFrom };
