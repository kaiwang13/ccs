'use strict';
// @ts-check
/**
 * The single place in the codebase that knows which OS this is.
 *
 * Both implementations export exactly the same surface (see the typedef below), so every caller
 * stays platform-blind. Nothing else in `src/` may read the platform;
 * `test/unit/platform-seam.test.js` enforces that.
 *
 * The surface is the process-information subset of `procinfo.js`, which re-exports it.
 *
 * @typedef {{
 *   procStart(pid: number): string|null,
 *   procState(pid: number): 'alive'|'zombie'|'gone',
 *   pgid(pid: number): number|null,
 *   ppid(pid: number): number|null,
 *   procSid(pid: number): number|null,
 *   bootId(): string,
 *   machineId(): string,
 *   readEnviron(pid: number): Record<string, string>|null,
 *   readArgv(pid: number): string[]|null,
 *   commandLine(pid: number): string|null,
 *   cwdOf(pid: number): string|null,
 *   listPids(): number[],
 *   listProcesses(): Array<{pid: number, ppid: number|null, argv: string|null}>,
 *   pidNs(pid: number): string|null,
 *   ttyOf(pid: number): string|null,
 *   argvVisibleToOthers(mountsFile?: string): boolean,
 *   procSource: string,
 *   selfTty(): string|null,
 *   shutdownCorroborated(o?: any): boolean,
 *   sameProcStart(recorded: string, live: string): boolean,
 *   name: string,
 *   platformReportsZombieParent: boolean,
 *   hangupOnMasterClose: boolean,
 *   oomScoreAdjPath: string|null,
 * }} Platform
 */

/** @type {Platform} */
let impl;
if (process.platform === 'darwin') {
  impl = require('./darwin.js');
} else if (process.platform === 'linux') {
  impl = require('./linux.js');
} else {
  // Fail loudly rather than silently falling back to the Linux readers: on an unsupported OS
  // every /proc read would fail closed one by one and the symptom would be "no processes
  // exist", which is far harder to diagnose than a refusal to start.
  throw new Error(`nmux: unsupported platform '${process.platform}' (supported: linux, darwin)`);
}

/**
 * Platform capabilities: the questions callers ask as "can this platform do X?", so a caller never
 * has to test the platform itself. That is what keeps `process.platform` confined to this file.
 * @type {{
 *   name: string,
 *   platformReportsZombieParent: boolean,
 *   hangupOnMasterClose: boolean,
 *   orphanScan: boolean,
 *   procSource: string,
 * }}
 */
const capabilities = {
  name: impl.name,
  // Taken from the implementation rather than re-tested here, so there is one place that states the
  // fact and the capability cannot drift from the code it describes.
  platformReportsZombieParent: impl.platformReportsZombieParent,
  hangupOnMasterClose: impl.hangupOnMasterClose,
  // Whether another process's environment can be read at all, which is what the orphan scan is
  // built on. Unmeasured on macOS, so it reports false there.
  orphanScan: process.platform === 'linux',
  // Stated by the implementation, like hangupOnMasterClose: doctor prints these instead of testing the OS.
  procSource: impl.procSource,
};

// A fresh object: writing `capabilities` onto `impl` would mutate linux.js's (or darwin.js's) own exports,
// and the two implementations would then no longer export the same surface.
module.exports = { ...impl, capabilities };
