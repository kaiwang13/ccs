'use strict';
// @ts-check
/**
 * macOS implementation of the process-information surface declared in `procinfo.js`.
 *
 * macOS has no /proc. Process facts come from libproc via the `ttyctl` addon's `procInfo` and
 * `listPids` exports (see native/ttyctl/ttyctl.c); the two machine identifiers come from
 * `ioreg` and `sysctl`, both cached module-level because they are read once per process lifetime.
 *
 * ## procStart encoding differs from Linux, deliberately
 *
 * Linux's `procStart` is clock ticks since boot (field 22 of /proc/<pid>/stat). Here it is
 * `"<seconds>.<microseconds>"` of absolute start time from libproc. Only two properties matter to
 * callers -- `isSameProcess(pid, start)` must be stable for a live process and must differ after
 * pid reuse -- and both hold for either encoding. The two are NOT interchangeable: a `procStart`
 * recorded on Linux will never equal one computed here, so `isSameProcess` returns false for a
 * cross-platform record. That is the fail-closed direction (a stale record is treated as "not the
 * same process" rather than resurrected), and it is why a session's state.json is not portable
 * between platforms.
 */
const { execFileSync } = require('node:child_process');
const { ttyctl } = require('./native.js');
const { ctimeUtc } = require('./ctime.js');

/** libproc pbi_status values, from <sys/proc.h>. @type {number} */
const SZOMB = 5;

/** PID namespace does not exist on macOS: there is one flat pid space per boot. @returns {null} */
function pidNs() {
  return null;
}

/**
 * Process start time as a ctime string (see ctime.js), or null when the pid is not live.
 *
 * A zombie has no readable start time (libproc reports ESRCH for it), so this returns null there.
 * That is the same answer Linux gives for a pid whose /proc/<pid>/stat read fails, and it is the
 * safe one for `isSameProcess`: a zombie is not the process that was recorded.
 * @param {number} pid @returns {string|null}
 */
function procStart(pid) {
  if (!Number.isSafeInteger(pid) || pid <= 0) return null;
  let info;
  try {
    info = ttyctl.procInfo(pid);
  } catch {
    return null;
  }
  if (!info || info.zombie) return null;
  return ctimeUtc(info.startSec * 1000);
}

/** @param {number} pid @returns {'alive'|'zombie'|'gone'} */
function procState(pid) {
  if (!Number.isSafeInteger(pid) || pid <= 0) return 'gone';
  let info;
  try {
    info = ttyctl.procInfo(pid);
  } catch {
    return 'gone';
  }
  if (!info) return 'gone';
  // `zombie` is set by the addon for the ESRCH-but-listed case, which is how macOS reports a
  // defunct process (see the comment on procInfo in native/ttyctl/ttyctl.c).
  if (info.zombie || info.status === SZOMB) return 'zombie';
  return 'alive';
}

/** @param {number} pid @returns {number|null} */
function pgid(pid) {
  if (!Number.isSafeInteger(pid) || pid <= 0) return null;
  let info;
  try {
    info = ttyctl.procInfo(pid);
  } catch {
    return null;
  }
  if (!info) return null;
  return Number.isSafeInteger(info.pgid) && info.pgid > 0 ? info.pgid : null;
}

/** @param {number} pid @returns {number|null} */
function procSid(pid) {
  if (!Number.isSafeInteger(pid) || pid <= 0) return null;
  let info;
  try {
    info = ttyctl.procInfo(pid);
  } catch {
    return null;
  }
  if (!info) return null;
  return Number.isSafeInteger(info.sid) && info.sid > 0 ? info.sid : null;
}

/** @param {number} pid @returns {number|null} */
function ppid(pid) {
  if (!Number.isSafeInteger(pid) || pid <= 0) return null;
  let info;
  try {
    info = ttyctl.procInfo(pid);
  } catch {
    return null;
  }
  if (!info) return null;
  return Number.isSafeInteger(info.ppid) && info.ppid >= 0 ? info.ppid : null;
}

/** @type {string|null} */
let bootIdCache = null;
/** @returns {string} */
function bootId() {
  if (bootIdCache === null) bootIdCache = execFileSync('/usr/sbin/sysctl', ['-n', 'kern.bootsessionuuid'], { encoding: 'utf8' }).trim();
  return bootIdCache;
}

/** @type {string|null} */
let machineIdCache = null;
/** @returns {string} */
function machineId() {
  if (machineIdCache === null) {
    // IOPlatformUUID is the machine's stable hardware identifier. Strip the dashes so the value
    // has the same 32-hex-character shape as Linux's /etc/machine-id -- callers compare these
    // across hosts, and a differently-shaped value would be compared as a different host anyway,
    // but matching the shape keeps registry keys and logs uniform.
    const out = execFileSync('/usr/sbin/ioreg', ['-rd1', '-c', 'IOPlatformExpertDevice'], { encoding: 'utf8' });
    const m = /"IOPlatformUUID"\s*=\s*"([^"]+)"/.exec(out);
    if (!m) throw new Error('machineId: IOPlatformUUID not found in ioreg output');
    machineIdCache = m[1].toLowerCase().replace(/-/g, '');
  }
  return machineIdCache;
}

/**
 * Environment of another process.
 *
 * Always null on macOS: this is the KERN_PROCARGS2 read whose availability under SIP is the open
 * question in the handoff brief's §5a, and it has never been measured. Returning null is the
 * honest "cannot tell", and `preflight.js`'s orphan scan must not treat it as "no orphans" --
 * see `src/sessiond/preflight.js`, which refuses to claim a clean scan when this cannot be read.
 * @param {number} _pid @returns {Record<string, string>|null}
 */
function readEnviron(_pid) {
  return null;
}

/** @param {number} _pid @returns {string[]|null} */
function readArgv(_pid) {
  return null;
}

/** What a process is running, as one line. @param {number} pid @returns {string|null} */
function commandLine(pid) {
  try {
    return execFileSync('/bin/ps', ['-o', 'command=', '-p', String(pid)], { encoding: 'utf8', timeout: 1000 }).trim() || null;
  } catch {
    return null;
  }
}

/** A process's working directory. @param {number} pid @returns {string|null} */
function cwdOf(pid) {
  try {
    const out = execFileSync('/usr/sbin/lsof', ['-a', '-d', 'cwd', '-p', String(pid), '-Fn'], { encoding: 'utf8', timeout: 1000 });
    const line = out.split('\n').find((l) => l.startsWith('n'));
    return line ? line.slice(1) : null;
  } catch {
    return null;
  }
}

/** @returns {number[]} */
function listPids() {
  try {
    return ttyctl.listPids();
  } catch {
    return [];
  }
}

/**
 * Every visible process with its parent and command line, from one `ps` call (readArgv is unavailable
 * here). Used by the test harness to find what a test started.
 * @returns {Array<{pid: number, ppid: number|null, argv: string|null}>}
 */
function listProcesses() {
  let text;
  try {
    text = execFileSync('/bin/ps', ['-Ao', 'pid=,ppid=,command='], { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
  } catch {
    return [];
  }
  const out = [];
  for (const line of text.split('\n')) {
    const m = /^\s*(\d+)\s+(\d+)\s+(.*)$/.exec(line);
    if (m) out.push({ pid: Number(m[1]), ppid: Number(m[2]), argv: m[3] });
  }
  return out;
}

/** Controlling terminal path of a process, via ttyname(3). @param {number} _pid @returns {string|null} */
function ttyOf(_pid) {
  // macOS has no /proc/<pid>/fd/0, and there is no portable unprivileged call to resolve another
  // process's tty. libproc's PROC_PIDVNODEPATHINFO can do it for processes we own, but it is not
  // needed by any current caller: the one consumer is preflight's SECOND_WRITER report, which
  // already tolerates null. Returning null is the documented shape.
  return null;
}

/** `ps` shows every process's full command line to every user and macOS has no hidepid equivalent.
 *  @param {string} [_mountsFile] accepted for surface parity; unused @returns {boolean} */
function argvVisibleToOthers(_mountsFile) {
  return true;
}

/** Where process information comes from, for a diagnostic report. */
const procSource = 'libproc';

/**
 * The controlling terminal of THIS process, i.e. what /proc/self/fd/0 resolves to on Linux.
 *
 * Deliberately not `ttyOf(pid)` for an arbitrary pid: that one is null here (no /proc, and no
 * unprivileged libproc call for another process's tty). This answers the much easier question the
 * attach path actually asks -- "which tty am I running on?" -- which ttyname(3) can answer.
 * @returns {string|null}
 */
function selfTty() {
  try {
    // `tty` prints the path on a tty and "not a tty" otherwise, exiting non-zero in that case.
    const out = execFileSync('/usr/bin/tty', { encoding: 'utf8', stdio: ['inherit', 'pipe', 'ignore'] }).trim();
    return out.startsWith('/dev/') ? out : null;
  } catch {
    return null;
  }
}

/**
 * Do a recorded `procStart` and a live one refer to the same process?
 *
 * A plain string comparison, same as Linux -- but on macOS that only works because `procStart` above
 * is rendered in one fixed form. Both values therefore agree by construction rather than by luck; see
 * the note on `ctimeUtc` in ctime.js.
 * @param {string} recorded @param {string} live @returns {boolean}
 */
function sameProcStart(recorded, live) {
  return String(recorded) === String(live);
}

/**
 * macOS has no OOM score adjustment: the memory-pressure killer is not steerable per process.
 * null means "skip this step", which is why the call site guards on it.
 */
const oomScoreAdjPath = null;

/**
 * Always false on macOS. The Linux answer comes from systemd (`/run/systemd/shutdown/scheduled`,
 * `systemctl is-system-running`), and macOS has no equivalent that is cheap and reliable enough to
 * justify the call. The consequence is deliberately small: the holder still treats SIGTERM
 * correctly, it just cannot distinguish "a shutdown is in progress" from "someone sent me a
 * SIGTERM", so one status message is less specific. Nothing about session safety depends on it.
 * @returns {false}
 */
function shutdownCorroborated() {
  return false;
}

/** This implementation's platform name, for a diagnostic report. */
const name = 'darwin';

/**
 * libproc returns ESRCH for a defunct process, so a zombie's parent cannot be read and a zombie
 * cannot be matched to the shell that spawned it (see procInfo in native/ttyctl/ttyctl.c).
 */
const platformReportsZombieParent = false;

/**
 * Closing the pty master does NOT hang up the slave on macOS: the child receives no SIGHUP (verified
 * by instrumenting a child that logs its signals -- it stays alive after `pty.destroy()`), and a
 * child that installs a SIGHUP handler and later calls `process.exit()` wedges instead. So the stop
 * sequence's cheapest step is a no-op here and the SIGTERM escalation is what actually ends an
 * agent. That escalation already exists and is unchanged; this flag exists so the tests assert the
 * platform's real behaviour instead of a Linux-only assumption.
 */
const hangupOnMasterClose = false;

module.exports = {
  procStart, procState, pgid, procSid, ppid,
  bootId, machineId, readEnviron, listPids, listProcesses, readArgv, commandLine, cwdOf, pidNs, ttyOf,
  argvVisibleToOthers, procSource, selfTty, shutdownCorroborated, sameProcStart,
  oomScoreAdjPath, name, platformReportsZombieParent, hangupOnMasterClose,
};
