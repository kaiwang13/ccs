'use strict';
// @ts-check
/**
 * Linux implementation of the process-information surface declared in `procinfo.js`.
 *
 * This file is a MOVE of the /proc readers that used to live in `procinfo.js` — the bodies are
 * unchanged, so the Linux behaviour is identical by construction rather than by inspection.
 * Nothing outside `procinfo.js` may require this module directly; callers import `procinfo.js`,
 * which dispatches on platform. See `darwin.js` for the macOS counterpart and the encoding note
 * on `procStart`.
 */
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { hidepidEnabled } = require('./linux-mounts.js');

/** @param {number} pid @returns {string[]|null} fields 3.. of /proc/<pid>/stat (index 0 = field 3) */
function statFields(pid) {
  if (!Number.isSafeInteger(pid) || pid <= 0) return null;
  let s;
  try {
    s = fs.readFileSync(`/proc/${pid}/stat`, 'latin1');
  } catch {
    return null;
  }
  const close = s.lastIndexOf(')');
  if (close < 0) return null;
  return s.slice(close + 2).trim().split(' ');
}

/**
 * Process start time: field 22 of /proc/<pid>/stat, in clock ticks since boot.
 * Only stability and comparability matter (see `isSameProcess`), never the absolute value.
 * @param {number} pid @returns {string|null}
 */
function procStart(pid) {
  const f = statFields(pid);
  return f && f.length > 19 ? f[19] : null; // field 22
}

/** @param {number} pid @returns {'alive'|'zombie'|'gone'} */
function procState(pid) {
  const f = statFields(pid);
  if (!f) return 'gone';
  if (f[0] === 'Z') return 'zombie';
  if (f[0] === 'X' || f[0] === 'x') return 'gone';
  return 'alive';
}

/** @param {number} pid @returns {number|null} */
function pgid(pid) {
  const f = statFields(pid);
  if (!f || f.length < 3) return null;
  const n = Number(f[2]); // field 5
  return Number.isSafeInteger(n) ? n : null;
}

/** @param {number} pid @returns {number|null} */
function ppid(pid) {
  const f = statFields(pid);
  if (!f || f.length < 2) return null;
  const n = Number(f[1]); // field 4
  return Number.isSafeInteger(n) ? n : null;
}

/** Field 6 (session id) of /proc/<pid>/stat. @param {number} pid @returns {number|null} */
function procSid(pid) {
  try { const s = fs.readFileSync(`/proc/${pid}/stat`, 'utf8'); return Number(s.slice(s.lastIndexOf(')') + 2).split(' ')[3]); } catch { return null; }
}

/** @type {string|null} */
let bootIdCache = null;
/** @returns {string} */
function bootId() {
  if (bootIdCache === null) bootIdCache = fs.readFileSync('/proc/sys/kernel/random/boot_id', 'utf8').trim();
  return bootIdCache;
}

/** @type {string|null} */
let machineIdCache = null;
/** @returns {string} */
function machineId() {
  if (machineIdCache === null) machineIdCache = fs.readFileSync('/etc/machine-id', 'utf8').trim();
  return machineIdCache;
}

/** @param {number} pid @returns {Record<string, string>|null} */
function readEnviron(pid) {
  if (!Number.isSafeInteger(pid) || pid <= 0) return null;
  let raw;
  try {
    raw = fs.readFileSync(`/proc/${pid}/environ`, 'utf8');
  } catch {
    return null;
  }
  /** @type {Record<string, string>} */
  const env = {};
  for (const entry of raw.split('\0')) {
    const eq = entry.indexOf('=');
    if (eq > 0) env[entry.slice(0, eq)] = entry.slice(eq + 1);
  }
  return env;
}

/** @returns {number[]} */
function listPids() {
  return fs.readdirSync('/proc').filter((n) => /^\d+$/.test(n)).map(Number);
}

/**
 * Every visible process with its parent and command line (null where unreadable), in one pass. Used by the
 * test harness to find what a test started.
 * @returns {Array<{pid: number, ppid: number|null, argv: string|null}>}
 */
function listProcesses() {
  return listPids().map((pid) => {
    const argv = readArgv(pid);
    return { pid, ppid: ppid(pid), argv: argv ? argv.join(' ') : null };
  });
}

/** @param {number} pid @returns {string[]|null} argv of the process */
function readArgv(pid) {
  if (!Number.isSafeInteger(pid) || pid <= 0) return null;
  try {
    return fs.readFileSync(`/proc/${pid}/cmdline`, 'utf8').split('\0').filter(Boolean);
  } catch {
    return null;
  }
}

/** What a process is running, as one line. @param {number} pid @returns {string|null} */
function commandLine(pid) {
  const argv = readArgv(pid);
  return argv && argv.length ? argv.join(' ') : null;
}

/** A process's working directory. @param {number} pid @returns {string|null} */
function cwdOf(pid) {
  try { return fs.readlinkSync(`/proc/${pid}/cwd`); } catch { return null; }
}

/** pid namespace inode of a process, e.g. '4026531836'. @param {number} pid @returns {string|null} */
function pidNs(pid) {
  try { const m = /\[(\d+)\]/.exec(fs.readlinkSync(`/proc/${pid}/ns/pid`)); return m ? m[1] : null; } catch { return null; }
}

/** Controlling terminal path of a process, or null. @param {number} pid @returns {string|null} */
function ttyOf(pid) {
  try { const t = fs.readlinkSync(`/proc/${pid}/fd/0`); return t.startsWith('/dev/') && t !== '/dev/null' ? t : null; } catch { return null; }
}

/**
 * Can other accounts on this host read this host's process command lines? Linux answers from /proc's hidepid
 * mount option. An unreadable mount table gets the conservative answer: yes.
 * @param {string} [mountsFile] the mount table (tests point this elsewhere)
 * @returns {boolean}
 */
function argvVisibleToOthers(mountsFile = '/proc/mounts') {
  let text;
  try {
    text = fs.readFileSync(mountsFile, 'utf8');
  } catch {
    return true;
  }
  return !hidepidEnabled(text);
}

/** Where process information comes from, for a diagnostic report. */
const procSource = '/proc';

/**
 * Independent evidence that the host is shutting down, so a bare SIGTERM to the holder can be told
 * apart from a system shutdown. systemd-specific; see darwin.js
 * for why macOS returns false. Reads only.
 * @param {{scheduledPath?: string, systemctl?: string}} [o]
 * @returns {boolean}
 */
function shutdownCorroborated({ scheduledPath = '/run/systemd/shutdown/scheduled', systemctl = 'systemctl' } = {}) {
  if (fs.existsSync(scheduledPath)) return true;
  try {
    const r = spawnSync(systemctl, ['is-system-running'], { encoding: 'utf8', timeout: 2000 });
    return (r.stdout || '').trim() === 'stopping';
  } catch { return false; }
}

/** The controlling terminal of THIS process, as /proc/self/fd/0 resolves it. @returns {string|null} */
function selfTty() {
  try { return fs.readlinkSync('/proc/self/fd/0'); } catch { return null; }
}

/**
 * Do a recorded `procStart` and a live one refer to the same process? Linux records clock ticks since
 * boot in both places, so this is a plain string comparison, kept here so both platforms share one
 * call and the Linux answer cannot drift.
 * @param {string} recorded @param {string} live @returns {boolean}
 */
function sameProcStart(recorded, live) {
  return String(recorded) === String(live);
}

/** Path sessiond raises to bias the OOM killer away from itself, or null where the concept does not exist. */
const oomScoreAdjPath = '/proc/self/oom_score_adj';

/** This implementation's platform name, for a diagnostic report. */
const name = 'linux';

/** /proc/<pid>/stat keeps reporting a defunct process's ppid, so a zombie can be matched to its parent. */
const platformReportsZombieParent = true;

/**
 * Closing the pty master makes the kernel hang up the slave, so the child receives SIGHUP and any
 * well-behaved program exits without escalation. The stop sequence relies on this as its cheapest
 * step, and still escalates to SIGTERM if it does not work.
 */
const hangupOnMasterClose = true;

module.exports = {
  procStart, procState, pgid, procSid, ppid,
  bootId, machineId, readEnviron, listPids, listProcesses, readArgv, commandLine, cwdOf, pidNs, ttyOf,
  argvVisibleToOthers, procSource, selfTty, shutdownCorroborated, sameProcStart,
  oomScoreAdjPath, name, platformReportsZombieParent, hangupOnMasterClose,
};
