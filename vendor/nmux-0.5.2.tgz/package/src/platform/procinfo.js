'use strict';
// @ts-check
/**
 * Process identity and machine identity, platform-blind.
 *
 * The OS-specific readers live behind `./platform` (linux.js / darwin.js), which export an
 * identical surface; this file re-exports them and adds the one piece of *policy* that does not
 * depend on the OS: `isSameProcess` (pid + start time, so a recycled pid is never mistaken for
 * the original).
 *
 * Process identity is always pid + procStart. The encoding of procStart differs per platform --
 * see the note at the top of darwin.js -- and the two are deliberately not interchangeable, so a
 * record written on one platform is never mistaken for a live process on the other.
 */
const platform = require('./index.js');

const { procStart, procState, pgid, procSid, ppid, bootId, machineId, readEnviron, readArgv, listPids, pidNs, ttyOf } = platform;

/**
 * Is the process at `pid` still the same process that `start` was captured from?
 * @param {number} pid @param {string} start
 */
function isSameProcess(pid, start) {
  if (typeof start !== 'string' || start === '') return false;
  return procStart(pid) === start;
}

module.exports = {
  procStart, procState, pgid, procSid, ppid,
  bootId, machineId, readEnviron, readArgv, listPids, pidNs, ttyOf,
  isSameProcess,
  commandLine: platform.commandLine,
  cwdOf: platform.cwdOf,
  // The rest of the seam surface, re-exported so callers that already reach for procinfo do not
  // have to know which helpers came from the platform: the CLI needs argvVisibleToOthers/selfTty and the
  // holder needs shutdownCorroborated.
  argvVisibleToOthers: platform.argvVisibleToOthers,
  listProcesses: platform.listProcesses,
  procSource: platform.procSource,
  platformReportsZombieParent: platform.platformReportsZombieParent,
  hangupOnMasterClose: platform.hangupOnMasterClose,
  selfTty: platform.selfTty,
  shutdownCorroborated: platform.shutdownCorroborated,
  sameProcStart: platform.sameProcStart,
  oomScoreAdjPath: platform.oomScoreAdjPath,
  name: platform.name,
  capabilities: platform.capabilities,
};
