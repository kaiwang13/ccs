'use strict';
// @ts-check
/** Process start time as a ctime string; its own file so it can be tested on any platform. */

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
/** @param {number} n */
const pad2 = (n) => String(n).padStart(2, '0');

/**
 * ctime rendering in UTC, e.g. "Mon Sep 21 01:13:03 2026".
 *
 * This is a format, not an arbitrary choice. A program that records a process's start time for itself
 * can only be matched against this value as a STRING, and on macOS the ctime form in UTC is the one
 * such programs write: emitting anything else (an epoch number, a different layout) means the strings
 * never match. Changing it is a breaking change for anyone comparing these values.
 *
 * The cost is resolution: ctime has one-second granularity, where libproc offers microseconds. Two
 * processes started in the same second on the same pid are therefore indistinguishable to
 * `isSameProcess`. The pid+start pair still distinguishes anything that started at a different second.
 * @param {number} ms @returns {string}
 */
function ctimeUtc(ms) {
  const d = new Date(ms);
  // ctime pads the day with a space, not a zero: "Mon Oct  5 …". A zero-padded day never matches on days 1-9.
  return `${DAYS[d.getUTCDay()]} ${MONTHS[d.getUTCMonth()]} ${String(d.getUTCDate()).padStart(2, ' ')} `
    + `${pad2(d.getUTCHours())}:${pad2(d.getUTCMinutes())}:${pad2(d.getUTCSeconds())} ${d.getUTCFullYear()}`;
}

module.exports = { ctimeUtc };
