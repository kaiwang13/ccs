'use strict';
// @ts-check
const net = require('node:net');
const { FramedSocket, T, CTL_PROTO } = require('../wire/proto.js');
const { onControl } = require('../wire/ctlclient.js');
const { realClock } = require('../base/clock.js');

/** One connection to a session at a time. Anything still arriving from an earlier one is ignored. */
class SessionLink {
  /** @param {{sockPath: string, onControl: (msg: any) => void, onOutput: (bytes: Buffer) => void, onLost: () => void}} o */
  constructor({ sockPath, onControl: control, onOutput, onLost }) {
    this.sockPath = sockPath;
    this.handlers = { control, onOutput, onLost };
    /** @type {FramedSocket|null} */
    this.sock = null;
    this.lastRx = realClock.now();
  }

  /** @param {() => object} hello the HELLO fields, read when the connection opens */
  connect(hello) {
    const s = net.createConnection(this.sockPath);
    const fsock = new FramedSocket(s);
    this.sock = fsock;
    s.on('connect', () => {
      if (this.sock !== fsock) return;
      this.lastRx = realClock.now();
      fsock.sendControl({ t: 'HELLO', proto: CTL_PROTO, role: 'attach', ...hello() });
    });
    onControl(fsock, (msg) => {
      if (this.sock !== fsock) return;
      this.lastRx = realClock.now();
      this.handlers.control(msg);
    });
    fsock.on('frame', (/** @type {any} */ f) => {
      if (this.sock !== fsock) return;
      this.lastRx = realClock.now();
      if (f.type === T.OUTPUT) this.handlers.onOutput(f.payload);
    });
    fsock.on('error', () => { /* 'close' follows */ });
    fsock.on('close', () => { if (this.sock === fsock) { this.sock = null; this.handlers.onLost(); } });
  }

  get connected() { return this.sock !== null; }
  get silentMs() { return realClock.now() - this.lastRx; }
  /** The silence so far does not count. */
  heard() { this.lastRx = realClock.now(); }

  /** @param {Buffer} bytes */
  sendInput(bytes) { if (this.sock) this.sock.send(T.INPUT, bytes); }
  /** @param {object} msg */
  sendControl(msg) { if (this.sock) this.sock.sendControl(msg); }

  drop() {
    const s = this.sock;
    this.sock = null;
    if (s) { try { s.destroy(); } catch { /* ignore */ } }
  }
}

module.exports = { SessionLink };
