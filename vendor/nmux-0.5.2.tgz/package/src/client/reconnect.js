'use strict';
// @ts-check
const { realClock } = require('../base/clock.js');

const BACKOFF_MS = [500, 1000, 2000, 4000, 5000];
const RECONNECT_WINDOW_MS = 120000;

/** How long to wait before the next connection attempt, and when to stop trying. */
class ReconnectPolicy {
  /** @param {{backoffMs?: number[], windowMs?: number, now?: () => number}} [o] */
  constructor({ backoffMs = BACKOFF_MS, windowMs = RECONNECT_WINDOW_MS, now = () => realClock.now() } = {}) {
    this.backoffMs = backoffMs; this.windowMs = windowMs; this.now = now;
    /** @type {number|null} */ this.lostAt = null;
    this.attempt = 0;
  }

  /** @param {boolean} immediate @returns {number|null} the delay in ms, or null once the window is over */
  next(immediate) {
    const t = this.now();
    if (this.lostAt === null) this.lostAt = t;
    if (t - this.lostAt > this.windowMs) return null;
    const delay = immediate ? 0 : this.backoffMs[Math.min(this.attempt, this.backoffMs.length - 1)];
    this.attempt++;
    return delay;
  }

  /** Joined again: the next loss starts over. */
  reset() { this.lostAt = null; this.attempt = 0; }
}

/** How many times a terminal may fall behind, or fail to take a snapshot, before rejoining stops being the answer. */
class RejoinPolicy {
  /** @param {{max?: number, windowMs?: number, snapshotTimeoutMax?: number, now?: () => number}} [o] */
  constructor({ max = 3, windowMs = 300000, snapshotTimeoutMax = 3, now = () => realClock.now() } = {}) {
    this.max = max; this.windowMs = windowMs; this.snapshotTimeoutMax = snapshotTimeoutMax; this.now = now;
    /** @type {number[]} */ this.overflows = [];
    this.snapshotTimeouts = 0;
  }
  /** An OVERFLOW rejoin is allowed at most `max` times per `windowMs`. */
  allowOverflow() {
    const t = this.now();
    this.overflows = this.overflows.filter((x) => t - x < this.windowMs);
    if (this.overflows.length >= this.max) return false;
    this.overflows.push(t);
    return true;
  }
  /** SNAPSHOT_TIMEOUT never draws on the overflow budget; the `snapshotTimeoutMax`-th consecutive one gives up. */
  allowSnapshotTimeout() { this.snapshotTimeouts++; return this.snapshotTimeouts < this.snapshotTimeoutMax; }
  onSnapshotEnd() { this.snapshotTimeouts = 0; }
}

module.exports = { ReconnectPolicy, RejoinPolicy };
