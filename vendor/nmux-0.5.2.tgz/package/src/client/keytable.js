'use strict';
// @ts-check
const { decodeInputToken, classify } = require('../vt/keys.js');

/**
 * What a key means to the client itself, before anything reaches the host. Detection lives here so that detaching works
 * even if the server has hung, and every other key belongs to the program.
 *
 * A key is named as `d`, `?` or `C-z`. `leader` is the one key this client takes; the key after it is looked up in
 * `bindings`, and the leader twice sends one to the program. `direct` keys act at once, with no leader. A key after the
 * leader with no binding is dropped: it was meant for this client, not for the program.
 *
 * @typedef {{leader?: string|null, bindings?: Record<string, string>, direct?: Record<string, string>}} KeySpec
 */
class KeyTable {
  /** @param {KeySpec} [spec] */
  constructor({ leader = null, bindings = {}, direct = {} } = {}) {
    this.leader = leader;
    this.bindings = bindings;
    this.direct = direct;
    this.afterLeader = false;
    this.state = { highSurrogate: '' };
  }

  /** @param {{kind: string, seq: string}} tok @returns {string[]} the names this token means, usually one */
  _names(tok) {
    if (tok.kind !== 'seq' && tok.kind !== 'lone-esc') return [];
    return decodeInputToken(tok.seq, this.state).map((ev) => {
      const base = ev.name && ev.name !== 'number' ? ev.name : ev.sequence;
      return ev.ctrl ? `C-${base}` : base;
    });
  }

  /**
   * @param {{kind: string, seq: string}} tok
   * @returns {string|null} null: the key is the program's. 'ignore': the key is used up here. 'literal': send this key
   *   after all. Anything else is an action of the caller's.
   */
  actionFor(tok) {
    const names = this._names(tok);
    if (this.afterLeader) {
      if (names.length === 0) { this.afterLeader = false; return null; }             // a paste: not meant for us
      if (/:3[u~A-Z]$/.test(tok.seq)) return 'ignore';                               // the leader's own key-up
      this.afterLeader = false;
      if (names.includes(/** @type {string} */ (this.leader))) return 'literal';
      for (const n of names) if (this.bindings[n]) return this.bindings[n];
      return 'ignore';
    }
    for (const n of names) if (this.direct[n]) return this.direct[n];
    if (this.leader && names.includes(this.leader)) { this.afterLeader = true; return 'ignore'; }
    return null;
  }

  /** Whether a key asks a client that is only waiting to give up. @param {{kind: string, seq: string}} tok */
  isInterrupt(tok) {
    if (tok.kind !== 'seq' && tok.kind !== 'lone-esc') return false;
    return decodeInputToken(tok.seq, { highSurrogate: '' }).map((ev) => classify(ev)).some((c) => c === 'C' || c === 'D');
  }
}

module.exports = { KeyTable };
