'use strict';
// @ts-check
/**
 * Where one session's sockets, locks and logs live under a runtime directory. The holder, the server
 * and every client derive these paths here, so they always agree.
 */
const path = require('node:path');

const SAFE_SEGMENT = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;

/**
 * @param {string} kind @param {string} value
 * @param {RegExp} [re] the shape to accept; defaults to a 64-character segment
 */
function segment(kind, value, re = SAFE_SEGMENT) {
  if (typeof value !== 'string' || !re.test(value)) {
    throw new TypeError(`invalid ${kind}: ${JSON.stringify(value)}`);
  }
  return value;
}

/**
 * @typedef {{
 *   uid: number, runtimeDir: string, logDir: string,
 *   sessionDir(id: string): string, ctlSock(id: string): string, ptySock(id: string): string,
 *   holderLock(id: string): string, sessiondLock(id: string): string,
 *   holderSpec(id: string, gen: number): string, holderJson(id: string): string, agentLink(id: string): string,
 *   logFile(id: string, comp: string): string,
 * }} Layout
 */

/** @param {string} runtimeDir absolute @returns {Layout} */
function sessionLayout(runtimeDir) {
  const uid = /** @type {() => number} */ (process.getuid)();
  const logDir = path.join(runtimeDir, 'log');
  const sessionDir = (/** @type {string} */ id) => path.join(runtimeDir, 's', segment('session id', id));
  return {
    uid,
    runtimeDir,
    logDir,
    sessionDir,
    ctlSock: (id) => path.join(sessionDir(id), 'ctl.sock'),
    ptySock: (id) => path.join(sessionDir(id), 'pty.sock'),
    holderLock: (id) => path.join(sessionDir(id), 'holder.lock'),
    sessiondLock: (id) => path.join(sessionDir(id), 'sessiond.lock'),
    holderSpec: (id, gen) => {
      if (!Number.isSafeInteger(gen) || gen < 0) throw new TypeError(`invalid holder gen: ${gen}`);
      return path.join(sessionDir(id), `holder-${gen}.json`);
    },
    holderJson: (id) => path.join(sessionDir(id), 'holder.json'),
    agentLink: (id) => path.join(sessionDir(id), 'agent.sock'),
    logFile: (id, comp) => path.join(logDir, segment('session id', id), `${segment('component', comp)}.log`),
  };
}

module.exports = { sessionLayout, segment };
