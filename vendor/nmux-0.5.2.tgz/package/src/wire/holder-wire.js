'use strict';
// @ts-check
/**
 * The field names on the wire that predate this project. Holders outlive every other process, so a server
 * must keep adopting the ones already running: these names stay as they are until a protocol version
 * negotiates them away, and this is the only file that spells them. Everything else sees `child`.
 */

/** @param {any} hello the holder's greeting, in memory */
const helloToWire = ({ child, ...rest }) => ({ ...rest, claude: child });
/** @param {any} m a greeting off the wire */
const helloFromWire = ({ claude, ...rest }) => ({ ...rest, child: claude });

/** @param {{icanon: boolean, isig: boolean, echo: boolean, fgIsChild: boolean, fg?: number}} l */
const lflagToWire = (l) => ({ t: 'LFLAG', icanon: l.icanon, isig: l.isig, echo: l.echo, fgIsClaude: l.fgIsChild, fg: l.fg });
/** @param {any} m @returns {{icanon: boolean, isig: boolean, echo: boolean, fgIsChild: boolean, fg: number|null}} */
const lflagFromWire = (m) => ({ icanon: m.icanon, isig: m.isig, echo: m.echo, fgIsChild: m.fgIsClaude, fg: m.fg ?? null });

/**
 * The session's current name from a STATE message. A server that predates the `name` field carries it
 * under the child's status instead.
 * @param {any} state @returns {string|null}
 */
const nameOfState = (state) => state.name || (state.claude && state.claude.name) || null;

module.exports = { helloToWire, helloFromWire, lflagToWire, lflagFromWire, nameOfState };
