'use strict';
// @ts-check
/**
 * The way to embed nmux. A program starts sessions, connects to them, and attaches terminals to them through this, and
 * nothing it does depends on how a session runs, so that can change underneath it.
 */
/**
 * @typedef {import('../client/text').ClientText} ClientText
 * @typedef {import('../wire/layout').Layout} Layout
 */
const { SessionClient } = require('./client');
const { createSession, startServer } = require('./host');
const { controlRequest, probeSocket, CtlError } = require('../wire/ctlclient');
const { sessionLayout, segment } = require('../wire/layout');
const { attach, attachPrecheck, labelFor, DEFAULT_TEXT } = require('../client/attach');
const { hhmm } = require('../client/text');
const { queryTermColors } = require('../client/termcolors');
const reader = require('../client/history');
const { parseWhen, stamp, dayOf, zone } = require('../base/time');
const { DEFAULTS: HOST_DEFAULTS } = require('../server/config');

/**
 * Kept histories: finding them, searching them, a pager on one, and the times they are read and shown in. A session keeps one when
 * its spec says `spool: {maxBytes: 0, keep: true, dir}`.
 */
const history = { keptUnder: reader.keptUnder, linesOf: reader.linesOf, allLinesOf: reader.allLinesOf, search: reader.search, view: reader.view,
  matchText: reader.matchText, matchJson: reader.matchJson, parseWhen, stamp, dayOf, zone };

module.exports = { HOST_DEFAULTS, segment, SessionClient, createSession, startServer, controlRequest, probeSocket, CtlError, sessionLayout, attach, attachPrecheck, labelFor, DEFAULT_TEXT, hhmm, queryTermColors, history };
