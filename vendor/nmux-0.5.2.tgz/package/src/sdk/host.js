'use strict';
// @ts-check
/** Starting a session's server, which is all an embedding program needs to know about how a session runs. */
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { writeAtomic } = require('../base/atomic');
const { ensureRuntime } = require('../platform/runtime');
const { sessionLayout } = require('../wire/layout');

const SERVER_MAIN = require.resolve('../server/run.js');

/**
 * Starts the server of a session whose spec is already on disk. `NMUX_SERVER_BIN` in `env` names another implementation's binary, run as
 * `BIN __server --spec FILE`: the two speak one protocol and read one spec, so a session can be served by either.
 * @param {string} specFile @param {{recover?: boolean, waitForClient?: boolean, env?: Record<string, string|undefined>}} [o]
 *   recover: adopt the holder that is running. waitForClient: a terminal is about to attach, so the program starts when it arrives.
 * @returns {import('node:child_process').ChildProcess}
 */
function startServer(specFile, { recover = false, waitForClient = false, env = process.env } = {}) {
  const args = ['--spec', specFile, ...(recover ? ['--recover'] : []), ...(waitForClient ? ['--wait-for-client'] : [])];
  const bin = env.NMUX_SERVER_BIN;
  const child = spawn(bin || process.execPath, bin ? ['__server', ...args] : [SERVER_MAIN, ...args], { detached: true, stdio: 'ignore', cwd: '/', env });
  child.unref();
  return child;
}

/**
 * Writes a session's spec and starts it.
 * @param {{id: string, name: string, runtimeDir: string, stateFile?: string|null, child: {argv: string[], env: Record<string, string|undefined>, cwd: string},
 *   pty: {cols: number, rows: number}, term?: string, nestEnv?: string|null, config?: object, configFile?: string, messages?: object,
 *   managed?: object, termColors?: object|null, holderEnv?: Record<string, string>}} spec see RemoteController for `managed`
 * @param {{waitForClient?: boolean, env?: Record<string, string|undefined>}} [o]
 * @returns {{specFile: string, process: import('node:child_process').ChildProcess}}
 */
function createSession(spec, o = {}) {
  const layout = sessionLayout(spec.runtimeDir);
  ensureRuntime(layout);
  fs.mkdirSync(layout.sessionDir(spec.id), { recursive: true, mode: 0o700 });
  const specFile = path.join(layout.sessionDir(spec.id), 'session.json');
  writeAtomic(specFile, { schema: 'nmux.session/1', stateFile: path.join(layout.sessionDir(spec.id), 'state.json'), createdAt: new Date().toISOString(), ...spec });
  return { specFile, process: startServer(specFile, o) };
}

module.exports = { startServer, createSession };
