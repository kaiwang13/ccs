'use strict';
// @ts-check
/**
 * A long-lived control connection to one session: requests, STATE and EVENT pushes, and reconnecting by itself, because a
 * session's server can restart at any moment and the session goes on.
 */
const net = require('node:net');
const { EventEmitter } = require('node:events');
const { FramedSocket, CTL_PROTO, T } = require('../wire/proto');
const { onControl, CtlError } = require('../wire/ctlclient');

const DEFAULT_TIMEOUT_MS = 5000;
/** What depends on the shell waits for a new server to read everything back, which on a busy machine is not quick. */
const READ_BACK_TIMEOUT_MS = 120000;

/**
 * Events: 'up'(welcome), 'down'(), 'subscribed'(where things stand), 'state'(STATE), 'event'({event, ...}), 'refused'(REFUSE).
 */
class SessionClient extends EventEmitter {
  /** @param {{sockPath: string, label?: string, backoffMs?: number[], subscribe?: {events?: string[], controller?: boolean}|null}} o */
  constructor({ sockPath, label = 'sdk', backoffMs = [100, 250, 500, 1000, 2000, 5000], subscribe = null }) {
    super();
    this.sockPath = sockPath;
    this.label = label;
    this.backoffMs = backoffMs;
    this.subscription = subscribe;
    /** @type {FramedSocket|null} */
    this.fsock = null;
    this.up = false;
    this.stopped = true;
    this.nextId = 1;
    this.attempt = 0;
    /** @type {ReturnType<typeof setTimeout>|null} */
    this.timer = null;
    /** @type {Map<number, {resolve: (v: any) => void, reject: (e: Error) => void, timer: ReturnType<typeof setTimeout>}>} */
    this.pending = new Map();
    /** @type {Buffer[]} text of a reply on its way */
    this.reply = [];
    /** @type {object[]|null} events that arrived before the answer to SUBSCRIBE: they are newer than it */
    this.early = null;
    /** one text reply at a time: nothing in OUTPUT frames says which request they answer */
    /** @type {Promise<unknown>} */
    this.textQueue = Promise.resolve();
  }

  open() {
    if (!this.stopped) return;
    this.stopped = false;
    this._connect();
  }

  close() {
    this.stopped = true;
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    const { fsock } = this;
    if (fsock) { this._closed(fsock); fsock.destroy(); }
  }

  /** Settle a closed connection, only if it is still the current one. @param {FramedSocket} fsock @returns {boolean} */
  _closed(fsock) {
    if (this.fsock !== fsock) return false;
    const wasUp = this.up;
    this.up = false;
    this.fsock = null;
    for (const [, p] of this.pending) { clearTimeout(p.timer); p.reject(new CtlError('DOWN', 'control connection closed')); }
    this.pending.clear();
    this.reply = [];
    if (wasUp) this.emit('down');
    return true;
  }

  _connect() {
    const sock = net.createConnection(this.sockPath);
    const fsock = new FramedSocket(sock);
    this.fsock = fsock;
    sock.on('connect', () => fsock.sendControl({ t: 'HELLO', proto: CTL_PROTO, role: 'control', cols: 0, rows: 0, cursorRow: 0, focus: false,
      tty: null, pid: process.pid, label: this.label, termProgram: null, flags: {} }));
    fsock.on('frame', (/** @type {any} */ f) => { if (f.type === T.OUTPUT) this.reply.push(f.payload); });
    onControl(fsock, (m) => {
      if (m.t === 'WELCOME') { this._welcomed(m); return; }
      if (m.t === 'STATE') { this.emit('state', m); return; }
      if (m.t === 'EVENT') { const { t, ...e } = m; void t; if (this.early) this.early.push(e); else this.emit('event', e); return; }
      if (m.t === 'PING') { fsock.sendControl({ t: 'PONG', seq: m.seq }); return; }
      if (m.t === 'RES') { this._answered(m); return; }
      if (m.t === 'REFUSE') { this.emit('refused', m); fsock.destroy(); }
    });
    fsock.on('error', () => {});
    fsock.on('close', () => {
      if (!this._closed(fsock) || this.stopped) return;
      const delay = this.backoffMs[Math.min(this.attempt++, this.backoffMs.length - 1)];
      this.timer = setTimeout(() => { this.timer = null; if (!this.stopped) this._connect(); }, delay);
    });
  }

  /** @param {any} m */
  _welcomed(m) {
    this.up = true;
    this.attempt = 0;
    this.emit('up', m);
    if (!this.subscription) return;
    this.early = [];
    this.request('SUBSCRIBE', this.subscription).then((r) => {
      const held = this.early || [];
      this.early = null;
      if (r.ok) this.emit('subscribed', r.data);
      for (const e of held) this.emit('event', e);
    }, () => { this.early = null; });
  }

  /** @param {any} m */
  _answered(m) {
    const p = this.pending.get(m.id);
    if (!p) { this.reply = []; return; }                                               // an answer given up on: its text is not the next one's
    this.pending.delete(m.id);
    clearTimeout(p.timer);
    const output = Buffer.concat(this.reply);
    this.reply = [];
    p.resolve({ ok: !!m.ok, data: m.data === undefined ? null : m.data, error: m.error === undefined ? null : m.error, output });
  }

  /** @param {string} op @param {object} [args] @param {number} [timeoutMs] @returns {Promise<{ok: boolean, data: any, error: any, output: Buffer}>} */
  request(op, args = {}, timeoutMs = DEFAULT_TIMEOUT_MS) {
    const { fsock } = this;
    if (!this.up || !fsock) return Promise.reject(new CtlError('DOWN', `${this.sockPath} is not connected`));
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(id); reject(new CtlError('TIMEOUT', `${op} got no reply within ${timeoutMs} ms`)); }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      fsock.sendControl({ t: 'REQ', id, op, args });
    });
  }

  /** A request that must succeed. @param {string} op @param {object} [args] @param {number} [timeoutMs] */
  async must(op, args, timeoutMs) {
    const r = await this.request(op, args, timeoutMs);
    if (!r.ok) throw new CtlError(String(r.error), `${op}: ${r.error}`);
    return r.data;
  }

  /** @param {string} op @param {object} args @param {number} [timeoutMs] @returns {Promise<any>} what the reply said, and its text */
  _reply(op, args, timeoutMs) {
    const run = () => this.request(op, args, timeoutMs).then((r) => { if (!r.ok) throw new CtlError(String(r.error), `${op}: ${r.error}`); return { ...r.data, text: r.output.toString('utf8') }; });
    const next = this.textQueue.then(run, run);
    this.textQueue = next.catch(() => {});
    return next;
  }

  /** @param {string} op @param {object} args @returns {Promise<string>} */
  _textOf(op, args) { return this._reply(op, args).then((r) => r.text); }

  // ---- reading -----------------------------------------------------------------------------------------------------
  status() { return this.must('STATUS'); }
  /** The rows of the screen as text. */
  screen() { return this._textOf('SCREEN', {}); }
  /** @param {{lines?: number|null, ansi?: boolean}} [o] */
  capture(o = {}) { return this._textOf('CAPTURE', o); }
  clients() { return this.must('CLIENTS').then((d) => d.clients); }
  /** What has been shown from a row on. @param {number|null} [row] null: the top of the screen @returns {Promise<{text: string, top: number, cursor: number}>} */
  since(row = null) { return this._reply('SINCE', { row }); }
  /** What the shell has said about itself, and what it has run. */
  commands() { return this.must('COMMANDS', {}, READ_BACK_TIMEOUT_MS); }
  /** A command's record and output: the last to finish, or the one asked for. @param {{seq?: number, ansi?: boolean}} [o] */
  last(o = {}) { return this._reply('LAST', o, READ_BACK_TIMEOUT_MS); }

  // ---- acting ------------------------------------------------------------------------------------------------------
  /** Types text as a person would, through the gates. @param {string} text @param {{enter?: boolean}} [o] */
  send(text, { enter = false } = {}) { return this.must('SEND', { text, enter }); }
  /**
   * Runs a line in the shell at its prompt; a `command` event with this `run` says how it went.
   * @param {string} text @param {{queue?: boolean}} [o] queue: wait for the prompt rather than be refused @returns {Promise<{run: number, queued?: boolean}>}
   */
  run(text, { queue = false } = {}) { return this.must('RUN', { text, queue }, READ_BACK_TIMEOUT_MS); }
  /** Past the gates. @param {string} text */
  write(text) { return this.must('WRITE', { text }); }
  /** @param {'SIGCONT'|'SIGTERM'} sig */
  signal(sig) { return this.must('SIGNAL', { sig }); }
  /** @param {number} [timeoutMs] */
  stop(timeoutMs) { return this.must('STOP', {}, timeoutMs); }
  restart() { return this.must('RESTART'); }
  /** @param {string[]} argv */
  respawn(argv) { return this.must('RESPAWN', { argv }); }
  /** @param {string} name */
  rename(name) { return this.must('RENAME', { name }); }
  /** @param {object} args see KICK */
  kick(args) { return this.must('KICK', args); }
  /** @param {'info'|'warn'} level @param {string} code @param {string} text */
  notice(level, code, text) { return this.must('NOTICE', { level, code, text }); }

  // ---- extending ---------------------------------------------------------------------------------------------------
  /** @param {string} to @param {{from?: string[]}} [o] */
  setPhase(to, o = {}) { return this.must('PHASE', { to, ...o }); }
  /** @param {string} code */
  block(code) { return this.must('PHASE', { code }); }
  /** @param {string} name @param {{effect?: 'drop'|'filter'|null, passable?: boolean, blocking?: boolean, rank?: number}} o effect null removes it */
  gate(name, o) { return this.must('GATE', { name, ...o }); }
  /** @param {Record<string, unknown>} attrs @param {{attention?: boolean}} [o] */
  setAttrs(attrs, o = {}) { return this.must('SET_ATTR', { attrs, ...o }); }
  stopProceed() { return this.must('STOP_PROCEED'); }
  /** The session's end has been written down, so it can go. */
  recorded() { return this.must('RECORDED'); }
}

module.exports = { SessionClient };
