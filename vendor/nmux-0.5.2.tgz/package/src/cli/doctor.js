'use strict';
// @ts-check
/** `nmux doctor`: each check says what is wrong and what to do about it. */
const { ensureRuntime } = require('../platform/runtime');
const { capabilities } = require('../platform');
const { ttyctl } = require('../platform/native');
const { listSessions } = require('./sessions');
const { withMarks } = require('./shells');

/** @param {any} paths @param {{stdout: any, env: Record<string, string|undefined>}} io @returns {number} */
function doctor(paths, { stdout, env }) {
  let failed = 0;
  /** @param {string} what @param {() => string} check */
  const line = (what, check) => {
    try { stdout.write(`ok    ${what}: ${check()}\n`); } catch (e) {
      failed += 1;
      stdout.write(`FAIL  ${what}: ${/** @type {Error} */ (e).message}\n`);
    }
  };
  line('node', () => process.version);
  line('process information', () => capabilities.procSource);
  line('native addon', () => { if (typeof ttyctl.flock !== 'function') throw new Error('not built: npm run build:native'); return 'loaded'; });
  line('node-pty', () => { require('node-pty'); return 'loaded'; });
  line('runtime dir', () => { ensureRuntime(paths); return paths.runtimeDir; });
  line('TERM', () => { if (!env.TERM) throw new Error('not set: sessions will use xterm-256color'); return env.TERM; });
  line('shell integration', () => (env.SHELL && withMarks([env.SHELL], env) ? `${env.SHELL} can say what it is doing` : `${env.SHELL || 'no $SHELL'} has none: run, last and wait --prompt will refuse`));
  line('sessions', () => `${listSessions(paths).filter((s) => s.alive).length} running`);
  return failed ? 1 : 0;
}

module.exports = { doctor };
