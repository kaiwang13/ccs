'use strict';
// @ts-check
/**
 * Starting a shell so that it says what it is doing. Each one is pointed at nmux's own start-up file, which runs the user's as
 * usual and adds the marks, so nothing is written to a dotfile. This only applies to a shell started as a person would start
 * one: arguments mean someone has something particular in mind.
 */
const crypto = require('node:crypto');
const path = require('node:path');

const DIR = path.join(__dirname, '..', '..', 'shell');
const LOGIN = '-l';

/** A word fish reads back as `text`. @param {string} text */
const fishQuoted = (text) => `'${text.replace(/[\\']/g, '\\$&')}'`;

/**
 * @param {string[]} argv @param {Record<string, string|undefined>} env the environment the shell would have
 * @returns {{argv: string[], env: Record<string, string>, shell: {token: string}}|null} what to start instead, or null
 */
function withMarks(argv, env) {
  const login = argv[1] === LOGIN;
  if (argv.length > (login ? 2 : 1)) return null;
  const token = crypto.randomBytes(8).toString('hex');
  const shell = { token };
  switch (path.basename(argv[0])) {
    case 'bash': return { argv: [argv[0], '--rcfile', path.join(DIR, 'nmux.bash')], env: { NMUX_SHELL_TOKEN: token, ...(login ? { NMUX_SHELL_LOGIN: '1' } : {}) }, shell };
    case 'zsh': return { argv, env: { NMUX_SHELL_TOKEN: token, ZDOTDIR: path.join(DIR, 'zsh'), ...(env.ZDOTDIR === undefined ? {} : { NMUX_ZDOTDIR: env.ZDOTDIR }) }, shell };
    case 'fish': return { argv: [...argv, '--init-command', `source ${fishQuoted(path.join(DIR, 'nmux.fish'))}`], env: { NMUX_SHELL_TOKEN: token }, shell };
    default: return null;
  }
}

module.exports = { withMarks };
