'use strict';
// @ts-check
/**
 * What `nmux demo` fills sessions with, to look at how nmux shows things: files a shell prints, the lines it types to print
 * them, a program that has the whole screen, and a history of three days. nmux-rs makes the same, byte for byte.
 */
const fs = require('node:fs');
const path = require('node:path');
const history = require('../wire/history');
const { parseWhen, stamp } = require('../base/time');

const ESC = '\x1b';
const HOUR_MS = 3600000;
const MINUTE_MS = 60000;
const SAMPLE = 'The quick brown fox jumps over the lazy dog';
const NAMES = ['black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'];

/** `text` in a style, and the style ended. @param {string} codes @param {string} text */
const sgr = (codes, text) => `${ESC}[${codes}m${text}${ESC}[m`;
/** A link. @param {string} url @param {string} text @param {string} [params] */
const link = (url, text, params = '') => `${ESC}]8;${params};${url}${ESC}\\${text}${ESC}]8;;${ESC}\\`;
/** A label and what it is about, lined up. @param {string} label @param {string} rest */
const row = (label, rest) => `  ${label.padEnd(30)}${rest}`;

function colours() {
  const out = ['The sixteen colours, as text and behind it:', ''];
  out.push(`  ${NAMES.map((n, i) => sgr(`3${i}`, n)).join(' ')}`);
  out.push(`  ${NAMES.map((n, i) => sgr(`9${i}`, n)).join(' ')}`);
  out.push(`  ${NAMES.map((n, i) => sgr(`4${i}`, ` ${n} `)).join('')}`);
  out.push(`  ${NAMES.map((n, i) => sgr(`10${i}`, ` ${n} `)).join('')}`);
  out.push('', 'The 256:', '');
  for (let r = 0; r < 6; r++) {
    let line = '  ';
    for (let i = 0; i < 36; i++) line += sgr(`48;5;${16 + r * 36 + i}`, '  ');
    out.push(line);
  }
  let greys = '  ';
  for (let i = 232; i < 256; i++) greys += sgr(`48;5;${i}`, '   ');
  out.push(greys, '', 'Any colour at all:', '');
  let ramp = '  ';
  for (let i = 0; i < 64; i++) ramp += sgr(`48;2;${i * 4};${255 - i * 4};128`, ' ');
  out.push(ramp);
  return out;
}

const STYLES = [['bold', '1'], ['dim', '2'], ['italic', '3'], ['underlined', '4'], ['underlined twice', '4:2'], ['underlined in a curl', '4:3'],
  ['underlined in dots', '4:4'], ['underlined in dashes', '4:5'], ['underlined in red', '4;58;2;255;0;0'], ['blinking', '5'], ['inverse', '7'],
  ['hidden', '8'], ['struck through', '9'], ['overlined', '53'], ['all of them', '1;3;4;9;53']];

function styles() {
  return ['Styles of text:', '', ...STYLES.map(([name, code]) => row(name, sgr(code, SAMPLE)))];
}

/** @param {number} cols */
function characters(cols) {
  return ['Characters that take two columns, none, or more than one code point:', '',
    row('Chinese, Japanese, Korean', '中文 日本語 한국어'),
    row('emoji', '😀 👍🏽 👨‍👩‍👧 🇯🇵 ✔️'),
    row('built from parts', 'é ä ñ ộ'),
    row('right to left', 'עברית العربية'),
    row('box drawing', '┌──┬──┐'), row('', '│  │  │'), row('', '├──┼──┤'), row('', '└──┴──┘'),
    row('blocks and shades', '░▒▓█ ▁▂▃▄▅▆▇█'),
    row('braille', '⠁⠃⠉⠙⠑⠋⠛⠓⠊⠚'),
    row('line drawing, the DEC way', `${ESC}(0lqqqqk${ESC}(B`), row('', `${ESC}(0x    x${ESC}(B`), row('', `${ESC}(0mqqqqj${ESC}(B`),
    '', 'A wide character that does not fit at the end of a line starts the next:', '',
    `${'x'.repeat(Math.max(cols - 1, 1))}中`];
}

/** @param {number} cols */
function wrapping(cols) {
  let ruler = '';
  for (let i = 1; ruler.length < cols * 3 + 5; i++) ruler += `${'.'.repeat(9)}${i % 10}`;
  return ['A line longer than the screen, which the terminal wraps, and which a narrower or wider one wraps again:', '', ruler,
    '', 'A line exactly as wide as the screen, then the next:', '', 'x'.repeat(cols), 'the next line',
    '', 'Tab stops:', '', 'a\tb\tc\td\te', '1234567\t12345678\t123456789\tend'];
}

function links() {
  return ['Links, which a terminal that knows them lets you open:', '',
    row('an ordinary link', link('https://example.com/', 'example.com')),
    row('one link in two pieces', `${link('https://example.com/one', 'one link', 'id=demo')} and ${link('https://example.com/one', 'in two pieces', 'id=demo')}`)];
}

/**
 * The files of a demo, for a screen `cols` wide: what its shell prints, and the program that has the whole screen.
 * @param {number} cols @returns {Array<{name: string, text: string}>}
 */
function samples(cols) {
  const printed = [['colours', colours()], ['styles', styles()], ['characters', characters(cols)], ['wrapping', wrapping(cols)], ['links', links()]]
    .map(([name, lines]) => ({ name: /** @type {string} */ (name), text: `${/** @type {string[]} */ (lines).join('\n')}\n` }));
  return [...printed, { name: 'screen', text: SCREEN }];
}

/** What the demo session types, one line at a time, each run when the one before has finished. */
const LINES = ['cat colours', 'cat styles', 'cat characters', 'cat wrapping', 'cat links', "printf '\\033]2;%s\\007' 'nmux demo'", 'cat missing', 'seq 1 300'];

/** A program that has the whole screen: a frame, the time, and colours, drawn again every second. */
const SCREEN = `# nmux demo: a program that has the whole screen
leave() { printf '\\033[?25h\\033[?1049l'; exit 0; }
trap leave INT TERM HUP
printf '\\033[?1049h\\033[?25l'
n=0
while :; do
  size=$(stty size 2>/dev/null) || size='24 80'
  rows=\${size% *} cols=\${size#* }
  line=''; i=2; while [ $i -lt "$cols" ]; do line="$line─"; i=$((i+1)); done
  printf '\\033[H\\033[2J┌%s┐' "$line"
  r=2; while [ $r -lt "$rows" ]; do printf '\\033[%d;1H│\\033[%d;%dH│' $r $r "$cols"; r=$((r+1)); done
  printf '\\033[%d;1H└%s┘' "$rows" "$line"
  printf '\\033[3;4H\\033[1mnmux demo:\\033[m a program that has the whole screen, on the other one'
  printf '\\033[5;4H%s, drawn %d times' "$(date +%H:%M:%S)" "$n"
  printf '\\033[7;4H'; c=0; while [ $c -lt 8 ]; do printf '\\033[4%dm    ' $c; c=$((c+1)); done; printf '\\033[m'
  printf '\\033[9;4HCtrl+\\\\ d leaves it running; nmux stop ends it.'
  n=$((n+1)); sleep 1
done
`;

/**
 * The lines of a history of three days, up to `now`, on clocks in `timeZone`: a build twice a day and more, some of which failed.
 * @param {number} now @param {string} timeZone @returns {Array<{at: number, text: string}>}
 */
function days(now, timeZone) {
  const today = /** @type {number} */ (parseWhen('today', now, timeZone));
  const yesterday = /** @type {number} */ (parseWhen('yesterday', now, timeZone));
  const before = /** @type {number} */ (parseWhen(stamp(yesterday - HOUR_MS, timeZone).slice(0, 10), now, timeZone));
  const out = [];
  let n = 0;
  for (const midnight of [before, yesterday, today]) {
    for (const hour of [1, 6, 9, 13, 17, 22]) {
      const at = midnight + hour * HOUR_MS + 17 * MINUTE_MS;
      if (at + 3 * MINUTE_MS > now) return out;
      n += 1;
      out.push({ at, text: '$ make test' });
      out.push({ at: at + MINUTE_MS, text: `build ${n}: 120 tests` });
      out.push({ at: at + 3 * MINUTE_MS, text: n % 3 === 0 ? `ERROR: build ${n}: 2 of 120 tests failed` : `build ${n}: all passed` });
    }
  }
  return out;
}

/**
 * Writes a history, as an ended session's is kept, into `dir`.
 * @param {string} dir @param {{id: string, name: string, cwd: string}} who @param {Array<{at: number, text: string}>} lines
 */
function keep(dir, who, lines) {
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  let text = '';
  for (const l of lines) text += history.timeLine(l.at) + history.rowLine(l.text, false);
  text += history.markLine(0, Buffer.byteLength(lines.map((l) => `${l.text}\n`).join('')), lines.length);
  fs.writeFileSync(path.join(dir, `${history.PREFIX}0`), text, { mode: 0o600 });
  const createdAt = new Date(lines.length ? lines[0].at : Date.now()).toISOString();
  const meta = { schema: 'nmux.history/1', id: who.id, name: who.name, createdAt, cwd: who.cwd, argv: ['nmux', 'demo'] };
  fs.writeFileSync(path.join(dir, history.META), JSON.stringify(meta), { mode: 0o600 });
}

module.exports = { samples, LINES, days, keep };
