'use strict';
// @ts-check
/**
 * What a shell says about itself: OSC 133, the marks terminals use for prompt jumping, with nmux's own fields beside the
 * standard ones. Anything a program prints can look like a mark, so only one carrying the session's token counts: without that,
 * `cat`-ing a file could end a `run` early. Fields nmux adds stop here, and a terminal gets the standard mark.
 *
 *   A       a prompt starts
 *   B       the prompt ends; what is typed goes here: typed=1, if the line already holds something
 *   C       a command starts: cmdline_url=
 *   D;code  a command ended, or a line was entered that ran none: cwd=, and vi=1 for a line editor in vi mode. No code: it is not known
 *   N       this shell cannot say any of the above
 */

/** @typedef {{kind: 'A'|'B'|'C'|'D'|'N', exit: number|null, command: string|null, cwd: string|null, typed?: boolean, vi?: boolean}} Mark */

const OSC = '\x1b]133;';
const BEL = '\x07';

/** @param {string} text */
function decoded(text) {
  try { return decodeURIComponent(text); } catch { return text; }
}

/**
 * The mark in an OSC 133 payload, or null if it is not from this session's shell.
 * @param {string} data the OSC payload @param {string} token
 * @returns {{mark: Mark, standard: Buffer}|null} `standard` is what goes on to a terminal
 */
function parseMark(data, token) {
  const [, kind, ...parts] = data.split(';');
  if (kind !== 'A' && kind !== 'B' && kind !== 'C' && kind !== 'D' && kind !== 'N') return null;
  /** @type {Record<string, string>} */
  const fields = {};
  /** @type {number|null} */
  let exit = null;
  for (const part of parts) {
    const eq = part.indexOf('=');
    if (eq > 0) fields[part.slice(0, eq)] = part.slice(eq + 1);
    else if (kind === 'D' && /^\d+$/.test(part)) exit = Number(part);
  }
  if (fields.nmux !== token) return null;
  /** @type {Mark} */
  const mark = { kind, exit, command: fields.cmdline_url === undefined ? null : decoded(fields.cmdline_url), cwd: fields.cwd === undefined ? null : decoded(fields.cwd), typed: fields.typed === '1', vi: fields.vi === '1' };
  if (kind === 'N') return { mark, standard: Buffer.alloc(0) };                         // not a standard mark, and of no interest to a terminal
  const rest = { A: fields.redraw === undefined ? '' : `;redraw=${fields.redraw}`, B: '', C: fields.cmdline_url === undefined ? '' : `;cmdline_url=${fields.cmdline_url}`, D: exit === null ? '' : `;${exit}` }[kind];
  return { mark, standard: Buffer.from(`${OSC}${kind}${rest}${BEL}`, 'utf8') };
}

module.exports = { parseMark };
