# zsh reads this because ZDOTDIR points here. It does what the user's own .zshenv would have, and stays in the way of the files after
# it, one by one, so that the marks are added once the last of them has run, when nothing can take them out again. Nothing here
# writes to a dotfile.

typeset -g __nmux_token=${NMUX_SHELL_TOKEN-}
typeset -g __nmux_dir=${${(%):-%x}:A:h}
unset NMUX_SHELL_TOKEN

if [[ -n ${NMUX_ZDOTDIR+set} ]]; then
  ZDOTDIR=$NMUX_ZDOTDIR
  unset NMUX_ZDOTDIR
else
  unset ZDOTDIR
fi

# At the top level, here and in the files after this: this is where the user's own `typeset` has to take effect.
if [[ -r ${ZDOTDIR:-$HOME}/.zshenv ]]; then
  builtin source ${ZDOTDIR:-$HOME}/.zshenv
fi

if [[ -o interactive && -n $__nmux_token ]]; then
  typeset -g __nmux_zdotdir=${ZDOTDIR-} __nmux_zdotdir_set=${ZDOTDIR+1}
  ZDOTDIR=$__nmux_dir
fi
