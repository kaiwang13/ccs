# The marks that tell nmux where a prompt starts, where a command starts, and how it ended. The token proves a mark came from this
# shell. It is only in variables that are not exported, so nothing this shell runs can print a mark. The prompt holds no token at
# all: where it ends is said once zle is waiting for keys, which no theme, widget or order of hooks can get in the way of.
#
# `emulate -L zsh` first in everything: the user's options, such as ksh_arrays, must not change what this means.

typeset -g __nmux_fd=

# What may not appear inside an OSC.
__nmux_encode() {
  emulate -L zsh
  local s=$1
  s=${s//\%/%25}
  s=${s//;/%3B}
  s=${s//$'\e'/%1B}
  s=${s//$'\a'/%07}
  s=${s//$'\n'/%0A}
  s=${s//$'\r'/%0D}
  REPLY=$s
}

# zle runs this as soon as it looks for keys, with the prompt on the screen. A line pushed back with Esc-q or print -z is already there.
__nmux_prompt_ready() {
  emulate -L zsh
  local fd=$__nmux_fd
  zle -F $fd
  exec {fd}<&-
  __nmux_fd=
  builtin printf '\e]133;B;%snmux=%s\a' "${BUFFER:+typed=1;}" $__nmux_token
}
zle -N __nmux_prompt_ready

# All precmd hooks are given the same $?, so it does not matter where this one is.
__nmux_before_prompt() {
  local code=$? REPLY
  emulate -L zsh
  __nmux_encode $PWD
  # Without bracketed paste, what is typed at a vi prompt in command mode would be commands to it.
  local vi=
  (( ${+zle_bracketed_paste} )) || [[ $(builtin bindkey -lL main) != *viins* ]] || vi='vi=1;'
  builtin printf '\e]133;D;%s;cwd=%s;%snmux=%s\a\e]7;file://%s%s\a' $code $REPLY "$vi" $__nmux_token ${HOST-} $REPLY
  if [[ -z $__nmux_fd ]]; then
    local fd
    exec {fd}</dev/null
    __nmux_fd=$fd
    zle -Fw $fd __nmux_prompt_ready
  fi
  return $code
}

# Only for terminals, so there is no token to look after. Without prompt_percent a person would see this.
__nmux_wrap_prompt() {
  [[ -o prompt_percent ]] || return 0
  emulate -L zsh
  [[ $PS1 == *133\;A* ]] || PS1=$'%{\e]133;A;redraw=0\a%}'$PS1
  return 0
}

__nmux_command_start() {
  emulate -L zsh
  local REPLY
  __nmux_encode $1
  builtin printf '\e]133;C;cmdline_url=%s;nmux=%s\a' $REPLY $__nmux_token
}

() {
  emulate -L zsh
  precmd_functions=(__nmux_before_prompt $precmd_functions __nmux_wrap_prompt)
  preexec_functions=($preexec_functions __nmux_command_start)
  # zsh ends a line a command left unfinished before any hook runs, so a mark from a hook would count that as output. This one is
  # drawn at the end of the output itself, and takes up no room. The one from the hook says where the shell has got to.
  PROMPT_EOL_MARK=$'%{\e]133;D;%?;nmux='$__nmux_token$'\a%}'${PROMPT_EOL_MARK-%B%S%#%s%b}
}
