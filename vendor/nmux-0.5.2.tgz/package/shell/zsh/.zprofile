# A login shell reads this in place of the user's own: see .zshenv.

if [[ -n $__nmux_zdotdir_set ]]; then ZDOTDIR=$__nmux_zdotdir; else unset ZDOTDIR; fi

if [[ -r ${ZDOTDIR:-$HOME}/.zprofile ]]; then
  builtin source ${ZDOTDIR:-$HOME}/.zprofile
fi

__nmux_zdotdir=${ZDOTDIR-} __nmux_zdotdir_set=${ZDOTDIR+1}
ZDOTDIR=$__nmux_dir
