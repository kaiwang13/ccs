# Read in place of the user's own: see .zshenv. ZDOTDIR is theirs again from here on, so zsh goes on to their .zlogin by itself.

if [[ -n $__nmux_zdotdir_set ]]; then ZDOTDIR=$__nmux_zdotdir; else unset ZDOTDIR; fi
unset __nmux_zdotdir __nmux_zdotdir_set

# /etc/zshrc has run with ZDOTDIR still pointing at nmux, and on some systems sets HISTFILE from it.
if [[ ${HISTFILE-} == $__nmux_dir/* ]]; then
  HISTFILE=${ZDOTDIR:-$HOME}/${HISTFILE:t}
fi

if [[ -r ${ZDOTDIR:-$HOME}/.zshrc ]]; then
  builtin source ${ZDOTDIR:-$HOME}/.zshrc
fi

builtin source $__nmux_dir/hooks.zsh
unset __nmux_dir
