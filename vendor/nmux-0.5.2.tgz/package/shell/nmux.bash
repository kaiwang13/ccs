# bash reads this in place of its usual start-up files (--rcfile). It does what bash would have done, then adds the marks that
# tell nmux where a prompt starts, where a command starts, and how it ended. Nothing here writes to a dotfile.
#
# The token proves a mark came from this shell. It stays in a variable that is not exported, and in nothing that might be, so
# nothing this shell runs can print a mark.

__nmux_token=${NMUX_SHELL_TOKEN-}
__nmux_login=${NMUX_SHELL_LOGIN-}
unset NMUX_SHELL_TOKEN NMUX_SHELL_LOGIN

if [ -n "$__nmux_login" ]; then
  [ -r /etc/profile ] && . /etc/profile
  if [ -r ~/.bash_profile ]; then . ~/.bash_profile
  elif [ -r ~/.bash_login ]; then . ~/.bash_login
  elif [ -r ~/.profile ]; then . ~/.profile
  fi
elif [ -r ~/.bashrc ]; then
  . ~/.bashrc
fi

# Those files may have left `set -a` on, which would export everything defined here.
case $- in *a*) set +a; __nmux_exporting=1 ;; esac

# --rcfile cannot be given to a login shell, so what makes one differ at the end is done here.
if [ -n "$__nmux_login" ]; then
  logout() { builtin exit "$@"; }
  [ -n "$(trap -p EXIT)" ] || trap '[ ! -r ~/.bash_logout ] || . ~/.bash_logout' EXIT
fi
unset __nmux_login

__nmux_writable() {
  local d
  d=$(declare -p "$1" 2>/dev/null) || return 0
  d=${d#declare -}
  case ${d%% *} in *r*) return 1 ;; esac
}

# PS0 arrived in bash 4.4, and only works with promptvars on: otherwise a person would see it.
__nmux_can_mark() {
  [ "$(( BASH_VERSINFO[0] * 100 + BASH_VERSINFO[1] ))" -ge 404 ] && shopt -q promptvars &&
    __nmux_writable PS0 && __nmux_writable PS1 && __nmux_writable PROMPT_COMMAND
}

if [ -z "$__nmux_token" ]; then
  :
elif ! __nmux_can_mark; then
  builtin printf '\e]133;N;nmux=%s\a' "$__nmux_token"
else
  declare +x __nmux_token
  __nmux_version=$(( BASH_VERSINFO[0] * 100 + BASH_VERSINFO[1] ))
  # Bytes rather than the prompt's own escapes, because a prompt expands its variables after those. Only the name is ever in PS1.
  __nmux_prompt_start=$'\001\e]133;A;redraw=0\a\002'
  __nmux_prompt_end=$'\001\e]133;B;nmux='"$__nmux_token"$'\a\002'
  __nmux_prompt_name='${__nmux_prompt_end-}'
  __nmux_next=0
  __nmux_steady=

  # In PROMPT_COMMAND as text, which an `export PROMPT_COMMAND` hands to shells without these functions.
  __nmux_first_entry='__nmux_code=$?;[ -z "${__nmux_token+x}" ]||{ __nmux_debug=$(trap -p DEBUG);__nmux_before_prompt; }'
  __nmux_last_entry='__nmux_after=$?;[ -z "${__nmux_token+x}" ]||__nmux_wrap_prompt'

  # A function that returns non-zero ends a shell under `set -e`, which a prompt must never do.
  __nmux_status() {
    case $- in *e*) return 0 ;; esac
    return "$1"
  }

  # What may not appear inside an OSC. The result is left in REPLY, because this runs on every prompt.
  __nmux_encode() {
    local percent=% s=$1
    s=${s//$percent/%25}
    s=${s//;/%3B}
    s=${s//$'\e'/%1B}
    s=${s//$'\a'/%07}
    s=${s//$'\n'/%0A}
    s=${s//$'\r'/%0D}
    REPLY=$s
  }

  __nmux_wrap() { PS1='${__nmux_prompt_start-}'$PS1$__nmux_prompt_name; }

  # Before bash 5.1 only the first element of an array is run, so one is no different from a string.
  __nmux_many_commands() { [ "$__nmux_version" -ge 501 ] && [[ ${PROMPT_COMMAND+x} && ${PROMPT_COMMAND@a} == *a* ]]; }

  # It has to be last, and may no longer be.
  __nmux_add_last_entry() {
    if __nmux_many_commands; then
      local i
      for i in "${!PROMPT_COMMAND[@]}"; do [ "${PROMPT_COMMAND[i]}" != "$__nmux_last_entry" ] || unset "PROMPT_COMMAND[i]"; done
      PROMPT_COMMAND+=("$__nmux_last_entry")
    else
      PROMPT_COMMAND=${PROMPT_COMMAND//$'\n'"$__nmux_last_entry"/}$'\n'$__nmux_last_entry
    fi
  }

  # The last entry is there for whatever rebuilds the prompt, and it costs anyone timing commands with a DEBUG trap: that fires for
  # it. So for them only, it goes if nothing needs it, and comes back if something turns out to. A function cannot see that trap,
  # which is why the first entry looks for it.
  __nmux_drop_last_entry() {
    __nmux_steady=
    if __nmux_many_commands; then
      local n=${#PROMPT_COMMAND[@]}
      [ "${PROMPT_COMMAND[n-1]}" != "$__nmux_last_entry" ] || unset "PROMPT_COMMAND[n-1]"
    else
      PROMPT_COMMAND=${PROMPT_COMMAND%$'\n'"$__nmux_last_entry"}
    fi
  }

  # First in PROMPT_COMMAND: nothing has yet touched $?.
  __nmux_before_prompt() {
    local code=$__nmux_code vi= REPLY
    # With history off, what it last kept says nothing about what is running. Before bash 5.1 HISTCMD here is that of the last entry.
    if [[ ! -o history ]]; then __nmux_next=2147483647
    elif [ "$__nmux_version" -ge 501 ]; then __nmux_next=${HISTCMD:-0}
    else
      local last
      last=$(HISTTIMEFORMAT= builtin history 1)
      last=${last#"${last%%[![:space:]]*}"}
      last=${last%%[![:digit:]]*}
      __nmux_next=$(( ${last:-0} + 1 ))
    fi
    # Something put itself ahead of this, as `source ~/.bashrc` can, so $? was not the command's. Not knowing beats saying 0.
    if [[ $PROMPT_COMMAND != "$__nmux_first_entry"* ]]; then
      code=
      PROMPT_COMMAND=$__nmux_first_entry$'\n'${PROMPT_COMMAND/"$__nmux_first_entry"/:}
    fi
    case ${PS0-} in *__nmux_command_start*) ;; *) PS0=${PS0-}'$(__nmux_command_start 2>/dev/null)' ;; esac
    [[ ! -o vi ]] || vi='vi=1;'
    __nmux_encode "$PWD"
    builtin printf '\e]133;D;%s;cwd=%s;%snmux=%s\a\e]7;file://%s%s\a' "$code" "$REPLY" "$vi" "$__nmux_token" "${HOSTNAME-}" "$REPLY"
    case $PS1 in
      *"$__nmux_prompt_name"*) if [ -n "$__nmux_steady" ] && [ -n "$__nmux_debug" ]; then __nmux_drop_last_entry; fi ;;
      *) __nmux_wrap; __nmux_add_last_entry ;;
    esac
    __nmux_status "${code:-0}"
  }

  # Last in PROMPT_COMMAND: whatever draws the prompt has now drawn it.
  __nmux_wrap_prompt() {
    local code=$__nmux_after
    case $PS1 in
      *"$__nmux_prompt_name"*) __nmux_steady=1 ;;
      *) __nmux_wrap ;;
    esac
    __nmux_status "$code"
  }

  # Runs in the substitution in PS0, so in a subshell. A command that history did not keep is reported as unknown, not as the one before it.
  __nmux_command_start() {
    local line number REPLY
    # A start-up file read again can assign PROMPT_COMMAND outright. That cannot be put right from here, but it can be said.
    case "${PROMPT_COMMAND[*]-}" in
      *__nmux_before_prompt*) ;;
      *) builtin printf '\e]133;N;nmux=%s\a' "$__nmux_token"; return ;;
    esac
    line=$(HISTTIMEFORMAT= builtin history 1)
    line=${line#"${line%%[![:space:]]*}"}
    number=${line%%[![:digit:]]*}
    line=${line#"$number"}
    line=${line#"${line%%[![:space:]]*}"}
    [ "${number:-0}" -ge "$__nmux_next" ] || line=
    __nmux_encode "$line"
    builtin printf '\e]133;C;cmdline_url=%s;nmux=%s\a' "$REPLY" "$__nmux_token"
  }

  PS0=${PS0-}'$(__nmux_command_start 2>/dev/null)'
  # In vi command mode readline has no binding for a paste, so its text would arrive as commands.
  bind -m vi-command '"\e[200~": bracketed-paste-begin' 2>/dev/null
  __nmux_wrap
  if __nmux_many_commands; then
    PROMPT_COMMAND=("$__nmux_first_entry" "${PROMPT_COMMAND[@]}" "$__nmux_last_entry")
  else
    PROMPT_COMMAND=$__nmux_first_entry${PROMPT_COMMAND:+$'\n'$PROMPT_COMMAND}$'\n'$__nmux_last_entry
  fi
fi

unset -f __nmux_can_mark __nmux_writable
[ -z "${__nmux_exporting-}" ] || { unset __nmux_exporting; set -a; }
