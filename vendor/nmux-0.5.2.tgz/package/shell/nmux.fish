# fish runs this with --init-command, after the user's own configuration. It adds the marks that tell nmux where a prompt starts,
# where a command starts, and how it ended. Nothing here writes to a dotfile.
#
# The token proves a mark came from this shell. It is not exported, so nothing this shell runs can print a mark.

set -g __nmux_token $NMUX_SHELL_TOKEN
set -e NMUX_SHELL_TOKEN

if test -n "$__nmux_token"
    function __nmux_command_start --on-event fish_preexec
        printf '\e]133;C;cmdline_url=%s;nmux=%s\a' (string escape --style=url -- $argv[1]) $__nmux_token
    end

    # Before fish's own end-of-line marker, which would otherwise count as output. fish says where it is itself, with OSC 7.
    function __nmux_command_end --on-event fish_postexec
        set -l code $status
        printf '\e]133;D;%s;cwd=%s;nmux=%s\a' $code (string escape --style=url -- $PWD) $__nmux_token
    end

    function __nmux_prompt_end
        printf '\e]133;B;nmux=%s\a' $__nmux_token
    end

    # A prompt can be replaced at any time, by a theme or a function typed in, so this looks each time. The user's prompt keeps its
    # own body, with one line added that does nothing without nmux, because `funcsave` can write what is here to their dotfiles.
    function __nmux_wrap_prompt
        functions -q fish_prompt; or return
        set -l body (functions --no-details fish_prompt)
        string match -q '*__nmux_prompt_end*' -- $body; and return
        printf '%s\n' $body[1..-2] 'set -q __nmux_token; and __nmux_prompt_end' end | source
    end

    # Not in fish_prompt: the user's prompt has to find $status as the command left it.
    function __nmux_prompt_start --on-event fish_prompt
        __nmux_wrap_prompt
        printf '\e]133;A;redraw=0\a'
    end

    __nmux_wrap_prompt
end
