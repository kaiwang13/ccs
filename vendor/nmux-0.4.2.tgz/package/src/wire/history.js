'use strict';
// @ts-check
/**
 * The history log: what a session printed, as whole lines, on disk. The server writes it, `nmux search` and `nmux view` read it,
 * and nmux-rs does both the same way, so this file is the format.
 *
 * A file is lines of text, named `spool-<n>` for the number of its first row, in a directory of its own with a `meta.json`. Each line
 * starts with one character that says what it is:
 *
 *   `.text`   a row that starts a line
 *   `+text`   a row that carries on the line before it
 *   `@ms`     the time, in ms since the epoch, of the rows after it
 *   `!n`      n rows that never reached the disk: it did not keep up, and the numbers go on as if they had
 *   `=g:o:n`  how far into program g's output the rows before it go, and how many rows there are by then
 *
 * Rows are written with their colours (what `serializeRows` makes): `plain` takes them out.
 */

const PREFIX = 'spool-';
const META = 'meta.json';
const ROW = '.';
const CONTINUES = '+';
const TIME = '@';
const LOST = '!';
const WATERMARK = '=';

/** What a row looks like with its colours taken out. @param {string} row */
const plain = (row) => row.replace(/\x1b\[(\d*)C/g, (_, n) => ' '.repeat(Number(n) || 1)).replace(/\x1b\[[0-9;]*[A-Za-z]/g, '');

/**
 * What one line of a history file means.
 * @param {string} line
 * @returns {{kind: 'row', text: string, continues: boolean}|{kind: 'time', at: number}|{kind: 'lost', rows: number}|{kind: 'mark', gen: number, offset: number, lines: number}|null}
 */
function parseLine(line) {
  switch (line[0]) {
    case ROW: return { kind: 'row', text: line.slice(1), continues: false };
    case CONTINUES: return { kind: 'row', text: line.slice(1), continues: true };
    case TIME: return { kind: 'time', at: Number(line.slice(1)) };
    case LOST: return { kind: 'lost', rows: Number(line.slice(1)) };
    case WATERMARK: {
      const [gen, offset, lines] = line.slice(1).split(':').map(Number);
      return { kind: 'mark', gen, offset, lines };
    }
    default: return null;
  }
}

/** @param {string} text @param {boolean} continues */
const rowLine = (text, continues) => `${continues ? CONTINUES : ROW}${text}\n`;
/** @param {number} at */
const timeLine = (at) => `${TIME}${at}\n`;
/** @param {number} rows */
const lostLine = (rows) => `${LOST}${rows}\n`;
/** @param {number} gen @param {number} offset @param {number} lines */
const markLine = (gen, offset, lines) => `${WATERMARK}${gen}:${offset}:${lines}\n`;

/** @param {string} name the number of its first row, if it is a history file */
const firstRowOf = (name) => (name.startsWith(PREFIX) ? Number(name.slice(PREFIX.length)) : null);

module.exports = { PREFIX, META, plain, parseLine, rowLine, timeLine, lostLine, markLine, firstRowOf };
