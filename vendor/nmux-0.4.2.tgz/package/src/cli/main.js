'use strict';
// @ts-check
/** The `nmux` command. Thin on purpose: every decision about a session is made by the session's own server. */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const readline = require('node:readline');
const { loadConfig } = require('../server/config');
const { attach, attachPrecheck } = require('../client/attach');
const { controlRequest, CtlError } = require('../wire/ctlclient');
const { isLocked } = require('../platform/locks');
const { ensureRuntime } = require('../platform/runtime');
const { commandLine, cwdOf } = require('../platform/procinfo');
const sessions = require('./sessions');
const sdk = require('../sdk');
const { printTable, printable, stateText, age, shortPath } = require('./format');
/** @typedef {import('../client/history').Kept} Kept */
const { doctor } = require('./doctor');
const { withMarks } = require('./shells');
const history = require('../client/history');
const { parseWhen, zone } = require('../base/time');
const { sameCommand } = require('../server/session/shell');

const SHELL_ARG = '-l';
const STOP_WAIT_MS = 120000;
const STOP_RETRY_MS = 50;
const SERVER_GRACE_MS = 300;
const SEND_MAX_BYTES = 48000;
/** As `timeout` does: 124 ran out of time, 125 never got as far as the command. */
const EXIT_TIMED_OUT = 124;
const EXIT_NOT_RUN = 125;
/** A shell that takes longer than this to start a line is more likely to be waiting for the rest of it. */
const NOT_STARTED_MS = 5000;
/** A new server answers once it has read everything back, which on a busy machine is not quick. */
const READ_BACK_WAIT_MS = 120000;
const WAIT_POLL_MS = 100;
/** A key that shows the history waits no longer than this for a busy session to say what it has not written; what is written shows anyway. */
const LEND_READ_WAIT_MS = 5000;
const TIME_UNITS = { ms: 1, s: 1000, m: 60000, h: 3600000 };
const BYTE_UNITS = { B: 1, K: 1024, M: 1048576, G: 1073741824 };

const USAGE = `nmux: terminal sessions that survive anything, with your terminal's own scrollback

  nmux                                attach, create or pick
  nmux new [NAME] [-d] [--cwd DIR] [--size CxR] [--no-integration] [--spool SIZE|--keep] [-- CMD…]
  nmux a [NAME] [--view] [--full]     attach; --view is read-only and never affects the size, --full repeats all history
  nmux ls [--json]
  nmux stop NAME|--all
  nmux restart NAME
  nmux rm NAME
  nmux rename [OLD] NEW
  nmux clients [NAME] [--json]        who is attached
  nmux kick [NAME] ID…|--others       detach them
  nmux send NAME [--no-enter] [--] TEXT…   type into a session
  nmux run NAME [--queue] [--timeout T] [--ansi] [--json] -- CMD…   run in its shell; exits as the command did
  nmux last [NAME] [--ansi] [--json]  what the last command printed
  nmux wait NAME --prompt|--exit|--text RE [--new] [--timeout T]
  nmux capture [NAME] [--lines N] [--ansi]
  nmux search PATTERN [NAME…] [--since T] [--until T] [-i] [--json]   every kept history, ended sessions too, or these
  nmux view [NAME] [--at T|--row N|--grep RE] [--times]               a session's history in a pager, kept or still running
  nmux events [NAME]                  what happens in a session, as JSON lines
  nmux doctor

Inside a session the keys belong to the program, except Ctrl+\\ then: d detach, c who is attached, ? help,
Ctrl+\\ a literal Ctrl+\\. Inside a session NAME defaults to that session.
`;

class UsageError extends Error {}

/** A failure with an exit code of its own. */
class Failure extends Error {
  /** @param {string} message @param {number} code */
  constructor(message, code) { super(message); this.exitCode = code; }
}

/** What a session's refusal means to a person. */
const WHY = /** @type {Record<string, (name: string) => string>} */ ({
  NO_INTEGRATION: (name) => `'${name}' has no shell integration, so its prompts cannot be told from anything else: start it with a bash, zsh or fish shell`,
  BUSY: (name) => `'${name}' is running something: --queue waits for its prompt`,
  NOT_AT_PROMPT: (name) => `'${name}' is not at a prompt: --queue waits for one`,
  TYPED: (name) => `something is already typed at the prompt in '${name}', or has been printed over it`,
  NO_PASTE: (name) => `the shell in '${name}' does not take pastes, so this cannot be typed there safely`,
  NONE: (name) => `'${name}' has not finished a command`,
  SYNTAX: () => 'the shell would not run that',
  RESTARTED: (name) => `'${name}' was restarted before the command finished`,
  UNSUPPORTED: (name) => `'${name}' started under an older nmux: nmux restart ${name} brings it up to date`,
  BAD_ARGS: () => 'that cannot be typed at a prompt',
});

/** @param {string} name @param {any} e a CtlError from the session */
function refusal(name, e) { return (WHY[e.code] || (() => e.message))(name); }

/** `30`, `30s`, `5m`, `1h`, `500ms` as milliseconds, or null when not given. @param {string|undefined} text */
function parseTime(text) {
  if (text === undefined) return null;
  const m = /^(\d+(?:\.\d+)?)(ms|s|m|h)?$/.exec(text);
  if (!m) throw new UsageError(`bad time '${text}': for example 30s, 5m or 1h`);
  return Number(m[1]) * TIME_UNITS[/** @type {keyof typeof TIME_UNITS} */ (m[2] || 's')];
}

/** `64M`, `1G`, `500K` as bytes. @param {string} text */
function parseBytes(text) {
  const m = /^(\d+)([KMG])?$/i.exec(text);
  if (!m) throw new UsageError(`bad size '${text}': for example 64M or 1G`);
  return Number(m[1]) * BYTE_UNITS[/** @type {keyof typeof BYTE_UNITS} */ ((m[2] || 'B').toUpperCase())];
}

/** An exit as a shell would report it. @param {{code?: number|null, signal?: string|null}|null|undefined} e */
function exitCodeOf(e) {
  if (!e) return 0;
  if (e.code !== null && e.code !== undefined) return e.code;
  return e.signal ? 128 + (os.constants.signals[/** @type {NodeJS.Signals} */ (e.signal)] || 0) : 1;
}

/** What is in a session's foreground. Asked here, not of the server: this can take a while, and a session must not wait for it.
 *  @param {{foregroundPid?: number|null, child?: {pid: number|null}}} status */
function foregroundOf(status) {
  for (const pid of [status.foregroundPid, status.child && status.child.pid]) {        // the holder's answer can be a moment old
    const command = pid ? commandLine(pid) : null;
    if (pid && command) return { pid, command, cwd: cwdOf(pid) };
  }
  return null;
}

const version = () => JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', 'package.json'), 'utf8')).version;

/**
 * @param {string[]} args @param {{flags?: string[], options?: string[]}} [known]
 * @returns {{flags: Set<string>, options: Record<string, string>, rest: string[], command: string[]}}
 */
function parseArgs(args, { flags = [], options = [] } = {}) {
  const out = { flags: new Set(/** @type {string[]} */ ([])), options: /** @type {Record<string, string>} */ ({}), rest: /** @type {string[]} */ ([]), command: /** @type {string[]} */ ([]) };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--') { out.command = args.slice(i + 1); break; }
    if (flags.includes(a)) out.flags.add(a);
    else if (options.includes(a)) {
      if (i + 1 >= args.length) throw new UsageError(`${a} needs a value`);
      out.options[a] = args[++i];
    } else if (a.startsWith('-') && a !== '-') throw new UsageError(`unknown option ${a}`);
    else out.rest.push(a);
  }
  return out;
}

/** The directory's project, as a session name. @param {string} cwd */
function nameForDirectory(cwd) {
  let root = cwd;
  for (let d = cwd; ; d = path.dirname(d)) {
    if (fs.existsSync(path.join(d, '.git'))) { root = d; break; }
    if (d === path.dirname(d)) break;
  }
  const name = path.basename(root).replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^[^A-Za-z0-9]+/, '').slice(0, 64);
  return name || 'shell';
}

/** @typedef {{stdin: any, stdout: any, stderr: any, env: Record<string, string|undefined>, cwd: string}} Io */

class Cli {
  /** @param {Io} io */
  constructor(io) {
    this.io = io;
    this.paths = sessions.resolvePaths(io.env);
    this.config = loadConfig(this.paths.configFile);
  }

  /** @param {string} s */
  say(s) { this.io.stdout.write(`${s}\n`); }

  get current() { return this.io.env.NMUX_ID || null; }

  /** Where kept histories are: the configuration says, or else the user's state directory. */
  get historyRoot() { return this.config.history.dir || this.paths.historyDir; }

  /** A named session, or the one this shell is running in. @param {string|undefined} name */
  resolve(name) {
    const all = sessions.listSessions(this.paths);
    const s = name !== undefined ? all.find((x) => x.name === name) : all.find((x) => x.id === this.current);
    if (s) return s;
    if (name === undefined) throw new UsageError('name a session (or run this inside one)');
    const known = all.map((x) => x.name);
    throw new Error(`no session named '${name}'${known.length ? ` (there is ${known.join(', ')})` : ''}`);
  }

  /** A session that can be talked to. A holder that gave up on its server gets a new one. @param {any} s */
  async live(s) {
    if (!s.alive) throw new Error(`session '${s.name}' has ended: nmux restart ${s.name}, or nmux rm ${s.name}`);
    if (!isLocked(this.paths.sessiondLock(s.id))) {
      await new Promise((r) => setTimeout(r, SERVER_GRACE_MS));                        // it may be on its way already
      const orphan = isLocked(this.paths.holderLock(s.id)) && !isLocked(this.paths.sessiondLock(s.id));   // no holder: it is still being created
      if (orphan) sessions.startServer(this.paths, s.id, { recover: true });
      await sessions.waitRunning(this.paths, s.id);
    }
    return s;
  }

  /** @param {any} s @param {string} op @param {object} [args] @param {number} [timeoutMs] */
  async request(s, op, args = {}, timeoutMs = 5000) {
    const r = await controlRequest(this.paths.ctlSock(s.id), op, args, { timeoutMs, label: 'nmux' });
    if (!r.ok) throw new Error(`session '${s.name}': ${r.error}`);
    return r;
  }

  /** @param {any} s @param {string} op @param {object} [args] @param {number} [timeoutMs] */
  async ask(s, op, args, timeoutMs) { return (await this.request(s, op, args, timeoutMs)).data; }

  /** @param {any} s @param {{view?: boolean, full?: boolean}} [flags] */
  async enter(s, flags = {}) {
    const actions = { history: (/** @type {() => boolean} */ take) => history.view(this.historyOf(undefined, s.id),
      { sockPath: this.paths.ctlSock(s.id), tz: zone(this.io.env.TZ), io: this.io, take, waitMs: LEND_READ_WAIT_MS }) };
    return attach({ sockPath: this.paths.ctlSock(s.id), name: s.name, config: this.config, keys: this.config.keys, flags, io: this.io, actions });
  }

  size() {
    const { columns, rows } = this.io.stdout;
    return columns && rows ? { cols: columns, rows } : { cols: this.config.size.defaultCols, rows: this.config.size.defaultRows };
  }

  /**
   * @param {{name: string|null, argv?: string[], cwd?: string, size?: {cols: number, rows: number}, attaching?: boolean, integration?: boolean, spool?: number,
   *   keep?: boolean}} o
   */
  async create({ name, argv, cwd = this.io.cwd, size = this.size(), attaching = false, integration = true, spool = this.config.history.spoolBytes, keep = this.config.history.keep }) {
    const { env } = this.io;
    const command = argv && argv.length ? argv : [env.SHELL || '/bin/sh', SHELL_ARG];
    if (!fs.existsSync(cwd)) throw new Error(`no such directory: ${cwd}`);
    const marked = integration && this.config.shell.integration ? withMarks(command, env) : null;
    return sessions.createSession(this.paths, { name, base: nameForDirectory(cwd), argv: marked ? marked.argv : command, cwd, env: marked ? { ...env, ...marked.env } : env,
      shell: marked && marked.shell, spool: keep ? { maxBytes: 0, keep: true, root: this.historyRoot } : (spool > 0 ? { maxBytes: spool } : null), ...size, term: env.TERM || 'xterm-256color', attaching });
  }

  // ---- commands ----------------------------------------------------------------------------------------------------
  /** Attach, create or pick. */
  async bare() {
    const live = sessions.listSessions(this.paths).filter((s) => s.alive);
    if (live.length === 0) return this.startAndAttach(null);
    if (live.length === 1) return this.enter(await this.live(live[0]));
    return this.pick(live);
  }

  /** @param {any[]} live @param {{view?: boolean, full?: boolean}} [flags] */
  async pick(live, flags = {}) {
    const { stdin, stdout } = this.io;
    if (!stdin.isTTY) throw new UsageError(`several sessions: name one of ${live.map((s) => s.name).join(', ')}`);
    live.forEach((s, i) => stdout.write(`  ${i + 1}  ${s.name}\n`));
    const rl = readline.createInterface({ input: stdin, output: stdout });
    const line = await new Promise((resolve) => { rl.question('Session (Enter for 1): ', resolve); rl.once('close', () => resolve('q')); });
    rl.close();
    if (/^q/i.test(line)) return 0;
    const chosen = live[line.trim() === '' ? 0 : Number(line) - 1] || live.find((s) => s.name === line.trim());
    if (!chosen) throw new Error(`no such session: ${line}`);
    return this.enter(await this.live(chosen), flags);
  }

  /** @param {string|null} name @param {Partial<Parameters<Cli['create']>[0]>} [o] */
  async startAndAttach(name, o = {}) {
    const refused = attachPrecheck(this.io);
    if (refused) { this.io.stderr.write(`${refused.message}\n`); return refused.code; }
    const s = await this.create({ name, ...o, attaching: true });
    return this.enter({ id: s.id, name: s.name });
  }

  /** @param {string[]} args */
  async new(args) {
    const a = parseArgs(args, { flags: ['-d', '--no-integration', '--keep'], options: ['--cwd', '--size', '--spool'] });
    if (a.rest.length > 1) throw new UsageError('nmux new takes one name');
    const name = a.rest[0] ?? null;
    if (name !== null && !sessions.validName(name)) throw new UsageError(`bad session name '${name}': letters, digits, '.', '_' and '-'`);
    const cwd = a.options['--cwd'] ? path.resolve(this.io.cwd, a.options['--cwd']) : this.io.cwd;
    const m = a.options['--size'] ? /^(\d+)x(\d+)$/.exec(a.options['--size']) : null;
    if (a.options['--size'] && !m) throw new UsageError('--size takes COLSxROWS');
    const size = m ? { cols: Number(m[1]), rows: Number(m[2]) } : this.size();
    const o = { argv: a.command, cwd, size, integration: !a.flags.has('--no-integration'), ...(a.options['--spool'] ? { spool: parseBytes(a.options['--spool']) } : {}),
      ...(a.flags.has('--keep') ? { keep: true } : {}) };
    if (a.flags.has('-d')) {
      const s = await this.create({ name, ...o });
      this.say(s.name);
      return 0;
    }
    return this.startAndAttach(name, o);
  }

  /** @param {string[]} args */
  async a(args) {
    const a = parseArgs(args, { flags: ['--view', '--full'] });
    const flags = { view: a.flags.has('--view'), full: a.flags.has('--full') };
    if (a.rest.length) return this.enter(await this.live(this.resolve(a.rest[0])), flags);
    const live = sessions.listSessions(this.paths).filter((s) => s.alive);
    if (live.length === 0) throw new Error('no sessions; nmux new starts one');
    return live.length === 1 ? this.enter(await this.live(live[0]), flags) : this.pick(live, flags);
  }

  /** @param {string[]} args */
  async ls(args) {
    const a = parseArgs(args, { flags: ['--json'] });
    const rows = await Promise.all(sessions.listSessions(this.paths).map(async (s) => ({ s, status: s.alive ? await sessions.statusOf(this.paths, s.id) : null })));
    for (const { status } of rows) if (status) { status.foreground = foregroundOf(status); status.cwd = status.foreground && status.foreground.cwd; }
    if (a.flags.has('--json')) {
      this.say(JSON.stringify(rows.map(({ s, status }) => ({ id: s.id, name: s.name, alive: s.alive, createdAt: s.spec.createdAt, status, lastExit: s.state?.restarts?.lastExit ?? null }))));
      return 0;
    }
    if (rows.length === 0) { this.say('no sessions'); return 0; }
    const table = rows.map(({ s, status }) => [`${s.id === this.current ? '*' : ' '} ${s.name}`, stateText(s, status), String(status ? status.clients.length || '–' : '–'),
      age(s.spec.createdAt), shortPath(status?.cwd || s.spec.child.cwd, this.io.env.HOME)]);
    printTable(this.io.stdout, ['  NAME', 'STATE', 'CLIENTS', 'AGE', 'CWD'], table);
    return 0;
  }

  /** @param {string[]} args */
  async stop(args) {
    const a = parseArgs(args, { flags: ['--all'] });
    const targets = a.flags.has('--all') ? sessions.listSessions(this.paths) : [this.resolve(a.rest[0])];
    await Promise.all(targets.map((s) => this.stopOne(s)));
    return 0;
  }

  /** Asks until the session has gone: a server that is restarting will be back within moments. @param {any} s */
  async stopOne(s) {
    if (!s.alive) { sessions.removeSession(this.paths, s.id); return; }
    const running = () => sessions.isAlive(this.paths, s.id);
    const deadline = Date.now() + STOP_WAIT_MS;
    while (running() && Date.now() < deadline) {
      try { await this.ask(s, 'STOP', {}, STOP_WAIT_MS); } catch (e) {
        if (!(e instanceof CtlError)) throw e;                                         // the connection went, which it does as a session ends
      }
      await new Promise((r) => setTimeout(r, STOP_RETRY_MS));
    }
    if (running()) throw new Error(`session '${s.name}' did not stop`);
    sessions.removeSession(this.paths, s.id);
  }

  /** @param {string[]} args */
  async restart(args) {
    const s = this.resolve(parseArgs(args).rest[0]);
    if (s.alive) { await this.ask(s, 'RESTART', {}, STOP_WAIT_MS); return 0; }
    sessions.startServer(this.paths, s.id);
    await sessions.waitRunning(this.paths, s.id);
    return 0;
  }

  /** @param {string[]} args */
  async rm(args) {
    const s = this.resolve(parseArgs(args).rest[0]);
    if (s.alive) throw new Error(`session '${s.name}' is running: nmux stop ${s.name}`);
    sessions.removeSession(this.paths, s.id);
    return 0;
  }

  /** @param {string[]} args */
  async rename(args) {
    const { rest } = parseArgs(args);
    if (rest.length < 1 || rest.length > 2) throw new UsageError('nmux rename [OLD] NEW');
    const to = rest[rest.length - 1];
    if (!sessions.validName(to)) throw new UsageError(`bad session name '${to}': letters, digits, '.', '_' and '-'`);
    const s = this.resolve(rest.length === 2 ? rest[0] : undefined);
    await sessions.renameSession(this.paths, s.id, to);
    if (s.alive) await this.ask(s, 'RENAME', { name: to });
    return 0;
  }

  /** @param {string[]} args */
  async clients(args) {
    const a = parseArgs(args, { flags: ['--json'] });
    const s = await this.live(this.resolve(a.rest[0]));
    const { clients } = await this.ask(s, 'CLIENTS');
    if (a.flags.has('--json')) { this.say(JSON.stringify(clients)); return 0; }
    if (clients.length === 0) { this.say(`nobody is attached to ${s.name}`); return 0; }
    printTable(this.io.stdout, ['ID', 'LABEL', 'SIZE', 'ATTACHED', 'IDLE'], clients.map((/** @type {any} */ c) => [c.id + (c.view ? ' (view)' : ''), c.label, `${c.cols}x${c.rows}`,
      age(Date.now() - c.attachedMs), c.idleMs === null ? '–' : age(Date.now() - c.idleMs)]));
    return 0;
  }

  /** @param {string[]} args */
  async kick(args) {
    const a = parseArgs(args, { flags: ['--others'] });
    const all = sessions.listSessions(this.paths);
    const named = a.rest.length && all.find((x) => x.name === a.rest[0]);
    const s = await this.live(named || this.resolve(undefined));
    const ids = named ? a.rest.slice(1) : a.rest;
    const others = a.flags.has('--others');
    if (others === (ids.length > 0)) throw new UsageError('nmux kick [NAME] ID…|--others');
    const data = await this.ask(s, 'KICK', others ? { allExcept: [await this.ownClient(s)], by: 'nmux kick' } : { clients: ids, by: 'nmux kick' });
    for (const c of data.kicked) this.say(`detached ${c.id} (${c.label})`);
    for (const id of data.unknown) this.io.stderr.write(`nmux: no client ${id} on ${s.name}\n`);
    return data.unknown.length ? 1 : 0;
  }

  /**
   * The terminal this command was typed in, which is the one that typed last. Only a shell inside the session can say that
   * of itself: from anywhere else there is no telling, so --others is refused rather than guessed.
   * @param {any} s @returns {Promise<string>}
   */
  async ownClient(s) {
    if (this.current !== s.id) throw new Error(`--others keeps your own terminal, which only a command typed inside '${s.name}' can tell: name the clients (nmux clients ${s.name})`);
    const { clients } = await this.ask(s, 'CLIENTS');
    const typed = clients.filter((/** @type {any} */ c) => c.idleMs !== null).sort((/** @type {any} */ a, /** @type {any} */ b) => a.idleMs - b.idleMs)[0];
    if (!typed) throw new Error('nobody has typed yet, so there is no telling which terminal is yours');
    return typed.id;
  }

  /** @param {string[]} args */
  async send(args) {
    const [name, ...words] = args;                                                     // the text is the caller's: nothing in it is an option
    const enter = words[0] !== '--no-enter';
    if (!enter) words.shift();
    if (words[0] === '--') words.shift();
    if (name === undefined || words.length === 0) throw new UsageError('nmux send NAME [--no-enter] [--] TEXT…');
    const text = words.join(' ');
    if (Buffer.byteLength(text, 'utf8') > SEND_MAX_BYTES) throw new Error(`that is too much to type at once: the limit is ${SEND_MAX_BYTES} bytes`);
    await this.ask(await this.live(this.resolve(name)), 'SEND', { text, enter });
    return 0;
  }

  /** @param {string[]} args */
  async capture(args) {
    const a = parseArgs(args, { flags: ['--ansi'], options: ['--lines'] });
    const s = await this.live(this.resolve(a.rest[0]));
    const { output } = await this.request(s, 'CAPTURE', { lines: a.options['--lines'] ? Number(a.options['--lines']) : null, ansi: a.flags.has('--ansi') });
    this.io.stdout.write(output);
    return 0;
  }

  /** A control connection that hears the given events, ready once `ready` has resolved. @param {any} s @param {string[]} events */
  subscribed(s, events) {
    const client = new sdk.SessionClient({ sockPath: this.paths.ctlSock(s.id), label: 'nmux', subscribe: { events } });
    const ready = new Promise((resolve) => { client.once('subscribed', resolve); });
    client.open();
    return { client, ready };
  }

  /**
   * @template T @param {Promise<T>} work @param {number|null} ms @param {() => string} what said when it is known how things stood
   * @returns {Promise<T>} `work`, or a failure with the exit code for running out of time
   */
  async within(work, ms, what) {
    if (ms === null) return work;
    /** @type {any} */
    let timer = null;
    const late = new Promise((_, reject) => { timer = setTimeout(() => reject(new Failure(`timed out waiting for ${what()}`, EXIT_TIMED_OUT)), ms); });
    try { return await Promise.race([work, late]); } finally { clearTimeout(timer); }
  }

  /** Runs a line in a session's shell and exits as it did. @param {string[]} args */
  async run(args) {
    const a = parseArgs(args, { flags: ['--queue', '--ansi', '--json'], options: ['--timeout'] });
    const text = a.command.join(' ');
    if (a.rest.length !== 1 || !text) throw new UsageError('nmux run NAME [--queue] [--timeout T] [--ansi] [--json] -- CMD…');
    const timeoutMs = parseTime(a.options['--timeout']);
    const s = await this.live(this.resolve(a.rest[0]));
    const { client, ready } = this.subscribed(s, ['command', 'prompt', 'stopped']);
    const progress = { queued: false, started: false };
    const stood = () => {
      if (progress.started) return `'${text}': it is still running in ${s.name}`;
      return progress.queued ? `a prompt in ${s.name}: '${text}' has not run, and now will not` : `'${text}' to start in ${s.name}`;
    };
    try {
      return await this.within(this.running(client, ready, s, text, { queue: a.flags.has('--queue'), ansi: a.flags.has('--ansi'), json: a.flags.has('--json') }, progress), timeoutMs, stood);
    } catch (e) {
      if (e instanceof Failure) throw e;
      throw new Failure(refusal(s.name, e), EXIT_NOT_RUN);
    } finally { client.close(); }
  }

  /**
   * A server can restart at any moment and forget what it was asked. A line it had typed runs anyway: the next time the shell is at
   * a prompt, the last record says how it went, if that is this line. A line it was holding has gone, and sending it again could
   * run it twice if that server got as far as typing it, so that one is reported as not run.
   * @param {any} client @param {Promise<unknown>} ready @param {any} s @param {string} text @param {{queue: boolean, ansi: boolean, json: boolean}} o
   * @param {{queued: boolean, started: boolean}} progress
   */
  async running(client, ready, s, text, o, progress) {
    await ready;
    return new Promise((resolve, reject) => {
      /** @type {number|null} */
      let run = null;
      /** @type {any} */
      let notStarted = null;
      let forgotten = false;
      const fail = (/** @type {Error} */ e) => { clearTimeout(notStarted); reject(e); };
      const lostTrack = () => fail(new Failure(`the server of '${s.name}' restarted, and there is no telling what became of this: see nmux last ${s.name}`, EXIT_NOT_RUN));
      const show = (/** @type {any} */ r) => {
        if (o.json) this.say(JSON.stringify({ command: r.command, cwd: r.cwd, exit: r.exit, durationMs: r.durationMs, complete: r.complete, output: r.text }));
        else this.io.stdout.write(r.text);
        if (!r.complete) this.io.stderr.write('nmux: the start of its output has already left the history\n');
        if (r.exit === null) this.io.stderr.write('nmux: it finished, but the shell did not say how\n');
        resolve(r.exit ?? EXIT_NOT_RUN);
      };
      const finish = (/** @type {number} */ seq, /** @type {boolean} */ unsure) => {
        clearTimeout(notStarted);
        client.last({ seq, ansi: o.ansi }).then((/** @type {any} */ r) => {
          if (unsure) this.io.stderr.write(`nmux: the shell says it ran: ${printable(r.command || '?')}\n`);
          show(r);
        }, fail);
      };
      const checkLast = () => client.last({ ansi: o.ansi }).then((/** @type {any} */ r) => {
        if (r.command !== null && !sameCommand(r.command, text)) lostTrack();
        else show(r);
      }, (/** @type {any} */ e) => { if (e.code === 'NONE') lostTrack(); else fail(e); });
      client.on('event', (/** @type {any} */ e) => {
        if (e.event === 'stopped') fail(new Failure(`'${s.name}' ended before the command did`, exitCodeOf(e.lastExit)));
        else if (forgotten && e.event === 'prompt') checkLast();
        else if (e.event === 'command' && run !== null && e.run === run) {
          if (e.phase === 'start') { progress.started = true; clearTimeout(notStarted); }
          else if (e.phase === 'refused') fail(Object.assign(new Error(e.error), { code: e.error }));
          else if (e.phase === 'end') finish(e.seq, !!e.unsure);
        }
      });
      client.on('subscribed', () => {
        forgotten = true;
        run = null;                                                                     // what the last server called it means nothing to this one
        clearTimeout(notStarted);
        if (progress.queued && !progress.started) fail(new Failure(`the server of '${s.name}' restarted before this had its turn, so it has not run`, EXIT_NOT_RUN));
        else client.commands().then((/** @type {any} */ c) => { if (c.state === 'prompt') checkLast(); }, fail);
      });
      client.on('down', () => {                                                         // gone for good, with its last word unheard
        if (sessions.isAlive(this.paths, s.id)) return;
        const state = sessions.readJson(this.paths.stateFile(s.id));
        fail(new Failure(`'${s.name}' ended before the command did`, exitCodeOf(state && state.restarts && state.restarts.lastExit)));
      });
      client.run(text, { queue: o.queue }).then((/** @type {any} */ r) => {
        run = r.run;
        progress.queued = !!r.queued;
        if (!r.queued) notStarted = setTimeout(() => this.io.stderr.write(`nmux: the shell has not started this yet; it may be waiting for the rest of it (nmux a ${s.name})\n`), NOT_STARTED_MS);
      }, fail);
    });
  }

  /** What the last command printed. @param {string[]} args */
  async last(args) {
    const a = parseArgs(args, { flags: ['--ansi', '--json'] });
    const s = await this.live(this.resolve(a.rest[0]));
    const r = await controlRequest(this.paths.ctlSock(s.id), 'LAST', { ansi: a.flags.has('--ansi') }, { label: 'nmux', timeoutMs: READ_BACK_WAIT_MS });
    if (!r.ok) throw new Error(refusal(s.name, { code: r.error, message: r.error }));
    if (a.flags.has('--json')) { this.say(JSON.stringify({ ...r.data, output: r.output.toString('utf8') })); return 0; }
    this.io.stdout.write(r.output);
    if (!r.data.complete) this.io.stderr.write('nmux: the start of its output has already left the history\n');
    return 0;
  }

  /** Blocks until a session gets there. @param {string[]} args */
  async wait(args) {
    const a = parseArgs(args, { flags: ['--prompt', '--exit', '--new'], options: ['--text', '--timeout'] });
    const wanted = ['--prompt', '--exit', '--text'].filter((f) => a.flags.has(f) || a.options[f] !== undefined);
    if (a.rest.length !== 1 || wanted.length !== 1) throw new UsageError('nmux wait NAME --prompt|--exit|--text RE [--new] [--timeout T]');
    const timeoutMs = parseTime(a.options['--timeout']);
    /** @type {RegExp|null} */
    let re = null;
    if (a.options['--text'] !== undefined) {
      try { re = new RegExp(a.options['--text'], 'm'); } catch (e) { throw new UsageError(`bad pattern: ${/** @type {Error} */ (e).message}`); }
    }
    const named = this.resolve(a.rest[0]);
    if (!named.alive) {
      if (wanted[0] === '--exit') return exitCodeOf(named.state && named.state.restarts && named.state.restarts.lastExit);
      await this.live(named);
    }
    const s = await this.live(named);
    const { client, ready } = this.subscribed(s, ['prompt', 'stopped']);
    await ready;
    try {
      const work = wanted[0] === '--prompt' ? this.untilPrompt(client, s) : wanted[0] === '--exit' ? this.untilExit(client, s) : this.untilText(client, s, /** @type {RegExp} */ (re), a.flags.has('--new'));
      return await this.within(work, timeoutMs, () => `${wanted[0].slice(2)} in ${s.name}`);
    } finally { client.close(); }
  }

  /** @param {any} client @param {any} s @returns {Promise<number>} */
  untilPrompt(client, s) {
    return new Promise((resolve, reject) => {
      const check = () => client.commands().then((/** @type {any} */ c) => { if (c.state === 'prompt') resolve(0); },
        (/** @type {any} */ e) => { if (e.code !== 'DOWN') reject(new Error(refusal(s.name, e))); });
      client.on('event', (/** @type {any} */ e) => {
        if (e.event === 'prompt') resolve(0);
        if (e.event === 'stopped') reject(new Error(`'${s.name}' ended`));
      });
      client.on('subscribed', check);
      check();
    });
  }

  /** @param {any} client @param {any} s @returns {Promise<number>} */
  untilExit(client, s) {
    return new Promise((resolve) => {
      client.on('event', (/** @type {any} */ e) => { if (e.event === 'stopped') resolve(exitCodeOf(e.lastExit)); });
      client.on('down', () => {
        if (sessions.isAlive(this.paths, s.id)) return;
        const state = sessions.readJson(this.paths.stateFile(s.id));                    // a clean exit leaves nothing behind
        resolve(exitCodeOf(state && state.restarts && state.restarts.lastExit));
      });
    });
  }

  /**
   * Text is read back rather than matched as it passes: a match then cannot fall between two reads of a program's output, or
   * depend on how it coloured it. What is on the screen counts, because what a script waits for may arrive before it starts
   * waiting; --new is for when that would be a stale answer.
   * @param {any} client @param {any} s @param {RegExp} re @param {boolean} onlyNew @returns {Promise<number>}
   */
  async untilText(client, s, re, onlyNew) {
    /** @type {number|null} */
    let from = null;
    let seen = '';
    if (onlyNew) {
      const first = await client.since(null);
      from = first.cursor;
      seen = first.text.slice(first.text.lastIndexOf('\n') + 1);
    }
    while (!client.stopped) {
      try {
        const r = await client.since(from);
        if (re.test(onlyNew && r.text.startsWith(seen) ? r.text.slice(seen.length) : r.text)) return 0;
        const cameBack = onlyNew && from !== null && r.cursor < from;                  // it went up the screen, past where this was reading from
        if (from !== (onlyNew ? r.cursor : r.top)) seen = '';
        from = onlyNew && !cameBack ? r.cursor : r.top;
        if (cameBack) continue;
      } catch (e) {
        if (/** @type {any} */ (e).code !== 'DOWN' && /** @type {any} */ (e).code !== 'TIMEOUT') throw e;
        if (!sessions.isAlive(this.paths, s.id)) throw new Error(`'${s.name}' ended`);
      }
      await new Promise((r) => setTimeout(r, WAIT_POLL_MS));
    }
    return 0;                                                                           // given up on: nobody is listening
  }

  /**
   * The history of a name: the one kept for it, whether its session is running or has ended, or else what a running session
   * still has, in its spool and on its screen. @param {string|undefined} name @param {string} [id] a running session's own
   * @returns {Kept}
   */
  historyOf(name, id) {
    const all = history.keptUnder(this.historyRoot);
    const live = sessions.listSessions(this.paths);
    const want = id || (name === undefined ? this.current : (live.find((s) => s.name === name) || {}).id);
    const found = all.filter((k) => (want ? k.id === want : k.name === name)).pop();
    if (found) return found;
    const running = live.find((s) => s.id === want);
    if (running) return { id: running.id, name: running.name || running.id, dir: this.paths.sessionDir(running.id), createdAt: null, cwd: null };
    const known = all.map((k) => k.name);
    throw new Error(name === undefined ? 'name a session, or one whose history is kept (nmux new --keep keeps one)'
      : `'${name}' is not running and has no kept history${known.length ? ` (there is ${[...new Set(known)].join(', ')})` : ''}`);
  }

  /** A running session's socket, so that what it has not written is read too. @param {Kept} k @returns {string|null} */
  sockOf(k) { return sessions.isAlive(this.paths, k.id) ? this.paths.ctlSock(k.id) : null; }

  /** Every line in kept histories that matches, or in these sessions'. @param {string[]} args */
  async search(args) {
    const a = parseArgs(args, { flags: ['-i', '--json'], options: ['--since', '--until', '--zone'] });
    const [pattern, ...names] = a.rest;
    if (!pattern) throw new UsageError('nmux search PATTERN [NAME…] [--since T] [--until T] [-i] [--json]');
    let re;
    try { re = new RegExp(pattern, a.flags.has('-i') ? 'i' : ''); } catch (e) { throw new UsageError(`bad pattern: ${/** @type {Error} */ (e).message}`); }
    const tz = zone(a.options['--zone'] || this.io.env.TZ);
    const when = (/** @type {string|undefined} */ t, /** @type {string} */ flag) => {
      if (t === undefined) return null;
      const ms = parseWhen(t, Date.now(), tz);
      if (ms === null) throw new UsageError(`${flag}: no time in '${t}': for example 2026-11-01, '2026-11-01 14:00', 14:00, yesterday or 2h`);
      return ms;
    };
    const since = when(a.options['--since'], '--since');
    const until = when(a.options['--until'], '--until');
    const kept = names.length ? names.map((n) => this.historyOf(n)) : history.keptUnder(this.historyRoot);
    const color = !!this.io.stdout.isTTY;
    let found = 0;
    for await (const m of history.search(kept.map((k) => ({ kept: k, sockPath: this.sockOf(k) })), { re, since, until })) {
      found += 1;
      this.say(a.flags.has('--json') ? history.matchJson(m) : history.matchText(m, { tz, re, color }));
    }
    return found ? 0 : 1;
  }

  /** A history in a pager, opened at a time, a row, or the first match. @param {string[]} args */
  async view(args) {
    const a = parseArgs(args, { flags: ['--times'], options: ['--at', '--row', '--grep', '--zone'] });
    const tz = zone(a.options['--zone'] || this.io.env.TZ);
    const at = a.options['--at'] !== undefined ? parseWhen(a.options['--at'], Date.now(), tz) : null;
    if (a.options['--at'] !== undefined && at === null) throw new UsageError(`--at: no time in '${a.options['--at']}'`);
    const row = a.options['--row'] !== undefined ? Number(a.options['--row']) : null;
    if (row !== null && !Number.isSafeInteger(row)) throw new UsageError(`--row: not a number: '${a.options['--row']}'`);
    const k = this.historyOf(a.rest[0]);
    return history.view(k, { sockPath: this.sockOf(k), tz, at, row, grep: a.options['--grep'] || null, times: a.flags.has('--times'), io: this.io });
  }

  /** Follows a session until it ends. @param {string[]} args */
  async events(args) {
    const s = await this.live(this.resolve(parseArgs(args).rest[0]));
    const client = new sdk.SessionClient({ sockPath: this.paths.ctlSock(s.id), label: 'nmux events', subscribe: { events: EVENTS } });
    await new Promise((resolve) => {
      client.on('event', (e) => {
        this.say(JSON.stringify({ at: new Date().toISOString(), ...e }));
        if (e.event === 'stopped') resolve(undefined);
      });
      client.on('down', () => { if (!sessions.isAlive(this.paths, s.id)) resolve(undefined); });
      client.open();
    });
    client.close();
    return 0;
  }

  async doctor() { return doctor(this.paths, this.io); }
}

const EVENTS = ['lifecycle', 'notice', 'stopped', 'holder', 'attached', 'tty', 'match', 'exit', 'respawned', 'prompt', 'command'];
const COMMANDS = { events: 'events', search: 'search', view: 'view', new: 'new', a: 'a', attach: 'a', ls: 'ls', list: 'ls', stop: 'stop', restart: 'restart', rm: 'rm', rename: 'rename', clients: 'clients', kick: 'kick', send: 'send', capture: 'capture', run: 'run', last: 'last', wait: 'wait', doctor: 'doctor' };

/**
 * @param {string[]} argv @param {Partial<Io>} [partial] @returns {Promise<number>} the exit code
 */
async function main(argv, partial = {}) {
  const io = { stdin: process.stdin, stdout: process.stdout, stderr: process.stderr, env: process.env, cwd: process.cwd(), ...partial };
  const [cmd, ...args] = argv;
  if (cmd === 'help' || cmd === '--help' || cmd === '-h') { io.stdout.write(USAGE); return 0; }
  if (cmd === '--version' || cmd === '-V') { io.stdout.write(`nmux ${version()}\n`); return 0; }
  const cli = new Cli(io);
  try {
    if (cmd !== 'doctor') ensureRuntime(cli.paths);                                     // doctor is how a bad one gets explained
    if (cmd === undefined) return await cli.bare();
    const method = /** @type {Record<string, string>} */ (COMMANDS)[cmd];
    if (!method) throw new UsageError(`unknown command '${cmd}'`);
    return await /** @type {any} */ (cli)[method](args);
  } catch (e) {
    const err = /** @type {Error} */ (e);
    io.stderr.write(`nmux: ${err.message}\n`);
    if (err instanceof UsageError) { io.stderr.write(`try 'nmux help'\n`); return 2; }
    return err instanceof Failure ? err.exitCode : 1;
  }
}

module.exports = { main, parseArgs, nameForDirectory, Cli, Failure };
