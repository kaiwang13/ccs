'use strict';
// @ts-check
const { buildJoinBytes, sendSnapshot, joinGeometry } = require('../output/snapshot');

const FLUSHED = Buffer.alloc(0);

/**
 * Resolves with the first `event` value matching `pred`, or null after `ms`.
 * @param {import('node:events').EventEmitter} emitter @param {string} event @param {number} ms @param {import('../../base/types').Clock} clock @param {(v: any) => boolean} [pred]
 */
function waitEvent(emitter, event, ms, clock, pred = () => true) {
  return new Promise((resolve) => {
    const on = (/** @type {any} */ v) => { if (!pred(v)) return; clock.clearTimeout(timer); emitter.off(event, on); resolve(v); };
    const timer = clock.setTimeout(() => { emitter.off(event, on); resolve(null); }, ms);
    emitter.on(event, on);
  });
}

/**
 * Register (size counts at once) → wait for the join repaint if this join shrinks the PTY → quiesce → build at S →
 * buffer live output from S → send the snapshot with flow control → go live. Live output from S is buffered per client
 * instead of keeping the holder paused for the whole send, so a slow joiner never delays anyone else.
 * @param {import('./hub').ClientHub} hub @param {import('./hub').Client} c
 */
async function runJoin(hub, c) {
  const { session, config, clock, messages, arbiter } = hub;
  const a = c.adapter;
  a.phase = 'JOINING';
  a.armed = false;
  if (arbiter) arbiter.onChange('join');
  const d = arbiter ? arbiter.desired() : null;
  const p = session.pty;
  if (d && (d.cols < p.cols || d.rows < p.rows)) {
    const size = config.size;
    const applied = await waitEvent(session, 'pty', size.shrinkMaxWaitMs + 200, clock);
    if (applied && session.repaint) await waitEvent(session, 'reset', size.joinRepaintWaitMs, clock, (off) => off >= session.tracker.lastResizeOffset);
  }
  await session.started;
  while (session.lifecycle === 'RECOVERING' && !c.closed) await waitEvent(session, 'lifecycle', 1000, clock);
  if (c.closed) return;
  const release = await session.quiesce();
  const missed = session.outputSince(c.hello.resume, a.cols, a.rows);
  if (missed) {                                                                        // its terminal is as it left it, so it only needs what came next
    try {
      a.armJoin();
      for (const chunk of missed) a.render(chunk);
    } finally {
      release();
    }
    c.fsock.sendControl({ t: 'SNAPSHOT_BEGIN', lines: 0, truncatedBefore: null });
    c.fsock.sendControl({ t: 'SNAPSHOT_END' });
    a.goLive();
    hub.broadcastState();
    return;
  }
  /** @type {Buffer} */
  let bytes;
  let lines = 0;
  /** @type {string|null} */
  let away = null;
  try {
    const historyLimit = config.snapshot.joinHistory;
    const back = hub.returning(c.hello.terminal);
    // A terminal whose screen is still the one it left, as after a pager, has that screen written over, from the row that was at
    // its top: what scrolled past since goes into its scrollback once, and nothing is drawn twice.
    const over = !!back && !!c.hello.flags && c.hello.flags.sameScreen === true && session.emulator.tracking;
    const historyFrom = back ? session.emulator.index(over ? back.top.row : session.rowAfter(back)) : 0;
    const where = !over ? {} : session.tracker.alt ? { alt: false, keepMain: true } : { overScreen: true };
    bytes = buildJoinBytes({ emulator: session.emulator, tracker: session.tracker, historyFrom,
      banner: (n) => {
        away = back ? session.awaySince(back, n) : null;
        return away === null ? (back ? null : messages.joinBanner(session.name, n)) : messages.away(session.name, away);
      },
      client: { rows: a.rows, cols: a.cols, cursorRow: c.hello.cursorRow ?? null, ...where }, historyLimit });
    if (!session.emulator.tracking) {
      const g = joinGeometry({ emulator: session.emulator, tracker: session.tracker, historyLimit, historyFrom });
      lines = g.scr - g.h0;
    }
    a.armJoin();
  } finally {
    release();
  }
  if (c.closed) return;
  const r = await sendSnapshot({ bytes, lines, truncatedBefore: session.historyTruncatedBefore, chunkBytes: config.snapshot.chunkBytes,
    timeoutMs: config.snapshot.snapshotTimeoutMs, clock, client: snapshotTarget(hub, c) });
  if (c.closed) return;
  if (r === 'timeout') { a.drop('SNAPSHOT_TIMEOUT', true, 'the join snapshot could not be delivered in time'); return; }
  a.goLive();
  if (away !== null) a.flash(away);                                                    // the line itself is just above the screen, out of sight
  hub.broadcastState();
}

/**
 * Resolves once everything queued for `c` has left, or `c` has. 'drain' will not do: it only fires for a queue that went
 * past the high-water mark, so a small residue would wait for it forever. An empty write completes after all that came first.
 * @param {{closed: boolean, fsock: {writableLength: number}, sock: import('node:net').Socket}} c
 */
function drained(c) {
  return new Promise((resolve) => {
    if (c.closed || c.fsock.writableLength === 0 || c.sock.destroyed) { resolve(undefined); return; }
    const done = () => { c.sock.off('close', done); resolve(undefined); };
    c.sock.once('close', done);
    c.sock.write(FLUSHED, done);
  });
}

/** @param {import('./hub').ClientHub} hub @param {import('./hub').Client} c */
const snapshotTarget = (hub, c) => ({ send: (/** @type {number} */ type, /** @type {any} */ payload) => { hub.sendTo(c, type, payload); }, writableLength: () => c.fsock.writableLength, drained: () => drained(c) });

/**
 * Brings a client that fell behind back to the present, on its own connection: once its socket has drained it gets the
 * current screen, and live output from that point. Nothing about the join changes for anyone else. There is no time limit:
 * a terminal that stopped reading costs nothing while it waits, because nothing is being queued for it.
 * @param {import('./hub').ClientHub} hub @param {import('./hub').Client} c
 * @param {{announce?: boolean, keepMain?: boolean}} [o] announce: say what was skipped. keepMain: the client's main screen is
 *   whole, so only a program's alternate screen needs drawing and nothing is pushed into scrollback.
 */
async function runResync(hub, c, { announce = true, keepMain = false } = {}) {
  const { session, config, clock, messages } = hub;
  const a = c.adapter;
  await drained(c);
  if (c.closed) return;
  const release = await session.quiesce();
  /** @type {Buffer} */
  let bytes;
  try {
    if (c.closed || a.phase === 'PAUSED') { a.behind = false; return; }                // growing back brings a full join
    const { skipped, lost } = a;
    const text = !announce ? null : (lost ? messages.lostOutput(skipped) : messages.skippedOutput(skipped, session.name));
    bytes = buildJoinBytes({ emulator: session.emulator, tracker: session.tracker, banner: () => text,
      client: { rows: a.rows, cols: a.cols, cursorRow: a.rows, alt: a.alt, keepMain }, historyLimit: 0 });
    a.armResync();
  } finally {
    release();
  }
  if (c.closed) return;
  c.fsock.sendControl({ t: 'RESYNC_BEGIN' });
  await sendSnapshot({ bytes, chunkBytes: config.snapshot.chunkBytes, timeoutMs: 0, clock, client: snapshotTarget(hub, c), framed: false });
  if (c.closed) return;
  a.goLive();
}

module.exports = { runJoin, runResync, waitEvent, drained };
