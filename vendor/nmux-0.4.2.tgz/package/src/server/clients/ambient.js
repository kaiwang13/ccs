'use strict';
// @ts-check
const { picture, tint } = require('../output/watermark');
const { buildRedraw, mainScreen, putBack } = require('../output/snapshot');
const { attrKey } = require('../output/cells');
const { wall, dayOf, zone, zoneLabel, monthShort } = require('../../base/time');

const TICK_MS = 1000;
/** Nothing is drawn while a session is printing: only once it has been quiet this long. */
const QUIET_MS = 1500;
const SYNC_MODE = 2026;

/** @typedef {import('./hub').Client & {ambient?: {shown: string, day: string, dirty: boolean}}} Client */

/**
 * What is drawn into a terminal beside the session's own output: a faint picture behind it while nothing is happening, and a line in
 * its scrollback when a new day starts. Neither is part of the session, and neither may end up in a terminal's scrollback by accident.
 *
 * This side decides what to draw and when, because only it knows which cells are empty. The client draws it and takes it back before
 * any output, an overlay or leaving, because only the client knows what its terminal is showing. So this only draws for a client that
 * asked to (`flags.paint`), into a terminal the pty's size, with the session quiet and on its main screen, and with nothing set that
 * would make writing a cell do anything else: insert mode, scroll margins, origin mode, a synchronized frame, a wrap pending.
 *
 * A terminal that changes size moves its rows before its client hears of it, so a picture cannot be taken back from where it went:
 * the client forgets it, and the screen is written over here once things are quiet. Until then, output can carry what was moved into
 * the scrollback. That is why the picture is faint and only in empty cells: at worst it is a tint behind nothing.
 */
class Ambient {
  /**
   * @param {{hub: import('./hub').ClientHub, config: any, clock: import('../../base/types').Clock, wallNow?: () => number}} o
   */
  constructor({ hub, config, clock, wallNow = Date.now }) {
    this.hub = hub;
    this.overlay = config.overlay || {};
    this.clock = clock;
    this.wallNow = wallNow;
    this.timeZone = zone(this.overlay.timeZone || process.env.TZ);
    /** @type {any} */
    this.timer = null;
    if (this.overlay.watermark || this.overlay.dayLines) this._schedule();
  }

  _schedule() {
    this.timer = this.clock.setTimeout(() => {
      this.tick()
        .catch((e) => this.hub.log.warn('ambient.failed', { error: String(e && e.message) }))   // a picture is never worth a session
        .finally(() => { if (this.timer !== null) this._schedule(); });
    }, TICK_MS);
  }

  dispose() {
    if (this.timer !== null) this.clock.clearTimeout(this.timer);
    this.timer = null;
  }

  /** Output went to this terminal, and its client took back what was drawn first. @param {Client} c */
  overwritten(c) { if (c.ambient) c.ambient.shown = ''; }

  /**
   * The terminal changed size, so what was drawn may have moved with the text around it. The screen is written over once things are quiet.
   * @param {Client} c
   */
  moved(c) {
    if (!c.ambient || !c.ambient.shown) return;
    c.ambient.shown = '';
    c.ambient.dirty = true;
  }

  async tick() {
    const { session } = this.hub;
    if (this.clock.now() - session.lastOutputAt < QUIET_MS) return;
    await session.emulator.tail;
    if (this.clock.now() - session.lastOutputAt < QUIET_MS || !this._drawable()) return;
    for (const c of /** @type {Client[]} */ (this.hub.clients)) this._look(c);
  }

  /** Whether writing into a cell now does exactly that and nothing else. */
  _drawable() {
    const { emulator, tracker, pipeline } = this.hub.session;
    if (tracker.alt || (pipeline && !pipeline.quiescent) || tracker.modes.raw(SYNC_MODE) === 1 || tracker.modes.raw(6) === 1) return false;
    if (/** @type {any} */ (emulator.term).modes.insertMode) return false;
    const { top, bottom } = emulator.margins();
    const { rows, cursorCol } = mainScreen(emulator, tracker);
    const cols = this.hub.session.pty.cols;                                              // a fixed emulator is wider than what a terminal shows
    return emulator.tracking ? top === 0 && bottom === rows - 1 && cursorCol < cols : cursorCol < cols;
  }

  /** @param {Client} c */
  _look(c) {
    if (!c.hello.flags || !c.hello.flags.paint || c.closed || c.joining) return;
    const a = c.adapter;
    const { session } = this.hub;
    if (a.phase !== 'LIVE' || a.behind || c.fsock.writableLength > 0 || a.cols !== session.pty.cols || a.rows !== session.pty.rows) return;
    const st = c.ambient || (c.ambient = { shown: '', day: '', dirty: false });
    const now = this.wallNow();
    const day = dayOf(now, this.timeZone);
    if (this.overlay.dayLines && st.day && st.day !== day.key) {
      st.day = day.key;
      this._redraw(c, `── ${day.words} · ${this.timeZone} · ${session.name} ──`.slice(0, a.cols - 1));
      return;
    }
    st.day = day.key;
    if (st.dirty) { this._redraw(c, null); return; }
    if (!this.overlay.watermark) return;
    const color = tint(c.hello.colors);
    if (!color) return;
    const w = wall(now, this.timeZone);
    const text = { time: `${String(w.hour).padStart(2, '0')}:${String(w.minute).padStart(2, '0')}`, date: `${w.weekday.slice(0, 3)} ${w.day} ${monthShort(now, this.timeZone)}`,
      detail: `${zoneLabel(now, this.timeZone)} ${session.name}` };
    const key = `${text.time}|${text.date}|${text.detail}|${a.cols}x${a.rows}`;
    if (st.shown === key) return;
    const paint = this._paint(text, color);
    if (!paint) return;
    c.fsock.sendControl({ t: 'PAINT', ...paint, cols: a.cols, rows: a.rows });
    st.shown = key;
  }

  /** @param {Client} c @param {string|null} lineAbove */
  _redraw(c, lineAbove) {
    const { session } = this.hub;
    /** @type {Client} */ (c).ambient = { ...(/** @type {any} */ (c).ambient), shown: '', dirty: false };
    c.adapter.underneath(buildRedraw({ emulator: session.emulator, tracker: session.tracker, lineAbove }));
  }

  /**
   * The picture, in the cells where it can go: those that are empty, with nothing in them and nothing set on them, not under the cursor,
   * and with an empty cell either side, because a terminal may draw a character wider than xterm measures it (`✔️` is two cells in
   * most, one here), and erasing half of one erases all of it.
   * @param {{time: string, date: string, detail: string}} text @param {string} color
   * @returns {{bytes: string, undo: string}|null}
   */
  _paint(text, color) {
    const { emulator, tracker, pty } = this.hub.session;
    const { b, top, rows, cursorRow, cursorCol } = mainScreen(emulator, tracker);
    const cell = b.getNullCell();
    /** @param {any} line @param {number} row @param {number} x */
    const blank = (line, row, x) => {
      if (x < 0 || x >= pty.cols) return true;
      if (row === cursorRow && x === cursorCol) return false;
      line.getCell(x, cell);
      return cell.getWidth() === 1 && (cell.getChars() === '' || cell.getChars() === ' ') && attrKey(cell) === '';
    };
    /** @type {Array<{row: number, col: number, len: number}>} */
    const free = [];
    for (const run of picture(text, pty.cols, rows)) {
      const line = b.getLine(top + run.row);
      if (!line) continue;
      let start = -1;
      for (let x = run.col; x <= run.col + run.len; x++) {
        const empty = x < run.col + run.len && blank(line, run.row, x - 1) && blank(line, run.row, x) && blank(line, run.row, x + 1);
        if (empty && start < 0) start = x;
        if (!empty && start >= 0) { free.push({ row: run.row, col: start, len: x - start }); start = -1; }
      }
    }
    if (!free.length) return null;
    const at = (/** @type {{row: number, col: number}} */ r) => `\x1b[${r.row + 1};${r.col + 1}H`;
    const back = putBack(emulator, tracker);
    // Erased in a colour rather than written with spaces: a cell left empty holds nothing a terminal would keep. When one gets
    // smaller it drops empty cells rather than push them into its scrollback, and copying gives nothing for them.
    return {
      bytes: `\x1b[?25l\x1b[0;${color}m${free.map((r) => `${at(r)}\x1b[${r.len}X`).join('')}${back}`,
      undo: `\x1b[?25l\x1b[0m${free.map((r) => `${at(r)}\x1b[${r.len}X`).join('')}${back}`,
    };
  }
}

module.exports = { Ambient, QUIET_MS };
