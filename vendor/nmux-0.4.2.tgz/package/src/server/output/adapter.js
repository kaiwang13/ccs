'use strict';
// @ts-check
const { T } = require('../../wire/proto');
const { DEFAULT_MESSAGES } = require('../messages');

/** @typedef {import('./pipeline').Edit} Edit */
/** @typedef {import('./pipeline').AnnotatedChunk} AnnotatedChunk */

const NOTICE_TITLE_MS = 8000;
const MAX_OUTPUT_FRAME = 512 * 1024;
/** Output held while a join is sent may run to this many live queues before the join is abandoned for a resync. */
const JOIN_QUEUE_FACTOR = 4;

/**
 * Rewrites an absolute row-positioning sequence to `row` (1-based), keeping its form and column.
 * @param {Edit} edit @param {number} row @returns {Buffer}
 */
function rewriteRow(edit, row) {
  switch (edit.form) {
    case 'home': return Buffer.from(`\x1b[${row};1H`);
    case 'cup': return Buffer.from(edit.col == null ? `\x1b[${row}H` : `\x1b[${row};${edit.col}H`);
    case 'hvp': return Buffer.from(`\x1b[${row};${edit.col == null ? 1 : edit.col}f`);
    case 'vpa': return Buffer.from(`\x1b[${row}d`);
    default: throw new Error(`rewriteRow: unknown form ${edit.form}`);
  }
}

/** @param {string} s */
const osc0 = (s) => Buffer.from(`\x1b]0;${s}\x07`);

/**
 * Per-client adapter. Δ row rewrite, alt-exit margin reset, title prefixes, notices, the live queue cap. A client past
 * the cap is never disconnected: output for it stops (`behind`) until `onBehind` has resynced it in place. OSC 52 is not
 * routed yet: clipboard edits are dropped.
 */
class ClientAdapter {
  /**
   * @param {{id: string, send: (type: number, payload: Buffer|object) => void, writableLength: () => number, cols: number, rows: number,
   *   flags?: {shrink?: boolean, allowSetup?: boolean, view?: boolean}, label?: string, config: any, tracker: import('./tracker').Tracker,
   *   clock: import('../../base/types').Clock, messages?: import('../messages').Messages, onDrop?: (reason: string, autoRejoin: boolean) => void, onBehind?: () => void}} o
   */
  constructor({ id, send, writableLength, cols, rows, flags = {}, label = '', config, tracker, clock, messages = DEFAULT_MESSAGES, onDrop = () => {}, onBehind = () => {} }) {
    this.id = id;
    this.sendFrame = send;
    this.writableLength = writableLength;
    this.cols = cols;
    this.rows = rows;
    this.flags = { shrink: !!flags.shrink, allowSetup: !!flags.allowSetup, view: !!flags.view };
    this.label = label;
    this.config = config;
    this.tracker = tracker;
    this.clock = clock;
    this.messages = messages;
    this.onDrop = onDrop;
    this.onBehind = onBehind;
    /** @type {'JOINING'|'LIVE'|'PAUSED'} */
    this.phase = 'JOINING';
    this.closed = false;
    this.stalled = false;
    this.unresponsive = false;
    /** set by armJoin() at the snapshot point S; output rendered after S is buffered until goLive() */
    this.armed = false;
    /** @type {Buffer[]} */
    this.pendingLive = [];
    this.pendingBytes = 0;
    /** output is being skipped for this client until it has been resynced */
    this.behind = false;
    /** bytes skipped since the last resync */
    this.skipped = 0;
    /** the skipped bytes are gone for everyone, not only for this client */
    this.lost = false;
    /** output has been skipped at some point, so this terminal's scrollback has a hole in it */
    this.hasGaps = false;
    /** bytes that passed while paused in the middle of a join */
    this.missed = 0;
    /** a resync is being sent: the client is live, and may type */
    this.resyncing = false;
    /** this client's terminal is on the alternate screen, going by what has actually been sent to it */
    this.alt = false;
    /** the same for the output held during a join; it counts when that is sent */
    /** @type {boolean|null} */
    this.heldAlt = null;
    this.atGround = true;
    this.attention = false;
    /** @type {string|null} */
    this.noticeText = null;
    this.noticeTimer = null;
    this.titleDirty = false;
  }

  titlePrefix() {
    if (this.noticeText !== null) return `[${this.messages.brand}: ${this.noticeText}] `;
    if (this.attention) return this.messages.attentionTitle;
    return '';
  }

  /** The screen the terminal is on once it has everything sent or held for it. */
  get lastAlt() { return this.heldAlt ?? this.alt; }

  /** @param {AnnotatedChunk} chunk */
  render(chunk) {
    if (this.closed) return;
    if (this.phase === 'PAUSED') { if (this.armed) this.missed += chunk.bytes.length; return; }
    if (this.behind) { this.skipped += chunk.bytes.length; this.atGround = chunk.groundAfter; return; }
    if (this.phase === 'JOINING' && !this.armed) return;
    /** @type {Buffer[]} */
    const out = [];
    let pos = 0;
    let alt = this.lastAlt;
    for (const e of chunk.edits) {
      out.push(chunk.bytes.subarray(pos, e.start));
      pos = e.end;
      switch (e.kind) {
        case 'drop': break;                                                           // queries never reach clients
        case 'row': {
          const d = Math.max(0, this.rows - /** @type {number} */ (e.renderRows));     // 0 for clients no taller than the render
          out.push(d ? rewriteRow(e, /** @type {number} */ (e.row) + d) : e.raw);
          break;
        }
        case 'margins': out.push(this._margins(e)); break;
        case 'alt-enter': alt = true; out.push(e.raw); break;
        case 'alt-exit': alt = false; out.push(e.raw, Buffer.from('\x1b7\x1b[r\x1b8')); break;      // drop vim's scroll margins
        case 'title': out.push(osc0(this.titlePrefix() + (e.text ?? ''))); this.titleDirty = false; break;
        case 'clipboard': break;                                                      // OSC 52 is not forwarded
        case 'mark': out.push(/** @type {Buffer} */ (e.standard)); break;
        default: out.push(e.raw);
      }
    }
    out.push(chunk.bytes.subarray(pos));
    this.atGround = chunk.groundAfter;
    if (this.titleDirty && this.atGround) { out.push(osc0(this.titlePrefix() + this.tracker.title)); this.titleDirty = false; }
    this._enqueue(Buffer.concat(out), alt);
  }

  /**
   * A client taller than the pty shows it on its bottom rows, so a scroll region moves down with it. DECSTBM also homes
   * the cursor, and home is not the client's first row. A region as tall as the pty is sent as no region at all: anything
   * else would keep lines leaving the top out of the terminal's scrollback.
   * @param {Edit} e
   */
  _margins(e) {
    const render = /** @type {number} */ (e.renderRows);
    const d = Math.max(0, this.rows - render);
    if (d === 0) return e.raw;
    const top = /** @type {number} */ (e.top);
    const bottom = e.bottom ?? render;
    const region = top === 1 && bottom >= render ? '\x1b[r' : `\x1b[${top + d};${bottom + d}r`;
    return Buffer.from(`${region}\x1b[${d + 1};1H`);
  }

  /** @param {Buffer} buf @param {boolean} [alt] the screen the terminal is on once it has these bytes */
  _enqueue(buf, alt = this.lastAlt) {
    if (buf.length === 0 || this.closed) return;
    if (this.behind) { this.skipped += buf.length; return; }
    const cap = this.config.clients.queueCapBytes;
    if (this.phase === 'JOINING') {
      if (!this.armed) return;
      this.pendingLive.push(buf);
      this.pendingBytes += buf.length;
      this.heldAlt = alt;
      if (this.pendingBytes > cap * JOIN_QUEUE_FACTOR) { this.pendingLive = []; this.heldAlt = null; this.skip(this.pendingBytes); this.pendingBytes = 0; }
      return;
    }
    if (this.writableLength() + buf.length > cap) { this.skip(buf.length); return; }
    this.alt = alt;
    for (let i = 0; i < buf.length; i += MAX_OUTPUT_FRAME) this.sendFrame(T.OUTPUT, buf.subarray(i, i + MAX_OUTPUT_FRAME));
  }

  /** Stops output for this client until it has been resynced. @param {number} bytes @param {{lost?: boolean}} [o] */
  skip(bytes, { lost = false } = {}) {
    this.skipped += bytes;
    this.hasGaps = true;
    this.lost = this.lost || lost;
    if (this.behind) return;
    this.behind = true;
    this.onBehind();
  }

  /** The client grew back while a join for it was still being sent: that join stands, and what passed meanwhile is made up for. */
  resumeJoin() {
    this.phase = 'JOINING';
    const { missed } = this;
    this.missed = 0;
    if (missed) this.skip(missed);
  }

  /** Snapshot point S reached (holder reading paused): buffer everything rendered from now on until goLive(). */
  armJoin() { this.pendingLive = []; this.pendingBytes = 0; this.armed = true; this.atGround = true; this.alt = this.tracker.alt; this.heldAlt = null; this.missed = 0; }

  /** The same point in a resync, for a client that stays live throughout. */
  armResync() {
    this.armJoin();
    this.behind = false;
    this.skipped = 0;
    this.lost = false;
    this.phase = 'JOINING';
    this.resyncing = true;
  }

  /** After SNAPSHOT_END: flush the output rendered during the join; live-queue accounting starts now. */
  goLive() {
    if (this.closed) return;
    this.armed = false;
    this.resyncing = false;
    const pending = Buffer.concat(this.pendingLive);
    this.pendingLive = [];
    this.pendingBytes = 0;
    if (this.phase === 'PAUSED') return;                                              // it went below the floor meanwhile
    this.phase = 'LIVE';
    if (this.heldAlt !== null) this.alt = this.heldAlt;
    this.heldAlt = null;
    for (let i = 0; i < pending.length; i += MAX_OUTPUT_FRAME) this.sendFrame(T.OUTPUT, pending.subarray(i, i + MAX_OUTPUT_FRAME));
  }

  /**
   * Something of nmux's own, written into the terminal between pieces of output, such as a screen written over in place. It goes in order with
   * the output, and only to a terminal that is live: one being joined or caught up will be drawn from scratch anyway.
   * @param {Buffer} bytes
   */
  underneath(bytes) { if (this.phase === 'LIVE' && !this.behind) this._enqueue(bytes); }

  /** NOTICE frame (the attach client prints it after detach) plus an 8 s title prefix; warnings ring BEL. */
  notice(level, code, text) {
    if (this.closed) return;
    this.sendFrame(T.CONTROL, { t: 'NOTICE', level, code, text });
    this.flash(text);
    if (level === 'warn') this._raw(Buffer.from('\x07'));
  }

  /** The title says this for a few seconds. @param {string} text */
  flash(text) {
    if (this.closed) return;
    this.noticeText = text;
    if (this.noticeTimer !== null) this.clock.clearTimeout(this.noticeTimer);
    this.noticeTimer = this.clock.setTimeout(() => { this.noticeTimer = null; this.noticeText = null; this._refreshTitle(); }, NOTICE_TITLE_MS);
    this._refreshTitle();
  }

  /** The title says so while the session is asking for a person; BEL once when it starts. @param {boolean} attention */
  setAttention(attention) {
    if (attention === this.attention) return;
    this.attention = attention;
    if (attention && this.config.notices.bellOnAttention) this._raw(Buffer.from('\x07'));
    this._refreshTitle();
  }

  /** A synthetic OSC 0 only ever goes out at a ground-state boundary, never inside a live sequence. */
  _refreshTitle() {
    this.titleDirty = true;
    if (this.atGround) { this.titleDirty = false; this._raw(osc0(this.titlePrefix() + this.tracker.title)); }
  }

  /** @param {Buffer} buf */
  _raw(buf) { if (this.phase !== 'PAUSED') this._enqueue(buf); }

  /** Sends BYE and tells the owner to close. @param {string} reason @param {boolean} autoRejoin @param {string} [text] @param {object} [extra] more BYE fields */
  drop(reason, autoRejoin, text = '', extra = {}) {
    if (this.closed) return;
    this.closed = true;
    if (this.noticeTimer !== null) { this.clock.clearTimeout(this.noticeTimer); this.noticeTimer = null; }
    this.pendingLive = [];
    this.sendFrame(T.CONTROL, { t: 'BYE', reason, autoRejoin, text, ...extra });
    this.onDrop(reason, autoRejoin);
  }

  setSize(cols, rows) { this.cols = cols; this.rows = rows; }
}

module.exports = { rewriteRow, ClientAdapter };
