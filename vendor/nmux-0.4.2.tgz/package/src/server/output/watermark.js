'use strict';
// @ts-check
/**
 * A faint picture behind a session: the time in large figures, and under it the date, the time zone and the session's name. It is
 * drawn by tinting the background of empty cells only, so text always stands in front of it, and they stay empty: copying gives nothing.
 * What this file decides is where those cells are: a picture is a list of runs of cells, by row, that are not yet known to be empty.
 */

/** Large figures, 5x7. A pixel is two cells wide, because a cell is about twice as tall as it is wide. */
const LARGE = /** @type {Record<string, string[]>} */ ({
  0: ['01110', '10001', '10011', '10101', '11001', '10001', '01110'],
  1: ['00100', '01100', '00100', '00100', '00100', '00100', '01110'],
  2: ['01110', '10001', '00001', '00010', '00100', '01000', '11111'],
  3: ['11111', '00010', '00100', '00010', '00001', '10001', '01110'],
  4: ['00010', '00110', '01010', '10010', '11111', '00010', '00010'],
  5: ['11111', '10000', '11110', '00001', '00001', '10001', '01110'],
  6: ['00110', '01000', '10000', '11110', '10001', '10001', '01110'],
  7: ['11111', '00001', '00010', '00100', '01000', '01000', '01000'],
  8: ['01110', '10001', '10001', '01110', '10001', '10001', '01110'],
  9: ['01110', '10001', '10001', '01111', '00001', '00010', '01100'],
  ':': ['0', '0', '1', '0', '1', '0', '0'],
});

/** Small letters and figures, 3x5. */
const SMALL = /** @type {Record<string, string[]>} */ ({
  A: ['010', '101', '111', '101', '101'], B: ['110', '101', '110', '101', '110'], C: ['011', '100', '100', '100', '011'],
  D: ['110', '101', '101', '101', '110'], E: ['111', '100', '110', '100', '111'], F: ['111', '100', '110', '100', '100'],
  G: ['011', '100', '101', '101', '011'], H: ['101', '101', '111', '101', '101'], I: ['111', '010', '010', '010', '111'],
  J: ['001', '001', '001', '101', '010'], K: ['101', '101', '110', '101', '101'], L: ['100', '100', '100', '100', '111'],
  M: ['101', '111', '111', '101', '101'], N: ['110', '101', '101', '101', '101'], O: ['010', '101', '101', '101', '010'],
  P: ['110', '101', '110', '100', '100'], Q: ['010', '101', '101', '110', '011'], R: ['110', '101', '110', '101', '101'],
  S: ['011', '100', '010', '001', '110'], T: ['111', '010', '010', '010', '010'], U: ['101', '101', '101', '101', '111'],
  V: ['101', '101', '101', '101', '010'], W: ['101', '101', '111', '111', '101'], X: ['101', '101', '010', '101', '101'],
  Y: ['101', '101', '010', '010', '010'], Z: ['111', '001', '010', '100', '111'],
  0: ['111', '101', '101', '101', '111'], 1: ['010', '110', '010', '010', '111'], 2: ['110', '001', '010', '100', '111'],
  3: ['110', '001', '010', '001', '110'], 4: ['101', '101', '111', '001', '001'], 5: ['111', '100', '110', '001', '110'],
  6: ['011', '100', '111', '101', '111'], 7: ['111', '001', '010', '010', '010'], 8: ['111', '101', '111', '101', '111'],
  9: ['111', '101', '111', '001', '110'], ' ': ['000', '000', '000', '000', '000'], '-': ['000', '000', '111', '000', '000'],
  '.': ['000', '000', '000', '000', '010'], '/': ['001', '001', '010', '100', '100'], ':': ['000', '010', '000', '010', '000'],
  '+': ['000', '010', '111', '010', '000'], '_': ['000', '000', '000', '000', '111'], '?': ['110', '001', '010', '000', '010'],
});

const PIXEL = 2;
const MARGIN = 2;
const GAP_ROWS = 1;

/** @typedef {{row: number, col: number, len: number}} Run */

/**
 * One line of the picture, as rows of pixels.
 * @param {string} text @param {Record<string, string[]>} font @returns {string[]} rows of '0' and '1'
 */
function rasterize(text, font) {
  const glyphs = [...text].map((ch) => font[ch] || font[ch.toUpperCase()] || font['?'] || font[':']);
  const height = glyphs[0] ? glyphs[0].length : 0;
  const rows = [];
  for (let y = 0; y < height; y++) rows.push(glyphs.map((g) => g[y]).join('0'));
  return rows;
}

/**
 * Where the picture goes on a screen this size: against the right edge, in the lower part, and only the lines that fit. Lines that
 * do not fit are left out from the end, so the time is the last thing to go.
 * @param {{time: string, date: string, detail: string}} text @param {number} cols @param {number} rows @returns {Run[]}
 */
function picture({ time, date, detail }, cols, rows) {
  const lines = [rasterize(time, LARGE), rasterize(date, SMALL), rasterize(detail, SMALL)];
  const fitting = [];
  let height = 0;
  for (const l of lines) {
    const extra = l.length + (fitting.length ? GAP_ROWS : 0);
    if (!l.length || l[0].length * PIXEL + MARGIN * 2 > cols || height + extra + MARGIN * 2 > rows) break;
    fitting.push(l);
    height += extra;
  }
  if (!fitting.length) return [];
  /** @type {Run[]} */
  const runs = [];
  let y = Math.max(MARGIN, rows - MARGIN - height - Math.floor((rows - height) / 4));
  for (const l of fitting) {
    const left = cols - MARGIN - l[0].length * PIXEL;
    for (const bits of l) {
      for (const m of bits.matchAll(/1+/g)) runs.push({ row: y, col: left + /** @type {number} */ (m.index) * PIXEL, len: m[0].length * PIXEL });
      y += 1;
    }
    y += GAP_ROWS;
  }
  return runs;
}

/**
 * The colour of the tint: the terminal's background moved a little towards its foreground, so it reads as faint on a dark theme and a
 * light one alike. Null when either is not known: guessing would be visible.
 * @param {{fg: string|null, bg: string|null}|null|undefined} colors as OSC 10/11 answer, `rgb:rrrr/gggg/bbbb` @param {number} [strength]
 * @returns {string|null} an SGR background
 */
function tint(colors, strength = 0.09) {
  const parse = (/** @type {string|null|undefined} */ c) => {
    const m = c ? /^rgb:([0-9a-f]{1,4})\/([0-9a-f]{1,4})\/([0-9a-f]{1,4})$/i.exec(c) : null;
    return m ? [m[1], m[2], m[3]].map((h) => Math.round((parseInt(h, 16) / (16 ** h.length - 1)) * 255)) : null;
  };
  const fg = parse(colors && colors.fg);
  const bg = parse(colors && colors.bg);
  if (!fg || !bg) return null;
  const [r, g, b] = bg.map((v, i) => Math.round(v + (fg[i] - v) * strength));
  return `48;2;${r};${g};${b}`;
}

module.exports = { picture, rasterize, tint, LARGE, SMALL };
