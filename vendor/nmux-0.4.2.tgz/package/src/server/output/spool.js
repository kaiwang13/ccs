'use strict';
// @ts-check
const fs = require('node:fs');
const path = require('node:path');
const { promisify } = require('node:util');
const { StringDecoder } = require('node:string_decoder');
const { cutLine } = require('./cells');
const history = require('../../wire/history');

const write = promisify(fs.write);
/** Reading goes this far between chances for anything else to run. */
const READ_BYTES = 1048576;
/** Longer than any watermark's line, so that one two reads divide is whole in one of them. */
const MARK_BYTES = 64;
const MARK = /^=(\d+):(\d+):(\d+)$/;
const NEWLINE_MARK = Buffer.from('\n=');
/** A history kept whole is split into files of about this size, none of them ever removed. */
const SEGMENT_BYTES = 67108864;
/** Past this much not yet written, the disk is not keeping up: rows are counted and dropped rather than held. */
const QUEUE_BYTES = 33554432;
/** A time goes in before a row printed this much earlier or later than the last time the file said. */
const TIME_EVERY_MS = 1000;

/**
 * Rows on their way to the disk. They are made into lines only as they are written, when it is known which file they go into.
 * @typedef {{rows: string[], wrapped: boolean[], times: number[], first: number, mark: {gen: number, offset: number, lines: number},
 *   bytes: number, lost?: number}} Chunk
 *   times: when each row was printed, 0 if not known; bytes: about what they take, for the limit on what is queued; lost: rows before
 *   them that never reached the disk
 */

/**
 * Rows that have left the screen, on disk, in the format of `wire/history.js`: it makes `capture`, `last`, `search` and `view` reach
 * back. Terminal output often has secrets in it, so this is off unless asked for, and the files are private.
 *
 * Bounded (`maxBytes`), two files are kept, each up to half of it, so the newest part is always there. Kept whole (`keep`), every file
 * stays, in a directory that outlives the session.
 *
 * Writing never makes the session wait: rows are queued and written in order, and a disk that does not keep up, such as an NFS
 * home that has hung, costs rows, which are counted, and never output. Something going wrong ends the spool, not the session.
 */
class Spool {
  /**
   * @param {{dir: string, maxBytes: number, keep?: boolean, log: any, wallNow?: () => number, meta?: object|null}} o
   *   meta: what `nmux search` says about the session this came from
   */
  constructor({ dir, maxBytes, keep = false, log, wallNow = Date.now, meta = null }) {
    this.dir = dir;
    this.maxBytes = maxBytes;
    this.keep = keep;
    this.log = log;
    this.wallNow = wallNow;
    /** the number the next row gets */
    this.lines = 0;
    /** @type {number|null} */
    this.fd = null;
    this.fileBytes = 0;
    /** program's output up to here is already written @type {number} */
    this.through = -1;
    this.gen = 0;
    /** @type {{gen: number, offset: number}|null} */
    this.lastMark = null;
    /** the time the current file last said, or null if it has said none yet @type {number|null} */
    this.fileTime = null;
    this.failed = false;
    /** @type {Chunk[]} */
    this.queue = [];
    this.queued = 0;
    /** rows counted but not queued, since the disk was behind: the next chunk says so */
    this.dropped = 0;
    this.writing = false;
    /** close() was called: nothing more is queued */
    this.closing = false;
    /** close() has stopped waiting: nothing more is written, and the file is closed once no write is under way */
    this.closed = false;
    /** @type {Array<() => void>} */
    this.idleWaiters = [];
    try {
      fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
      if (meta) this.describe(meta);
      this._open();
    } catch (e) { this._failed(e); }
  }

  /** Nothing more is written: what is queued is let go, so that nobody waits for it. @param {unknown} e */
  _failed(e) {
    if (!this.failed) this.log.warn('spool.failed', { error: String(/** @type {Error} */ (e).message) });
    this.failed = true;
    this.queue = [];
    this.queued = 0;
  }

  /** What `nmux search` says about the session. @param {object} meta */
  describe(meta) {
    try {
      const file = path.join(this.dir, history.META);
      fs.writeFileSync(`${file}.new`, JSON.stringify({ schema: 'nmux.history/1', ...meta }), { mode: 0o600 });
      fs.renameSync(`${file}.new`, file);
    } catch (e) { this.log.warn('spool.meta_failed', { error: String(/** @type {Error} */ (e).message) }); }
  }

  /** @returns {Array<{file: string, first: number}>} oldest first */
  _files() {
    let names = [];
    try { names = fs.readdirSync(this.dir); } catch { return []; }
    return names.map((n) => ({ file: path.join(this.dir, n), first: history.firstRowOf(n) })).filter((f) => f.first !== null)
      .map((f) => ({ file: f.file, first: /** @type {number} */ (f.first) })).sort((a, b) => a.first - b.first);
  }

  /**
   * Carries on from whatever is there. Every write ends with a watermark, but a server can go in the middle of one, when it crashes
   * or a slow disk outlasts its wait, and leave part of a chunk after the last. That part is cut off: written again after it, its rows
   * would be there twice and its last row would run into the next. The server carrying on writes them again, from where the mark says.
   * A file started for a chunk that never got as far as its mark has nothing before it that is not in the file before.
   */
  _open() {
    const files = this._files();
    for (;;) {
      const last = files.pop();
      if (!last) { this._startFile(0); return; }
      const fd = fs.openSync(last.file, 'r');
      let size = 0;
      /** @type {{mark: {gen: number, offset: number, lines: number}, end: number}|null} */
      let found = null;
      let counted = { rows: 0, end: 0 };
      try {
        size = fs.fstatSync(fd).size;
        found = lastMark(fd, size);
        if (!found && !files.length) counted = wholeRows(fd, size);
      } finally {
        fs.closeSync(fd);
      }
      if (!found && files.length) {
        if (size > 0) this.log.warn('spool.cut', { file: last.file, bytes: size });
        fs.rmSync(last.file, { force: true });
        continue;
      }
      if (found) {
        this.lastMark = { gen: found.mark.gen, offset: found.mark.offset };
        this.lines = found.mark.lines;
      } else this.lines = last.first + counted.rows;                                    // nothing says how far it went: as far as it has rows
      const end = found ? found.end : counted.end;
      if (end < size) {
        this.log.warn('spool.cut', { file: last.file, bytes: size - end });
        fs.truncateSync(last.file, end);
      }
      this.fd = fs.openSync(last.file, 'a', 0o600);
      this.fileBytes = end;
      return;
    }
  }

  /** @param {number} first the number of the file's first row */
  _startFile(first) {
    this._closeFd();
    this.fd = fs.openSync(path.join(this.dir, `${history.PREFIX}${first}`), 'a', 0o600);
    fs.fchmodSync(this.fd, 0o600);
    this.fileBytes = 0;
    this.fileTime = null;                                                               // each file says when it starts
    if (!this.keep) for (const old of this._files().slice(0, -2)) fs.rmSync(old.file, { force: true });
  }

  _closeFd() {
    if (this.fd === null) return;
    try { fs.closeSync(this.fd); } catch { /* already */ }
    this.fd = null;
  }

  /** The program's output from here on is a new stream. @param {number} gen */
  stream(gen) { this.gen = gen; }

  /** A new program, whose stream starts again from nothing. @param {number} gen */
  newStream(gen) {
    this.gen = gen;
    this.through = -1;
  }

  /** The server before this one wrote what it read of this program. @param {number} gen */
  resume(gen) { if (this.lastMark && this.lastMark.gen === gen) this.through = this.lastMark.offset; }

  /** @param {number} offset how far into the program's output a row goes */
  alreadyHas(offset) { return offset <= this.through; }

  /**
   * @param {string[]} rows what serializeRows made @param {boolean[]} wrapped whether each carries on from the row before it
   * @param {number} offset how far into the output these go
   * @param {number[]|null} [times] when each was printed, in ms since the epoch, 0 if that is not known; none: now
   * @returns {number} the number of the first
   */
  append(rows, wrapped, offset, times = null) {
    const first = this.lines;
    this.lines += rows.length;
    if (this.failed || this.closing) return first;
    let bytes = 64;
    for (const row of rows) bytes += row.length + 2;
    this._queue({ rows, wrapped, times: times || rows.map(() => this.wallNow()), first, mark: { gen: this.gen, offset, lines: this.lines }, bytes });
    return first;
  }

  /** @param {Chunk} chunk */
  _queue(chunk) {
    if (this.queued > QUEUE_BYTES) { this.dropped += chunk.rows.length; return; }
    if (this.dropped) {
      this.log.warn('spool.dropped', { rows: this.dropped });
      chunk.lost = this.dropped;
      this.dropped = 0;
    }
    this.queue.push(chunk);
    this.queued += chunk.bytes;
    this._pump();
  }

  /**
   * A chunk as the lines of the file it goes into. A file starts by saying when, and says it again before a row printed at another time.
   * @param {Chunk} c @param {number|null} said the time the file last said @returns {{bytes: Buffer, said: number}}
   */
  _serialize(c, said) {
    let text = '';
    if (said === null) {
      said = c.times.find((t) => t > 0) || this.wallNow();
      text += history.timeLine(said);
    }
    if (c.lost) text += history.lostLine(c.lost);
    for (let i = 0; i < c.rows.length; i++) {
      const at = c.times[i];
      if (at > 0 && Math.abs(at - said) >= TIME_EVERY_MS) { text += history.timeLine(at); said = at; }
      text += history.rowLine(c.rows[i], c.wrapped[i]);
    }
    text += history.markLine(c.mark.gen, c.mark.offset, c.mark.lines);
    return { bytes: Buffer.from(text, 'utf8'), said };
  }

  async _pump() {
    if (this.writing) return;
    this.writing = true;
    while (this.queue.length && !this.failed && !this.closed) {
      const chunk = /** @type {Chunk} */ (this.queue.shift());
      this.queued -= chunk.bytes;
      try {
        const limit = this.keep ? SEGMENT_BYTES : this.maxBytes / 2;
        let out = this._serialize(chunk, this.fileTime);
        if (this.fileBytes + out.bytes.length > limit && this.fileBytes > 0) {
          this._startFile(chunk.first - (chunk.lost || 0));                            // the rows it says were lost are the file's first
          out = this._serialize(chunk, this.fileTime);
        }
        const { bytes } = out;
        for (let at = 0; at < bytes.length;) at += (await write(/** @type {number} */ (this.fd), bytes, at, bytes.length - at)).bytesWritten;
        this.fileBytes += bytes.length;
        this.fileTime = out.said;
      } catch (e) { this._failed(e); }
    }
    this.writing = false;
    if (this.closed) this._closeFd();
    for (const done of this.idleWaiters.splice(0)) done();
  }

  /** Resolves once everything given so far is on disk, or `ms` has passed. @param {number} [ms] */
  idle(ms = Infinity) {
    if (!this.writing && this.queue.length === 0) return Promise.resolve();
    return new Promise((resolve) => {
      const timer = Number.isFinite(ms) ? setTimeout(resolve, ms) : null;
      this.idleWaiters.push(() => { if (timer) clearTimeout(timer); resolve(undefined); });
    });
  }

  /**
   * Hands over the rows with these numbers, a piece at a time, so that a big spool holds nothing up.
   * @param {number} from @param {number} to `to` excluded @param {(row: string, number: number) => void} visit
   */
  async _scan(from, to, visit) {
    await this.idle();
    const files = this._files();
    for (let i = 0; i < files.length; i++) {
      const next = files[i + 1];
      if ((next && next.first <= from) || files[i].first >= to) continue;
      try { await scanFile(files[i], from, to, visit); } catch (e) { if (/** @type {any} */ (e).code !== 'ENOENT') throw e; }   // rotated away just now
    }
  }

  /** Adds a row to whole lines, however they wrapped. @param {string[]} lines @param {string} row @param {boolean} continues @param {boolean} ansi */
  _add(lines, row, continues, ansi) {
    const text = ansi ? row : history.plain(row);
    if (continues && lines.length) lines[lines.length - 1] += text;
    else lines.push(text);
  }

  /**
   * The rows with these numbers, as whole lines, or null if some of them have gone.
   * @param {number} from @param {number} to `to` excluded @param {{ansi?: boolean, lastChars?: number|null}} [o] lastChars: only this much of the last line
   * @returns {Promise<string[]|null>}
   */
  async range(from, to, { ansi = false, lastChars = null } = {}) {
    const files = this._files();
    if (!files.length || files[0].first > from) return null;
    /** @type {string[]} */
    const lines = [];
    let seen = false;
    await this._scan(from, to, (row, _n, continues) => {
      this._add(lines, row, continues, ansi);
      seen = true;
    });
    if (lastChars !== null && lines.length) lines[lines.length - 1] = cutLine(lines[lines.length - 1], lastChars);
    return !seen && to > from ? null : lines;
  }

  /**
   * The last lines there are.
   * @param {number|null} count null: all of them @param {{ansi?: boolean}} [o] @returns {Promise<string[]>}
   */
  async lastLines(count, { ansi = false } = {}) {
    /** @type {string[]} */
    let lines = [];
    await this._scan(0, this.lines, (row, _n, continues) => {
      this._add(lines, row, continues, ansi);
      if (count !== null && lines.length > count * 2 + 1) lines = lines.slice(-count - 1);    // the last may yet be added to
    });
    return count === null ? lines : lines.slice(-count);
  }

  /**
   * Waits a little for what is queued, so that a session's last rows are written before its server goes. A disk that has hung must not
   * keep it, so what is not written by then is let go. A write under way is never cut short: the file is closed when it returns.
   * @param {number} [ms]
   */
  async close(ms = Infinity) {
    this.closing = true;
    await this.idle(ms);
    this.closed = true;
    if (this.queue.length) {
      this.log.warn('spool.unwritten', { rows: this.queue.reduce((n, c) => n + c.rows.length, 0) });
      this.queue = [];
      this.queued = 0;
    }
    if (!this.writing) this._closeFd();
  }
}

/** @param {number} fd @param {Buffer} buf @param {number} length @param {number} position @returns {number} what was read */
function readAt(fd, buf, length, position) {
  let got = 0;
  while (got < length) {
    const n = fs.readSync(fd, buf, got, length - got, position + got);
    if (n === 0) break;
    got += n;
  }
  return got;
}

/**
 * The last whole watermark in a file, and where its line ends. Looked for from the end back, as far as it takes, a piece at a time.
 * @param {number} fd @param {number} size @returns {{mark: {gen: number, offset: number, lines: number}, end: number}|null}
 */
function lastMark(fd, size) {
  const buf = Buffer.allocUnsafe(READ_BYTES + MARK_BYTES);
  /** @param {number} start @param {number} length where a line starts in `buf`, and how much there is */
  const markAt = (start, length) => {
    const nl = buf.indexOf(0x0a, start);
    if (nl < 0 || nl >= length) return null;                                            // not a whole line
    const m = MARK.exec(buf.toString('latin1', start, nl));
    return m ? { mark: { gen: Number(m[1]), offset: Number(m[2]), lines: Number(m[3]) }, end: nl + 1 } : null;
  };
  for (let hi = size; hi > 0;) {
    const lo = Math.max(0, hi - READ_BYTES);
    const length = readAt(fd, buf, Math.min(size, hi + MARK_BYTES) - lo, lo);
    for (let at = buf.lastIndexOf(NEWLINE_MARK, Math.min(hi - lo - 1, length - 2)); at >= 0; at = at > 0 ? buf.lastIndexOf(NEWLINE_MARK, at - 1) : -1) {
      const found = markAt(at + 1, length);                                             // lines that start after a line feed in [lo, hi)
      if (found) return { mark: found.mark, end: lo + found.end };
    }
    if (lo === 0 && buf[0] === 0x3d) {
      const found = markAt(0, length);
      if (found) return found;
    }
    hi = lo;
  }
  return null;
}

/**
 * How many rows a file with no watermark has, as far as its last whole line, and where that ends.
 * @param {number} fd @param {number} size @returns {{rows: number, end: number}}
 */
function wholeRows(fd, size) {
  const buf = Buffer.allocUnsafe(READ_BYTES);
  let rows = 0;
  let end = 0;
  let head = '';                                                                        // the start of a line, as much as says what it is
  for (let pos = 0; pos < size;) {
    const n = readAt(fd, buf, Math.min(READ_BYTES, size - pos), pos);
    if (n === 0) break;
    for (let start = 0; ;) {
      const nl = buf.subarray(0, n).indexOf(0x0a, start);
      if (nl < 0) { if (head.length < MARK_BYTES) head += buf.toString('latin1', start, Math.min(n, start + MARK_BYTES - head.length)); break; }
      const l = history.parseLine(head + buf.toString('latin1', start, Math.min(nl, start + MARK_BYTES)));
      if (l && l.kind === 'row') rows += 1;
      else if (l && l.kind === 'lost') rows += l.rows;
      head = '';
      end = pos + nl + 1;
      start = nl + 1;
    }
    pos += n;
  }
  return { rows, end };
}

/**
 * The rows of one file, numbered from its first.
 * @param {{file: string, first: number}} f @param {number} from @param {number} to @param {(row: string, number: number, continues: boolean) => void} visit
 */
async function scanFile({ file, first }, from, to, visit) {
  const handle = await fs.promises.open(file, 'r');
  try {
    const buf = Buffer.allocUnsafe(READ_BYTES);
    const decoder = new StringDecoder('utf8');
    let number = first;
    let rest = '';
    for (;;) {
      const { bytesRead } = await handle.read(buf, 0, READ_BYTES, null);
      if (bytesRead === 0) return;
      const lines = `${rest}${decoder.write(buf.subarray(0, bytesRead))}`.split('\n');
      rest = /** @type {string} */ (lines.pop());
      for (const line of lines) {
        const l = history.parseLine(line);
        if (!l) continue;
        if (l.kind === 'lost') { number += l.rows; continue; }
        if (l.kind !== 'row') continue;
        if (number >= to) return;
        if (number >= from) visit(l.text, number, l.continues);
        number += 1;
      }
    }
  } finally {
    await handle.close();
  }
}

module.exports = { Spool, plain: history.plain };
