'use strict';
// @ts-check
/**
 * Attach client.
 *
 * Byte transparency: OUTPUT frames are written to the terminal unchanged. Node's raw mode (libuv
 * UV_TTY_MODE_RAW) keeps OPOST|ONLCR on, so a bare LF would become CRLF — harmless here, because every
 * byte the child writes already passed ONLCR on the holder's pty (an existing CRLF becomes CR CR LF, which
 * renders identically).
 *
 * Native scrollback is the product. This client therefore NEVER writes RIS (ESC c), ED2 (CSI 2J),
 * ED3 (CSI 3J) or ED0 (CSI J): each of those wipes or truncates the user's history in some terminal. The
 * detach teardown only resets modes, moves to the last row and prints one dim line.
 *
 * Keys go through the KeyTable first, so a detach works even while the host is hung; everything else is sent as
 * INPUT and filtered authoritatively by the server.
 *
 * Overlays (help, who is attached) live on the alternate screen, so leaving one restores the main screen exactly and
 * nothing can reach scrollback. Output arriving meanwhile is held. If there is too much of it, or the session is on the
 * alternate screen itself so the overlay has drawn over it, the server redraws instead, and whatever was already on the
 * way is ignored until it starts: RESYNC_BEGIN marks the place in the stream.
 */
const fs = require('node:fs');
const { InputTokenizer } = require('../vt/inputtok.js');
const { realClock } = require('../base/clock.js');
const { nameOfState } = require('../wire/holder-wire.js');
const platform = require('../platform/index.js');
const { KeyTable } = require('./keytable.js');
const { ReconnectPolicy, RejoinPolicy } = require('./reconnect.js');
const { SessionLink } = require('./link.js');
const { TerminalDriver, KittyTracker, detachBytes, parseCpr } = require('./terminal.js');
const { queryTermColors, COLOR_REPLY_RE } = require('./termcolors.js');
const { DEFAULT_TEXT, hhmm } = require('./text.js');

const SILENCE_MS = 15000;
const SILENCE_CHECK_MS = 1000;
const PENDING_INPUT_CAP = 65536;
const OVERLAY_HOLD_CAP = 1048576;
const REDRAW_WAIT_MS = 3000;
/** Whether input is a terminal's whole answer to OSC 10 or 11, and not something typed. @param {Buffer} bytes */
const isColorReply = (bytes) => bytes[0] === 0x1b && bytes[1] === 0x5d && bytes.toString('latin1').replace(COLOR_REPLY_RE, '') === '';

/** XTWINOPS: the terminal's title stack. A terminal without one ignores both. */
const TITLE_SAVE = '\x1b[22;2t';
const TITLE_RESTORE = '\x1b[23;2t';
/** Set by terminals to say which window this is, which a tty's number alone cannot: those get reused. */
const WINDOW_IDS = ['KITTY_WINDOW_ID', 'WEZTERM_PANE', 'ALACRITTY_WINDOW_ID', 'ITERM_SESSION_ID', 'TERM_SESSION_ID', 'WT_SESSION', 'TMUX_PANE'];

/**
 * Says which terminal this is, so that coming back to it is known to be coming back: what is already in its scrollback need not
 * be sent again. Null when that cannot be told, because a line repeated is better than a line missing.
 * @param {Record<string, string|undefined>} env @param {string|null} tty @returns {string|null}
 */
function terminalIdentity(env, tty) {
  if (!tty) return null;
  try { return [tty, fs.statSync(tty).ctimeMs, ...WINDOW_IDS.map((k) => env[k] || '')].join('|'); } catch { return null; }
}

/** @param {Record<string, string|undefined>} env @param {string|null} ttyPath */
function labelFor(env, ttyPath) {
  const m = /^\/dev\/(pts\/\d+)$/.exec(ttyPath || '');
  const short = m ? m[1] : (ttyPath ? ttyPath.replace(/^\/dev\//, '') : 'tty');
  return `${env.TERM_PROGRAM === 'vscode' ? 'vscode' : 'ssh'} ${short}`;
}

/** Refusal conditions checked before anything else. @param {{stdin: any, stdout: any, env: Record<string, string|undefined>}} io
 *  @param {import('./text.js').ClientText} [text]
 *  @returns {{code: number, message: string}|null} */
function attachPrecheck({ stdin, stdout, env }, text = DEFAULT_TEXT) {
  if (!stdin.isTTY || !stdout.isTTY) return { code: 2, message: `${text.brand}: attach needs an interactive terminal (stdin and stdout must both be a TTY)` };
  const nested = env[text.nestEnv];
  if (nested) return { code: 2, message: text.refuseNested(nested) };
  return null;
}

class AttachClient {
  /**
   * @param {{sockPath: string, name: string, flags: {shrink?: boolean, allowSetup?: boolean, view?: boolean, full?: boolean}, io: {stdin: any, stdout: any, stderr: any, env: Record<string, string|undefined>}, config: any, text?: import('./text.js').ClientText, keys?: import('./keytable.js').KeySpec,
   *   actions?: Record<string, (take: () => boolean) => Promise<unknown>>}} o
   *   actions: what a key can run with the terminal lent to it, such as `history`, which shows the session's history in a pager. It is
   *   given `take`, to call just before it needs the terminal: false means this terminal has gone meanwhile, and it must not
   */
  constructor({ sockPath, name, flags, io, config, text = DEFAULT_TEXT, keys = {}, actions = {} }) {
    this.name = name; this.flags = flags; this.io = io; this.config = config; this.text = text;
    this.actions = actions;
    /** settles when whatever has the terminal gives it back @type {Promise<void>|null} */ this.lending = null;
    /** what a key asked to run, once the server has let this terminal go @type {((take: () => boolean) => Promise<unknown>)|null} */ this.lendRun = null;
    this.phase = 'init'; // init | measuring | connecting | joining | live | lending | lent | refused | reconnecting | done
    /** @type {any} */ this.lendTimer = null;
    /** the next join is to a terminal still showing the screen it left, so that screen is written over rather than drawn below */
    this.sameScreen = false;
    /** @type {Buffer[]} */ this.pendingInput = [];
    this.pendingBytes = 0;
    /** output from this connection that reached the terminal */
    this.received = 0;
    this.others = 0;
    this.joinedOnce = false;
    /** @type {any[]} */ this.notices = [];
    /** how far the last server said this terminal had got @type {object|null} */ this.resume = null;
    /** what takes back what the server drew into this terminal's empty cells @type {{undo: string}|null} */ this.painted = null;
    /** the terminal's own colours, which a tint is worked out from @type {{fg: string|null, bg: string|null}} */ this.colors = { fg: null, bg: null };
    this.rejoin = new RejoinPolicy({ max: config.clients.rejoinMax, windowMs: config.clients.rejoinWindowMs });
    this.reconnect = new ReconnectPolicy();
    this.keySpec = keys;
    this.keys = new KeyTable(keys);
    /** @type {any[]} */ this.attached = [];
    /** @type {null|{held: Buffer[], bytes: number, overAlt: boolean, skipped: number}} */ this.overlay = null;
    this.awaitingRedraw = false;
    this.tokenizer = new InputTokenizer({ clock: realClock, escFlushMs: config.input.escFlushMs, pasteIdleCloseMs: config.input.pasteIdleCloseMs, onTimerTokens: (toks) => this.onTokens(toks) });
    this.link = new SessionLink({ sockPath, onControl: (msg) => this.onControl(msg), onOutput: (b) => this.onOutput(b), onLost: () => this.onSocketLost() });
    this.terminal = new TerminalDriver({ io, onBytes: (b) => this.onTokens(this.tokenizer.feed(b)),
      onEnd: () => this.detach('detached'), onWinch: () => this.onResize(), onHangup: () => this.detach('detached') });
    /** @type {any} */ this.reconnectTimer = null;
    /** @type {any} */ this.redrawTimer = null;
    /** @type {any} */ this.silenceTimer = null;
    this.silenceMs = SILENCE_MS;
    this.lastSilenceCheck = realClock.now();
    this.lastRefusedSize = '';
    this.titleSaved = false;
    /** @type {(code: number) => void} */ this.resolveExit = () => {};
  }

  /** @returns {Promise<number>} */
  run() {
    return new Promise((resolve) => {
      this.resolveExit = resolve;
      const { env } = this.io;
      if (env.TMUX || env.STY) this.io.stderr.write(this.text.insideMultiplexer);
      /** @type {Buffer[]} what was typed while the terminal was asked its colours, which is the session's */
      const typed = [];
      queryTermColors(this.io, undefined, { onTyped: (b) => typed.push(b) }).then((colors) => {
        this.colors = colors;
        this.terminal.open();
        this.silenceTimer = setInterval(() => this.checkSilence(), SILENCE_CHECK_MS);
        this.phase = 'measuring';
        for (const b of typed) this.onTokens(this.tokenizer.feed(b));
        return this.terminal.measureCursor();
      }).then((row) => this.connect(row));
    });
  }

  /** Local detach check, then forward. @param {Array<{kind: string, bytes: Buffer, seq: string}>} toks */
  onTokens(toks) {
    if (this.phase === 'done') return;
    if (this.overlay) { if (toks.length) this.closeOverlay(); return; }
    if (this.phase === 'lending' || this.phase === 'lent') {                           // only leaving counts until the terminal is lent
      if (toks.some((tok) => this.keys.actionFor(tok) === 'detach')) this.finish(0, 'detached', null);
      return;
    }
    /** @type {Buffer[]} */
    const forward = [];
    for (const tok of toks) {
      if (this.phase === 'refused' && this.keys.isInterrupt(tok)) {
        this.finish(1, 'gave-up', 'gave up waiting for a larger terminal');
        return;
      }
      if (isColorReply(tok.bytes)) continue;                                          // a terminal that answered after it was given up on
      const action = this.keys.actionFor(tok);
      if (action === 'ignore') continue;
      if (action === null || action === 'literal') { forward.push(tok.bytes); continue; }
      if (forward.length) this.sendInput(Buffer.concat(forward));
      forward.length = 0;
      this.keyAction(action);
      if (this.phase === 'done' || this.overlay) return;
    }
    if (forward.length) this.sendInput(Buffer.concat(forward));
  }

  /** @param {string} action */
  keyAction(action) {
    if (action === 'detach') this.detach('detached');
    else if (action === 'help') this.openOverlay(this.text.help({ name: this.name, keys: this.keySpec }));
    else if (action === 'clients') this.openOverlay(this.text.whoIsAttached({ name: this.name, clients: this.attached }));
    else if (this.actions[action]) this.lend(this.actions[action]);
  }

  /**
   * Hands the terminal to `run`, such as a pager on the session's history, the way a window detaches and comes back. The server is told
   * this terminal is leaving, everything it sent before saying goodbye is shown, so it knows exactly how far this terminal got, and
   * `run` has the terminal on its alternate screen with the program's modes off. Then this terminal joins again, and gets what the
   * session printed meanwhile, with a line saying so, as a window that comes back does. Nothing waits for the server in between.
   * @param {(take: () => boolean) => Promise<unknown>} run
   */
  lend(run) {
    if (this.phase !== 'live' || this.overlay) return;
    this.takeBackPaint();
    this.phase = 'lending';
    this.lendRun = run;
    this.link.sendControl({ t: 'DETACH', received: this.received, drain: true });       // its BYE comes after what it has sent
    this.lendTimer = setTimeout(() => { if (this.phase === 'lending') { this.link.drop(); this.lent(); } }, REDRAW_WAIT_MS);   // a server that never says goodbye
  }

  /** The server has let this terminal go: `run` has it, once it asks for it. */
  async lent() {
    const run = /** @type {(take: () => boolean) => Promise<unknown>} */ (this.lendRun);
    this.lendRun = null;
    clearTimeout(this.lendTimer);
    this.phase = 'lent';
    let handed = false;
    /** @type {() => void} */
    let given = () => {};
    const take = () => {
      if (this.phase !== 'lent') return false;
      handed = true;
      this.lending = new Promise((resolve) => { given = resolve; });
      this.terminal.lend();
      return true;
    };
    try { await run(take); } catch { /* it said why on the terminal, and the join draws the screen again */ }
    if (handed) {
      this.terminal.takeBack();
      this.lending = null;
      given();                                                                          // what waited for the terminal goes after this
    }
    if (this.phase !== 'lent') return;                                                  // it left meanwhile
    this.phase = 'measuring';
    this.sameScreen = true;                                                             // the pager drew on the other screen
    this.connect(await this.terminal.measureCursor());
  }

  /** What the server drew into empty cells goes, before anything else is written over or under it. */
  takeBackPaint() {
    if (this.painted === null) return;
    this.terminal.write(this.painted.undo);
    this.painted = null;
  }

  /** Drawn only into a terminal the size it was worked out for: one that has changed since has moved its cells. @param {{bytes: string, undo: string, cols: number, rows: number}} m */
  paint(m) {
    if (this.phase !== 'live' || this.overlay || this.awaitingRedraw || typeof m.bytes !== 'string' || typeof m.undo !== 'string') return;
    if (m.cols !== this.terminal.cols || m.rows !== this.terminal.rows) return;
    this.takeBackPaint();
    this.terminal.write(m.bytes);
    this.painted = { undo: m.undo };
  }

  /** @param {string[]} lines */
  openOverlay(lines) {
    if (this.phase !== 'live') return;
    this.takeBackPaint();
    this.overlay = { held: [], bytes: 0, overAlt: this.terminal.alt, skipped: 0 };
    this.terminal.write(`\x1b[?1049h\x1b[H\x1b[2J${lines.join('\r\n')}`);
  }

  closeOverlay() {
    const o = this.overlay;
    this.overlay = null;
    if (!o) return;
    this.terminal.leaveOverlay();
    if (!o.overAlt && o.skipped === 0) { for (const b of o.held) this.show(b); return; }
    this.awaitingRedraw = true;
    this.redrawTimer = setTimeout(() => this.redrawArrived(), REDRAW_WAIT_MS);         // a server that never answers must not silence this terminal
    this.link.sendControl({ t: 'RESYNC', alt: false, skipped: o.skipped });
  }

  redrawArrived() {
    this.awaitingRedraw = false;
    clearTimeout(this.redrawTimer);
  }

  restoreTitle() {
    if (this.titleSaved) { this.titleSaved = false; this.terminal.write(TITLE_RESTORE); }
  }

  /** @param {Buffer} bytes */
  show(bytes) {
    this.takeBackPaint();
    this.received += bytes.length;
    this.terminal.output(bytes);
  }

  /** @param {Buffer} bytes */
  onOutput(bytes) {
    if (this.awaitingRedraw) return;
    const o = this.overlay;
    if (!o) { this.show(bytes); return; }
    if (o.overAlt) return;                                                             // redrawn on the way out
    o.bytes += bytes.length;
    if (o.bytes <= OVERLAY_HOLD_CAP) { o.held.push(bytes); return; }
    o.held = [];
    o.skipped = o.bytes;
  }

  /** @param {Buffer} bytes */
  sendInput(bytes) {
    if (this.phase === 'live' && this.link.connected) this.link.sendInput(bytes);
    else if ((this.phase === 'measuring' || this.phase === 'connecting' || this.phase === 'joining') && this.pendingBytes + bytes.length <= PENDING_INPUT_CAP) {
      this.pendingInput.push(bytes); // typed while a join is on its way: delivered after SNAPSHOT_END
      this.pendingBytes += bytes.length;
    }
    // while disconnected or refused, input is dropped: never replay a stale draft into a fresh join
  }

  /** @param {number|null} cursorRow */
  connect(cursorRow) {
    if (this.phase === 'done') return;
    this.phase = 'connecting';
    const { env } = this.io;
    let tty = null;
    try { tty = platform.selfTty(); } catch { /* no controlling terminal */ }
    this.link.connect(() => ({
      cols: this.terminal.cols, rows: this.terminal.rows, cursorRow: cursorRow === null ? this.terminal.rows : cursorRow, focus: true, tty, pid: process.pid,
      label: labelFor(env, tty), termProgram: env.TERM_PROGRAM || null, terminal: this.flags.full ? null : terminalIdentity(env, tty), agent: env.SSH_AUTH_SOCK || null, resume: this.resume,
      colors: this.colors,
      flags: { shrink: !!this.flags.shrink, allowGated: !!this.flags.allowSetup, allowSetup: !!this.flags.allowSetup, view: !!this.flags.view, paint: true,
        ...(this.sameScreen ? { sameScreen: true } : {}) },
    }));
  }

  /** @param {any} msg */
  onControl(msg) {
    switch (msg.t) {
      case 'WELCOME':
        this.phase = 'joining';
        this.received = 0;
        if (msg.name) this.name = msg.name;
        // host silence limit: never shorter than 3 host ping intervals (clients.pingMs is configurable up to 60 s)
        this.silenceMs = Math.max(SILENCE_MS, 3 * ((msg.ping && msg.ping.intervalMs) || 0));
        break;
      case 'REFUSE':
        if (msg.code === 'BELOW_FLOOR' || msg.code === 'TOO_SHORT') this.onRefusedSize(msg.code, msg.need || {});
        else this.finish(1, 'gave-up', msg.text || `refused: ${msg.code}`);
        break;
      case 'RESYNC_BEGIN':
        this.redrawArrived();
        break;
      case 'SNAPSHOT_BEGIN':
        this.phase = 'joining';
        this.redrawArrived();
        this.joinedOnce = true;
        this.sameScreen = false;
        this.restoreTitle();                                                          // before the join: it may set a newer one
        break;
      case 'SNAPSHOT_END':
        this.phase = 'live';
        this.resume = null;
        this.reconnect.reset();
        this.rejoin.onSnapshotEnd();
        if (this.pendingInput.length) this.link.sendInput(Buffer.concat(this.pendingInput));
        this.pendingInput = [];
        this.pendingBytes = 0;
        break;
      case 'STATE': {
        if (Array.isArray(msg.clients)) { this.attached = msg.clients; this.others = Math.max(0, msg.clients.length - 1); }
        const name = nameOfState(msg);
        if (name) this.name = name;
        break;
      }
      case 'NOTICE':
        if (this.notices.length < 50) this.notices.push(msg);
        break;
      case 'PING':
        this.link.sendControl({ t: 'PONG', seq: msg.seq });
        break;
      case 'BYE':
        this.onBye(msg);
        break;
      case 'PAINT':
        this.paint(msg);
        break;
      case 'ERR':
        this.finish(1, 'gave-up', `host error ${msg.code || ''}`.trim());
        break;
      default:
        break; // unknown control types are ignored for forward compatibility
    }
  }

  /** @param {any} msg */
  onBye(msg) {
    const reason = String(msg.reason || '');
    this.link.drop();
    if (this.phase === 'lending') { this.lent(); return; }
    if (reason === 'CLIENT_EXIT') { this.finish(0, 'client-exit', null, msg.text || null); return; }
    if (reason === 'KICKED') { this.finish(0, 'kicked', typeof msg.by === 'string' && msg.by ? msg.by : null); return; }
    if (reason === 'BELOW_FLOOR') {
      this.restoreModes();
      this.onRefusedSize('BELOW_FLOOR', msg.need || { cols: this.config.size.floorCols, rows: this.config.size.floorRows });
      return;
    }
    if (reason === 'OVERFLOW') {
      if (this.rejoin.allowOverflow()) { this.scheduleReconnect(true); return; }
      this.finish(1, 'gave-up', `this terminal fell behind ${this.rejoin.max} times in ${Math.round(this.rejoin.windowMs / 60000)} minutes`);
      return;
    }
    if (reason === 'SNAPSHOT_TIMEOUT') {
      if (this.rejoin.allowSnapshotTimeout()) { this.scheduleReconnect(true); return; }
      this.finish(1, 'gave-up', `the join snapshot timed out ${this.rejoin.snapshotTimeoutMax} times in a row`);
      return;
    }
    if (msg.autoRejoin) {
      this.resume = this.overlay || this.awaitingRedraw ? null : msg.resume || null;  // what it held back goes, and only a join makes up for that
      this.scheduleReconnect(false);
      return;
    }
    if ('ended' in msg) { this.finish(0, 'ended', msg.ended === 0 ? null : (typeof msg.ended === 'number' ? `exit ${msg.ended}` : msg.ended), msg.text || null); return; }
    this.finish(0, 'ended', reason ? reason.toLowerCase().replace(/_/g, ' ') : null, msg.text || null);
  }

  /** @param {string} code @param {{cols?: number, rows?: number}} need */
  onRefusedSize(code, need) {
    this.link.drop();
    this.phase = 'refused';
    this.restoreTitle();
    if (this.joinedOnce) { this.pendingInput = []; this.pendingBytes = 0; }           // it may be a long time before this joins
    const { cols, rows } = this.terminal;
    const size = `${cols}x${rows}`;
    if (!this.lastRefusedSize) {
      this.terminal.write(this.text.floorMessage({ code, cols, rows, need: { cols: need.cols || this.config.size.floorCols, rows: need.rows || this.config.size.floorRows }, name: this.name, shrink: !!this.flags.shrink, hardMinCols: this.config.size.hardMinCols }));
    } else if (size !== this.lastRefusedSize) {
      this.terminal.write(`${this.text.brand}: now ${size} — still too small; waiting\r\n`);
    }
    this.lastRefusedSize = size;
  }

  onResize() {
    if (this.phase === 'refused') { this.connect(this.terminal.rows); return; }
    if (this.painted !== null) {                                                     // the terminal moved it with the text, to where nobody knows:
      this.painted = null;                                                           // the server writes the screen over once things are quiet
      this.link.sendControl({ t: 'REDRAW' });
    }
    if (this.phase === 'joining' || this.phase === 'live') this.link.sendControl({ t: 'RESIZE', cols: this.terminal.cols, rows: this.terminal.rows });
  }

  onSocketLost() {
    if (this.phase === 'lending') { this.lent(); return; }                              // it comes back as a terminal not seen before
    if (this.phase === 'done' || this.phase === 'refused' || this.phase === 'lent') return;
    this.scheduleReconnect(false);
  }

  /** @param {boolean} immediate */
  scheduleReconnect(immediate) {
    if (this.phase === 'done') return;
    const delay = this.reconnect.next(immediate);
    if (delay === null) { this.finish(1, 'lost', null); return; }
    if (this.joinedOnce) { this.pendingInput = []; this.pendingBytes = 0; }           // typed into a connection that did not last
    this.sameScreen = false;
    this.takeBackPaint();
    if (this.overlay) { this.overlay = null; this.terminal.leaveOverlay(); }           // the join redraws everything
    this.phase = 'reconnecting';
    if (!this.titleSaved) { this.titleSaved = true; this.terminal.write(TITLE_SAVE); }
    this.terminal.write(`\x1b]0;${this.text.brand}: reconnecting…\x07`);
    clearTimeout(this.reconnectTimer);
    // A rejoin pushes the whole visible screen into scrollback (cursorRow = rows) before the snapshot.
    this.reconnectTimer = setTimeout(() => this.connect(this.terminal.rows), delay);
  }

  checkSilence() {
    const now = realClock.now();
    const late = now - this.lastSilenceCheck > 3 * SILENCE_CHECK_MS;
    this.lastSilenceCheck = now;
    if (late) { this.link.heard(); return; }                                        // this process was the one not running
    if (this.link.connected && (this.phase === 'joining' || this.phase === 'live') && this.link.silentMs > this.silenceMs) {
      this.link.drop();
      this.scheduleReconnect(false);
    }
  }

  restoreModes() { if (this.joinedOnce) this.terminal.restore(); }

  /** User-initiated detach (key, SIGHUP, SIGTERM, stdin EOF). @param {'detached'} kind */
  detach(kind) {
    if (this.phase === 'done') return;
    try { this.link.sendControl({ t: 'DETACH', received: this.received }); } catch { /* ignore */ }
    this.finish(0, kind, null);
  }

  /**
   * @param {number} code
   * @param {'detached'|'client-exit'|'kicked'|'ended'|'lost'|'gave-up'} kind
   * @param {string|null} reason
   * @param {string|null} [text]
   */
  finish(code, kind, reason, text = null) {
    if (this.phase === 'done') return;
    if (this.lending) { this.lending.then(() => this.finish(code, kind, reason, text)); return; }   // the pager stays until it is quit
    const wasRefused = this.phase === 'refused';
    if (!wasRefused) this.takeBackPaint();
    this.phase = 'done';
    if (this.overlay) { this.overlay = null; this.terminal.leaveOverlay(); }
    this.restoreTitle();
    clearTimeout(this.reconnectTimer);
    clearInterval(this.silenceTimer);
    this.redrawArrived();
    this.terminal.finishMeasure(null);
    this.link.drop();
    if (this.joinedOnce && !wasRefused) this.restoreModes();
    else this.terminal.write('\r\n');
    this.terminal.write(this.text.detachLine({ kind, name: this.name, others: this.others, at: new Date(), reason: reason || undefined }));
    if (text) this.terminal.write(`${String(text).replace(/\r?\n/g, '\r\n')}\r\n`);
    let lastCode = '';
    for (const n of this.notices) {
      if (n.code === lastCode) continue;
      lastCode = n.code;
      this.terminal.write(`${this.text.brand}: ${n.level === 'warn' ? 'warning' : 'note'} ${n.code}: ${n.text}\r\n`);
    }
    this.terminal.close();
    this.tokenizer.close();
    this.resolveExit(code);
  }
}

/**
 * @param {{sockPath: string, name: string, config: any, flags?: {shrink?: boolean, allowSetup?: boolean, view?: boolean, full?: boolean}, text?: import('./text.js').ClientText,
 *          keys?: import('./keytable.js').KeySpec, io?: {stdin?: any, stdout?: any, stderr?: any, env?: Record<string, string|undefined>},
 *          actions?: Record<string, (take: () => boolean) => Promise<unknown>>}} a
 * @returns {Promise<number>}
 */
async function attach({ sockPath, name, config, flags = {}, text = DEFAULT_TEXT, keys = {}, io = {}, actions = {} }) {
  const full = { stdin: io.stdin || process.stdin, stdout: io.stdout || process.stdout, stderr: io.stderr || process.stderr, env: io.env || process.env };
  const refused = attachPrecheck(full, text);
  if (refused) { full.stderr.write(`${refused.message}\n`); return refused.code; }
  return new AttachClient({ sockPath, name, flags, io: full, config, text, keys, actions }).run();
}

module.exports = { attach, attachPrecheck, labelFor, parseCpr, detachBytes, hhmm, KittyTracker, RejoinPolicy, AttachClient, DEFAULT_TEXT };
