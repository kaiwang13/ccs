//! The attach client's run loop: everything [`Attach`] does not do itself. It reads the terminal and the session's socket on
//! the reactor, hands the core what happened, and does what it asks: writes to the terminal, raw mode, connections, and
//! lending the terminal to an action such as a pager. Also here, [`ask`]: a question at the terminal, for the picker.

use std::collections::VecDeque;
use std::fs;
use std::io;
use std::os::fd::{AsFd, BorrowedFd};
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};
use std::time::Instant;

use nmux_io::{Conn, Interest, Reactor, ReadEnd, SourceFd, Token, UnixStream};
use nmux_platform::{RawMode, Signal, SignalPipe, inq, is_terminal, self_tty, window_size};
use rustix::event::{PollFd, PollFlags, Timespec};

use crate::attach::{Attach, AttachFlags, Effect, Event, Identity, Options};
use crate::config::Config;
use crate::question::{Question, Step};
use crate::text::Words;

const STDIN: Token = Token(0);
const FIRST_CONN: usize = 1;
const READ_BYTES: usize = 65_536;
/// Set by terminals to say which window this is, which a tty's number alone cannot: those get reused.
const WINDOW_IDS: [&str; 7] = [
    "KITTY_WINDOW_ID",
    "WEZTERM_PANE",
    "ALACRITTY_WINDOW_ID",
    "ITERM_SESSION_ID",
    "TERM_SESSION_ID",
    "WT_SESSION",
    "TMUX_PANE",
];

/// The environment, as the client reads it.
pub type Env = std::collections::HashMap<String, String>;

/// What a key can run with the terminal lent to it: the action's name, and `take`, to call just before it needs the
/// terminal. `take` says false when this terminal has gone meanwhile, and then it must not use it.
pub type Actions<'a> = dyn FnMut(&str, &mut dyn FnMut() -> bool) + 'a;

/// What a terminal is called in lists of clients: `ssh pts/3`, `vscode pts/3`.
pub fn label_for(env: &Env, tty: Option<&str>) -> String {
    let short = match tty {
        Some(t)
            if t.strip_prefix("/dev/pts/").is_some_and(|n| !n.is_empty() && n.bytes().all(|b| b.is_ascii_digit())) =>
        {
            t["/dev/".len()..].to_owned()
        }
        Some(t) => t.strip_prefix("/dev/").unwrap_or(t).to_owned(),
        None => "tty".to_owned(),
    };
    let program = if env.get("TERM_PROGRAM").is_some_and(|p| p == "vscode") { "vscode" } else { "ssh" };
    format!("{program} {short}")
}

/// Says which terminal this is, so that coming back to it is known to be coming back: what is already in its scrollback
/// need not be sent again. None when that cannot be told, because a line repeated is better than a line missing.
pub fn terminal_identity(env: &Env, tty: Option<&str>) -> Option<String> {
    let tty = tty?;
    let meta = fs::metadata(tty).ok()?;
    // `ctimeMs`, as Node works it out and writes it.
    #[allow(clippy::cast_precision_loss)] // as JavaScript holds it, in a double
    let ctime_ms = meta.ctime() as f64 * 1000.0 + meta.ctime_nsec() as f64 / 1_000_000.0;
    let mut parts = vec![tty.to_owned(), format!("{ctime_ms}")];
    parts.extend(WINDOW_IDS.iter().map(|k| env.get(*k).cloned().unwrap_or_default()));
    Some(parts.join("|"))
}

/// Why a terminal cannot attach, checked before anything else: its exit code and what to say, in `words`.
pub fn attach_precheck(stdin_tty: bool, stdout_tty: bool, env: &Env, words: &Words) -> Option<(i32, String)> {
    words.precheck(stdin_tty, stdout_tty, env.get(&words.nest_env).map(String::as_str))
}

/// What attaching needs.
#[derive(Debug)]
pub struct Attaching<'a> {
    /// The session's socket.
    pub sock: &'a Path,
    /// Its name.
    pub name: &'a str,
    /// The configuration.
    pub config: &'a Config,
    /// See [`AttachFlags`].
    pub flags: AttachFlags,
    /// The environment.
    pub env: &'a Env,
    /// The actions there are, by name.
    pub actions: Vec<String>,
    /// What it says.
    pub words: &'a Words,
}

/// Attaches this terminal to a session, until it detaches or the session ends. The exit code.
pub fn attach(a: &Attaching<'_>, actions: &mut Actions<'_>) -> i32 {
    let (stdin, stdout) = (io::stdin(), io::stdout());
    if let Some((code, message)) =
        attach_precheck(is_terminal(stdin.as_fd()), is_terminal(stdout.as_fd()), a.env, a.words)
    {
        eprintln!("{message}");
        return code;
    }
    if a.env.contains_key("TMUX") || a.env.contains_key("STY") {
        eprint!("{}", a.words.inside_multiplexer);
    }
    match Loop::new(a) {
        Ok(mut l) => l.run(actions),
        Err(e) => {
            eprintln!("{}: {e}", a.words.brand);
            1
        }
    }
}

/// Asks `prompt` at this terminal, whose output is one, and reads the answer as the Node command's readline does: raw mode
/// meanwhile, the line edited by [`Question`], drawn again when the terminal's size changes, and a stop at ^Z. `dumb` is a
/// TERM of `dumb`. None when the person gave up, with ^C or ^D, or the terminal went.
pub fn ask(prompt: &str, dumb: bool) -> io::Result<Option<String>> {
    let raw = RawMode::enter(stdin_fd())?;
    let mut signals = SignalPipe::install(&[Signal::Winch])?;
    let columns = || window_size(stdout_fd()).map_or(0, |(columns, _)| columns);
    let mut question = Question::new(prompt);
    let mut out = String::new();
    question.ask(columns(), dumb, &mut out);
    let mut buf = [0u8; 4096];
    let mut caught = Vec::new();
    loop {
        if !write_terminal(out.as_bytes()) {
            return Ok(None);
        }
        out.clear();
        let wait = question.escape_deadline().map(|at| {
            let left = at.saturating_duration_since(Instant::now());
            Timespec { tv_sec: i64::try_from(left.as_secs()).unwrap_or(i64::MAX), tv_nsec: left.subsec_nanos().into() }
        });
        let (input, signal) = {
            let (stdin, signal_fd) = (stdin_fd(), signals.fd());
            let mut fds = [PollFd::new(&stdin, PollFlags::IN), PollFd::new(&signal_fd, PollFlags::IN)];
            match rustix::event::poll(&mut fds, wait.as_ref()) {
                Ok(_) | Err(rustix::io::Errno::INTR) => {}
                Err(e) => return Err(e.into()),
            }
            (!fds[0].revents().is_empty(), !fds[1].revents().is_empty())
        };
        if signal {
            signals.drain(&mut caught);
            if caught.drain(..).any(|s| s == Signal::Winch) {
                question.redraw(columns(), &mut out);
            }
        }
        if !input {
            question.wait(Instant::now(), &mut out);
            continue;
        }
        let n = match rustix::io::read(stdin_fd(), &mut buf) {
            Ok(0) | Err(rustix::io::Errno::IO | rustix::io::Errno::BADF) => return Ok(None),
            Ok(n) => n,
            Err(_) => continue,
        };
        match question.read(&buf[..n], Instant::now(), columns(), &mut out) {
            Step::Asking => {}
            Step::Answered(line) => return Ok(write_terminal(out.as_bytes()).then_some(line)),
            Step::GaveUp => {
                write_terminal(out.as_bytes());
                return Ok(None);
            }
            Step::Stop => {
                write_terminal(out.as_bytes());
                out.clear();
                raw.restore()?;
                nmux_platform::stop_self()?;
                raw.again()?;
                question.redraw(columns(), &mut out);
            }
        }
    }
}

/// Writes all of `bytes` to the terminal, waiting for it as a terminal is written in Node. False when it has gone.
fn write_terminal(mut bytes: &[u8]) -> bool {
    while !bytes.is_empty() {
        match rustix::io::write(stdout_fd(), bytes) {
            Ok(n) => bytes = &bytes[n..],
            Err(rustix::io::Errno::INTR) => {}
            Err(rustix::io::Errno::AGAIN) => {
                let out = stdout_fd();
                let mut fds = [PollFd::new(&out, PollFlags::OUT)];
                let _ = rustix::event::poll(&mut fds, None);
            }
            Err(_) => return false,
        }
    }
    true
}

/// What the loop has yet to tell the core about a connection, which happened while it was doing what the core asked.
#[derive(Debug)]
enum Later {
    Connected,
    Lost,
}

#[derive(Debug)]
struct Loop<'a> {
    reactor: Reactor,
    core: Attach,
    sock: PathBuf,
    env: &'a Env,
    raw: Option<RawMode>,
    reading: bool,
    conn: Option<Conn>,
    conn_token: usize,
    later: VecDeque<Later>,
    exit: Option<i32>,
    gone: bool,
    buf: Vec<u8>,
    /// What the core asked while the terminal was being handed over, done once the action is.
    held: Vec<Effect>,
}

fn stdin_fd() -> BorrowedFd<'static> {
    rustix::stdio::stdin()
}

fn stdout_fd() -> BorrowedFd<'static> {
    rustix::stdio::stdout()
}

impl<'a> Loop<'a> {
    fn new(a: &Attaching<'a>) -> io::Result<Self> {
        let mut reactor = Reactor::new()?;
        reactor.catch_signals(&[Signal::Winch, Signal::Hup, Signal::Term])?;
        let raw_fd = std::os::fd::AsRawFd::as_raw_fd(&stdin_fd());
        reactor.registry().register(&mut SourceFd(&raw_fd), STDIN, Interest::READABLE)?;
        let (cols, rows) = window_size(stdout_fd()).unwrap_or((0, 0));
        let config = a.config;
        let core = Attach::new(Options {
            name: a.name.to_owned(),
            flags: a.flags,
            keys: config.keys(),
            actions: a.actions.clone(),
            rejoin_max: usize::try_from(config.count("clients", "rejoinMax")).unwrap_or(3),
            rejoin_window_ms: config.count("clients", "rejoinWindowMs"),
            floor_cols: u32::try_from(config.count("size", "floorCols")).unwrap_or(2),
            floor_rows: u32::try_from(config.count("size", "floorRows")).unwrap_or(1),
            hard_min_cols: u32::try_from(config.count("size", "hardMinCols")).unwrap_or(2),
            words: a.words.clone(),
            esc_flush_ms: config.count("input", "escFlushMs"),
            paste_idle_close_ms: config.count("input", "pasteIdleCloseMs"),
            cols: u32::from(cols),
            rows: u32::from(rows),
            zone: nmux_time::zone(a.env.get("TZ").map(String::as_str)),
            bar: config.truthy("overlay", "bar"),
            truecolor: a
                .env
                .get("COLORTERM")
                .is_some_and(|c| c.eq_ignore_ascii_case("truecolor") || c.eq_ignore_ascii_case("24bit")),
            clipboard: config.clipboard(),
        });
        Ok(Self {
            reactor,
            core,
            sock: a.sock.to_owned(),
            env: a.env,
            raw: None,
            reading: false,
            conn: None,
            conn_token: FIRST_CONN,
            later: VecDeque::new(),
            exit: None,
            gone: false,
            buf: vec![0; READ_BYTES],
            held: Vec::new(),
        })
    }

    fn run(&mut self, actions: &mut Actions<'_>) -> i32 {
        let now = self.reactor.now();
        self.core.on_event(Event::Start, now);
        loop {
            self.settle(actions);
            if let Some(code) = self.exit {
                self.raw = None;
                return code;
            }
            let deadline = self.core.next_deadline();
            if self.reactor.wait(deadline).is_err() {
                // The reactor itself failed: there is nothing left to wait with.
                return 1;
            }
            let now = self.reactor.now();
            self.signals(now);
            let ready: Vec<_> = self.reactor.ready().to_vec();
            for r in ready {
                if r.token == STDIN {
                    self.drain_stdin(r.closed || r.error, actions);
                } else if r.token.0 == self.conn_token {
                    self.read_conn(&r);
                }
                self.settle(actions);
            }
            let now = self.reactor.now();
            self.core.on_event(Event::Tick, now);
        }
    }

    fn signals(&mut self, now: nmux_io::Now) {
        for signal in self.reactor.take_signals() {
            match signal {
                Signal::Winch => {
                    let (cols, rows) = window_size(stdout_fd()).unwrap_or((0, 0));
                    self.core.on_event(Event::Resized { cols: u32::from(cols), rows: u32::from(rows) }, now);
                }
                Signal::Hup => self.core.on_event(Event::Hangup, now),
                Signal::Term => self.core.on_event(Event::Terminate, now),
                _ => {}
            }
        }
    }

    /// Does what the core asked, and tells it what came of that, until it asks nothing more.
    fn settle(&mut self, actions: &mut Actions<'_>) {
        loop {
            let mut effects = std::mem::take(&mut self.held);
            effects.extend(self.core.take_effects());
            if effects.is_empty() {
                let Some(later) = self.later.pop_front() else { break };
                let now = self.reactor.now();
                match later {
                    Later::Connected => {
                        let id = self.identity();
                        self.core.on_event(Event::Connected(&id), now);
                    }
                    Later::Lost => self.core.on_event(Event::Lost, now),
                }
                continue;
            }
            for effect in effects {
                self.apply(effect, actions);
            }
        }
        self.flush_conn();
    }

    fn apply(&mut self, effect: Effect, actions: &mut Actions<'_>) {
        match effect {
            Effect::Write(bytes) => self.write(&bytes),
            Effect::Raw(true) => self.raw = RawMode::enter(stdin_fd()).ok(),
            Effect::Raw(false) => self.raw = None,
            Effect::RawAgain => {
                if let Some(raw) = &self.raw {
                    let _ = raw.restore().and_then(|()| raw.again());
                }
            }
            Effect::Reading(on) => {
                self.reading = on;
                if on {
                    // What was typed while nothing read it.
                    self.drain_stdin(false, actions);
                }
            }
            Effect::Connect => self.connect(),
            Effect::Drop(mut last) => self.drop_conn(&mut last),
            Effect::Lend(action) => self.lend(&action, actions),
            Effect::Exit(code) => self.exit = Some(code),
        }
    }

    fn identity(&self) -> Identity {
        let tty = self_tty();
        Identity {
            label: label_for(self.env, tty.as_deref()),
            term_program: self.env.get("TERM_PROGRAM").filter(|p| !p.is_empty()).cloned(),
            terminal: terminal_identity(self.env, tty.as_deref()),
            agent: self.env.get("SSH_AUTH_SOCK").filter(|p| !p.is_empty()).cloned(),
            pid: u32::try_from(nmux_platform::pid()).unwrap_or(0),
            tty,
        }
    }

    // ---- the terminal ------------------------------------------------------------------------------------------------

    /// Writes to the terminal, waiting for it as a terminal is written in Node: a stuck terminal stops this client, which
    /// is how the server sees it has fallen behind. A terminal that has gone takes nothing more.
    fn write(&mut self, bytes: &[u8]) {
        if !self.gone {
            self.gone = !write_terminal(bytes);
        }
    }

    /// Reads one chunk of what the terminal has sent, if there is any and the client is reading. True when there may be more.
    fn read_stdin(&mut self, hung_up: bool) -> bool {
        if !self.reading || self.exit.is_some() {
            return false;
        }
        let waiting = inq(stdin_fd()).unwrap_or(0);
        if waiting == 0 && !hung_up {
            return false;
        }
        let now = self.reactor.now();
        loop {
            match rustix::io::read(stdin_fd(), &mut self.buf) {
                Err(rustix::io::Errno::INTR) => {}
                Ok(n) if n > 0 => {
                    let bytes = self.buf[..n].to_vec();
                    self.core.on_event(Event::Input(&bytes), now);
                    return true;
                }
                // The end, or a terminal that has gone.
                _ => {
                    self.core.on_event(Event::InputEnd, now);
                    return false;
                }
            }
        }
    }

    /// Everything the terminal has sent, a chunk at a time, with what the core asks done after each.
    fn drain_stdin(&mut self, hung_up: bool, actions: &mut Actions<'_>) {
        while self.read_stdin(hung_up) {
            self.settle(actions);
        }
    }

    // ---- the session -------------------------------------------------------------------------------------------------

    fn connect(&mut self) {
        self.close_conn();
        self.conn_token += 1;
        let token = Token(self.conn_token);
        match UnixStream::connect(&self.sock) {
            Ok(stream) => {
                let mut conn = Conn::new(stream);
                if conn.register(self.reactor.registry(), token).is_ok() {
                    self.conn = Some(conn);
                    self.later.push_back(Later::Connected);
                } else {
                    self.later.push_back(Later::Lost);
                }
            }
            Err(_) => self.later.push_back(Later::Lost),
        }
    }

    fn close_conn(&mut self) {
        if let Some(mut conn) = self.conn.take() {
            let _ = conn.deregister(self.reactor.registry());
        }
        // What was on its way about an earlier connection means nothing now.
        self.later.clear();
    }

    /// Writes what was left to send as far as the socket takes it now, and closes the connection.
    fn drop_conn(&mut self, last: &mut nmux_io::OutBuf) {
        if let Some(conn) = &mut self.conn {
            let _ = conn.flush(last);
        }
        self.close_conn();
    }

    fn flush_conn(&mut self) {
        let Some(conn) = &mut self.conn else { return };
        if conn.flush(self.core.out()).is_err() {
            self.close_conn();
            self.later.push_back(Later::Lost);
        }
    }

    fn read_conn(&mut self, ready: &nmux_io::Ready) {
        let Some(conn) = &mut self.conn else { return };
        conn.on_ready(ready);
        let now = self.reactor.now();
        let core = &mut self.core;
        let mut stale = false;
        let end = conn.read(|frame| {
            // Once the core has let this connection go, the rest of what came on it is not its business.
            if !stale && core.connected() {
                core.on_event(Event::Frame(frame), now);
                stale = !core.connected() || core.done();
            }
        });
        match end {
            ReadEnd::Open => {}
            ReadEnd::Closed | ReadEnd::Failed(_) => {
                if !stale && self.core.connected() {
                    self.close_conn();
                    self.core.on_event(Event::Lost, now);
                }
            }
        }
    }

    // ---- lending -----------------------------------------------------------------------------------------------------

    /// Runs an action with the terminal lent to it. Nothing else happens meanwhile: what the terminal and signals say waits
    /// until it is done, as it waited in Node for a pager that had the terminal.
    fn lend(&mut self, action: &str, actions: &mut Actions<'_>) {
        let mut take = || {
            // What came since the action started may mean the terminal is not this client's to lend any more.
            let _ = self.reactor.wait(Some(self.reactor.now().time));
            let now = self.reactor.now();
            self.signals(now);
            self.core.on_event(Event::Take, now);
            for effect in self.core.take_effects() {
                match effect {
                    Effect::Write(bytes) => self.write(&bytes),
                    Effect::Reading(on) => self.reading = on,
                    other => self.held.push(other),
                }
            }
            self.core.handed()
        };
        actions(action, &mut take);
        let now = self.reactor.now();
        self.core.on_event(Event::LendDone, now);
    }
}
