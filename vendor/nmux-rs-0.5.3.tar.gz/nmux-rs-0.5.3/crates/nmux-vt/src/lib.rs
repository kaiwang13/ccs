//! The one parser of nmux: output tokens, input tokens, keys, modes and marks. It has no dependencies and does no I/O.
//!
//! [`Lexer`] turns the child's output into [`Token`]s, which drive both the clients' edits and the emulator, so that output
//! is parsed once. `seq` classifies tokens, [`ModeState`] follows the modes they set, and `marks` reads what a shell says
//! about itself. [`InputTokenizer`] does for client input what the lexer does for output, and `keys` says what each input
//! token is. See `docs/DESIGN.md`.

pub mod inputtok;
pub mod keys;
mod lexer;
pub mod marks;
pub mod modes;
pub mod seq;
mod token;

pub use inputtok::{InputKind, InputToken, InputTokenizer};
pub use lexer::{HOLD_BYTES, Lexer};
pub use modes::{ModeState, RAW_MODES};
pub use token::{Csi, Kind, Param, Params, Token};
