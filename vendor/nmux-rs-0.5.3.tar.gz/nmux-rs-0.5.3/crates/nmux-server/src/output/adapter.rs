//! One client's view of the output, `adapter.js`: rows moved down for a terminal taller than the pty, scroll margins put
//! back after the alternate screen, titles with nmux's notices in front, and the cap on what is queued for it. A client past
//! the cap is never disconnected: output for it stops ([`ClientAdapter::behind`]) until it has been brought up to date.
//! OSC 52 is not passed on yet.
//!
//! It owns what is queued for its connection, which the run loop writes out.

use nmux_io::{OutBuf, Time};
use nmux_wire::{Bye, Control, FrameType, Size};
use serde_json::Value;

use super::pipeline::{Chunk, Edit, EditKind, rewrite_row};
use super::tracker::Tracker;

/// How long a notice stays in front of the title.
pub const NOTICE_TITLE_MS: u64 = 8000;
/// The most output in one frame.
const MAX_OUTPUT_FRAME: usize = 512 * 1024;
/// Output held while a join is sent may run to this many live queues before the join is given up for a redraw.
const JOIN_QUEUE_FACTOR: usize = 4;

/// Where a client is.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Phase {
    /// Being sent the session.
    Joining,
    /// Up to date, and sent output as it comes.
    Live,
    /// Below the size floor: sent nothing.
    Paused,
}

impl Phase {
    /// As STATE says it.
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Joining => "JOINING",
            Self::Live => "LIVE",
            Self::Paused => "PAUSED",
        }
    }
}

/// How a client takes part.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct ClientFlags {
    /// May go below the usual floor.
    pub shrink: bool,
    /// May type through gates.
    pub allow_gated: bool,
    /// Only watches.
    pub view: bool,
}

/// What the words of the adapter are.
#[derive(Clone, Debug)]
pub struct Titles {
    /// What a notice in a title starts with.
    pub brand: String,
    /// What a title starts with while the session asks for a person.
    pub attention: String,
    /// Ring the bell when it starts asking.
    pub bell_on_attention: bool,
}

/// What every client's output is decided with: the session's words, what the output says, and the queue cap.
#[derive(Clone, Copy, Debug)]
pub struct Context<'a> {
    /// See [`Titles`].
    pub titles: &'a Titles,
    /// What the program's output says.
    pub tracker: &'a Tracker,
    /// Past this much queued, a client is skipped ahead rather than queued for.
    pub queue_cap: usize,
}

/// See the module.
#[derive(Debug)]
#[allow(clippy::struct_excessive_bools)] // the client's state, as Node keeps it
pub struct ClientAdapter {
    /// What is queued for the connection.
    pub out: OutBuf,
    /// Its columns.
    pub cols: u32,
    /// Its rows.
    pub rows: u32,
    /// How it takes part.
    pub flags: ClientFlags,
    /// Where it is.
    pub phase: Phase,
    /// It has been let go: nothing more is sent.
    pub closed: bool,
    /// It stopped answering pings.
    pub stalled: bool,
    /// It stopped answering for long.
    pub unresponsive: bool,
    /// The point a join was built at has passed: output from then on is held until it goes live.
    pub armed: bool,
    pending_live: Vec<u8>,
    held_alt: Option<bool>,
    /// Output is being skipped for it until it has been brought up to date.
    pub behind: bool,
    /// Bytes skipped since.
    pub skipped: u64,
    /// The skipped bytes are gone for everyone, not only for this client.
    pub lost: bool,
    /// Output was skipped at some point, so its scrollback has a hole in it.
    pub has_gaps: bool,
    /// Bytes that passed while it was paused in the middle of a join.
    missed: u64,
    /// A redraw is being sent: it is live, and may type.
    pub resyncing: bool,
    /// Its terminal is on the alternate screen, going by what has been sent to it.
    pub alt: bool,
    at_ground: bool,
    attention: bool,
    notice_text: Option<String>,
    /// When the notice in the title ends.
    pub notice_until: Option<Time>,
    title_dirty: bool,
    /// It fell behind since this was last looked at: the hub starts a redraw.
    pub became_behind: bool,
    /// Why it was let go, once it has been: the hub closes it once what is queued has gone.
    pub dropped: Option<String>,
    /// The output it has been sent, in bytes: what it counts as received.
    pub sent_output: u64,
    /// nmux's bar is on the terminal's last row, below the `rows` the session has of it. Its scroll region always ends
    /// above the bar and starts at the top, so what scrolls off the top still goes into the terminal's own scrollback: a
    /// region the program resets or leaves to the terminal's height is stated as that, and every full reset and change of
    /// screen is followed by it.
    pub bar: bool,
    /// Output may have written over its bar since this was last looked at: the hub has it drawn again.
    pub bar_hit: bool,
}

impl ClientAdapter {
    /// A client that has just said hello.
    pub fn new(cols: u32, rows: u32, flags: ClientFlags) -> Self {
        Self {
            out: OutBuf::new(),
            cols,
            rows,
            flags,
            phase: Phase::Joining,
            closed: false,
            stalled: false,
            unresponsive: false,
            armed: false,
            pending_live: Vec::new(),
            held_alt: None,
            behind: false,
            skipped: 0,
            lost: false,
            has_gaps: false,
            missed: 0,
            resyncing: false,
            alt: false,
            at_ground: true,
            attention: false,
            notice_text: None,
            notice_until: None,
            title_dirty: false,
            became_behind: false,
            dropped: None,
            sent_output: 0,
            bar: false,
            bar_hit: false,
        }
    }

    /// The scroll region of the whole of what the session has of this terminal: with a bar below it, a region that says so.
    pub fn full_region(&self) -> String {
        if self.bar { format!("\x1b[1;{}r", self.rows) } else { "\x1b[r".to_owned() }
    }

    fn title_prefix(&self, t: &Titles) -> String {
        match &self.notice_text {
            Some(text) => format!("[{}: {text}] ", t.brand),
            None if self.attention => t.attention.clone(),
            None => String::new(),
        }
    }

    /// The screen the terminal is on once it has everything sent or held for it.
    pub fn last_alt(&self) -> bool {
        self.held_alt.unwrap_or(self.alt)
    }

    /// A chunk of output, as this client is sent it.
    pub fn render(&mut self, chunk: &Chunk, cx: &Context<'_>) {
        if self.closed {
            return;
        }
        if self.phase == Phase::Paused {
            if self.armed {
                self.missed += chunk.bytes.len() as u64;
            }
            return;
        }
        if self.behind {
            self.skipped += chunk.bytes.len() as u64;
            self.at_ground = chunk.ground_after;
            return;
        }
        if self.phase == Phase::Joining && !self.armed {
            return;
        }
        let (t, tracker) = (cx.titles, cx.tracker);
        let mut out: Vec<u8> = Vec::with_capacity(chunk.bytes.len() + 16);
        let mut pos = 0;
        let mut alt = self.last_alt();
        for e in &chunk.edits {
            out.extend_from_slice(&chunk.bytes[pos..e.start]);
            pos = e.end;
            let raw = chunk.raw(e);
            match &e.kind {
                EditKind::Drop(_) | EditKind::Clipboard => {} // queries never reach clients, and OSC 52 is not passed on
                EditKind::Row { form, row, col, render_rows } => {
                    let d = self.rows.saturating_sub(*render_rows); // none for clients no taller than the screen drawn
                    let row = row + d;
                    if d > 0 || (self.bar && row > self.rows) {
                        out.extend(rewrite_row(*form, *col, if self.bar { row.min(self.rows) } else { row }));
                    } else {
                        out.extend_from_slice(raw);
                    }
                }
                EditKind::Margins { .. } => out.extend(self.margins(e, raw)),
                EditKind::Region { .. } => out.extend(self.region(e, raw)),
                EditKind::AltEnter { .. } => {
                    alt = true;
                    out.extend_from_slice(raw);
                    if self.bar {
                        out.extend(format!("\x1b7{}\x1b8", self.full_region()).bytes());
                    }
                }
                EditKind::AltExit => {
                    alt = false;
                    out.extend_from_slice(raw);
                    out.extend(format!("\x1b7{}\x1b8", self.full_region()).bytes()); // drop vim's scroll margins
                }
                EditKind::Title(text) => {
                    out.extend(osc0(&(self.title_prefix(t) + text)));
                    self.title_dirty = false;
                }
                EditKind::Mark { standard, .. } => out.extend_from_slice(standard),
                _ => out.extend_from_slice(raw),
            }
        }
        out.extend_from_slice(&chunk.bytes[pos..]);
        self.at_ground = chunk.ground_after;
        if self.title_dirty && self.at_ground {
            out.extend(osc0(&(self.title_prefix(t) + &tracker.title)));
            self.title_dirty = false;
        }
        self.enqueue(&out, alt, cx.queue_cap);
        if self.bar && chunk.wipes {
            self.bar_hit = true;
        }
    }

    /// A client taller than the pty shows it on its bottom rows, so a scroll region moves down with it, and DECSTBM homes
    /// the cursor, which is not the client's first row. A region as tall as the pty is sent as none: anything else would keep
    /// lines that leave the top out of the terminal's scrollback.
    fn margins(&self, e: &Edit, raw: &[u8]) -> Vec<u8> {
        let EditKind::Margins { top, bottom, render_rows } = e.kind else { return raw.to_vec() };
        let d = self.rows.saturating_sub(render_rows);
        if d == 0 && !self.bar {
            return raw.to_vec();
        }
        let bottom = bottom.unwrap_or(render_rows);
        let region = if top == 1 && bottom >= render_rows {
            self.full_region()
        } else {
            format!("\x1b[{};{}r", top + d, (bottom + d).min(self.rows))
        };
        if d == 0 { region.into_bytes() } else { format!("{region}\x1b[{};1H", d + 1).into_bytes() }
    }

    /// A scroll region nothing moves, or every setting reset: a terminal with a bar keeps its region above it. After a
    /// reset the cursor is where the reset left it, which DECSC and DECRC keep through stating the region.
    fn region(&self, e: &Edit, raw: &[u8]) -> Vec<u8> {
        let EditKind::Region { top, bottom, reset } = e.kind else { return raw.to_vec() };
        if !self.bar {
            return raw.to_vec();
        }
        if reset {
            let mut out = raw.to_vec();
            out.extend(format!("\x1b7{}\x1b8", self.full_region()).bytes());
            return out;
        }
        let bottom = bottom.unwrap_or(self.rows).min(self.rows);
        if top == 1 && bottom == self.rows {
            self.full_region().into_bytes()
        } else {
            format!("\x1b[{top};{bottom}r").into_bytes()
        }
    }

    fn enqueue(&mut self, buf: &[u8], alt: bool, cap: usize) {
        if buf.is_empty() || self.closed {
            return;
        }
        if self.behind {
            self.skipped += buf.len() as u64;
            return;
        }
        if self.phase == Phase::Joining {
            if !self.armed {
                return;
            }
            self.pending_live.extend_from_slice(buf);
            self.held_alt = Some(alt);
            if self.pending_live.len() > cap * JOIN_QUEUE_FACTOR {
                let n = self.pending_live.len() as u64;
                self.pending_live.clear();
                self.held_alt = None;
                self.skip(n, false);
            }
            return;
        }
        if self.out.len() + buf.len() > cap {
            self.skip(buf.len() as u64, false);
            return;
        }
        self.alt = alt;
        self.send_output(buf);
    }

    /// Output, in frames no larger than a terminal can be sent at once.
    pub fn send_output(&mut self, bytes: &[u8]) {
        self.sent_output += bytes.len() as u64;
        for piece in bytes.chunks(MAX_OUTPUT_FRAME) {
            // An OUTPUT frame this size is always within the limits.
            let _ = self.out.frame(FrameType::Output, piece);
        }
    }

    /// A control message. One too large to send is dropped: the client is told nothing rather than something broken.
    pub fn send_control(&mut self, message: &Control) {
        let _ = self.out.control(message);
    }

    /// Stops output for this client until it has been brought up to date. `lost`: the bytes are gone for everyone.
    pub fn skip(&mut self, bytes: u64, lost: bool) {
        self.skipped += bytes;
        self.has_gaps = true;
        self.lost = self.lost || lost;
        if self.behind {
            return;
        }
        self.behind = true;
        self.became_behind = true;
    }

    /// The client grew back while a join for it was still being sent: that join stands, and what passed meanwhile is
    /// made up for.
    pub fn resume_join(&mut self) {
        self.phase = Phase::Joining;
        let missed = std::mem::take(&mut self.missed);
        if missed > 0 {
            self.skip(missed, false);
        }
    }

    /// The point a join is built at: everything rendered from now on is held until it goes live.
    pub fn arm_join(&mut self, tracker: &Tracker) {
        self.pending_live.clear();
        self.armed = true;
        self.at_ground = true;
        self.alt = tracker.alt;
        self.held_alt = None;
        self.missed = 0;
    }

    /// The same point in a redraw, for a client that stays live throughout.
    pub fn arm_resync(&mut self, tracker: &Tracker) {
        self.arm_join(tracker);
        self.behind = false;
        self.skipped = 0;
        self.lost = false;
        self.phase = Phase::Joining;
        self.resyncing = true;
    }

    /// The join has been sent: what was held goes out, and the live queue counts from now.
    pub fn go_live(&mut self) {
        if self.closed {
            return;
        }
        self.armed = false;
        self.resyncing = false;
        let pending = std::mem::take(&mut self.pending_live);
        if self.phase == Phase::Paused {
            return; // it went below the floor meanwhile
        }
        self.phase = Phase::Live;
        if let Some(alt) = self.held_alt.take() {
            self.alt = alt;
        }
        self.send_output(&pending);
    }

    /// Something of nmux's own, written into the terminal between pieces of output, such as a screen written over in place.
    /// Only to a terminal that is live: one being joined or caught up will be drawn from scratch anyway.
    pub fn underneath(&mut self, bytes: &[u8], cap: usize) {
        if self.phase == Phase::Live && !self.behind {
            self.enqueue(bytes, self.last_alt(), cap);
        }
    }

    /// A NOTICE, which the attach client prints after it detaches, and the title saying it for a while. Warnings ring.
    pub fn notice(&mut self, level: &str, code: &str, text: &str, now: Time, cx: &Context<'_>) {
        if self.closed {
            return;
        }
        self.send_control(&Control::Notice { level: level.to_owned(), code: code.to_owned(), text: text.to_owned() });
        self.flash(text, now, cx);
        if level == "warn" {
            self.raw(b"\x07", cx.queue_cap);
        }
    }

    /// The title says this for a few seconds.
    pub fn flash(&mut self, text: &str, now: Time, cx: &Context<'_>) {
        if self.closed {
            return;
        }
        self.notice_text = Some(text.to_owned());
        self.notice_until = Some(now.after(NOTICE_TITLE_MS));
        self.refresh_title(cx);
    }

    /// The notice in the title has had its time.
    pub fn notice_ended(&mut self, cx: &Context<'_>) {
        self.notice_until = None;
        self.notice_text = None;
        self.refresh_title(cx);
    }

    /// The title says so while the session asks for a person, with a bell once when it starts.
    pub fn set_attention(&mut self, attention: bool, cx: &Context<'_>) {
        if attention == self.attention {
            return;
        }
        self.attention = attention;
        if attention && cx.titles.bell_on_attention {
            self.raw(b"\x07", cx.queue_cap);
        }
        self.refresh_title(cx);
    }

    /// A title of nmux's own only goes out between sequences, never inside one.
    fn refresh_title(&mut self, cx: &Context<'_>) {
        self.title_dirty = true;
        if self.at_ground {
            self.title_dirty = false;
            let title = osc0(&(self.title_prefix(cx.titles) + &cx.tracker.title));
            self.raw(&title, cx.queue_cap);
        }
    }

    fn raw(&mut self, buf: &[u8], cap: usize) {
        if self.phase != Phase::Paused {
            self.enqueue(buf, self.last_alt(), cap);
        }
    }

    /// Sends BYE and marks the client to be closed.
    pub fn drop_with(&mut self, reason: &str, auto_rejoin: bool, text: &str, extra: ByeExtra) {
        if self.closed {
            return;
        }
        self.closed = true;
        self.notice_until = None;
        self.pending_live.clear();
        let bye = Bye {
            reason: reason.to_owned(),
            auto_rejoin,
            text: text.to_owned(),
            by: extra.by,
            need: extra.need,
            ended: extra.ended,
            resume: extra.resume,
            extra: serde_json::Map::new(),
        };
        self.send_control(&Control::Bye(bye));
        self.dropped = Some(reason.to_owned());
    }

    /// A new size.
    pub fn set_size(&mut self, cols: u32, rows: u32) {
        self.cols = cols;
        self.rows = rows;
    }
}

/// What a BYE says beyond its reason.
#[derive(Clone, Debug, Default)]
pub struct ByeExtra {
    /// Who sent it away.
    pub by: Option<String>,
    /// The size it needs.
    pub need: Option<Size>,
    /// How the child ended.
    pub ended: Option<Value>,
    /// Where it had got, for the next server.
    pub resume: Option<Value>,
}

fn osc0(title: &str) -> Vec<u8> {
    format!("\x1b]0;{title}\x07").into_bytes()
}
