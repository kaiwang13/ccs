//! What the whole session knows from the program's output: which screen it is on, its modes, its title and pen, and the
//! sizes the pty has had, applied at the offsets they took effect. `tracker.js`.

use nmux_vt::ModeState;

/// Sequences that damage a client's own scrollback, and repaints that did not add up: counted, for `nmux status`.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, serde::Serialize)]
#[serde(rename_all = "camelCase")]
#[allow(clippy::struct_field_names)] // the Node names
pub struct Census {
    /// Absolute row positioning on the main screen.
    pub absolute: u64,
    /// `CSI 2 J`
    pub ed2: u64,
    /// `CSI 3 J`
    pub ed3: u64,
    /// `ESC c`
    pub ris: u64,
    /// `CSI top ; bottom r`
    pub decstbm: u64,
    /// `CSI S`
    pub su: u64,
    /// `CSI T`
    pub sd: u64,
    /// The alternate screen entered with 47 or 1047.
    pub alt47: u64,
    /// `CSI H` that did not start a repaint.
    pub bare_home: u64,
    /// A repaint for a size the pty has not had lately.
    pub reset_mismatch: u64,
    /// Kept for the record's shape: nothing counts it.
    pub unknown_status: u64,
}

/// The SGR parameter lists applied since the last SGR reset: the pen a join ends with. Most output changes it all the time,
/// so the strings it holds are reused rather than made for each change.
#[derive(Clone, Debug, Default)]
pub struct Pen {
    lists: Vec<String>,
    len: usize,
}

impl Pen {
    /// The parameter lists, oldest first.
    pub fn lists(&self) -> &[String] {
        &self.lists[..self.len]
    }

    /// Back to the default pen.
    pub fn clear(&mut self) {
        self.len = 0;
    }

    fn push(&mut self, params: &str) {
        if self.len == 64 {
            self.lists[..64].rotate_left(1); // the oldest goes: a pen is never that long but by mistake
            self.len -= 1;
        }
        if self.len == self.lists.len() {
            self.lists.push(String::new());
        }
        let slot = &mut self.lists[self.len];
        slot.clear();
        slot.push_str(params);
        self.len += 1;
    }
}

/// A resize the holder applied, which takes effect when the stream reaches its offset.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Applied {
    /// Columns.
    pub cols: u32,
    /// Rows.
    pub rows: u32,
    /// Where in the stream.
    pub offset: u64,
}

/// See the module.
#[derive(Clone, Debug)]
pub struct Tracker {
    /// The program is on the alternate screen.
    pub alt: bool,
    /// The modes it set.
    pub modes: ModeState,
    /// Its title.
    pub title: String,
    /// See [`Pen`].
    pub pen: Pen,
    /// The character set designated G0 (`B` is ASCII, `0` line drawing), for writing letters of nmux's own.
    pub g0: u8,
    /// SO has shifted to G1.
    pub shifted: bool,
    /// The pty's columns, as far as the stream has got.
    pub pty_cols: u32,
    /// The pty's rows, as far as the stream has got.
    pub pty_rows: u32,
    /// The row counts the pty has had, oldest first, the first one it had included.
    pub applied_rows: Vec<u32>,
    /// The rows of the screen as last drawn: a repaint's own count, or the pty's after a resize.
    pub screen_rows: u32,
    /// Where the last repaint started, or `None`.
    pub last_reset_offset: Option<u64>,
    /// Where the last resize took effect, or `None` since the program started.
    pub last_resize_offset: Option<u64>,
    /// See [`Census`].
    pub census: Census,
    pending: Vec<Applied>,
}

impl Tracker {
    /// A program just started on a pty of this size.
    pub fn new(cols: u32, rows: u32) -> Self {
        Self {
            alt: false,
            modes: ModeState::new(),
            title: String::new(),
            pen: Pen::default(),
            g0: b'B',
            shifted: false,
            pty_cols: cols,
            pty_rows: rows,
            applied_rows: vec![rows],
            screen_rows: rows,
            last_reset_offset: None,
            last_resize_offset: None,
            census: Census::default(),
            pending: Vec::new(),
        }
    }

    /// The holder resized the pty when its stream had got to `offset`: it takes effect when processing gets there.
    pub fn note_resize(&mut self, cols: u32, rows: u32, offset: u64) {
        let at = self.pending.partition_point(|r| r.offset <= offset);
        self.pending.insert(at, Applied { cols, rows, offset });
    }

    /// Applies every pending resize at or before `offset`, and says which.
    pub fn advance_to(&mut self, offset: u64) -> Vec<Applied> {
        let due = self.pending.partition_point(|r| r.offset <= offset);
        let applied: Vec<Applied> = self.pending.drain(..due).collect();
        for r in &applied {
            self.pty_cols = r.cols;
            if self.applied_rows.last() != Some(&r.rows) {
                self.applied_rows.push(r.rows);
                if self.applied_rows.len() > 16 {
                    self.applied_rows.remove(0);
                }
            }
            self.pty_rows = r.rows;
            self.screen_rows = r.rows;
            self.last_resize_offset = Some(r.offset);
        }
        applied
    }

    /// The pen after `CSI params m`.
    pub fn note_pen(&mut self, params: &str) {
        if params.is_empty() || params == "0" || params.starts_with("0;") || params.starts_with(';') {
            self.pen.clear(); // and what follows a reset is all of the pen
        }
        if !params.is_empty() && params != "0" {
            self.pen.push(params);
        }
    }

    /// A new program on a new holder: its stream starts again, and it has set nothing yet. The census and the row counts
    /// the pty has had are kept.
    pub fn rebase(&mut self, cols: u32, rows: u32) {
        self.alt = false;
        self.modes = ModeState::new();
        self.title.clear();
        self.pen.clear();
        self.pending.clear();
        self.pty_cols = cols;
        if self.applied_rows.last() != Some(&rows) {
            self.applied_rows.push(rows);
        }
        self.pty_rows = rows;
        self.screen_rows = rows;
        self.last_reset_offset = None;
        self.last_resize_offset = None;
    }

    /// The rows a repaint of `n` rows was drawn for: its own count only if the pty had that many lately, since programs
    /// repaint for a size already replaced; otherwise the pty's, counted as a mismatch.
    pub fn reset_rows(&mut self, n: u32) -> u32 {
        let recent = &self.applied_rows[self.applied_rows.len().saturating_sub(3)..];
        if recent.contains(&n) {
            return n;
        }
        self.census.reset_mismatch += 1;
        self.pty_rows
    }
}
