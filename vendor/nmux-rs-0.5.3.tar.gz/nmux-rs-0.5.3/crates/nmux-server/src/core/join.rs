//! Joins and redraws, `join.js`, as states: a join waits for a shrink it caused to reach the pty, for a program that
//! repaints to repaint at the new size, for the session to have started, and for the output to be between frames; then it
//! is built, and sent as the client's connection takes it, while live output from that point is held for it. A redraw
//! brings a client that fell behind back to the present on its own connection: once its socket has drained it gets the
//! screen as it is, and live output from there. Nothing about either changes anything for another client.

use nmux_io::{TimerId, Timers};
use nmux_wire::Control;

use super::{ConnId, Due, Server};
use crate::output::{ByeExtra, Client, Join as JoinBytes, Phase, join_bytes, join_geometry};

/// Where a join or redraw is.
#[derive(Debug)]
enum Stage {
    /// The shrink this join causes has not reached the pty yet.
    WaitPty,
    /// The program has not repainted at the new size yet.
    WaitReset,
    /// The session has not started, or is still reading back what the holder had.
    WaitStart,
    /// A redraw waits for what is queued for the client to be written.
    Drain,
    /// Waiting for the output to be between frames; tries so far.
    Quiesce(u32),
    /// Being sent: the bytes, how far, whether in SNAPSHOT frames, and the line to flash after.
    Sending { bytes: Vec<u8>, at: usize, framed: bool, away: Option<String> },
}

/// A join or a redraw under way for one client.
#[derive(Debug)]
pub struct Join {
    /// A redraw: whether to say what was skipped, and whether the client's main screen is whole.
    resync: Option<(bool, bool)>,
    stage: Stage,
    timer: Option<TimerId>,
    snapshot_timer: Option<TimerId>,
}

impl Join {
    /// Lets go of its timers.
    pub fn cancel(self, timers: &mut Timers<Due>) {
        for t in [self.timer, self.snapshot_timer].into_iter().flatten() {
            timers.cancel(t);
        }
    }
}

impl Server {
    /// Starts a join for a client, unless one is running for it already: that one reads the client's size when it is built.
    pub(super) fn start_join(&mut self, conn: ConnId) {
        let Some(c) = self.clients.get_mut(&conn) else { return };
        if c.adapter.closed || c.joining.is_some() {
            return;
        }
        c.adapter.phase = Phase::Joining;
        c.adapter.armed = false;
        self.arbiter_changed();
        let seats = self.seats();
        let shrinks = self.arbiter.desired(&seats).is_some_and(|d| d.cols < self.pty.cols || d.rows < self.pty.rows);
        // Never in the event that brought the client: input it sent with its HELLO comes before the join is over, and is not
        // taken, as it is not in Node, where a join always goes on after what was read with it.
        let (stage, wait) = if shrinks {
            (Stage::WaitPty, Some(self.config.size.shrink_max_wait_ms + 200))
        } else {
            (Stage::WaitStart, Some(0))
        };
        let timer = wait.map(|ms| self.set_timer(ms, Due::Join(conn)));
        if let Some(c) = self.clients.get_mut(&conn) {
            c.joining = Some(Join { resync: None, stage, timer, snapshot_timer: None });
        }
        self.advance_join(conn);
    }

    /// Brings a client that fell behind back to the present, unless a join for it is running: that one ends in
    /// [`Server::join_done`].
    pub(super) fn start_resync(&mut self, conn: ConnId, announce: bool, keep_main: bool) {
        let Some(c) = self.clients.get_mut(&conn) else { return };
        if c.adapter.closed || c.joining.is_some() {
            return;
        }
        c.joining =
            Some(Join { resync: Some((announce, keep_main)), stage: Stage::Drain, timer: None, snapshot_timer: None });
        let (id, skipped) = (c.id.clone(), c.adapter.skipped);
        self.log(nmux_holder::Level::Info, "client.behind", &[("client", id.into()), ("skipped", skipped.into())]);
        self.advance_join(conn);
    }

    /// The client wants its screen drawn again.
    pub(super) fn request_resync(&mut self, conn: ConnId, alt: Option<bool>, skipped: u64) {
        let Some(c) = self.clients.get_mut(&conn) else { return };
        if c.joining.is_some() {
            c.asked = Some((alt, skipped));
            return;
        }
        let a = &mut c.adapter;
        if alt == Some(false) {
            a.alt = false;
        }
        if skipped > 0 {
            a.has_gaps = true;
        }
        a.behind = true;
        a.skipped += skipped;
        self.start_resync(conn, skipped > 0, skipped == 0);
    }

    /// Whatever was asked of a client while something else was being sent to it.
    fn join_done(&mut self, conn: ConnId) {
        let Some(c) = self.clients.get_mut(&conn) else { return };
        if let Some(j) = c.joining.take() {
            j.cancel(&mut self.timers);
        }
        if c.adapter.closed {
            return;
        }
        match c.asked.take() {
            Some((alt, skipped)) => self.request_resync(conn, alt, skipped),
            None if c.adapter.behind => self.start_resync(conn, true, false),
            None => {}
        }
    }

    /// The pty took a new size: joins that waited for it go on.
    pub(super) fn joins_hear_pty(&mut self) {
        let waiting: Vec<ConnId> = self
            .clients
            .iter()
            .filter(|(_, c)| matches!(c.joining.as_ref().map(|j| &j.stage), Some(Stage::WaitPty)))
            .map(|(k, _)| *k)
            .collect();
        for conn in waiting {
            let repaint = self.repaint;
            let wait = self.config.size.join_repaint_wait_ms;
            let timer = repaint.then(|| self.set_timer(wait, Due::Join(conn)));
            if let Some(j) = self.clients.get_mut(&conn).and_then(|c| c.joining.as_mut()) {
                if let Some(old) = j.timer.take() {
                    self.timers.cancel(old);
                }
                j.stage = if repaint { Stage::WaitReset } else { Stage::WaitStart };
                j.timer = timer;
            }
            self.advance_join(conn);
        }
    }

    /// A program repainted: joins that waited for a repaint at the new size go on.
    pub(super) fn on_reset(&mut self, offset: u64) {
        if self.tracker.last_resize_offset.is_some_and(|r| offset < r) {
            return;
        }
        let waiting: Vec<ConnId> = self
            .clients
            .iter()
            .filter(|(_, c)| matches!(c.joining.as_ref().map(|j| &j.stage), Some(Stage::WaitReset)))
            .map(|(k, _)| *k)
            .collect();
        for conn in waiting {
            if let Some(j) = self.clients.get_mut(&conn).and_then(|c| c.joining.as_mut()) {
                if let Some(old) = j.timer.take() {
                    self.timers.cancel(old);
                }
                j.stage = Stage::WaitStart;
            }
            self.advance_join(conn);
        }
    }

    /// The session started, or its lifecycle changed: joins waiting for that go on.
    pub(super) fn joins_hear_start(&mut self) {
        let waiting: Vec<ConnId> = self
            .clients
            .iter()
            .filter(|(_, c)| matches!(c.joining.as_ref().map(|j| &j.stage), Some(Stage::WaitStart)))
            .map(|(k, _)| *k)
            .collect();
        for conn in waiting {
            self.advance_join(conn);
        }
    }

    /// Everything queued for a client has been written.
    pub(super) fn drained(&mut self, conn: ConnId) {
        if self.clients.get(&conn).is_some_and(|c| c.joining.is_some()) {
            self.advance_join(conn);
        }
    }

    /// Whether no client is in the middle of a join.
    pub(super) fn joins_done(&self) -> bool {
        self.clients.values().all(|c| c.joining.is_none())
    }

    /// Moves a join on as far as it can go now. Its timer firing means what it waited for has had its time.
    pub(super) fn advance_join(&mut self, conn: ConnId) {
        for _ in 0..16 {
            let Some(c) = self.clients.get_mut(&conn) else { return };
            if c.adapter.closed {
                if let Some(j) = c.joining.take() {
                    j.cancel(&mut self.timers);
                }
                return;
            }
            let Some(j) = c.joining.as_mut() else { return };
            let due = j.timer.is_some_and(|t| !self.timers.is_set(t));
            if due {
                j.timer = None;
            }
            let out_empty = c.adapter.out.is_empty();
            let next = match &j.stage {
                Stage::WaitPty | Stage::WaitReset if due => Some(Stage::WaitStart),
                Stage::WaitStart => {
                    if j.timer.is_some() || !self.started || self.machine.lifecycle.is("RECOVERING") {
                        return;
                    }
                    Some(Stage::Quiesce(0))
                }
                Stage::Drain if out_empty => Some(Stage::WaitStart),
                Stage::WaitPty | Stage::WaitReset | Stage::Drain => return,
                Stage::Quiesce(tries) => {
                    let tries = *tries;
                    let ground = self.last_chunk.is_none_or(|c| c.1)
                        && self.pipeline.as_ref().is_none_or(crate::output::Pipeline::quiescent);
                    let framing = self.tracker.modes.raw(2026) == 1;
                    if (ground && !framing) || tries >= self.timer_cfg.quiesce_tries || due {
                        self.build(conn);
                        continue;
                    }
                    let timer = self.timers.set(self.now.time, self.timer_cfg.sync_frame_wait_ms, Due::Join(conn));
                    if let Some(j) = self.clients.get_mut(&conn).and_then(|c| c.joining.as_mut()) {
                        j.timer = Some(timer);
                        j.stage = Stage::Quiesce(tries + 1);
                    }
                    return;
                }
                Stage::Sending { .. } => {
                    if self.send_some(conn) {
                        self.sent(conn);
                    }
                    return;
                }
            };
            if let (Some(next), Some(j)) = (next, self.clients.get_mut(&conn).and_then(|c| c.joining.as_mut())) {
                j.stage = next;
            }
        }
    }

    /// Builds what is sent, at this point of the output.
    fn build(&mut self, conn: ConnId) {
        let Some(c) = self.clients.get(&conn) else { return };
        let resync = c.joining.as_ref().and_then(|j| j.resync);
        match resync {
            Some((announce, keep_main)) => self.build_resync(conn, announce, keep_main),
            None => self.build_join(conn),
        }
    }

    fn build_join(&mut self, conn: ConnId) {
        let Some(c) = self.clients.get(&conn) else { return };
        let (cols, rows) = (c.adapter.cols, c.adapter.rows);
        let resume = c.hello.resume.clone();
        if let Some(missed) = self.output_since(resume.as_ref(), cols, rows) {
            // its terminal is as it left it, so it only needs what came next
            let cx = self.cx();
            let (titles, tracker, cap) = (cx.titles.clone(), self.tracker.clone(), cx.queue_cap);
            let Some(c) = self.clients.get_mut(&conn) else { return };
            c.adapter.arm_join(&tracker);
            let cx = crate::output::Context { titles: &titles, tracker: &tracker, queue_cap: cap };
            for chunk in &missed {
                c.adapter.render(chunk, &cx);
            }
            c.adapter.send_control(&Control::SnapshotBegin { lines: 0, truncated_before: None });
            c.adapter.send_control(&Control::SnapshotEnd);
            c.adapter.go_live();
            self.join_done(conn);
            self.broadcast_state();
            return;
        }
        let terminal = c.hello.terminal.clone().flatten();
        let same_screen = c.hello.flags.same_screen();
        let cursor_row = Some(c.hello.cursor_row as usize).filter(|r| *r > 0);
        let back = self.returning(terminal.as_deref());
        let over = back.is_some() && same_screen && self.emulator.tracking();
        let history_from = back
            .as_ref()
            .and_then(|b| if over { self.emulator.pin_row(b.top) } else { self.row_after(b) })
            .map_or(0, |row| self.emulator.index(row));
        let (alt, keep_main, over_screen) = match (over, self.tracker.alt) {
            (false, _) => (None, false, false),
            (true, true) => (Some(false), true, false),
            (true, false) => (None, false, true),
        };
        let name = self.name();
        let mut away: Option<String> = None;
        let bar = self.join_bar(conn);
        let client = Client { rows: rows as usize, cols: cols as usize, cursor_row, alt, keep_main, over_screen, bar };
        let limit = self.config.snapshot.join_history;
        let bytes = {
            let banner = |n: usize| {
                away = back.as_ref().and_then(|b| self.away_since(b, n as u64));
                match &away {
                    Some(what) => Some(self.messages.away(&name, what)),
                    None if back.is_some() => None,
                    None => self.messages.join_banner(&name, n as u64),
                }
            };
            let join = JoinBytes {
                emulator: &self.emulator,
                tracker: &self.tracker,
                banner,
                client,
                history_limit: limit,
                history_from,
            };
            join_bytes(join)
        };
        if let Some(b) = &back {
            self.unpin_bookmark(b);
        }
        let lines = if self.emulator.tracking() {
            0
        } else {
            let g = join_geometry(&self.emulator, &self.tracker, limit, history_from);
            g.scr - g.h0
        };
        let truncated = self.history_truncated_before;
        let timeout = self.config.snapshot.snapshot_timeout_ms;
        let tracker = self.tracker.clone();
        let Some(c) = self.clients.get_mut(&conn) else { return };
        c.adapter.arm_join(&tracker);
        c.adapter.send_control(&Control::SnapshotBegin { lines: lines as u64, truncated_before: truncated });
        let timer = self.timers.set(self.now.time, timeout, Due::SnapshotTimeout(conn));
        if let Some(j) = self.clients.get_mut(&conn).and_then(|c| c.joining.as_mut()) {
            j.snapshot_timer = Some(timer);
            j.stage = Stage::Sending { bytes, at: 0, framed: true, away };
        }
    }

    fn build_resync(&mut self, conn: ConnId, announce: bool, keep_main: bool) {
        let name = self.name();
        let Some(c) = self.clients.get_mut(&conn) else { return };
        if c.adapter.phase == Phase::Paused {
            c.adapter.behind = false; // growing back brings a whole join
            self.join_done(conn);
            return;
        }
        let (skipped, lost) = (c.adapter.skipped, c.adapter.lost);
        let (cols, rows, alt) = (c.adapter.cols, c.adapter.rows, c.adapter.alt);
        let text = announce.then(|| {
            if lost { self.messages.lost_output(skipped) } else { self.messages.skipped_output(skipped, &name) }
        });
        let client = Client {
            rows: rows as usize,
            cols: cols as usize,
            cursor_row: Some(rows as usize),
            alt: Some(alt),
            keep_main,
            over_screen: false,
            bar: self.join_bar(conn),
        };
        let banner = |_| text.clone();
        let bytes = join_bytes(JoinBytes {
            emulator: &self.emulator,
            tracker: &self.tracker,
            banner,
            client,
            history_limit: Some(0),
            history_from: 0,
        });
        let tracker = self.tracker.clone();
        let Some(c) = self.clients.get_mut(&conn) else { return };
        c.adapter.arm_resync(&tracker);
        c.adapter.send_control(&Control::ResyncBegin);
        if let Some(j) = c.joining.as_mut() {
            j.stage = Stage::Sending { bytes, at: 0, framed: false, away: None };
        }
    }

    /// Sends what the connection takes. True when all of it has gone.
    fn send_some(&mut self, conn: ConnId) -> bool {
        let chunk = self.config.snapshot.chunk_bytes.max(1);
        let Some(c) = self.clients.get_mut(&conn) else { return false };
        let Some(Join { stage: Stage::Sending { bytes, at, .. }, .. }) = c.joining.as_mut() else { return false };
        while *at < bytes.len() && c.adapter.out.len() < chunk {
            let end = (*at + chunk).min(bytes.len());
            c.adapter.send_output(&bytes[*at..end]);
            *at = end;
        }
        *at >= bytes.len()
    }

    /// It has all been sent: the client goes live.
    fn sent(&mut self, conn: ConnId) {
        let Some(c) = self.clients.get_mut(&conn) else { return };
        let Some(j) = c.joining.as_mut() else { return };
        let Stage::Sending { framed, away, .. } = &mut j.stage else { return };
        let (framed, away) = (*framed, away.take());
        if framed {
            c.adapter.send_control(&Control::SnapshotEnd);
        }
        c.adapter.go_live();
        if let Some(line) = away {
            // the line itself is just above the screen, out of sight
            let cap = self.config.clients.queue_cap_bytes;
            let cx = crate::output::Context { titles: &self.titles, tracker: &self.tracker, queue_cap: cap };
            c.adapter.flash(&line, self.now.time, &cx);
        }
        self.join_done(conn);
        if framed {
            self.broadcast_state();
        }
    }

    /// A join's snapshot took too long to be delivered.
    pub(super) fn snapshot_timeout(&mut self, conn: ConnId) {
        let Some(c) = self.clients.get_mut(&conn) else { return };
        if let Some(j) = c.joining.as_mut() {
            j.snapshot_timer = None;
        }
        if matches!(c.joining.as_ref().map(|j| &j.stage), Some(Stage::Sending { framed: true, .. })) {
            let text = "the join snapshot could not be delivered in time";
            self.bye(conn, "SNAPSHOT_TIMEOUT", true, text, ByeExtra::default());
        }
    }
}

impl Server {
    /// The bar a join draws for a terminal that has one, which is then what it shows.
    fn join_bar(&mut self, conn: ConnId) -> Option<String> {
        if !self.clients.get(&conn).is_some_and(|c| c.adapter.bar) {
            return None;
        }
        let line = self.bar_for(conn);
        let c = self.clients.get_mut(&conn)?;
        c.ambient.shown.clone_from(&line);
        c.ambient.redraw = false;
        Some(line)
    }
}
