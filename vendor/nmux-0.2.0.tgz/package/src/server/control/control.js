'use strict';
// @ts-check
const fs = require('node:fs');
const net = require('node:net');
const procinfo = require('../../platform/procinfo');
const { CTL_PROTO, FramedSocket, T } = require('../../wire/proto');
const { DEFAULT_MESSAGES } = require('../messages');

const HELLO_TIMEOUT_MS = 5000;
const REPLY_PIECE = 262144;
const SIGNALS = ['SIGCONT', 'SIGTERM'];
const NOTICE_LEVELS = ['info', 'warn'];
/** What a subscriber gets unless it asks for less. */
const ALL_EVENTS = ['lifecycle', 'notice', 'stopped', 'holder', 'attached', 'replayed', 'tty', 'match', 'exit', 'respawned', 'stopping', 'record'];
/** Printed on terminals, so it may not carry escape sequences, and not so long a STATE no longer fits. */
const NAME = /^[^\x00-\x1f\x7f-\x9f]{1,64}$/;

/** INPUT keys a control client may send. Deliberately no Ctrl+Z / Ctrl+\ /
 *  Ctrl+C or arrows: a remote client must not be able to suspend, detach, interrupt-by-signal or navigate menus. */
const INPUT_KEYS = Object.freeze({ esc: '\x1b', enter: '\r', 1: '1', 2: '2', 3: '3', 4: '4', 5: '5', 6: '6', 7: '7', 8: '8', 9: '9' });
const MAX_INPUT_TEXT = 16384;
const PASTE_START = Buffer.from('\x1b[200~', 'latin1');
const PASTE_END = Buffer.from('\x1b[201~', 'latin1');
const PASTE_END_SUBMIT = Buffer.from('\x1b[201~\r', 'latin1');
const ENTER = Buffer.from('\r', 'latin1');
const EMPTY = Buffer.alloc(0);

/**
 * The bytes an INPUT request stands for, or null when its arguments are malformed. Text is a bracketed paste followed
 * by CR, so newlines inside it are part of the prompt rather than submitting it early; it may not carry NUL, ESC, DEL or
 * any C0 control other than TAB and LF, so it cannot smuggle a key sequence or end the paste itself.
 * @param {any} args @returns {Buffer|null}
 */
function inputBytes(args) {
  if (!args || typeof args !== 'object') return null;
  const hasText = typeof args.text === 'string';
  const hasKey = typeof args.key === 'string';
  if (hasText === hasKey) return null;
  if (hasKey) return Object.prototype.hasOwnProperty.call(INPUT_KEYS, args.key) ? Buffer.from(/** @type {any} */ (INPUT_KEYS)[args.key], 'latin1') : null;
  const text = /** @type {string} */ (args.text);
  if (text.length === 0 || Buffer.byteLength(text, 'utf8') > MAX_INPUT_TEXT) return null;
  if (/[\x00-\x08\x0b-\x1f\x7f]/.test(text)) return null;
  return Buffer.concat([PASTE_START, Buffer.from(text, 'utf8'), PASTE_END_SUBMIT]);
}

/** @typedef {{id: string, label: string, inputClient: any, fsock: FramedSocket, unsubscribe?: (() => void)|null}} Conn */

/**
 * ctl.sock server. HELLO → WELCOME or REFUSE{PROTO|STOPPING|BLOCKED|NESTED|BELOW_FLOOR|TOO_SHORT}; role "attach" joins
 * through the ClientHub; role "control" gets STATE pushes and REQ → RES and never counts in arbitration. Anything unknown is
 * answered UNSUPPORTED.
 *   Read: STATUS PEEK SCREEN CAPTURE CLIENTS. SCREEN and CAPTURE send their text as OUTPUT frames before the RES.
 *   Act: INPUT SEND WRITE SIGNAL STOP RESTART RESPAWN RENAME KICK NOTICE.
 *   Extend: SUBSCRIBE (EVENT pushes), and on a managed session PHASE GATE SET_ATTR STOP_PROCEED.
 */
class ControlServer {
  /**
   * @param {{sockPath: string, config: any, clock: import('../../base/types').Clock, log: any, id: string, nestEnv?: string|null,
   *   registry: import('../clients/hub').ClientHub, session: import('../session/session').Session,
   *   messages?: import('../messages').Messages}} o
   */
  constructor({ sockPath, config, clock, log, id, nestEnv = null, registry, session, messages = DEFAULT_MESSAGES }) {
    this.sockPath = sockPath;
    this.config = config;
    this.clock = clock;
    this.log = log;
    this.id = id;
    this.nestEnv = nestEnv;
    this.registry = registry;
    this.session = session;
    this.messages = messages;
    /** @type {net.Server|null} */
    this.server = null;
    /** @type {Set<net.Socket>} */
    this.sockets = new Set();
  }

  async listen() {
    try { fs.unlinkSync(this.sockPath); } catch { /* not there */ }
    const server = net.createServer((sock) => this._conn(sock));
    this.server = server;
    await new Promise((resolve, reject) => { server.once('error', reject); server.listen(this.sockPath, () => resolve(undefined)); });
    fs.chmodSync(this.sockPath, 0o600);
  }

  close() {
    if (this.server) { this.server.close(); this.server = null; }
    for (const s of this.sockets) s.destroy();
    try { fs.unlinkSync(this.sockPath); } catch { /* gone */ }
  }

  /** @param {net.Socket} sock */
  _conn(sock) {
    this.sockets.add(sock);
    sock.on('close', () => this.sockets.delete(sock));
    const fsock = new FramedSocket(sock);
    fsock.on('error', () => {});
    let greeted = false;
    const timer = this.clock.setTimeout(() => { if (!greeted) fsock.destroy(); }, HELLO_TIMEOUT_MS);
    const onFirst = (/** @type {any} */ m) => {
      if (greeted) return;
      greeted = true;
      this.clock.clearTimeout(timer);
      fsock.off('control', onFirst);
      if (!m || m.t !== 'HELLO') { this._refuse(fsock, 'PROTO', 'expected HELLO'); return; }
      this._hello(fsock, sock, m);
    };
    fsock.on('control', onFirst);
  }

  /** @param {FramedSocket} fsock @param {string} code @param {string} text @param {object|null} [need] */
  _refuse(fsock, code, text, need = null) {
    fsock.sendControl({ t: 'REFUSE', code, need, text });
    fsock.end();
  }

  /** @param {FramedSocket} fsock @param {net.Socket} sock @param {any} h */
  _hello(fsock, sock, h) {
    const size = this.config.size;
    const name = this.session.name;
    if (h.proto !== CTL_PROTO) { this._refuse(fsock, 'PROTO', this.messages.protoMismatch(h.proto, CTL_PROTO, name)); return; }
    if (h.role !== 'attach' && h.role !== 'control') { this._refuse(fsock, 'PROTO', `unknown role ${h.role}`); return; }
    if (h.role === 'control') { this._control(fsock, h); return; }
    const lc = this.session.lifecycle;
    if (lc === 'STOPPING' || lc === 'STOPPED' || lc === 'STOP_STUCK') { this._refuse(fsock, 'STOPPING', `session '${name}' is stopping`); return; }
    if (lc === 'BLOCKED') { this._refuse(fsock, 'BLOCKED', this.messages.blocked(name, this.session.blockedCode)); return; }
    if (this.nestEnv && Number.isInteger(h.pid) && h.pid > 0) {
      // Refuse a client that is itself running inside this session. This needs the attaching
      // process's environment, which macOS does not expose, so the guard cannot fire there. Walking
      // the process tree instead is not a substitute: a genuine client is spawned by the user's
      // shell and may share the holder as an ancestor with the child, so a parent-chain test would
      // refuse legitimate attaches. Not offering the check is better than a wrong one.
      const env = procinfo.readEnviron(h.pid);
      if (env && env[this.nestEnv] === this.id) { this._refuse(fsock, 'NESTED', 'refusing to attach a session from inside itself'); return; }
    }
    const cols = Number(h.cols) | 0;
    const rows = Number(h.rows) | 0;
    const floorC = h.flags && h.flags.shrink ? size.hardMinCols : size.floorCols;
    const need = { cols: floorC, rows: size.floorRows };
    if (cols < floorC) {
      this._refuse(fsock, 'BELOW_FLOOR', this.messages.belowFloor(name, cols, rows, floorC, size.hardMinCols), need);
      return;
    }
    if (rows < size.floorRows) { this._refuse(fsock, 'TOO_SHORT', `this terminal is ${cols}x${rows} — below the ${size.floorRows}-row floor for shared sessions`, need); return; }
    const id = this.registry.nextId();
    fsock.sendControl(this._welcome(id));
    this.registry.add(fsock, sock, { ...h, cols, rows }, id);
  }

  /** @param {string} clientId */
  _welcome(clientId) {
    const size = this.config.size;
    return { t: 'WELCOME', proto: CTL_PROTO, id: this.id, ...this.session.controller.welcomeFields(), name: this.session.name, clientId, pty: { ...this.session.pty }, lifecycle: this.session.lifecycle,
      policy: { floorCols: size.floorCols, floorRows: size.floorRows, hardMinCols: size.hardMinCols },
      ping: { intervalMs: this.config.clients.pingMs, timeoutMs: this.config.clients.stallMs } };
  }

  /** @param {FramedSocket} fsock @param {any} h */
  _control(fsock, h) {
    const id = `k${this.registry.nextId().slice(1)}`;
    fsock.sendControl(this._welcome(id));
    this.registry.watchers.add(fsock);
    fsock.sendControl(this.registry.stateMessage());
    /** Per-connection INPUT identity; created on the first INPUT (see _input). */
    /** @type {Conn} */
    const conn = { id, label: String((h && h.label) || 'control'), inputClient: null, fsock };
    fsock.on('close', () => {
      this.registry.watchers.delete(fsock);
      if (conn.unsubscribe) conn.unsubscribe();
      if (conn.inputClient) {
        conn.inputClient.closed = true;
        if (this.registry.router) this.registry.router.removeClient(conn.inputClient);
      }
    });
    fsock.on('control', (/** @type {any} */ m) => {
      if (m.t === 'PING') { fsock.sendControl({ t: 'PONG', seq: m.seq }); return; }
      if (m.t !== 'REQ') return;
      this._req(m, conn).then((res) => fsock.sendControl({ t: 'RES', id: m.id, ...res }))
        .catch((e) => fsock.sendControl({ t: 'RES', id: m.id, ok: false, error: String(e && e.message) }))
        .catch(() => fsock.destroy());                                                 // no request can take the session down with it
    });
  }

  /** @param {{id: any, op: string, args?: any}} m @param {Conn} conn
   *  @returns {Promise<{ok: boolean, data?: any, error?: string}>} */
  async _req(m, conn) {
    const a = (m.args && typeof m.args === 'object') ? m.args : {};
    switch (m.op) {
      case 'STATUS':
        return { ok: true, data: { id: this.id, ...this.session.status(), clients: this.registry.info() } };
      case 'PEEK': {
        const n = Math.max(1, Math.min(50, Number(m.args && m.args.lines) || 6));
        const lines = this.session.screenText().split('\n').filter((l) => l.trim() !== '');
        return { ok: true, data: { lines: lines.slice(-n) } };
      }
      case 'CAPTURE': {
        const lines = m.args && Number.isSafeInteger(m.args.lines) && m.args.lines > 0 ? m.args.lines : null;
        return this._text(conn, await this.session.capture({ lines, ansi: !!(m.args && m.args.ansi) }));
      }
      case 'SCREEN':
        return this._text(conn, await this.session.screen());
      case 'STOP':
        await this.session.stop();
        return { ok: true, data: { lifecycle: this.session.lifecycle } };
      case 'RESTART':
        this.session.restart();
        return { ok: true, data: {} };
      case 'RENAME':
        if (!m.args || typeof m.args.name !== 'string' || !NAME.test(m.args.name)) return { ok: false, error: 'BAD_ARGS' };
        this.session.rename(m.args.name);
        this.session.saveState(true);
        this.registry.broadcastState();
        return { ok: true, data: { name: m.args.name } };
      case 'SEND':
        return this._send(conn, m.args);
      case 'WRITE':
        // Past the gates: this is for a controller that knows what it is doing, as a stop's own last word is.
        if (typeof a.text !== 'string' || !a.text) return { ok: false, error: 'BAD_ARGS' };
        return { ok: true, data: { watchId: this.session.write(Buffer.from(a.text, 'utf8')) } };
      case 'SIGNAL':
        if (!SIGNALS.includes(a.sig)) return { ok: false, error: 'BAD_ARGS' };
        this.session.signal(a.sig);
        return { ok: true, data: {} };
      case 'RESPAWN':
        return this._respawn(a);
      case 'NOTICE':
        if (!NOTICE_LEVELS.includes(a.level) || typeof a.code !== 'string' || typeof a.text !== 'string') return { ok: false, error: 'BAD_ARGS' };
        this.session.notify(a.level, a.code, a.text);
        return { ok: true, data: {} };
      case 'SUBSCRIBE':
        return this._subscribe(conn, a);
      case 'PHASE':
      case 'GATE':
      case 'SET_ATTR':
      case 'STOP_PROCEED':
        return this._manage(m.op, a);
      case 'INPUT':
        return this._input(conn, m.args);
      case 'CLIENTS':
        return { ok: true, data: { clients: this.registry.listing() } };
      case 'KICK':
        return this._kick(m.args);
      default:
        return { ok: false, error: 'UNSUPPORTED' };
    }
  }

  /**
   * KICK{clients: [id…]} detaches those clients; KICK{allExcept: [id…]} detaches every other one. `by` names who asked,
   * for the kicked terminal's detach line; `because: 'CLIENT_EXIT'` says the terminal asked to leave, and `text` what it reads.
   * (Kept in `_kick` so a client that left and one that was thrown off cannot be confused.)
   * @param {any} args @returns {{ok: boolean, data?: any, error?: string}}
   */
  _kick(args) {
    const ids = (/** @type {any} */ v) => Array.isArray(v) && v.length <= 256 && v.every((x) => typeof x === 'string' && x.length <= 32);
    if (!args || typeof args !== 'object') return { ok: false, error: 'BAD_ARGS' };
    const hasClients = args.clients !== undefined;
    const hasExcept = args.allExcept !== undefined;
    if (hasClients === hasExcept || (hasClients && (!ids(args.clients) || args.clients.length === 0)) || (hasExcept && !ids(args.allExcept))) return { ok: false, error: 'BAD_ARGS' };
    // Printed on the kicked terminal: never let it carry escape sequences.
    const by = typeof args.by === 'string' ? args.by.replace(/[\x00-\x1f\x7f-\x9f]/g, '').slice(0, 64) : '';
    if (args.because === 'CLIENT_EXIT') return { ok: true, data: this.registry.leave(hasClients ? args.clients : []) };
    return { ok: true, data: this.registry.kick(hasClients ? { clients: args.clients, by } : { allExcept: args.allExcept, by }) };
  }

  /** @param {Conn} conn @param {string} text @returns {{ok: boolean, data: any}} */
  _text(conn, text) {
    const bytes = Buffer.from(text, 'utf8');
    for (let i = 0; i < bytes.length; i += REPLY_PIECE) conn.fsock.send(T.OUTPUT, bytes.subarray(i, i + REPLY_PIECE));   // far more than a JSON reply may carry
    return { ok: true, data: { bytes: bytes.length } };
  }

  /**
   * A new child in this session, with the same clients attached. The old one is hung up on first if it is still there.
   * @param {any} a @returns {{ok: boolean, data?: any, error?: string}}
   */
  _respawn(a) {
    const argv = a.argv;
    if (!Array.isArray(argv) || argv.length === 0 || argv.some((x) => typeof x !== 'string')) return { ok: false, error: 'BAD_ARGS' };
    const { session } = this;
    /** @type {any} */ (session.controller).nextArgv = argv;
    if (session.exited) session.respawn(argv).catch((e) => session._respawnFailed(e));
    else session.restart();
    return { ok: true, data: {} };
  }

  /**
   * SUBSCRIBE{events?, controller?}: pushes EVENT messages until the connection closes. The reply says where things stand,
   * so nothing that happened earlier needs replaying. `controller` claims the session: its controller is connected.
   * @param {Conn} conn @param {any} a @returns {{ok: boolean, data?: any, error?: string}}
   */
  _subscribe(conn, a) {
    const { session } = this;
    const { controller } = session;
    const remote = /** @type {any} */ (controller).events ? /** @type {import('../session/remote').RemoteController} */ (controller) : null;
    if (a.controller && !remote) return { ok: false, error: 'UNSUPPORTED' };
    if (conn.unsubscribe) conn.unsubscribe();
    const want = new Set(Array.isArray(a.events) ? a.events : ALL_EVENTS);
    const send = (/** @type {any} */ e) => { if (want.has(e.event)) { try { conn.fsock.sendControl({ t: 'EVENT', ...e }); } catch (err) { this.log.warn('event.too_large', { event: e.event, error: String(err) }); } } };
    const onLifecycle = (/** @type {string} */ lifecycle) => send({ event: 'lifecycle', lifecycle });
    const onStopped = () => send({ event: 'stopped', lastExit: session.lastExit });
    const onNotice = (/** @type {object} */ n) => send({ event: 'notice', ...n });
    session.on('lifecycle', onLifecycle);
    session.on('notice', onNotice);
    session.on('stopped', onStopped);
    if (remote) remote.events.on('event', send);
    if (a.controller && remote) remote.connect(conn);
    conn.unsubscribe = () => {
      conn.unsubscribe = null;
      session.off('lifecycle', onLifecycle);
      session.off('notice', onNotice);
      session.off('stopped', onStopped);
      if (remote) {
        remote.events.off('event', send);
        if (remote.controllerConn === conn) { remote.controllerConn = null; remote.connected = false; }
      }
    };
    return { ok: true, data: remote ? remote.snapshot() : { lifecycle: session.lifecycle, name: session.name, lastExit: session.lastExit } };
  }

  /** What a controller may ask of a managed session. @param {string} op @param {any} a @returns {{ok: boolean, data?: any, error?: string}} */
  _manage(op, a) {
    const { session } = this;
    const remote = /** @type {any} */ (session.controller);
    if (!remote.events) return { ok: false, error: 'UNSUPPORTED' };
    switch (op) {
      case 'PHASE':
        if (a.code) { session.block(String(a.code)); return { ok: true, data: { lifecycle: session.lifecycle } }; }
        if (typeof a.to !== 'string' || !a.to) return { ok: false, error: 'BAD_ARGS' };
        session.setPhase(a.to, Array.isArray(a.from) ? { from: a.from } : {});
        return { ok: true, data: { lifecycle: session.lifecycle } };
      case 'GATE':
        if (typeof a.name !== 'string' || !a.name) return { ok: false, error: 'BAD_ARGS' };
        remote.setGate(a.name, a);
        return { ok: true, data: { gate: session.gateName() } };
      case 'SET_ATTR':
        if (!a.attrs || typeof a.attrs !== 'object') return { ok: false, error: 'BAD_ARGS' };
        remote.setAttrs(a.attrs);
        session.publish(typeof a.attention === 'boolean' ? { attention: a.attention } : {});
        return { ok: true, data: {} };
      default:                                                                         // STOP_PROCEED
        if (remote.proceed) remote.proceed();
        return { ok: true, data: {} };
    }
  }

  /**
   * INPUT from a control connection: through the same InputRouter and gates as a terminal's keystrokes. The gates are
   * checked here first only so the caller learns why nothing was typed; the router applies them again.
   * @param {Conn} conn @param {any} args
   * @returns {{ok: boolean, error?: string}}
   */
  _input(conn, args) {
    const bytes = inputBytes(args);
    if (bytes === null) return { ok: false, error: 'BAD_ARGS' };
    return this._type(conn, bytes, typeof args.text === 'string' ? 'text' : 'key');
  }

  /**
   * SEND{text, enter}: types what the caller wrote, which may be anything. Text of several lines goes in as one paste
   * when the program asked for pastes to be marked, so that a line of it cannot run before the rest has arrived.
   * @param {Conn} conn @param {any} args
   * @returns {{ok: boolean, error?: string}}
   */
  _send(conn, args) {
    if (!args || typeof args.text !== 'string' || !args.text) return { ok: false, error: 'BAD_ARGS' };
    const paste = args.text.includes('\n') && this.session.tracker.modes.raw(2004) === 1;
    const text = Buffer.from(paste ? args.text.replaceAll('\x1b[201~', '') : args.text, 'utf8');   // it must not end its own paste
    return this._type(conn, Buffer.concat([paste ? PASTE_START : EMPTY, text, paste ? PASTE_END : EMPTY, args.enter ? ENTER : EMPTY]), 'send');
  }

  /**
   * @param {Conn} conn @param {Buffer} bytes @param {string} kind
   * @returns {{ok: boolean, error?: string}}
   */
  _type(conn, bytes, kind) {
    const gates = this.session.gates();
    for (const g of this.session.blockingGates()) if (gates.includes(g)) return { ok: false, error: g };
    const router = this.registry.router;
    if (!router) return { ok: false, error: 'EXITED' };
    if (!conn.inputClient) {
      // The router keys its per-client state by object and calls back through .adapter / .flags (a detach key, an Esc
      // hold expiring). A control connection has no screen to notify and nothing to detach, so its callbacks are inert.
      conn.inputClient = { id: conn.id, label: conn.label, closed: false, flags: { shrink: false, allowSetup: false },
        adapter: { notice() {}, drop() {} } };
      router.addClient(conn.inputClient);
    }
    router.onInput(conn.inputClient, bytes);
    this.log.info('control.input', { client: conn.id, label: conn.label, kind, bytes: bytes.length });
    return { ok: true };
  }
}

module.exports = { ControlServer };
