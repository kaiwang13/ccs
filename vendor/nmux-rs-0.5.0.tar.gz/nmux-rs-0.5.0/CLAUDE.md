# Working on nmux-rs

This is the Rust implementation of `nmux`. `../nmux` is the Node one, and **the two move together**: a change of behaviour lands in both in the same sitting, and neither is finished until `tools/conformance.sh` passes
here and `npm test` passes there. A feature starts in whichever is easier, and is ported before moving on. Both versions carry the same version number.

Read `docs/DESIGN.md` before changing anything: what may not differ, the layers, and how it is judged. `docs/ROUTE.md` says why it is built this way.

`shell/` is the same as `../nmux/shell`, byte for byte. Change it there and copy it here.

Build with `CARGO_TARGET_DIR` on a local disk: this repository is on NFS.
