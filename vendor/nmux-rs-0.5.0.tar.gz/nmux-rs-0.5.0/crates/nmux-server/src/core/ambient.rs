//! What is drawn into terminals beside the session's own output, `ambient.js`: nmux's bar on the last row of a terminal
//! that asked for one, and a line in its scrollback when a new day starts. Neither is part of the session, and neither ends
//! up in a terminal's scrollback by accident: the bar's row is below the scroll region, and a day line goes in above a
//! screen that is then written over.
//!
//! The bar is drawn again when what it says changes, when output may have written over it, and when the terminal has
//! changed size, where the emulator has everything the terminal was sent, so that what the program had set is put back
//! after it exactly. Here the emulator has it as soon as nothing is half sent.

use std::path::Path;

use nmux_platform::command_line;
use nmux_time::{Zone, day_of, zone};

use super::hub::Client;
use super::{ConnId, Due, Server};
use crate::config::OverlayConfig;
use crate::output::{BarInfo, Phase, Pipeline, bar_line, draw_bar, redraw};

const TICK_MS: u64 = 1000;
/// A day line is drawn only once the session has been quiet this long.
const QUIET_MS: u64 = 1500;
/// How soon a bar that output may have written over is drawn again, and how long until another try while a sequence is
/// half sent.
const BAR_SOON_MS: u64 = 30;
const SYNC_MODE: u32 = 2026;
const ORIGIN_MODE: u32 = 6;

/// What the bar and the day lines need.
#[derive(Debug)]
pub struct Ambient {
    day_lines: bool,
    zone: Zone,
    on: bool,
    /// A draw of due bars is coming.
    soon: bool,
    /// What the terminal's foreground process was called, when it was asked.
    foreground: Option<(i64, Option<String>)>,
}

impl Ambient {
    /// What the overlay section of the configuration asks for.
    pub fn new(overlay: &OverlayConfig) -> Self {
        Self {
            day_lines: overlay.day_lines,
            zone: zone(overlay.time_zone.as_deref()),
            on: false,
            soon: false,
            foreground: None,
        }
    }
}

/// What has been drawn into one terminal.
#[derive(Clone, Debug, Default)]
pub struct Drawn {
    /// What its bar said when it was drawn.
    pub(super) shown: String,
    day: String,
    /// Its screen is to be written over once the sizes agree.
    pub(super) redraw: bool,
    /// Its bar is to be drawn again.
    due: bool,
}

/// The first `units` UTF-16 units of a line, as JavaScript's `slice` cuts it.
fn cut_units(s: &str, units: usize) -> String {
    let mut n = 0;
    s.chars()
        .take_while(|c| {
            n += c.len_utf16();
            n <= units
        })
        .collect()
}

/// Whether a client is live: joined, not behind and not being let go.
fn live(c: &Client) -> bool {
    !c.adapter.closed && c.joining.is_none() && c.adapter.phase == Phase::Live && !c.adapter.behind
}

impl Server {
    pub(super) fn ambient_start(&mut self) {
        self.ambient.on = true;
        self.set_timer(TICK_MS, Due::Ambient);
    }

    pub(super) fn ambient_stop(&mut self) {
        self.ambient.on = false;
    }

    /// Output may have written over this terminal's bar.
    pub(super) fn bar_hit(&mut self, conn: ConnId) {
        let Some(c) = self.clients.get_mut(&conn) else { return };
        c.ambient.due = true;
        self.bar_soon(BAR_SOON_MS);
    }

    /// The terminal changed size, or its bar came or went (`toggled`): the screen is written over once the sizes agree, so
    /// that the terminal shows it where the emulator has it, and the bar is drawn under it if it has one.
    pub(super) fn ambient_moved(&mut self, conn: ConnId, toggled: bool) {
        let Some(c) = self.clients.get_mut(&conn) else { return };
        if !c.adapter.bar && !toggled {
            return;
        }
        c.ambient.redraw = true;
        self.bar_hit(conn);
    }

    fn bar_soon(&mut self, ms: u64) {
        if self.ambient.on && !self.ambient.soon {
            self.ambient.soon = true;
            self.set_timer(ms, Due::Bar);
        }
    }

    pub(super) fn bar_due(&mut self) {
        self.ambient.soon = false;
        self.draw_bars();
    }

    /// What the program in front of the session's shell is called, or `None` when the shell itself is in front.
    fn running(&mut self) -> Option<String> {
        let fg = self.fg?;
        if self.hello.as_ref().is_some_and(|h| i64::from(h.child.pid) == fg) {
            return None;
        }
        if self.ambient.foreground.as_ref().is_none_or(|(pid, _)| *pid != fg) {
            let command = i32::try_from(fg).ok().and_then(command_line);
            let first = command.as_deref().and_then(|c| c.split(' ').next()).filter(|f| !f.is_empty());
            let name = first
                .and_then(|f| Path::new(f).file_name())
                .map(|n| n.to_string_lossy().trim_start_matches('-').to_owned());
            self.ambient.foreground = Some((fg, name));
        }
        self.ambient.foreground.as_ref().and_then(|(_, name)| name.clone())
    }

    /// What a terminal's bar says now.
    pub(super) fn bar_for(&mut self, conn: ConnId) -> String {
        let running = self.running();
        let name = self.name();
        let Some(c) = self.clients.get(&conn) else { return String::new() };
        let keys = &self.config.keys;
        let info = BarInfo {
            brand: &self.titles.brand,
            name: &name,
            running: running.as_deref(),
            clients: self.clients.len(),
            now: self.now.wall_ms,
            zone: &self.ambient.zone,
            leader: keys.leader.as_deref(),
            bindings: &keys.bindings,
            direct: &keys.direct,
            truecolor: c.hello.flags.truecolor(),
        };
        bar_line(&info, c.adapter.cols as usize)
    }

    pub(super) fn ambient_tick(&mut self) {
        if !self.ambient.on {
            return;
        }
        self.set_timer(TICK_MS, Due::Ambient);
        let conns: Vec<ConnId> =
            self.clients.iter().filter(|(_, c)| c.adapter.bar && live(c)).map(|(k, _)| *k).collect();
        let mut any = false;
        for conn in conns {
            let line = self.bar_for(conn);
            if let Some(c) = self.clients.get_mut(&conn).filter(|c| c.ambient.shown != line) {
                c.ambient.due = true;
                any = true;
            }
        }
        if any {
            self.draw_bars();
        }
        if self.ambient.day_lines {
            self.day_lines();
        }
    }

    /// The bars that are due, once nothing is half sent: the emulator then has all that went to the terminals.
    fn draw_bars(&mut self) {
        let settled =
            self.last_chunk.is_none_or(|(_, ground)| ground) && self.pipeline.as_ref().is_none_or(Pipeline::quiescent);
        if !settled {
            self.bar_soon(BAR_SOON_MS);
            return;
        }
        let mut later = false;
        let cap = self.config.clients.queue_cap_bytes;
        let conns: Vec<ConnId> = self.clients.iter().filter(|(_, c)| c.ambient.due).map(|(k, _)| *k).collect();
        for conn in conns {
            let Some(c) = self.clients.get_mut(&conn) else { continue };
            if c.adapter.closed || (!c.adapter.bar && !c.ambient.redraw) {
                c.ambient.due = false;
                continue;
            }
            if !live(c) {
                continue; // a join draws it
            }
            let a = &c.adapter;
            let sized = a.cols == self.pty.cols && a.rows == self.pty.rows && self.emulator.rows() == a.rows as usize;
            if c.ambient.redraw && !sized {
                later = true; // the pty has not taken the terminal's size yet
                continue;
            }
            let (bar, rows, redrawn) = (a.bar, a.rows as usize, c.ambient.redraw);
            let mut bytes =
                if redrawn && !self.tracker.alt { redraw(&self.emulator, &self.tracker, None) } else { Vec::new() };
            let line = if bar { self.bar_for(conn) } else { String::new() };
            if bar {
                bytes.extend(draw_bar(&self.emulator, &self.tracker, rows, self.pty.cols as usize, &line).bytes());
            }
            let Some(c) = self.clients.get_mut(&conn) else { continue };
            c.adapter.underneath(&bytes, cap);
            c.ambient.shown = line;
            c.ambient.redraw = false;
            c.ambient.due = false;
        }
        if later {
            self.bar_soon(BAR_SOON_MS * 4);
        }
    }

    /// A line above the screen of each terminal that has seen a day end, once the session is quiet.
    fn day_lines(&mut self) {
        if self.now.time.since(self.last_output_at) < QUIET_MS || !self.screen_writable() {
            return;
        }
        let day = day_of(self.now.wall_ms, &self.ambient.zone);
        let cap = self.config.clients.queue_cap_bytes;
        let conns: Vec<ConnId> = self.clients.keys().copied().collect();
        for conn in conns {
            let Some(c) = self.clients.get(&conn) else { continue };
            let a = &c.adapter;
            if !live(c) || !a.out.is_empty() || a.cols != self.pty.cols || a.rows != self.pty.rows {
                continue;
            }
            if !c.ambient.day.is_empty() && c.ambient.day != day.key {
                let (bar, rows, cols) = (a.bar, a.rows as usize, a.cols as usize);
                let line = format!("── {} · {} · {} ──", day.words, self.ambient.zone.name(), self.name());
                let mut bytes = redraw(&self.emulator, &self.tracker, Some(&cut_units(&line, cols.saturating_sub(1))));
                if bar {
                    let shown = self.bar_for(conn);
                    bytes.extend(draw_bar(&self.emulator, &self.tracker, rows, self.pty.cols as usize, &shown).bytes());
                }
                if let Some(c) = self.clients.get_mut(&conn) {
                    c.adapter.underneath(&bytes, cap);
                }
            }
            if let Some(c) = self.clients.get_mut(&conn) {
                c.ambient.day.clone_from(&day.key);
            }
        }
    }

    /// Whether writing the screen over now does exactly that and nothing else.
    fn screen_writable(&self) -> bool {
        let modes = &self.tracker.modes;
        if self.tracker.alt
            || self.pipeline.as_ref().is_some_and(|p| !p.quiescent())
            || modes.raw(SYNC_MODE) == 1
            || modes.raw(ORIGIN_MODE) == 1
            || self.emulator.term().modes().insert
        {
            return false;
        }
        let (top, bottom) = self.emulator.margins();
        !self.emulator.tracking() || (top == 0 && bottom + 1 == self.emulator.rows())
    }
}
