//! Control messages: JSON objects with a `t` field, one variant of [`Control`] for each `t` the Node code sends.
//!
//! Field names are those on the wire. A field the Node code may leave out is an `Option`, left out again when `None`. Where
//! null and absent differ, or only writing null back gives the same bytes, it is an `Option` of an `Option` or of a
//! [`Value`]: `None` is absent and `Some(null)` is null.
//!
//! New fields are additive, and either side can be the older. So a message the Node code passes on whole keeps what this
//! side does not name in `extra`, in the order it came. A `t` nobody knows arrives as [`Control::Unknown`] with all its
//! fields, and so does a known `t` with a field missing or of another type than the Node code ever sends there, which
//! another implementation would have to be broken to send. Open payloads, a request's arguments, a reply's data, an event's
//! fields and what a client only passes back, stay [`Value`]s.

use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};

use crate::framing::{ErrorCode, ProtocolError};
use crate::holder_wire::{HHello, Lflag};
use crate::proto::CTL_PROTO;

/// Fields a message carries that this side does not name, in the order they came.
pub type Extra = Map<String, Value>;

/// A control message.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(tag = "t", rename_all = "SCREAMING_SNAKE_CASE", rename_all_fields = "camelCase")]
pub enum Control {
    // ---- ctl.sock, from a client --------------------------------------------------------------------------------------
    /// The first message of a connection.
    Hello(Hello),
    /// A control client's request. `args` is the operation's own.
    Req {
        /// Echoed in the [`Control::Res`].
        id: Value,
        /// `STATUS`, `SEND`, `RUN` and so on.
        op: String,
        /// The operation's arguments, an object.
        args: Value,
    },
    /// The client is leaving.
    Detach {
        /// How many OUTPUT bytes it had when it left.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        received: Option<u64>,
        /// It reads on until its BYE, so everything sent before then reaches it, and it is remembered as having it all.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        drain: Option<bool>,
    },
    /// The client wants the picture behind the screen drawn again: it forgot it, at a new size.
    Redraw,
    /// The client wants its screen drawn again.
    Resync {
        /// `false`: it has left the alternate screen.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        alt: Option<bool>,
        /// Output it dropped.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        skipped: Option<u64>,
    },
    // ---- ctl.sock, from the server ------------------------------------------------------------------------------------
    /// The answer to a HELLO that is let in.
    Welcome(Welcome),
    /// The session's state, sent whenever it changes.
    State(State),
    /// The answer to a [`Control::Req`].
    Res(Res),
    /// Something a subscriber asked to hear about.
    Event(Event),
    /// The answer to a HELLO that is not let in. The connection ends after it.
    Refuse {
        /// `PROTO`, `BELOW_FLOOR`, `TOO_SHORT`, `STOPPING` and so on.
        code: String,
        /// The size the terminal needs, or null.
        need: Option<Size>,
        /// For a person.
        text: String,
    },
    /// The server is letting this client go.
    Bye(Bye),
    /// Something for the person at the terminal.
    Notice {
        /// `info` or `warn`.
        level: String,
        /// What it is about.
        code: String,
        /// For a person.
        text: String,
    },
    /// A join's snapshot starts.
    SnapshotBegin {
        /// History lines in it.
        lines: u64,
        /// Where history was cut, or null.
        truncated_before: Option<u64>,
    },
    /// A join's snapshot is complete, and live output follows.
    SnapshotEnd,
    /// A redraw of the screen starts.
    ResyncBegin,
    // ---- either socket, either way ------------------------------------------------------------------------------------
    /// Asks for a [`Control::Pong`] with the same `seq`.
    Ping {
        /// Echoed.
        seq: u64,
    },
    /// The answer to a [`Control::Ping`].
    Pong {
        /// The ping's.
        seq: u64,
    },
    /// A client's new size, or the size the server gives the pty.
    Resize {
        /// Columns.
        cols: u32,
        /// Rows: the session's, which nmux's bar is not among.
        rows: u32,
        /// From a client: whether nmux's bar is on its terminal's last row now, below `rows`.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        bar: Option<bool>,
    },
    /// Something was refused: `BUSY`, `FORBIDDEN`, `WRITE_OVERFLOW` and so on.
    Err(ErrorMessage),
    // ---- pty.sock, from the holder ------------------------------------------------------------------------------------
    /// The holder's first message.
    HHello(HHello),
    /// The pty's local modes and foreground process group.
    Lflag(Lflag),
    /// The child has exited. It never overtakes the child's last output.
    Exit(Exit),
    /// Output was lost from the ring before it could be sent.
    Gap {
        /// The first offset lost.
        from: u64,
        /// The offset sending goes on from.
        to: u64,
    },
    /// The bytes of a watched WRITE are written.
    Consumed {
        /// The WRITE's id.
        watch_id: u32,
    },
    /// A query only the server can answer, CPR or DECXCPR, at an offset in the stream.
    QueryFwd {
        /// Echoed in the [`Control::QueryReply`].
        id: u32,
        /// `CPR` or `DECXCPR`.
        kind: String,
        /// Where the query ends in the stream.
        offset: u64,
    },
    /// The pty has the size the server asked for, from this offset on.
    Resized(Resized),
    // ---- pty.sock, from the server ------------------------------------------------------------------------------------
    /// The server starts taking output.
    Attach {
        /// The holder sends from here, or from the start of its ring, with a GAP if it skipped.
        from_offset: u64,
        /// The server's pid.
        pid: u32,
        /// It will acknowledge what it parsed: see [`HHello::flow`].
        #[serde(default)]
        flow: bool,
    },
    /// Everything before this offset has been parsed.
    Ack {
        /// The offset.
        offset: u64,
    },
    /// A signal for the child: `SIGCONT` or `SIGTERM`, nothing stronger.
    Signal {
        /// Its name.
        sig: String,
    },
    /// Hang up the pty.
    CloseMaster,
    /// The child has exited and the holder may go.
    Release,
    /// The answer to a [`Control::QueryFwd`].
    QueryReply {
        /// The query's.
        id: u32,
        /// The reply, base64 on the wire. Empty means there is none.
        #[serde(with = "base64")]
        bytes: Vec<u8>,
    },
    /// A message whose `t` this side does not know, or whose fields are not what it expects, with all its fields.
    #[serde(untagged, skip_deserializing)]
    Unknown(Extra),
}

impl Control {
    /// Reads a control payload. Invalid UTF-8 becomes U+FFFD first, as it does in Node.
    pub(crate) fn parse(payload: &[u8]) -> Result<Self, ProtocolError> {
        let text = String::from_utf8_lossy(payload);
        let value = serde_json::from_str(&text)
            .or_else(|_| serde_json::from_str(&without_lone_surrogates(&text)))
            .map_err(|_| ProtocolError::new(ErrorCode::BadJson, "control frame is not valid JSON"))?;
        let Value::Object(fields) = value else {
            return Err(ProtocolError::new(ErrorCode::BadJson, "control frame is not a JSON object"));
        };
        // serde would read a number in `t` as the index of a variant.
        let tagged = fields.get("t").is_some_and(Value::is_string);
        let known = if tagged { Self::deserialize(&fields).ok() } else { None };
        Ok(known.unwrap_or_else(|| Self::Unknown(fields)))
    }
}

/// `JSON.parse` takes an escaped lone surrogate, which JavaScript makes when it cuts a string in two, and `serde_json`
/// refuses one. It becomes U+FFFD, as it does wherever such a string meets UTF-8.
fn without_lone_surrogates(text: &str) -> String {
    let unit = |s: &str| s.strip_prefix("\\u").and_then(|h| h.get(..4)).and_then(|h| u16::from_str_radix(h, 16).ok());
    let mut out = String::with_capacity(text.len());
    let mut rest = text;
    while let Some(at) = rest.find('\\') {
        out.push_str(&rest[..at]);
        rest = &rest[at..];
        let len = match unit(rest) {
            Some(0xd800..=0xdbff) if unit(&rest[6..]).is_some_and(|low| (0xdc00..=0xdfff).contains(&low)) => 12,
            Some(0xd800..=0xdfff) => {
                out.push_str("\\ufffd");
                rest = &rest[6..];
                continue;
            }
            Some(_) => 6,
            None => rest.chars().take(2).map(char::len_utf8).sum(),
        };
        out.push_str(&rest[..len]);
        rest = &rest[len..];
    }
    out.push_str(rest);
    out
}

/// A terminal's size, or a pty's.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Size {
    /// Columns.
    pub cols: u32,
    /// Rows.
    pub rows: u32,
}

/// A client's greeting.
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Hello {
    /// [`CTL_PROTO`] for this version.
    pub proto: u32,
    /// `attach` or `control`.
    pub role: String,
    /// The terminal's columns, 0 for a control client.
    pub cols: u32,
    /// The terminal's rows, 0 for a control client.
    pub rows: u32,
    /// Where the cursor is.
    pub cursor_row: u32,
    /// The terminal has focus.
    pub focus: bool,
    /// The client's tty.
    pub tty: Option<String>,
    /// The client's pid.
    pub pid: u32,
    /// What lists of clients call it.
    pub label: String,
    /// `TERM_PROGRAM`.
    pub term_program: Option<String>,
    /// What the terminal calls itself, so that coming back to it can be recognised. Only an attach client sends it.
    #[serde(skip_serializing_if = "Option::is_none", with = "present")]
    pub terminal: Option<Option<String>>,
    /// The client's `SSH_AUTH_SOCK`. Only an attach client sends it.
    #[serde(skip_serializing_if = "Option::is_none", with = "present")]
    pub agent: Option<Option<String>>,
    /// What the last server said in its BYE about how far this terminal had got: see [`Resume`]. Only an attach client
    /// sends it.
    #[serde(skip_serializing_if = "Option::is_none", with = "present")]
    pub resume: Option<Value>,
    /// The terminal's own colours, which a tint behind the screen is worked out from. Only an attach client sends them.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub colors: Option<Colors>,
    /// How the client takes part.
    pub flags: Flags,
    /// Fields this side does not name.
    #[serde(flatten)]
    pub extra: Extra,
}

impl Hello {
    /// The greeting of a control connection, which never counts as a terminal.
    pub fn control(pid: u32, label: &str) -> Self {
        Self {
            proto: CTL_PROTO,
            role: "control".to_owned(),
            pid,
            label: label.to_owned(),
            flags: Flags { shrink: Some(false), allow_setup: Some(false), ..Flags::default() },
            ..Self::default()
        }
    }
}

/// A HELLO's flags. A flag left out is off.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Flags {
    /// May go below the usual floor, down to the hard minimum.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub shrink: Option<bool>,
    /// May type through gates.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub allow_gated: Option<bool>,
    /// The older name of `allow_gated`.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub allow_setup: Option<bool>,
    /// Only watches.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub view: Option<bool>,
    /// nmux's bar is on the terminal's last row, below the rows it says it has.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub bar: Option<bool>,
    /// The terminal shows any colour, as `COLORTERM` says.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub truecolor: Option<bool>,
    /// The terminal still shows the screen it left, which coming back writes over instead of adding to its scrollback.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub same_screen: Option<bool>,
}

impl Flags {
    /// The client may go below the floor.
    pub fn shrink(&self) -> bool {
        self.shrink == Some(true)
    }

    /// The client may type through gates, by either name.
    pub fn allow_gated(&self) -> bool {
        self.allow_gated == Some(true) || self.allow_setup == Some(true)
    }

    /// The client only watches.
    pub fn view(&self) -> bool {
        self.view == Some(true)
    }

    /// nmux's bar is on the terminal's last row.
    pub fn bar(&self) -> bool {
        self.bar == Some(true)
    }

    /// The terminal shows any colour.
    pub fn truecolor(&self) -> bool {
        self.truecolor == Some(true)
    }

    /// The terminal still shows the screen it left.
    pub fn same_screen(&self) -> bool {
        self.same_screen == Some(true)
    }
}

/// A terminal's default colours, as OSC 10 and 11 report them: `rgb:…` or `#…`. Either may be missing.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default)]
pub struct Colors {
    /// The default foreground.
    pub fg: Option<String>,
    /// The default background.
    pub bg: Option<String>,
}

/// Where a terminal had got when its server went, as a BYE says and the next HELLO repeats. A client only passes it on;
/// the server reads it, and finds nothing it can use in anything else.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Resume {
    /// The holder generation it was read from.
    #[serde(rename = "gen")]
    pub generation: u64,
    /// The stream offset the terminal had.
    pub offset: u64,
    /// The terminal's columns.
    pub cols: u32,
    /// The terminal's rows.
    pub rows: u32,
}

/// The answer to a HELLO that is let in.
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Welcome {
    /// [`CTL_PROTO`]
    pub proto: u32,
    /// The session's id.
    pub id: String,
    /// What the session's controller adds.
    #[serde(flatten)]
    pub extra: Extra,
    /// The session's name.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    /// This client's id.
    pub client_id: String,
    /// The pty's size.
    pub pty: Size,
    /// The session's lifecycle state.
    pub lifecycle: String,
    /// The size rules.
    pub policy: Policy,
    /// The heartbeat.
    pub ping: PingPolicy,
}

/// The size rules a server applies.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Policy {
    /// Fewer columns than this pauses a client.
    pub floor_cols: u32,
    /// Fewer rows than this pauses a client.
    pub floor_rows: u32,
    /// The floor for a client that asked to shrink.
    pub hard_min_cols: u32,
}

/// The heartbeat a server keeps.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct PingPolicy {
    /// How often it pings.
    pub interval_ms: u64,
    /// How long it waits for a pong.
    pub timeout_ms: u64,
}

/// The session's state.
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct State {
    /// The lifecycle state.
    pub lifecycle: String,
    /// The session's name. A server that predates it puts it elsewhere: see [`crate::name_of_state`].
    #[serde(skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    /// What the session's controller publishes.
    #[serde(flatten)]
    pub extra: Extra,
    /// The pty's size.
    pub pty: Size,
    /// The child is on the alternate screen.
    pub alt: bool,
    /// The attached clients.
    pub clients: Vec<ClientInfo>,
}

/// An attached client, as STATE lists it.
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ClientInfo {
    /// Its id.
    pub id: String,
    /// Its label.
    pub label: String,
    /// It only watches.
    pub view: bool,
    /// Its columns.
    pub cols: u32,
    /// Its rows.
    pub rows: u32,
    /// Where it is in a join.
    pub phase: String,
    /// It stopped reading.
    pub stalled: bool,
    /// It stopped answering pings.
    pub unresponsive: bool,
    /// When it last typed, in the server's monotonic milliseconds, which are fractional in Node; 0 if never.
    #[serde(with = "js_number")]
    pub last_input_at: f64,
    /// Fields this side does not name.
    #[serde(flatten)]
    pub extra: Extra,
}

/// The answer to a request.
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Res {
    /// The request's.
    pub id: Value,
    /// It worked.
    pub ok: bool,
    /// What it returned.
    #[serde(skip_serializing_if = "Option::is_none", with = "present")]
    pub data: Option<Value>,
    /// Why it did not work.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
    /// Fields this side does not name.
    #[serde(flatten)]
    pub extra: Extra,
}

/// Something a subscriber asked to hear about.
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct Event {
    /// What happened: `lifecycle`, `command` and so on.
    pub event: String,
    /// What the event says, which depends on it.
    #[serde(flatten)]
    pub fields: Extra,
}

/// The server is letting a client go.
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Bye {
    /// `USER`, `KICKED`, `SESSION_ENDING`, `STALLED` and so on.
    pub reason: String,
    /// The client should come back by itself.
    pub auto_rejoin: bool,
    /// For a person.
    pub text: String,
    /// Who sent it away, with `KICKED`.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub by: Option<String>,
    /// The size it needs, with `BELOW_FLOOR`.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub need: Option<Size>,
    /// How the child ended: an exit code, a signal's name or null. Being there at all says the session ended.
    #[serde(skip_serializing_if = "Option::is_none", with = "present")]
    pub ended: Option<Value>,
    /// Where the terminal had got, to give the next server: see [`Resume`].
    #[serde(skip_serializing_if = "Option::is_none", with = "present")]
    pub resume: Option<Value>,
    /// Fields this side does not name.
    #[serde(flatten)]
    pub extra: Extra,
}

/// ERR
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct ErrorMessage {
    /// What was refused.
    pub code: String,
    /// The signal that was refused, with `FORBIDDEN`.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sig: Option<String>,
    /// Fields this side does not name.
    #[serde(flatten)]
    pub extra: Extra,
}

/// The child's exit, as the holder saw it.
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Exit {
    /// The exit code, if it exited.
    pub code: Option<i64>,
    /// The signal's name, if a signal ended it.
    pub signal: Option<String>,
    /// When, as an ISO 8601 date.
    pub at: String,
    /// The holder was shutting down.
    pub shutting_down: bool,
    /// `pty` or `proc`.
    pub detected_by: String,
    /// What went wrong starting it.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
    /// Fields this side does not name.
    #[serde(flatten)]
    pub extra: Extra,
}

/// The pty's size from an offset on: a RESIZED message, and an entry of the holder's resize log.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default)]
pub struct Resized {
    /// The stream offset it applies from.
    pub offset: u64,
    /// Columns.
    pub cols: u32,
    /// Rows.
    pub rows: u32,
}

/// Keeps a field that is null apart from one that is not there: with `skip_serializing_if = "Option::is_none"`, `None` is
/// left out and `Some` is written, whatever it holds.
mod present {
    use serde::{Deserialize, Deserializer, Serialize, Serializer};

    #[allow(clippy::ref_option)] // serde's signature
    pub fn serialize<T: Serialize, S: Serializer>(value: &Option<T>, serializer: S) -> Result<S::Ok, S::Error> {
        value.serialize(serializer)
    }

    pub fn deserialize<'de, T: Deserialize<'de>, D: Deserializer<'de>>(deserializer: D) -> Result<Option<T>, D::Error> {
        T::deserialize(deserializer).map(Some)
    }
}

/// A number as JavaScript writes one: without a fraction when it has none.
mod js_number {
    use serde::{Deserialize, Deserializer, Serializer};

    /// Below this every integer is exact in a double, and JavaScript writes none with an exponent.
    const EXACT: f64 = 9_007_199_254_740_992.0;

    #[allow(clippy::trivially_copy_pass_by_ref)] // serde's signature
    pub fn serialize<S: Serializer>(value: &f64, serializer: S) -> Result<S::Ok, S::Error> {
        if value.fract() == 0.0 && value.abs() < EXACT {
            #[allow(clippy::cast_possible_truncation)] // exact: it is an integer below 2^53
            return serializer.serialize_i64(*value as i64);
        }
        serializer.serialize_f64(*value)
    }

    pub fn deserialize<'de, D: Deserializer<'de>>(deserializer: D) -> Result<f64, D::Error> {
        f64::deserialize(deserializer)
    }
}

/// Bytes as base64, as `Buffer` writes and reads it. Reading is as lenient as Node's: anything outside the alphabet is
/// skipped, the URL-safe alphabet is taken too, and the first `=` ends it.
mod base64 {
    use serde::{Deserialize, Deserializer, Serializer};

    const ALPHABET: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    pub fn serialize<S: Serializer>(bytes: &[u8], serializer: S) -> Result<S::Ok, S::Error> {
        let mut out = String::with_capacity(bytes.len().div_ceil(3) * 4);
        for group in bytes.chunks(3) {
            let n = group.iter().enumerate().fold(0u32, |n, (i, &b)| n | (u32::from(b) << (16 - 8 * i)));
            for i in 0..4 {
                let digit = if i <= group.len() { ALPHABET[(n >> (18 - 6 * i)) as usize & 0x3f] } else { b'=' };
                out.push(char::from(digit));
            }
        }
        serializer.serialize_str(&out)
    }

    fn value(c: u8) -> Option<u32> {
        let v = match c {
            b'A'..=b'Z' => c - b'A',
            b'a'..=b'z' => c - b'a' + 26,
            b'0'..=b'9' => c - b'0' + 52,
            b'+' | b'-' => 62,
            b'/' | b'_' => 63,
            _ => return None,
        };
        Some(u32::from(v))
    }

    pub fn deserialize<'de, D: Deserializer<'de>>(deserializer: D) -> Result<Vec<u8>, D::Error> {
        let text = String::deserialize(deserializer)?;
        let digits: Vec<u32> = text.bytes().take_while(|&c| c != b'=').filter_map(value).collect();
        let mut out = Vec::with_capacity(digits.len() * 3 / 4);
        for group in digits.chunks(4) {
            let n = group.iter().enumerate().fold(0u32, |n, (i, &d)| n | (d << (18 - 6 * i)));
            let [_, a, b, c] = n.to_be_bytes();
            out.extend_from_slice(&[a, b, c][..group.len().saturating_sub(1)]);
        }
        Ok(out)
    }
}
