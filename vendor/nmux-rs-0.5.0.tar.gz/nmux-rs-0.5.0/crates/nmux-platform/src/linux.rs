//! Linux: process information from /proc, as `linux.js` reads it, and the Linux answers to the rest of the surface.

use std::collections::HashMap;
use std::fs;
use std::io;
use std::os::fd::BorrowedFd;
use std::path::Path;
use std::process::Command;
use std::time::Duration;

use crate::process::{Capabilities, ProcState, Process, ShutdownEvidence, run_within};

pub(crate) const CAPABILITIES: Capabilities =
    Capabilities { reports_zombie_parent: true, hangup_on_master_close: true, orphan_scan: true, proc_source: "/proc" };

pub(crate) const OOM_SCORE_ADJ_PATH: Option<&str> = Some("/proc/self/oom_score_adj");

pub(crate) const SHUTDOWN_SCHEDULED: &str = "/run/systemd/shutdown/scheduled";

/// What `execvp(3)` searches when the environment has no PATH: glibc's `confstr(_CS_PATH)`.
pub(crate) const DEFAULT_PATH: &[u8] = b"/bin:/usr/bin";

/// node-pty's child prints why it could not start, with `perror`, onto the pty before it exits.
pub(crate) const EXEC_FAILURE_SAYS_WHY: bool = true;

/// `NSIG`: one more than the highest signal number.
pub(crate) const SIGNAL_LIMIT: i32 = 65;

/// `os.constants.signals` as Node lists it here, so that a number gets the name Node gives it: the first with that number.
pub(crate) const SIGNAL_NAMES: &[(&str, i32)] = &[
    ("SIGHUP", libc::SIGHUP),
    ("SIGINT", libc::SIGINT),
    ("SIGQUIT", libc::SIGQUIT),
    ("SIGILL", libc::SIGILL),
    ("SIGTRAP", libc::SIGTRAP),
    ("SIGABRT", libc::SIGABRT),
    ("SIGIOT", libc::SIGIOT),
    ("SIGBUS", libc::SIGBUS),
    ("SIGFPE", libc::SIGFPE),
    crate::signals::UNCATCHABLE,
    ("SIGUSR1", libc::SIGUSR1),
    ("SIGSEGV", libc::SIGSEGV),
    ("SIGUSR2", libc::SIGUSR2),
    ("SIGPIPE", libc::SIGPIPE),
    ("SIGALRM", libc::SIGALRM),
    ("SIGTERM", libc::SIGTERM),
    ("SIGCHLD", libc::SIGCHLD),
    ("SIGSTKFLT", libc::SIGSTKFLT),
    ("SIGCONT", libc::SIGCONT),
    ("SIGSTOP", libc::SIGSTOP),
    ("SIGTSTP", libc::SIGTSTP),
    ("SIGTTIN", libc::SIGTTIN),
    ("SIGTTOU", libc::SIGTTOU),
    ("SIGURG", libc::SIGURG),
    ("SIGXCPU", libc::SIGXCPU),
    ("SIGXFSZ", libc::SIGXFSZ),
    ("SIGVTALRM", libc::SIGVTALRM),
    ("SIGPROF", libc::SIGPROF),
    ("SIGWINCH", libc::SIGWINCH),
    ("SIGIO", libc::SIGIO),
    ("SIGPOLL", libc::SIGPOLL),
    ("SIGPWR", libc::SIGPWR),
    ("SIGSYS", libc::SIGSYS),
];

/// Where this thread's errno is, for a signal handler to keep it as it found it.
pub(crate) fn errno_location() -> *mut libc::c_int {
    // SAFETY: `__errno_location` has no preconditions and returns this thread's errno, which lives as long as the thread.
    unsafe { libc::__errno_location() }
}

/// Fields 3 on of /proc/<pid>/stat: index 0 is field 3, the state. The command name may hold spaces and parentheses, so
/// the fields are read after the last `)`.
fn stat_fields(pid: i32) -> Option<Vec<String>> {
    let s = fs::read(format!("/proc/{pid}/stat")).ok()?;
    let close = s.iter().rposition(|&b| b == b')')?;
    let rest = s.get(close + 2..).unwrap_or_default();
    let text: String = rest.iter().map(|&b| char::from(b)).collect();
    Some(text.trim().split(' ').map(str::to_owned).collect())
}

fn number(field: Option<&String>) -> Option<i32> {
    field?.parse().ok()
}

/// Field 22: clock ticks since boot.
pub(crate) fn proc_start(pid: i32) -> Option<String> {
    let mut fields = stat_fields(pid)?;
    (fields.len() > 19).then(|| fields.swap_remove(19))
}

pub(crate) fn proc_state(pid: i32) -> ProcState {
    match stat_fields(pid).as_ref().and_then(|f| f.first()).map(String::as_str) {
        None | Some("X" | "x") => ProcState::Gone,
        Some("Z") => ProcState::Zombie,
        Some(_) => ProcState::Alive,
    }
}

/// Field 5.
pub(crate) fn pgid(pid: i32) -> Option<i32> {
    number(stat_fields(pid)?.get(2))
}

/// Field 4.
pub(crate) fn ppid(pid: i32) -> Option<i32> {
    number(stat_fields(pid)?.get(1))
}

/// Field 6.
pub(crate) fn proc_sid(pid: i32) -> Option<i32> {
    number(stat_fields(pid)?.get(3))
}

pub(crate) fn boot_id() -> io::Result<String> {
    Ok(fs::read_to_string("/proc/sys/kernel/random/boot_id")?.trim().to_owned())
}

pub(crate) fn machine_id() -> io::Result<String> {
    Ok(fs::read_to_string("/etc/machine-id")?.trim().to_owned())
}

pub(crate) fn read_environ(pid: i32) -> Option<HashMap<String, String>> {
    let raw = fs::read(format!("/proc/{pid}/environ")).ok()?;
    let raw = String::from_utf8_lossy(&raw);
    let mut env = HashMap::new();
    for entry in raw.split('\0') {
        if let Some((name, value)) = entry.split_once('=').filter(|(name, _)| !name.is_empty()) {
            env.insert(name.to_owned(), value.to_owned());
        }
    }
    Some(env)
}

pub(crate) fn read_argv(pid: i32) -> Option<Vec<String>> {
    let raw = fs::read(format!("/proc/{pid}/cmdline")).ok()?;
    Some(String::from_utf8_lossy(&raw).split('\0').filter(|a| !a.is_empty()).map(str::to_owned).collect())
}

pub(crate) fn command_line(pid: i32) -> Option<String> {
    read_argv(pid).filter(|argv| !argv.is_empty()).map(|argv| argv.join(" "))
}

pub(crate) fn cwd_of(pid: i32) -> Option<String> {
    Some(fs::read_link(format!("/proc/{pid}/cwd")).ok()?.to_string_lossy().into_owned())
}

pub(crate) fn list_pids() -> Vec<i32> {
    let Ok(dir) = fs::read_dir("/proc") else { return Vec::new() };
    dir.filter_map(|entry| {
        let name = entry.ok()?.file_name();
        let name = name.to_str()?;
        if name.is_empty() || !name.bytes().all(|b| b.is_ascii_digit()) {
            return None;
        }
        name.parse().ok()
    })
    .collect()
}

pub(crate) fn list_processes() -> Vec<Process> {
    list_pids()
        .into_iter()
        .map(|pid| Process { pid, ppid: ppid(pid), argv: read_argv(pid).map(|argv| argv.join(" ")) })
        .collect()
}

pub(crate) fn pid_ns(pid: i32) -> Option<String> {
    let link = fs::read_link(format!("/proc/{pid}/ns/pid")).ok()?;
    let link = link.to_string_lossy();
    let open = link.find('[')?;
    let digits: String = link[open + 1..].chars().take_while(char::is_ascii_digit).collect();
    let closed = link[open + 1 + digits.len()..].starts_with(']');
    (closed && !digits.is_empty()).then_some(digits)
}

pub(crate) fn tty_of(pid: i32) -> Option<String> {
    let link = fs::read_link(format!("/proc/{pid}/fd/0")).ok()?;
    let link = link.to_string_lossy().into_owned();
    (link.starts_with("/dev/") && link != "/dev/null").then_some(link)
}

pub(crate) fn self_tty() -> Option<String> {
    Some(fs::read_link("/proc/self/fd/0").ok()?.to_string_lossy().into_owned())
}

/// From /proc's `hidepid` mount option.
pub(crate) fn argv_visible_to_others(mounts: Option<&Path>) -> bool {
    match fs::read_to_string(mounts.unwrap_or(Path::new("/proc/mounts"))) {
        Ok(text) => !crate::hidepid_enabled(&text),
        Err(_) => true,
    }
}

/// systemd's: a scheduled shutdown, or a system that says it is stopping.
pub(crate) fn shutdown_corroborated(evidence: &ShutdownEvidence<'_>) -> bool {
    if evidence.scheduled.exists() {
        return true;
    }
    let mut command = Command::new(evidence.systemctl);
    command.arg("is-system-running");
    run_within(&mut command, Duration::from_secs(2)).is_some_and(|ran| ran.stdout.trim() == "stopping")
}

/// `SO_PEERCRED`.
pub(crate) fn peer_uid(fd: BorrowedFd<'_>) -> io::Result<u32> {
    Ok(rustix::net::sockopt::socket_peercred(fd)?.uid.as_raw())
}

/// Special characters node-pty sets only on some platforms: none here.
pub(crate) fn more_special_chars(_cc: &mut [libc::cc_t]) {}

/// TIOCSCTTY: the terminal on `fd` becomes this session's controlling terminal.
///
/// # Safety
///
/// For a session leader without a controlling terminal, such as a child just after setsid(2). Async-signal-safe.
pub(crate) unsafe fn set_controlling_terminal(fd: libc::c_int) {
    // SAFETY: the ioctl takes an integer argument and touches no memory of ours.
    unsafe { libc::ioctl(fd, libc::TIOCSCTTY, 0) };
}
