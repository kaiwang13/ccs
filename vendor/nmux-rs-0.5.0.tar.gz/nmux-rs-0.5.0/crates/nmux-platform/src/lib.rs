//! Everything that differs between Linux and macOS, behind one surface, from `src/platform` and `native/ttyctl` in the
//! Node code, and what node-pty did there: process identity and liveness, a pty's modes and foreground group, locks, the
//! runtime directory, peers on a unix socket, signals, and starting a program on a pty.
//!
//! Callers ask a question (`proc_start`, `argv_visible_to_others`, [`CAPABILITIES`]) and never which OS this is:
//! `#[cfg(target_os)]` appears in this crate only, and chooses between `linux.rs` and `darwin.rs`, which answer the same
//! questions under the same names.
//!
//! This crate also holds the project's `unsafe`: system calls that have no safe wrapper, each with a `// SAFETY:` comment
//! saying why it is sound. Its `Cargo.toml` sets the workspace's lints for this crate alone, with `unsafe_code` allowed
//! and `clippy::undocumented_unsafe_blocks` denied.

#[cfg(not(any(target_os = "linux", target_os = "macos")))]
compile_error!("nmux runs on Linux and macOS");

#[cfg(target_os = "macos")]
#[path = "darwin.rs"]
mod os;
#[cfg(target_os = "linux")]
#[path = "linux.rs"]
mod os;

mod ctime;
mod locks;
mod mounts;
mod process;
mod pty;
mod runtime;
mod signals;
mod sock;
mod spawn;
mod term;
mod tty;

pub use ctime::{ctime_utc, iso_utc};
pub use locks::{Lock, flock, is_locked, try_lock};
pub use mounts::hidepid_enabled;
pub use process::{
    CAPABILITIES, Capabilities, OOM_SCORE_ADJ_PATH, ProcState, Process, ShutdownEvidence, argv_visible_to_others,
    boot_id, command_line, cwd_of, hostname, is_same_process, list_pids, list_processes, machine_id, pgid, pid_ns,
    ppid, proc_sid, proc_start, proc_state, read_argv, read_environ, same_proc_start, self_tty, shutdown_corroborated,
    tty_of,
};
pub use pty::{PtyCommand, Spawned, set_winsize, spawn_pty};
pub use runtime::{RuntimeError, SUBDIRS, ensure_runtime, ensure_safe_dir};
pub use signals::{Exited, Shield, Signal, SignalPipe, kill, reap, signal_name, signal_number, stop_self};
pub use sock::{peer_uid, pid, uid};
pub use spawn::{spawn_detached, spawn_detached_with};
pub use term::{RawMode, is_terminal, window_size};
pub use tty::{Lflags, inq, lflag, open_slave, tcgetpgrp};
