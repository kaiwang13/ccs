//! Process identity and the machine's: `procinfo.js`, and the surface of `platform/index.js` it re-exports.
//!
//! A process is its pid and its start time, so a pid used again is never taken for the one recorded. How the start time
//! is written differs between the OSes, on purpose: on Linux it is clock ticks since boot, on macOS a ctime string (see
//! [`crate::ctime_utc`]). A record from one is never mistaken for a live process on the other, which is the safe way to
//! be wrong.

use std::collections::HashMap;
use std::ffi::OsStr;
use std::io::{self, Read};
use std::os::fd::AsFd;
use std::path::Path;
use std::process::{Child, Command, Stdio};
use std::sync::OnceLock;
use std::time::{Duration, Instant};

use crate::os;

/// Whether a process is there.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ProcState {
    /// Running, sleeping or stopped.
    Alive,
    /// Exited, and not yet collected by its parent.
    Zombie,
    /// Not there.
    Gone,
}

impl ProcState {
    /// `alive`, `zombie` or `gone`, as the Node code says it.
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Alive => "alive",
            Self::Zombie => "zombie",
            Self::Gone => "gone",
        }
    }
}

/// A process as [`list_processes`] sees it.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Process {
    /// Its pid.
    pub pid: i32,
    /// Its parent, where that can be read.
    pub ppid: Option<i32>,
    /// Its command line as one string, where that can be read.
    pub argv: Option<String>,
}

/// What callers ask as "can this platform do X?", so that none of them has to ask which OS this is.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)] // one answer each
pub struct Capabilities {
    /// A defunct process still reports its parent, so a zombie can be matched to the one that started it.
    pub reports_zombie_parent: bool,
    /// Closing a pty master hangs up the slave, so the child gets SIGHUP. Where it does not, a stop has to go on to
    /// SIGTERM.
    pub hangup_on_master_close: bool,
    /// Another process's environment can be read, which the orphan scan is built on.
    pub orphan_scan: bool,
    /// Where process information comes from, for a diagnostic report.
    pub proc_source: &'static str,
}

/// This platform's answers.
pub const CAPABILITIES: Capabilities = os::CAPABILITIES;

/// The file a server writes to bias the OOM killer away from itself, or `None` where there is no such thing.
pub const OOM_SCORE_ADJ_PATH: Option<&str> = os::OOM_SCORE_ADJ_PATH;

/// When the process started, as this platform writes it, or `None` when it is not there or cannot be read. Only its
/// stability and comparison with another reading matter, never its value.
pub fn proc_start(pid: i32) -> Option<String> {
    if pid <= 0 { None } else { os::proc_start(pid) }
}

/// Whether `pid` is there.
pub fn proc_state(pid: i32) -> ProcState {
    if pid <= 0 { ProcState::Gone } else { os::proc_state(pid) }
}

/// The process group of `pid`.
pub fn pgid(pid: i32) -> Option<i32> {
    if pid <= 0 { None } else { os::pgid(pid) }
}

/// The parent of `pid`.
pub fn ppid(pid: i32) -> Option<i32> {
    if pid <= 0 { None } else { os::ppid(pid) }
}

/// The session of `pid`.
pub fn proc_sid(pid: i32) -> Option<i32> {
    if pid <= 0 { None } else { os::proc_sid(pid) }
}

/// Is the process at `pid` still the one `start` was read from?
pub fn is_same_process(pid: i32, start: &str) -> bool {
    !start.is_empty() && proc_start(pid).is_some_and(|live| same_proc_start(start, &live))
}

/// Do a recorded start time and a live one name the same process? Both are written the same way on one platform, so this
/// is a comparison of strings, kept in one place so that the platforms cannot drift apart.
pub fn same_proc_start(recorded: &str, live: &str) -> bool {
    recorded == live
}

/// This boot, as an id that changes when the machine starts again. It is read once.
pub fn boot_id() -> io::Result<String> {
    static CACHE: OnceLock<String> = OnceLock::new();
    cached(&CACHE, os::boot_id)
}

/// This machine, as an id that stays the same across boots. It is read once.
pub fn machine_id() -> io::Result<String> {
    static CACHE: OnceLock<String> = OnceLock::new();
    cached(&CACHE, os::machine_id)
}

fn cached(cache: &OnceLock<String>, read: fn() -> io::Result<String>) -> io::Result<String> {
    if let Some(value) = cache.get() {
        return Ok(value.clone());
    }
    let value = read()?;
    Ok(cache.get_or_init(|| value).clone())
}

/// Another process's environment, or `None` where it cannot be read. A name given twice keeps its last value.
pub fn read_environ(pid: i32) -> Option<HashMap<String, String>> {
    if pid <= 0 { None } else { os::read_environ(pid) }
}

/// Another process's arguments, or `None` where they cannot be read.
pub fn read_argv(pid: i32) -> Option<Vec<String>> {
    if pid <= 0 { None } else { os::read_argv(pid) }
}

/// What a process is running, as one line.
pub fn command_line(pid: i32) -> Option<String> {
    if pid <= 0 { None } else { os::command_line(pid) }
}

/// A process's working directory.
pub fn cwd_of(pid: i32) -> Option<String> {
    if pid <= 0 { None } else { os::cwd_of(pid) }
}

/// Every pid this process can see.
pub fn list_pids() -> Vec<i32> {
    os::list_pids()
}

/// Every process this process can see, with its parent and command line, in one pass.
pub fn list_processes() -> Vec<Process> {
    os::list_processes()
}

/// The pid namespace a process is in, where there are such things.
pub fn pid_ns(pid: i32) -> Option<String> {
    if pid <= 0 { None } else { os::pid_ns(pid) }
}

/// The terminal a process reads from, where that can be read.
pub fn tty_of(pid: i32) -> Option<String> {
    if pid <= 0 { None } else { os::tty_of(pid) }
}

/// The terminal this process reads from.
pub fn self_tty() -> Option<String> {
    os::self_tty()
}

/// Can other accounts on this host read its processes' command lines? `mounts` points the Linux answer at another mount
/// table, for tests. A table that cannot be read gets the cautious answer: yes.
pub fn argv_visible_to_others(mounts: Option<&Path>) -> bool {
    os::argv_visible_to_others(mounts)
}

/// Where the evidence of a host shutdown is looked for. Tests point it elsewhere.
#[derive(Clone, Copy, Debug)]
pub struct ShutdownEvidence<'a> {
    /// A file that is there while a shutdown is scheduled.
    pub scheduled: &'a Path,
    /// The service manager's command.
    pub systemctl: &'a OsStr,
}

impl Default for ShutdownEvidence<'_> {
    fn default() -> Self {
        Self { scheduled: Path::new(os::SHUTDOWN_SCHEDULED), systemctl: OsStr::new("systemctl") }
    }
}

/// Independent evidence that the host is shutting down, so that a bare SIGTERM to a holder can be told apart from a
/// shutdown. It only reads. Where there is no such evidence to be had it is always false: the holder still treats SIGTERM
/// correctly, and only one message is less specific.
pub fn shutdown_corroborated(evidence: &ShutdownEvidence<'_>) -> bool {
    os::shutdown_corroborated(evidence)
}

/// What a command printed on its standard output, and how it ended. Linux only ever wants the first.
#[cfg_attr(target_os = "linux", allow(dead_code))]
pub(crate) struct Ran {
    /// It ended within the time it was given.
    pub finished: bool,
    /// It ended with status 0.
    pub ok: bool,
    /// What it printed, as far as it got.
    pub stdout: String,
}

/// Runs a command for what it prints, giving it `timeout`. One that takes longer is sent SIGTERM, as `execFileSync` and
/// `spawnSync` do with a timeout, and is waited for only a moment more: the holder's reaper collects it later.
pub(crate) fn run_within(command: &mut Command, timeout: Duration) -> Option<Ran> {
    let mut child = command.stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::null()).spawn().ok()?;
    let mut stdout = child.stdout.take()?;
    rustix::io::ioctl_fionbio(stdout.as_fd(), true).ok()?;
    let mut out = Vec::new();
    let mut buf = [0u8; 8192];
    let deadline = Instant::now() + timeout;
    let ended = loop {
        let wait = deadline.saturating_duration_since(Instant::now()).min(Duration::from_millis(20));
        let mut fds = [rustix::event::PollFd::new(&stdout, rustix::event::PollFlags::IN)];
        let _ = rustix::event::poll(&mut fds, rustix::event::Timespec::try_from(wait).ok().as_ref());
        read_available(&mut stdout, &mut buf, &mut out);
        match child.try_wait() {
            Ok(Some(status)) => break Some(status.success()),
            Err(_) => break Some(false),
            Ok(None) if Instant::now() >= deadline => break None,
            Ok(None) => {}
        }
    };
    read_available(&mut stdout, &mut buf, &mut out);
    if ended.is_none() {
        stop(&mut child);
    }
    Some(Ran { finished: ended.is_some(), ok: ended == Some(true), stdout: String::from_utf8_lossy(&out).into_owned() })
}

/// Reads what is there, without waiting for more.
fn read_available(r: &mut impl Read, buf: &mut [u8], out: &mut Vec<u8>) {
    loop {
        match r.read(buf) {
            Ok(0) => return,
            Ok(n) => out.extend_from_slice(&buf[..n]),
            Err(e) if e.kind() == io::ErrorKind::Interrupted => {}
            Err(_) => return,
        }
    }
}

/// SIGTERM for a command this process started and gave up on, and a moment for it to go.
fn stop(child: &mut Child) {
    if let Ok(pid) = i32::try_from(child.id()) {
        let _ = crate::signals::kill(pid, crate::Signal::Term);
    }
    let deadline = Instant::now() + Duration::from_secs(1);
    while Instant::now() < deadline {
        if !matches!(child.try_wait(), Ok(None)) {
            return;
        }
        std::thread::sleep(Duration::from_millis(5));
    }
}

/// This machine's host name, as `os.hostname()` gives it.
pub fn hostname() -> String {
    rustix::system::uname().nodename().to_string_lossy().into_owned()
}
