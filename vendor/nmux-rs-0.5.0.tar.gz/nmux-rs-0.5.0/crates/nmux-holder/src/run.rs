//! The holder's run loop: everything [`Holder`] does not do itself. It starts the child, takes the lock, writes
//! holder.json, listens on pty.sock, and then waits on the reactor, hands the core what happened and does what it asks:
//! reads and writes the pty and the sockets, signals, starts servers and writes the log.

use std::collections::BTreeMap;
use std::error::Error;
use std::ffi::OsString;
use std::fs::File;
use std::fs::{self, DirBuilder, OpenOptions};
use std::io::{ErrorKind, Read as _, Write as _};
use std::os::fd::{AsFd, AsRawFd, OwnedFd};
use std::os::unix::fs::{DirBuilderExt, OpenOptionsExt};
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use nmux_io::{Conn, Interest, Listener, OutBuf, Reactor, ReadEnd, Ready, SourceFd, Token};
use nmux_platform::{
    ProcState, PtyCommand, ShutdownEvidence, Signal, Spawned, iso_utc, kill, lflag, open_slave, pgid, pid, proc_sid,
    proc_start, proc_state, set_winsize, shutdown_corroborated, spawn_detached, spawn_pty, tcgetpgrp, try_lock, uid,
};
use nmux_wire::{Control, ErrorMessage, Layout};
use serde_json::{Map, json};

use crate::holder::{ConnId, Effect, Event, Holder, Started};
use crate::log::{Level, Log, Logger};
use crate::spec::HolderSpec;

const LISTENER: Token = Token(0);
const MASTER: Token = Token(1);
const FIRST_CONN: usize = 2;
/// What is read from the pty at a time.
const READ_BYTES: usize = 65536;
/// Reads of the pty in one turn, before other work is let in.
const READS_PER_TURN: usize = 16;
/// The most of a pty's tail read when its child has gone: what something left behind writes has no end.
const TAIL_MAX_BYTES: usize = 4 * 1024 * 1024;
/// Refused connections kept until their peer has read why. Past this the oldest goes, so that they cannot pile up.
const REFUSED_KEPT: usize = 16;
/// Rounds of effects and flushing in one turn before the reactor is asked again.
const SETTLE_ROUNDS: usize = 8;

/// `nmux __holder --spec FILE`: runs the holder and returns its exit code.
pub fn main(args: &[OsString]) -> i32 {
    let spec = args.iter().position(|a| a == "--spec").and_then(|i| args.get(i + 1)).filter(|a| !a.is_empty());
    let Some(spec) = spec else {
        eprintln!("usage: nmux __holder --spec <holder-spec.json>");
        return 2;
    };
    match std::path::absolute(spec) {
        Ok(path) => run(&path),
        Err(e) => {
            eprintln!("holder: {e}");
            1
        }
    }
}

/// Runs the holder for the spec at `spec_path`, until the child has exited and been released, has been orphaned for too
/// long, or SIGTERM. 0 when it is done, 3 when another holder has the session, 1 when it could not start.
pub fn run(spec_path: &Path) -> i32 {
    match start(spec_path) {
        Ok(code) => code,
        Err(e) => {
            eprintln!("holder: {e}");
            1
        }
    }
}

fn start(spec_path: &Path) -> Result<i32, Box<dyn Error>> {
    let spec = HolderSpec::parse(&fs::read(spec_path)?)?;
    let layout = Layout::new(&spec.runtime_dir);
    DirBuilder::new().recursive(true).mode(0o700).create(layout.session_dir(&spec.id)?)?;
    let Some(lock) = try_lock(&layout.holder_lock(&spec.id)?)? else { return Ok(3) };
    let mut log = Logger::new(layout.log_file(&spec.id, "holder")?, "holder", &spec.id);
    let mut reactor = Reactor::new()?;
    // A hangup must never end a session, nor Ctrl-C in whatever started it. Caught rather than ignored, so that what this
    // process starts gets them back at their defaults.
    reactor.catch_signals(&[Signal::Term, Signal::Hup, Signal::Int, Signal::Chld])?;
    let env = spec.child_env();
    let command = PtyCommand { argv: &spec.argv, env: &env, cwd: &spec.cwd, cols: spec.cols, rows: spec.rows };
    let spawned = spawn_pty(&command)?;
    let first_start = proc_start(spawned.pid);
    let leader_error = become_leader(spawned.pid, &mut log, &reactor);
    let me = Started {
        pid: pid(),
        proc_start: proc_start(pid()),
        uid: uid(),
        child_pid: spawned.pid,
        child_start: proc_start(spawned.pid).or(first_start),
        pts_name: spawned.pts_name.clone(),
        leader_error,
    };
    write_holder_json(&layout.holder_json(&spec.id)?, &me, spec.generation)?;
    let spawn = Log::new(Level::Info, "spawn")
        .with("pid", spawned.pid)
        .with("ptsName", spawned.pts_name.clone())
        .with("cols", spec.cols)
        .with("rows", spec.rows)
        .with("gen", spec.generation);
    log.write(&spawn, &iso_utc(reactor.now().wall_ms));
    let child_start = me.child_start.clone();
    let core = Holder::new(&spec, me)?;
    let pty_sock = layout.pty_sock(&spec.id)?;
    let listener = Listener::bind(&pty_sock, 0o600)?;
    let mut shell = Shell::new(reactor, listener, spawned, child_start, log, pty_sock)?;
    let exit_code = shell.run(core);
    drop(lock);
    Ok(exit_code)
}

/// The child must lead its own session: job control and the foreground check depend on it. It is started that way, and
/// this makes sure, as the Node holder does, for up to a second.
fn become_leader(child: i32, log: &mut Logger, reactor: &Reactor) -> Option<String> {
    let deadline = Instant::now() + Duration::from_secs(1);
    let is_leader = || pgid(child) == Some(child) && proc_sid(child) == Some(child);
    while Instant::now() < deadline && proc_state(child) == ProcState::Alive && !is_leader() {
        std::thread::sleep(Duration::from_millis(5));
    }
    if proc_state(child) != ProcState::Alive || is_leader() {
        return None;
    }
    let record = Log::new(Level::Error, "spawn.not_session_leader").with("pid", child);
    log.write(&record, &iso_utc(reactor.now().wall_ms));
    let _ = kill(child, Signal::Term);
    Some("NOT_SESSION_LEADER".to_owned())
}

/// What the running holder says about itself, for whoever looks: `nmux.holder/1`.
fn write_holder_json(path: &Path, me: &Started, generation: u64) -> Result<(), Box<dyn Error>> {
    let record = json!({
        "schema": "nmux.holder/1",
        "pid": me.pid,
        "procStart": me.proc_start,
        "child": { "pid": me.child_pid, "procStart": me.child_start },
        "ptsName": me.pts_name,
        "gen": generation,
    });
    let mut file = OpenOptions::new().write(true).create(true).truncate(true).mode(0o600).open(path)?;
    file.write_all(serde_json::to_string(&record)?.as_bytes())?;
    Ok(())
}

/// A connection on pty.sock.
#[derive(Debug)]
struct Link {
    conn: Conn,
    /// A refused connection's own words: it never becomes the core's.
    refused: Option<OutBuf>,
    /// End it once what is queued is written.
    ending: bool,
    /// Its writing half is shut.
    shut: bool,
}

/// The run loop's state: everything with a descriptor in it.
#[derive(Debug)]
#[allow(clippy::struct_excessive_bools)] // what was last seen of the pty, one flag each
struct Shell {
    reactor: Reactor,
    listener: Option<Listener>,
    /// The pty's master, as a file, for reading and writing without blocking.
    master: Option<File>,
    master_readable: bool,
    master_writable: bool,
    paused: bool,
    child_pid: i32,
    child_start: Option<String>,
    child_reaped: bool,
    pts_name: String,
    slave: Option<OwnedFd>,
    conns: BTreeMap<ConnId, Link>,
    next_conn: u64,
    log: Logger,
    pty_sock: PathBuf,
    buf: Vec<u8>,
    exit: Option<bool>,
}

impl Shell {
    fn new(
        reactor: Reactor,
        mut listener: Listener,
        spawned: Spawned,
        child_start: Option<String>,
        log: Logger,
        pty_sock: PathBuf,
    ) -> std::io::Result<Self> {
        listener.register(reactor.registry(), LISTENER)?;
        let raw = spawned.master.as_raw_fd();
        reactor.registry().register(&mut SourceFd(&raw), MASTER, Interest::READABLE | Interest::WRITABLE)?;
        Ok(Self {
            reactor,
            listener: Some(listener),
            master: Some(File::from(spawned.master)),
            master_readable: true,
            master_writable: true,
            paused: false,
            child_pid: spawned.pid,
            child_start,
            child_reaped: false,
            pts_name: spawned.pts_name,
            slave: None,
            conns: BTreeMap::new(),
            next_conn: 0,
            log,
            pty_sock,
            buf: vec![0; READ_BYTES],
            exit: None,
        })
    }

    fn run(&mut self, mut core: Holder) -> i32 {
        core.on_event(Event::Started, self.reactor.now());
        loop {
            self.settle(&mut core);
            if let Some(hang_up) = self.exit {
                return self.finish(hang_up);
            }
            let deadline = if self.busy(&mut core) { Some(self.reactor.now().time) } else { core.next_deadline() };
            if let Err(e) = self.reactor.wait(deadline) {
                self.write_log(&Log::new(Level::Error, "reactor.failed").with("error", e.to_string()));
                return 1;
            }
            let ready: Vec<Ready> = self.reactor.ready().to_vec();
            for r in ready {
                self.on_ready(&mut core, r);
            }
            for signal in self.reactor.take_signals() {
                self.on_signal(&mut core, signal);
            }
            self.reap(&mut core);
            self.read_master(&mut core);
            self.read_conns(&mut core);
            core.on_event(Event::Tick, self.reactor.now());
        }
    }

    /// Whether there is work that must not wait for the reactor.
    fn busy(&self, core: &mut Holder) -> bool {
        let master = self.master.is_some();
        (master && self.master_readable && !self.paused)
            || (master && self.master_writable && !core.pty_out().is_empty())
            || self.conns.values().any(|l| l.conn.wants_read())
            || self.conns.iter().any(|(&id, l)| {
                l.conn.writable()
                    && l.refused
                        .as_ref()
                        .map_or_else(|| core.conn_out(id).is_some_and(|o| !o.is_empty()), |o| !o.is_empty())
            })
    }

    /// Does what the core asks and writes what it queued, until it asks for nothing more or a round limit is reached.
    fn settle(&mut self, core: &mut Holder) {
        for _ in 0..SETTLE_ROUNDS {
            self.apply_effects(core);
            if self.exit.is_some() || !self.flush(core) {
                return;
            }
        }
    }

    fn apply_effects(&mut self, core: &mut Holder) {
        while let Some(effect) = core.next_effect() {
            match effect {
                Effect::Log(log) => self.write_log(&log),
                _ if self.exit.is_some() => {}
                effect => self.apply(core, effect),
            }
        }
    }

    fn apply(&mut self, core: &mut Holder, effect: Effect) {
        let now = self.reactor.now();
        match effect {
            Effect::PauseOutput => self.paused = true,
            Effect::ResumeOutput => {
                self.paused = false;
                // What was there when reading stopped raised no new readiness.
                self.master_readable = true;
            }
            Effect::ReadLflag => {
                let reading =
                    self.master.as_ref().and_then(|m| Some((lflag(m.as_fd()).ok()?, tcgetpgrp(m.as_fd()).ok()?)));
                core.on_event(Event::Lflag(reading), now);
            }
            Effect::ReadInq => {
                let result = self.inq();
                core.on_event(Event::Inq(result), now);
            }
            Effect::CloseSlave => self.slave = None,
            Effect::Resize { cols, rows } => {
                if let Some(m) = &self.master {
                    let _ = set_winsize(m.as_fd(), cols, rows);
                }
            }
            Effect::SignalChild(signal) => {
                let same = proc_start(self.child_pid) == self.child_start;
                if !self.child_reaped && same && kill(self.child_pid, signal).is_ok() {
                    self.write_log(&Log::new(Level::Info, "signal").with("sig", signal.name()));
                }
            }
            Effect::ReadTail { read, then_close } => {
                if read {
                    self.read_tail(core);
                }
                if then_close {
                    self.close_master(core);
                    core.on_event(Event::PtyClosed, self.reactor.now());
                } else {
                    core.on_event(Event::TailRead, self.reactor.now());
                }
            }
            Effect::HangUp => {
                self.close_master(core);
                if !self.child_reaped {
                    let _ = kill(self.child_pid, Signal::Hup);
                }
            }
            Effect::SpawnServer { argv, attempt } => {
                let log = match spawn_detached(&argv, Path::new("/")) {
                    Ok(pid) => Log::new(Level::Info, "sessiond.spawn").with("pid", pid).with("attempt", attempt),
                    Err(e) => Log::new(Level::Warn, "sessiond.spawn_error").with("error", e.to_string()),
                };
                self.write_log(&log);
            }
            Effect::IdentifyServer { pid } => {
                core.on_event(Event::ServerIdentified { pid, start: proc_start(pid) }, now);
            }
            Effect::EndServer { pid, start } => {
                if proc_start(pid).as_deref() == Some(start.as_str()) {
                    let _ = kill(pid, Signal::Term);
                }
            }
            Effect::Refuse { conn, code } => self.refuse(core, conn, code.to_owned()),
            Effect::EndConn(conn) => {
                if let Some(link) = self.conns.get_mut(&conn) {
                    link.ending = true;
                }
            }
            Effect::DestroyConn(conn) => self.drop_conn(core, conn),
            Effect::CloseListener => {
                if let Some(mut listener) = self.listener.take() {
                    let _ = listener.deregister(self.reactor.registry());
                }
            }
            Effect::Log(log) => self.write_log(&log),
            Effect::Exit { hang_up } => self.exit = Some(hang_up),
        }
    }

    fn write_log(&mut self, log: &Log) {
        let ts = iso_utc(self.reactor.now().wall_ms);
        self.log.write(log, &ts);
    }

    /// Input that waits on the slave, which is opened the first time it is needed.
    fn inq(&mut self) -> Result<usize, String> {
        if self.slave.is_none() {
            self.slave = Some(open_slave(&self.pts_name).map_err(|e| e.to_string())?);
        }
        match &self.slave {
            Some(slave) => nmux_platform::inq(slave.as_fd()).map_err(|e| e.to_string()),
            None => Err("no slave".to_owned()),
        }
    }

    fn refuse(&mut self, core: &mut Holder, conn: ConnId, why: String) {
        let Some(link) = self.conns.get_mut(&conn) else { return };
        let mut out = OutBuf::new();
        let _ = out.control(&Control::Err(ErrorMessage { code: why, sig: None, extra: Map::new() }));
        link.refused = Some(out);
        link.ending = true;
        let refused: Vec<ConnId> = self.conns.iter().filter(|(_, l)| l.refused.is_some()).map(|(&id, _)| id).collect();
        for &oldest in refused.iter().take(refused.len().saturating_sub(REFUSED_KEPT)) {
            self.drop_conn(core, oldest);
        }
    }

    fn drop_conn(&mut self, core: &mut Holder, conn: ConnId) {
        let Some(mut link) = self.conns.remove(&conn) else { return };
        let _ = link.conn.deregister(self.reactor.registry());
        drop(link);
        core.on_event(Event::ConnClosed(conn), self.reactor.now());
    }

    fn close_master(&mut self, core: &mut Holder) {
        if let Some(master) = self.master.take() {
            let raw = master.as_raw_fd();
            let _ = self.reactor.registry().deregister(&mut SourceFd(&raw));
        }
        core.pty_out().clear();
    }

    /// Writes what the core queued for the pty and for each connection. True when that let the core go on: a connection
    /// drained, or one closed.
    fn flush(&mut self, core: &mut Holder) -> bool {
        match &self.master {
            Some(master) => {
                let mut master: &File = master;
                while self.master_writable {
                    let written = match core.pty_out().front() {
                        Some(front) => master.write(front),
                        None => break,
                    };
                    match written {
                        Ok(n) => core.pty_out().consume(n),
                        Err(e) if e.kind() == ErrorKind::WouldBlock => self.master_writable = false,
                        Err(e) if e.kind() == ErrorKind::Interrupted => {}
                        // node-pty gives up on what is queued when a write fails other than for want of room.
                        Err(_) => core.pty_out().clear(),
                    }
                }
            }
            None => core.pty_out().clear(),
        }
        let mut progressed = false;
        let ids: Vec<ConnId> = self.conns.keys().copied().collect();
        for id in ids {
            let Some(link) = self.conns.get_mut(&id) else { continue };
            let result = match link.refused.as_mut() {
                Some(out) => link.conn.flush(out).map(|done| (done, false)),
                None => match core.conn_out(id) {
                    Some(out) => {
                        let had = !out.is_empty();
                        link.conn.flush(out).map(|done| (done, had && done))
                    }
                    None => Ok((true, false)),
                },
            };
            let Ok((done, drained)) = result else {
                self.drop_conn(core, id);
                progressed = true;
                continue;
            };
            if done && link.ending && !link.shut {
                link.shut = true;
                let _ = link.conn.shutdown_write();
            }
            if drained {
                core.on_event(Event::Drained(id), self.reactor.now());
                progressed = true;
            }
        }
        progressed
    }

    fn on_ready(&mut self, core: &mut Holder, r: Ready) {
        match r.token {
            LISTENER => self.accept(core),
            MASTER => {
                self.master_readable |= r.readable || r.closed || r.error;
                self.master_writable |= r.writable || r.closed || r.error;
            }
            Token(n) => {
                let id = ConnId(n.saturating_sub(FIRST_CONN) as u64);
                if let Some(link) = self.conns.get_mut(&id) {
                    link.conn.on_ready(&r);
                }
            }
        }
    }

    fn accept(&mut self, core: &mut Holder) {
        loop {
            let Some(listener) = &self.listener else { return };
            let Ok(Some(stream)) = listener.accept() else { return };
            let id = ConnId(self.next_conn);
            self.next_conn += 1;
            let mut conn = Conn::new(stream);
            let Ok(token) = usize::try_from(id.0).map(|n| Token(FIRST_CONN + n)) else { continue };
            if conn.register(self.reactor.registry(), token).is_err() {
                continue;
            }
            let peer_uid = conn.peer_uid().ok();
            self.conns.insert(id, Link { conn, refused: None, ending: false, shut: false });
            core.on_event(Event::Accepted { conn: id, peer_uid }, self.reactor.now());
        }
    }

    fn on_signal(&mut self, core: &mut Holder, signal: Signal) {
        match signal {
            Signal::Chld => self.reap(core),
            // Corroborated before it is believed to be a shutdown.
            Signal::Term if !core.closing() => {
                let corroborated = shutdown_corroborated(&ShutdownEvidence::default());
                core.on_event(Event::Sigterm { corroborated }, self.reactor.now());
            }
            _ => {}
        }
    }

    /// Collects every child that has exited: the one on the pty, and servers this holder started.
    fn reap(&mut self, core: &mut Holder) {
        while let Some(exited) = nmux_platform::reap() {
            if exited.pid == self.child_pid && !self.child_reaped {
                self.child_reaped = true;
                core.on_event(Event::ChildExited { code: exited.code, signal: exited.signal }, self.reactor.now());
            }
        }
    }

    fn read_master(&mut self, core: &mut Holder) {
        for _ in 0..READS_PER_TURN {
            if !self.master_readable || self.paused {
                return;
            }
            let Some(mut master) = self.master.as_ref() else { return };
            match master.read(&mut self.buf) {
                Ok(0) => return self.pty_gone(core),
                Ok(n) => {
                    core.on_event(Event::Output(&self.buf[..n]), self.reactor.now());
                    self.apply_effects(core);
                }
                Err(e) if e.kind() == ErrorKind::WouldBlock => self.master_readable = false,
                Err(e) if e.kind() == ErrorKind::Interrupted => {}
                // EIO on Linux: nobody holds the slave any more.
                Err(_) => return self.pty_gone(core),
            }
        }
    }

    /// Nobody holds the slave any more: the pty is closed.
    fn pty_gone(&mut self, core: &mut Holder) {
        self.close_master(core);
        core.on_event(Event::PtyClosed, self.reactor.now());
    }

    /// Reads what the pty still has, paused or not, up to [`TAIL_MAX_BYTES`].
    fn read_tail(&mut self, core: &mut Holder) {
        let mut total = 0;
        while total < TAIL_MAX_BYTES {
            let Some(mut master) = self.master.as_ref() else { return };
            match master.read(&mut self.buf) {
                Ok(0) => return self.pty_gone(core),
                Ok(n) => {
                    total += n;
                    core.on_event(Event::Output(&self.buf[..n]), self.reactor.now());
                }
                Err(e) if e.kind() == ErrorKind::Interrupted => {}
                Err(e) if e.kind() == ErrorKind::WouldBlock => return,
                Err(_) => return self.pty_gone(core),
            }
        }
    }

    fn read_conns(&mut self, core: &mut Holder) {
        let ids: Vec<ConnId> = self.conns.iter().filter(|(_, l)| l.conn.wants_read()).map(|(&id, _)| id).collect();
        for id in ids {
            let Some(link) = self.conns.get_mut(&id) else { continue };
            let refused = link.refused.is_some();
            let now = self.reactor.now();
            let end = link.conn.read(|frame| {
                if !refused {
                    core.on_event(Event::Frame { conn: id, frame }, now);
                }
            });
            if !matches!(end, ReadEnd::Open) {
                self.drop_conn(core, id);
            }
        }
    }

    /// `end()` in `main.js`: pty.sock goes, and a child that has not exited is hung up.
    fn finish(&mut self, hang_up: bool) -> i32 {
        let _ = fs::remove_file(&self.pty_sock);
        if hang_up {
            if let Some(master) = self.master.take() {
                drop(master);
            }
            if !self.child_reaped {
                let _ = kill(self.child_pid, Signal::Hup);
            }
        }
        0
    }
}
