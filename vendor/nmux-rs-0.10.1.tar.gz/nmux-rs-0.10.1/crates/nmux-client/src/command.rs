//! A command a key runs with the terminal lent to it, as the configuration's `actions` name them: an editor for notes, or a
//! program that embeds nmux and has a screen of its own to show. It is told which session it was run from, so that it can
//! reach it, and the terminal is this client's again when it ends.

use std::io::Read;
use std::path::Path;
use std::process::Command;

/// Runs `argv` once `take` says the terminal is this client's to lend, and waits for it to end. `NMUX_SESSION` is the
/// session's name and `NMUX_SOCK` its socket. A command that cannot be run says so, and the terminal goes back at a key.
pub fn run_lent(argv: &[String], session: &str, sock: &Path, take: &mut dyn FnMut() -> bool) {
    let Some((program, rest)) = argv.split_first() else { return };
    if !take() {
        return;
    }
    let ran = Command::new(program).args(rest).env("NMUX_SESSION", session).env("NMUX_SOCK", sock).status();
    if let Err(e) = ran {
        eprint!("nmux: {program}: {e}\r\n(a key goes back)");
        let _ = std::io::stdin().read(&mut [0u8; 1]);
    }
}
