//! `nmux __attach --json SPEC`: the attach client for a program that embeds nmux and runs this binary to attach, in that
//! program's words and with its configuration rather than nmux's own. The spec is JSON:
//!
//! ```json
//! { "sock": "/path/to/ctl.sock", "name": "api",
//!   "flags": { "shrink": false, "allowSetup": false, "view": false, "full": false },
//!   "config": { "size": { "floorCols": 80 }, "keys": { "leader": null, "direct": { "C-z": "detach", "C-]": "notes" } },
//!               "actions": { "notes": ["acme", "notes", "api"] } },
//!   "words": { "brand": "acme", "nestEnv": "ACME_ID", "detached": "── acme · detached from {name} {time} ──" } }
//! ```
//!
//! `config` is laid out as nmux's configuration file is, and goes over the defaults in the same way: its `actions` are the
//! commands its keys can run with the terminal lent to them ([`run_lent`]). `words` names any of [`Words`]'s templates. The
//! exit code is the client's, or 2 for a spec that cannot be used.

use std::ffi::OsString;
use std::path::PathBuf;

use serde_json::Value;

use crate::attach::AttachFlags;
use crate::command::run_lent;
use crate::config::Config;
use crate::run::{Attaching, Env, attach};
use crate::text::Words;

const USAGE: &str = "usage: nmux __attach --json SPEC";

/// Runs the client a spec describes, until it detaches or the session ends: the exit code.
pub fn main(args: &[OsString]) -> i32 {
    let spec = match args {
        [flag, json] if flag == "--json" => serde_json::from_str::<Value>(&json.to_string_lossy()),
        _ => {
            eprintln!("nmux: {USAGE}");
            return 2;
        }
    };
    let spec = match spec {
        Ok(v) if v.is_object() => v,
        Ok(_) => return refuse("the spec is not an object"),
        Err(e) => return refuse(&format!("the spec is not JSON: {e}")),
    };
    let text = |k: &str| spec.get(k).and_then(Value::as_str).filter(|s| !s.is_empty());
    let (Some(sock), Some(name)) = (text("sock"), text("name")) else { return refuse("the spec needs sock and name") };
    let flag = |k: &str| spec.get("flags").and_then(|f| f.get(k)).is_some_and(crate::config::truthy);
    let flags =
        AttachFlags { shrink: flag("shrink"), allow_setup: flag("allowSetup"), view: flag("view"), full: flag("full") };
    let config = spec.get("config").map_or_else(Config::default, Config::from_value);
    let words = spec.get("words").map_or_else(Words::default, |w| Words::default().over(w));
    let env: Env = std::env::vars_os()
        .map(|(k, v)| (k.to_string_lossy().into_owned(), v.to_string_lossy().into_owned()))
        .collect();
    let sock = PathBuf::from(sock);
    let commands = config.commands();
    let actions = commands.iter().map(|(n, _)| n.clone()).collect();
    let a = Attaching { sock: &sock, name, config: &config, flags, env: &env, actions, words: &words };
    attach(&a, &mut |action, take| {
        if let Some((_, argv)) = commands.iter().find(|(n, _)| n == action) {
            run_lent(argv, name, &sock, take);
        }
    })
}

fn refuse(why: &str) -> i32 {
    eprintln!("nmux: __attach: {why} ({USAGE})");
    2
}
