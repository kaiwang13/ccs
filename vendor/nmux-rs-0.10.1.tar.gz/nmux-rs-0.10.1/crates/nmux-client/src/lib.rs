//! The attach client, ported from `src/client` of the Node code: the terminal joins a session, its keys go to the program
//! except the few this client takes, and it leaves the terminal as it found it. [`attach::Attach`] is the logic, with no I/O;
//! [`run::attach`] is the thin loop that connects it to the terminal and the session's socket on `nmux-io`.
//!
//! A program that embeds nmux attaches with this binary in its own words: [`embed`], `nmux __attach`.
//!
//! Also here, because both the client and the command need them: a control connection to a session's server
//! ([`ctl`], [`control`]), the configuration file ([`config`]), a pager on a kept history ([`pager`]), and a question at the
//! terminal ([`question`]).

pub mod attach;
pub mod command;
pub mod config;
pub mod control;
pub mod ctl;
pub mod embed;
pub mod keytable;
pub mod pager;
pub mod question;
pub mod reconnect;
pub mod run;
pub mod termcolors;
pub mod terminal;
pub mod text;
