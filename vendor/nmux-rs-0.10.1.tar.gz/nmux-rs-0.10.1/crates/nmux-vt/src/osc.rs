//! What a program sets with an OSC that a terminal goes on showing: colours (OSC 4, 10, 11 and 12, and the resets 104, 110,
//! 111 and 112), and the progress of a task (OSC 9;4, which Ghostty, Windows Terminal and others show as a bar).
//! nmux keeps them so that a terminal that attaches later shows them too.
//!
//! A colour is kept as the program said it, which a terminal reads as it reads the program's own: `#rrggbb`, `rgb:r/g/b`, a
//! name. Queries never get here: the holder answers them, or a terminal does, before they are seen. Colours stay on a
//! terminal when it leaves, as they would after the program had run there itself: what sets them is most often a shell
//! theming the terminal from its start-up file, which means them to last. A task's progress does not outlive watching it,
//! and comes off.

use std::collections::BTreeMap;
use std::fmt::Write as _;

/// A colour a program can set.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Slot {
    /// One of the 256: OSC 4.
    Palette(u8),
    /// The default foreground: OSC 10.
    Foreground,
    /// The default background: OSC 11.
    Background,
    /// The cursor's: OSC 12.
    Cursor,
}

/// What an OSC does.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Change<'a> {
    /// A colour is this from now on.
    Set(Slot, &'a str),
    /// A colour is the terminal's own again.
    Reset(Slot),
    /// All 256 are: OSC 104 with no index.
    ResetPalette,
    /// A task's progress, `state;percent` as the program said it, or `None` when there is none (state 0).
    Progress(Option<&'a str>),
}

/// The longest colour kept: more is not a colour.
const SPEC_MAX: usize = 64;

/// Whether `spec` is a colour to keep: not a query, and nothing a terminal would read as more than a colour.
fn is_spec(spec: &str) -> bool {
    !spec.is_empty() && spec != "?" && spec.len() <= SPEC_MAX && spec.bytes().all(|b| (0x20..0x7f).contains(&b))
}

/// The slot that OSC `n` sets: 10 to 12.
fn dynamic(n: u32) -> Option<Slot> {
    match n {
        10 => Some(Slot::Foreground),
        11 => Some(Slot::Background),
        12 => Some(Slot::Cursor),
        _ => None,
    }
}

/// `OSC 9 ; 4 ; state ; percent`, given what follows `9;4;`: the state and percent as given, none for state 0, or nothing
/// for what is not one.
fn progress(rest: &str) -> Option<Change<'_>> {
    let mut parts = rest.split(';');
    let state = parts.next().unwrap_or("");
    let percent = parts.next();
    let digits = |s: &str| s.len() <= 3 && s.bytes().all(|b| b.is_ascii_digit());
    if parts.next().is_some() || !digits(state) || percent.is_some_and(|p| !digits(p)) {
        return None;
    }
    match state {
        "" | "0" => Some(Change::Progress(None)),
        "1" | "2" | "3" | "4" => Some(Change::Progress(Some(rest))),
        _ => None,
    }
}

/// The changes an OSC's data, what comes between `OSC` and its end, makes, in order.
pub fn changes<'a>(data: &'a [u8], mut f: impl FnMut(Change<'a>)) {
    let Ok(s) = std::str::from_utf8(data) else { return };
    let (number, rest) = s.split_once(';').unwrap_or((s, ""));
    let fields = || rest.split(';').filter(|f| !f.is_empty());
    match number {
        "4" => {
            let mut pairs = rest.split(';');
            while let (Some(i), Some(spec)) = (pairs.next(), pairs.next()) {
                if let (Ok(i), true) = (i.parse::<u8>(), is_spec(spec)) {
                    f(Change::Set(Slot::Palette(i), spec));
                }
            }
        }
        "10" | "11" | "12" => {
            // each colour sets the next of 10, 11 and 12, as xterm reads `OSC 10 ; fg ; bg`
            let first = number.parse::<u32>().unwrap_or(0);
            for (n, spec) in (first..).zip(rest.split(';')) {
                if let (Some(slot), true) = (dynamic(n), is_spec(spec)) {
                    f(Change::Set(slot, spec));
                }
            }
        }
        "104" => {
            let mut any = false;
            for i in fields() {
                any = true;
                if let Ok(i) = i.parse::<u8>() {
                    f(Change::Reset(Slot::Palette(i)));
                }
            }
            if !any {
                f(Change::ResetPalette);
            }
        }
        "110" => f(Change::Reset(Slot::Foreground)),
        "111" => f(Change::Reset(Slot::Background)),
        "112" => f(Change::Reset(Slot::Cursor)),
        "9" => {
            let args = match rest.strip_prefix('4') {
                Some("") => Some(""),
                Some(r) => r.strip_prefix(';'),
                None => None, // a notification, `OSC 9 ; text`
            };
            if let Some(change) = args.and_then(progress) {
                f(change);
            }
        }
        _ => {}
    }
}

/// What a program has set that a terminal shows: see the module.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Shown {
    colors: BTreeMap<Slot, String>,
    progress: Option<String>,
}

impl Shown {
    /// Takes in an OSC's data.
    pub fn apply(&mut self, data: &[u8]) {
        changes(data, |c| match c {
            Change::Set(slot, spec) => {
                self.colors.insert(slot, spec.to_owned());
            }
            Change::Reset(slot) => {
                self.colors.remove(&slot);
            }
            Change::ResetPalette => self.colors.retain(|slot, _| !matches!(slot, Slot::Palette(_))),
            Change::Progress(p) => self.progress = p.map(str::to_owned),
        });
    }

    /// RIS: the colours are the terminal's own again. A task's progress is not a setting, and stays.
    pub fn reset_colors(&mut self) {
        self.colors.clear();
    }

    /// What makes a terminal show the same.
    pub fn restore(&self) -> String {
        let mut palette = String::new();
        let mut out = String::new();
        for (slot, spec) in &self.colors {
            let _ = match slot {
                Slot::Palette(i) => write!(palette, ";{i};{spec}"),
                Slot::Foreground => write!(out, "\x1b]10;{spec}\x07"),
                Slot::Background => write!(out, "\x1b]11;{spec}\x07"),
                Slot::Cursor => write!(out, "\x1b]12;{spec}\x07"),
            };
        }
        if !palette.is_empty() {
            out.insert_str(0, &format!("\x1b]4{palette}\x07"));
        }
        if let Some(p) = &self.progress {
            let _ = write!(out, "\x1b]9;4;{p}\x07");
        }
        out
    }

    /// What takes the progress off a terminal that was told it, for a new program, which has none yet.
    pub fn gone(&self) -> &'static str {
        if self.progress.is_some() { PROGRESS_GONE } else { "" }
    }
}

/// What takes a task's progress off a terminal.
pub const PROGRESS_GONE: &str = "\x1b]9;4;0\x07";

/// Finds each OSC in `s` and gives its data to `f`, for a reader of bytes that has no lexer. Returns where an OSC that has
/// not ended starts, to be read again with what comes next, or `s.len()`.
pub fn scan(s: &[u8], mut f: impl FnMut(&[u8])) -> usize {
    let mut i = 0;
    while let Some(at) = s[i..].iter().position(|&b| b == 0x1b).map(|p| i + p) {
        match s.get(at + 1) {
            None => return at,
            Some(b']') => {}
            Some(_) => {
                i = at + 1;
                continue;
            }
        }
        let data = at + 2;
        let Some(len) = s[data..].iter().position(|&b| matches!(b, 0x07 | 0x1b | 0x18 | 0x1a)) else { return at };
        let end = data + len;
        match s[end] {
            0x07 => f(&s[data..end]),
            0x1b => match s.get(end + 1) {
                None => return at,
                Some(b'\\') => f(&s[data..end]),
                Some(_) => {
                    i = end; // another sequence cut it short, and is read next
                    continue;
                }
            },
            _ => {} // CAN or SUB: cancelled
        }
        i = end + 1;
    }
    s.len()
}
