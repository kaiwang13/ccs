//! Times as a person reads them, on a clock in a given time zone: what history, search and the picture behind a session all
//! show. A port of `src/base/time.js`, which formats with Node's `Intl`, and this has to show the same: the rules of each
//! zone come from the system's time zone database through `jiff`, and what only `Intl` knows, which names it takes and how a
//! clock in each is labelled, is in `icu.rs`, made from Node itself by `tests/data/generate.js`.
//!
//! Times are milliseconds since 1970 in UTC, as JavaScript keeps them.

#[rustfmt::skip]
mod icu;

use jiff::Timestamp;
use jiff::tz::{Offset, TimeZone, TimeZoneDatabase};

/// A day in milliseconds.
pub const DAY_MS: i64 = 86_400_000;
const HOUR_MS: i64 = 3_600_000;

const WEEKDAYS: [&str; 7] = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const MONTHS: [&str; 12] = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
];
const MONTHS_SHORT: [&str; 12] = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/// A time zone, by the name it was asked for.
#[derive(Clone, Debug)]
pub struct Zone {
    /// What it is called where it is shown, which is how it was asked for.
    name: String,
    /// How `Intl` spells it, for its labels; none for an offset.
    id: Option<&'static str>,
    rules: TimeZone,
}

impl Zone {
    /// UTC.
    pub fn utc() -> Self {
        Self { name: "UTC".to_owned(), id: Some("UTC"), rules: TimeZone::UTC }
    }

    /// Its name, as it is shown: `America/Los_Angeles`, `+05:30`.
    pub fn name(&self) -> &str {
        &self.name
    }

    /// The zone `Intl` takes this name for, if it takes it: an IANA name or alias in any case, one of its own (`PST`), or an
    /// offset (`+05:30`, `-08`).
    pub fn named(name: &str) -> Option<Self> {
        if let Some(offset) = parse_offset(name) {
            return Some(Self { name: name.to_owned(), id: None, rules: TimeZone::fixed(offset) });
        }
        let (id, resolved) = known(name, false)?;
        // `Intl` takes, and resolves to, old names (`Asia/Calcutta`) that a system may not have, as Debian and Ubuntu leave
        // them to tzdata-legacy: the copy of the database built in has them
        let rules = [id, resolved].into_iter().find_map(|n| TimeZone::get(n).ok()).or_else(|| {
            let built_in = TimeZoneDatabase::bundled();
            [id, resolved].into_iter().find_map(|n| built_in.get(n).ok())
        })?;
        Some(Self { name: name.to_owned(), id: Some(id), rules })
    }
}

/// `name` as `Intl` spells it, and what it resolves to, if it knows it. `exact`: only in that spelling.
fn known(name: &str, exact: bool) -> Option<(&'static str, &'static str)> {
    let lower = name.to_ascii_lowercase();
    let at = icu::NAMES.binary_search_by(|(n, _)| cmp_lower(n, &lower)).ok()?;
    let found = icu::NAMES[at];
    (!exact || found.0 == name).then_some(found)
}

fn cmp_lower(a: &str, lower: &str) -> std::cmp::Ordering {
    a.bytes().map(|b| b.to_ascii_lowercase()).cmp(lower.bytes())
}

/// `+05:30`, `+0530` or `+05`, as `Intl` takes an offset for a zone.
fn parse_offset(name: &str) -> Option<Offset> {
    let sign = match name.as_bytes().first()? {
        b'+' => 1,
        b'-' => -1,
        _ => return None,
    };
    let digits: Vec<u8> = name[1..].bytes().filter(|&b| b != b':').collect();
    let well_formed = match name.len() {
        3 => digits.len() == 2,
        5 => digits.len() == 4 && !name.contains(':'),
        6 => digits.len() == 4 && name.as_bytes()[3] == b':',
        _ => false,
    };
    if !well_formed || !digits.iter().all(u8::is_ascii_digit) {
        return None;
    }
    let number = |d: &[u8]| d.iter().fold(0, |n, &b| n * 10 + i32::from(b - b'0'));
    let (hours, minutes) = (number(&digits[..2]), digits.get(2..).map_or(0, number));
    if hours > 23 || minutes > 59 {
        return None;
    }
    Offset::from_seconds(sign * (hours * 3600 + minutes * 60)).ok()
}

/// The time zone to show times in: the one asked for, or this process's. `TZ` may be written as the C library takes it
/// (`:America/New_York`, `/usr/share/zoneinfo/Europe/Paris`, `:/etc/localtime`, `EST5EDT,M3.2.0,M11.1.0`), which `Intl` does
/// not: a name it knows in there is used, and anything else means this process's zone.
pub fn zone(asked: Option<&str>) -> Zone {
    let tz = std::env::var("TZ").ok();
    zone_in(asked, tz.as_deref(), system_name)
}

/// [`zone`], with the process's `TZ` and the system's own zone given, for tests.
pub fn zone_in(asked: Option<&str>, tz: Option<&str>, system: impl FnOnce() -> Option<String>) -> Zone {
    let Some(asked) = asked.filter(|a| !a.is_empty()) else { return own(tz, system) };
    let name = asked.strip_prefix(':').unwrap_or(asked);
    let name = name.find("/zoneinfo/").map_or(name, |at| &name[at + "/zoneinfo/".len()..]);
    Zone::named(name).unwrap_or_else(|| own(tz, system))
}

/// This process's zone, as `Intl` reads it: `TZ` when it is a name it knows, as written, or else the system's zone, and
/// UTC when neither says.
fn own(tz: Option<&str>, system: impl FnOnce() -> Option<String>) -> Zone {
    let resolved = match tz {
        // ICU reads a bare `GMT` in TZ as an offset of nothing.
        Some("GMT") => return Zone::named("+00:00").unwrap_or_else(Zone::utc),
        Some("") => None,
        Some(tz) => known(tz.strip_prefix(':').unwrap_or(tz), true),
        None => system().and_then(|name| known(&name, true)),
    };
    resolved.and_then(|(_, resolved)| Zone::named(resolved)).unwrap_or_else(Zone::utc)
}

/// The system's zone as the database names it, which is what `/etc/localtime` points at.
fn system_name() -> Option<String> {
    TimeZone::try_system().ok()?.iana_name().map(str::to_owned)
}

/// The parts of a time as they are on a clock in a zone.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Wall {
    /// The year.
    pub year: i32,
    /// 1 to 12.
    pub month: u32,
    /// 1 to 31.
    pub day: u32,
    /// 0 to 23.
    pub hour: u32,
    /// 0 to 59.
    pub minute: u32,
    /// 0 to 59.
    pub second: u32,
    /// `Monday`.
    pub weekday: &'static str,
}

/// The parts of a time as they are on a clock in `zone`.
pub fn wall(ms: i64, zone: &Zone) -> Wall {
    let t = zone.rules.to_datetime(timestamp(ms));
    let weekday = usize::try_from(t.weekday().to_sunday_zero_offset()).unwrap_or(0);
    let unsigned = |n: i8| u32::try_from(n).unwrap_or(0);
    Wall {
        year: i32::from(t.year()),
        month: unsigned(t.month()),
        day: unsigned(t.day()),
        hour: unsigned(t.hour()),
        minute: unsigned(t.minute()),
        second: unsigned(t.second()),
        weekday: WEEKDAYS[weekday],
    }
}

/// A time as `jiff` holds it, which is a range of ten thousand years either side of 1970.
fn timestamp(ms: i64) -> Timestamp {
    let ms = ms.clamp(Timestamp::MIN.as_millisecond(), Timestamp::MAX.as_millisecond());
    Timestamp::from_millisecond(ms).unwrap_or(Timestamp::UNIX_EPOCH)
}

/// `2026-11-01T22:03:22.000Z`: a time as `Date.prototype.toISOString` writes it, in UTC, to the millisecond.
pub fn iso(ms: i64) -> String {
    let t = TimeZone::UTC.to_datetime(timestamp(ms));
    let year = i32::from(t.year());
    let year = if (0..=9999).contains(&year) {
        format!("{year:04}")
    } else {
        format!("{}{:06}", if year < 0 { '-' } else { '+' }, year.abs())
    };
    let millis = t.subsec_nanosecond() / 1_000_000;
    format!("{year}-{:02}-{:02}T{:02}:{:02}:{:02}.{millis:03}Z", t.month(), t.day(), t.hour(), t.minute(), t.second())
}

/// `Date.parse` for a time as [`iso`] writes it, and the other forms of RFC 3339: milliseconds since 1970, or none.
pub fn parse_iso(text: &str) -> Option<i64> {
    text.parse::<Timestamp>().ok().map(Timestamp::as_millisecond)
}

/// `2026-11-01 14:03:22`, on a clock in `zone`.
pub fn stamp(ms: i64, zone: &Zone) -> String {
    let w = wall(ms, zone);
    format!("{}-{:02}-{:02} {:02}:{:02}:{:02}", w.year, w.month, w.day, w.hour, w.minute, w.second)
}

/// The day a time is in, on a clock in some zone.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Day {
    /// `2026-11-1`: the same for every time that day.
    pub key: String,
    /// `Sunday 1 November 2026`.
    pub words: String,
}

/// The day `ms` is in, on a clock in `zone`, as a key and as a person says it.
pub fn day_of(ms: i64, zone: &Zone) -> Day {
    let w = wall(ms, zone);
    Day {
        key: format!("{}-{}-{}", w.year, w.month, w.day),
        words: format!("{} {} {} {}", w.weekday, w.day, month_long(&w), w.year),
    }
}

fn month_long(w: &Wall) -> &'static str {
    MONTHS[(w.month as usize).clamp(1, 12) - 1]
}

/// `Nov`: the month on a clock in `zone`, short.
pub fn month_short(ms: i64, zone: &Zone) -> &'static str {
    MONTHS_SHORT[(wall(ms, zone).month as usize).clamp(1, 12) - 1]
}

/// `PST`, `GMT+1`: the zone as a clock in it is labelled at that moment.
pub fn zone_label(ms: i64, zone: &Zone) -> String {
    let offset = zone.rules.to_offset(timestamp(ms)).seconds();
    let named = zone.id.and_then(|id| {
        let at = icu::LABELS.binary_search_by(|(n, _)| n.cmp(&id)).ok()?;
        icu::LABELS[at].1.iter().rev().find(|&&(from, o, _)| from <= ms && o == offset).map(|&(_, _, label)| label)
    });
    named.map_or_else(|| gmt(offset), str::to_owned)
}

/// What ICU writes for an offset with no name of its own: `GMT`, `GMT+1`, `GMT+5:30`, `GMT-0:44:30`.
fn gmt(seconds: i32) -> String {
    if seconds == 0 {
        return "GMT".to_owned();
    }
    let a = seconds.unsigned_abs();
    let (h, m, s) = (a / 3600, a / 60 % 60, a % 60);
    let sign = if seconds < 0 { '-' } else { '+' };
    match (m, s) {
        (0, 0) => format!("GMT{sign}{h}"),
        (_, 0) => format!("GMT{sign}{h}:{m:02}"),
        _ => format!("GMT{sign}{h}:{m:02}:{s:02}"),
    }
}

/// `Date.UTC`, which is where `time.js` does its arithmetic: a month or day out of range carries into the next, and a year
/// from 0 to 99 means one in the 1900s.
fn date_utc(year: i64, month0: i64, day: i64, hour: i64, minute: i64, second: i64) -> i64 {
    let year = if (0..=99).contains(&year) { 1900 + year } else { year };
    let (year, month0) = (year + month0.div_euclid(12), month0.rem_euclid(12));
    let days = days_from_civil(year, month0 + 1, 1) + day - 1;
    days * DAY_MS + hour * HOUR_MS + minute * 60_000 + second * 1000
}

/// Days from 1970-01-01 to a date, by Howard Hinnant's `days_from_civil`.
fn days_from_civil(year: i64, month: i64, day: i64) -> i64 {
    let year = if month <= 2 { year - 1 } else { year };
    let era = year.div_euclid(400);
    let yoe = year.rem_euclid(400);
    let mp = (month + 9) % 12;
    let doy = (153 * mp + 2) / 5 + day - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146_097 + doe - 719_468
}

/// The moment a clock in `zone` shows this, found as `time.js` finds it, so that a time a change of clocks skips or repeats
/// comes out the same.
#[allow(clippy::many_single_char_names)] // a date and a time, as the Node code names them
fn from_wall(y: i64, mo: i64, d: i64, h: i64, mi: i64, s: i64, zone: &Zone) -> i64 {
    let as_utc = date_utc(y, mo - 1, d, h, mi, s);
    let mut guess = as_utc;
    for _ in 0..3 {
        // The offset can differ either side of a change of clocks.
        let w = wall(guess, zone);
        let shown = date_utc(
            i64::from(w.year),
            i64::from(w.month) - 1,
            i64::from(w.day),
            i64::from(w.hour),
            i64::from(w.minute),
            i64::from(w.second),
        );
        guess += as_utc - shown;
    }
    guess
}

/// When a day begins on a clock in `zone`: midnight, or where a zone whose clocks go forward at midnight skips it, the first
/// moment that is that day.
fn start_of_day(y: i64, mo: i64, d: i64, zone: &Zone) -> i64 {
    let mut t = from_wall(y, mo, d, 0, 0, 0, zone);
    // No zone skips more than a few hours.
    for _ in 0..16 {
        let (wy, wm, wd) = ymd(t, zone);
        if (wy, wm, wd) >= (y, mo, d) {
            break;
        }
        t += HOUR_MS / 4;
    }
    t
}

fn ymd(ms: i64, zone: &Zone) -> (i64, i64, i64) {
    let w = wall(ms, zone);
    (i64::from(w.year), i64::from(w.month), i64::from(w.day))
}

/// What JavaScript's `\s` and `trim` take for space.
fn is_js_space(c: char) -> bool {
    matches!(c, '\t' | '\n' | '\u{b}' | '\u{c}' | '\r' | ' ' | '\u{a0}' | '\u{1680}' | '\u{2000}'..='\u{200a}')
        || matches!(c, '\u{2028}' | '\u{2029}' | '\u{202f}' | '\u{205f}' | '\u{3000}' | '\u{feff}')
}

/// A time as a person might write it: `2026-11-01`, `2026-11-01 14:00`, `14:00` (today), `yesterday`, `today`, or how long
/// ago (`90m`, `2h`, `3d`). Milliseconds since 1970; how long ago, in a fraction of a millisecond, is rounded up, which is
/// exact for the `--since` and `--at` it is read for.
pub fn parse_when(text: &str, now: i64, zone: &Zone) -> Option<i64> {
    let t = text.trim_matches(is_js_space).to_lowercase();
    if let Some(ago) = parse_ago(&t) {
        #[allow(clippy::cast_precision_loss, clippy::cast_possible_truncation)] // as JavaScript does it, in doubles
        return Some((now as f64 - ago).ceil() as i64);
    }
    let today = wall(now, zone);
    let (ty, tm, td) = (i64::from(today.year), i64::from(today.month), i64::from(today.day));
    if t == "today" || t == "yesterday" {
        let midnight = start_of_day(ty, tm, td, zone);
        if t == "today" {
            return Some(midnight);
        }
        let (y, m, d) = ymd(midnight - HOUR_MS, zone);
        return Some(start_of_day(y, m, d, zone));
    }
    let when = parse_written(&t)?;
    let (y, mo, d) = when.date.unwrap_or((ty, tm, td));
    let (h, mi, sec) = when.time.unwrap_or((0, 0, 0));
    let days_in_month = (date_utc(y, mo, 1, 0, 0, 0) - date_utc(y, mo - 1, 1, 0, 0, 0)) / DAY_MS;
    if !(1..=12).contains(&mo) || d < 1 || d > days_in_month || h > 23 || mi > 59 || sec > 59 {
        // 2026-02-30, 25:99
        return None;
    }
    Some(if (h, mi, sec) == (0, 0, 0) { start_of_day(y, mo, d, zone) } else { from_wall(y, mo, d, h, mi, sec, zone) })
}

/// `^(\d+(?:\.\d+)?)\s*(s|m|h|d)(?:\s+ago)?$`: how many milliseconds ago.
fn parse_ago(t: &str) -> Option<f64> {
    let t = t
        .strip_suffix("ago")
        .filter(|rest| rest.ends_with(is_js_space))
        .map_or(t, |rest| rest.trim_end_matches(is_js_space));
    let unit = match t.as_bytes().last()? {
        b's' => 1000.0,
        b'm' => 60_000.0,
        b'h' => 3_600_000.0,
        b'd' => 86_400_000.0,
        _ => return None,
    };
    let number = t[..t.len() - 1].trim_end_matches(is_js_space);
    let (whole, fraction) = number.split_once('.').map_or((number, None), |(w, f)| (w, Some(f)));
    let digits = |s: &str| !s.is_empty() && s.bytes().all(|b| b.is_ascii_digit());
    if !digits(whole) || fraction.is_some_and(|f| !digits(f)) {
        return None;
    }
    number.parse::<f64>().ok().map(|n| n * unit)
}

/// A date, a time or both, as `^(?:(\d{4})-(\d{1,2})-(\d{1,2}))?(?:[ t]?(\d{1,2}):(\d{2})(?::(\d{2}))?)?$` reads them.
struct Written {
    date: Option<(i64, i64, i64)>,
    time: Option<(i64, i64, i64)>,
}

fn parse_written(t: &str) -> Option<Written> {
    let b = t.as_bytes();
    // The day takes two digits where it can, as the expression's greedy match does, and one where only that matches.
    for day_len in [2, 1, 0] {
        let (date, rest) = if day_len == 0 {
            (None, b)
        } else {
            let Some((date, used)) = date_part(b, day_len) else { continue };
            (Some(date), &b[used..])
        };
        let time = if rest.is_empty() { None } else { Some(time_part(rest)) };
        match time {
            None if date.is_some() => return Some(Written { date, time: None }),
            Some(Some(time)) => return Some(Written { date, time: Some(time) }),
            _ => {}
        }
    }
    None
}

fn digits_at(b: &[u8], at: usize, len: usize) -> Option<i64> {
    let d = b.get(at..at + len)?;
    d.iter().all(u8::is_ascii_digit).then(|| d.iter().fold(0, |n, &x| n * 10 + i64::from(x - b'0')))
}

/// `YYYY-M(M)-D(D)` at the start, with a day of `day_len` digits, and how long it is.
fn date_part(b: &[u8], day_len: usize) -> Option<((i64, i64, i64), usize)> {
    let year = digits_at(b, 0, 4)?;
    (b.get(4) == Some(&b'-')).then_some(())?;
    let month_len = if b.get(6).is_some_and(u8::is_ascii_digit) { 2 } else { 1 };
    let month = digits_at(b, 5, month_len)?;
    let at = 5 + month_len;
    (b.get(at) == Some(&b'-')).then_some(())?;
    let day = digits_at(b, at + 1, day_len)?;
    Some(((year, month, day), at + 1 + day_len))
}

/// `[ t]?H(H):MM(:SS)?`, all of what is left.
fn time_part(b: &[u8]) -> Option<(i64, i64, i64)> {
    let b = if matches!(b.first(), Some(b' ' | b't')) { &b[1..] } else { b };
    let hour_len = if b.get(1).is_some_and(u8::is_ascii_digit) { 2 } else { 1 };
    let hour = digits_at(b, 0, hour_len)?;
    let rest = &b[hour_len..];
    if rest.first() != Some(&b':') {
        return None;
    }
    let minute = digits_at(rest, 1, 2)?;
    match &rest[3..] {
        [] => Some((hour, minute, 0)),
        [b':', s @ ..] if s.len() == 2 => Some((hour, minute, digits_at(s, 0, 2)?)),
        _ => None,
    }
}
