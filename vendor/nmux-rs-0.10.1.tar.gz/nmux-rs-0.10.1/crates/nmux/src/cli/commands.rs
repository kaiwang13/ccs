//! The subcommands: `Cli` in `src/cli/main.js`, one method each.

use std::fmt::Write as _;
use std::io::{self, BufRead, Write};
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use nmux_client::attach::{AttachFlags, MIN_BAR_ROWS};
use nmux_client::command::run_lent;
use nmux_client::config::Config;
use nmux_client::control::{Incoming, SessionClient};
use nmux_client::ctl::{CtlError, Reply, control_request};
use nmux_client::pager::{Output, View, view};
use nmux_client::run::{Attaching, ask, attach, attach_precheck};
use nmux_client::text::Words;
use nmux_history::read::{Kept, Pattern, Target, Window, all_lines_of, kept_under, match_json, match_text, matches};
use nmux_platform::{command_line, cwd_of, is_locked, is_terminal};
use nmux_time::{Zone, parse_when, zone};
use serde_json::{Map, Value, json};

use super::demo;
use super::doctor::doctor;
use super::format::{age, js_text, print_table, short_path, state_text};
use super::running::{NOT_STARTED_MS, Running};
use super::sessions::{
    NewSession, Paths, Session, Spool, at_once, create_session, ensure_runtime, find_session, is_alive, list_sessions,
    now_ms, random_hex, read_json, remove_session, rename_session, resolve_path, start_server, status_of, valid_name,
    wait_running,
};
use super::shells::{shell_dir, with_marks};
use super::{
    Args, CliError, EXIT_TIMED_OUT, Failure, Io, exit_code_of, name_for_directory, parse_args, parse_bytes, parse_time,
    refusal,
};

const SHELL_ARG: &str = "-l";
const STOP_WAIT_MS: u64 = 120_000;
const STOP_RETRY_MS: u64 = 50;
const SERVER_GRACE_MS: u64 = 300;
const SEND_MAX_BYTES: usize = 48_000;
/// A new server answers once it has read everything back, which on a busy machine is not quick.
const READ_BACK_WAIT_MS: u64 = 120_000;
const WAIT_POLL_MS: u64 = 100;
/// A key that shows the history waits no longer than this for a busy session to say what it has not written; what is
/// written shows anyway.
const LEND_READ_WAIT_MS: u64 = 5000;
const PICK_PROMPT: &str = "Session (Enter for 1): ";
const EVENTS: [&str; 11] =
    ["lifecycle", "notice", "stopped", "holder", "attached", "tty", "match", "exit", "respawned", "prompt", "command"];

/// Writes to standard output, as far as it takes it: a reader that has gone is not this command's failure.
fn out(text: &str) {
    let mut o = io::stdout().lock();
    let _ = o.write_all(text.as_bytes()).and_then(|()| o.flush());
}

fn out_bytes(bytes: &[u8]) {
    let mut o = io::stdout().lock();
    let _ = o.write_all(bytes).and_then(|()| o.flush());
}

fn err(text: &str) {
    let mut e = io::stderr().lock();
    let _ = e.write_all(text.as_bytes());
}

fn say(text: &str) {
    out(&format!("{text}\n"));
}

fn sleep(ms: u64) {
    std::thread::sleep(Duration::from_millis(ms));
}

/// `Number(text)`, for what a person gives as a number.
fn js_number(text: &str) -> f64 {
    let t = text.trim();
    if t.is_empty() {
        return 0.0;
    }
    let radix = |prefix: &[&str], radix: u32| {
        prefix.iter().find_map(|p| t.strip_prefix(p)).map(|digits| {
            #[allow(clippy::cast_precision_loss)] // as JavaScript reads it, into a double
            u64::from_str_radix(digits, radix).map_or(f64::NAN, |n| n as f64)
        })
    };
    if let Some(n) = radix(&["0x", "0X"], 16).or_else(|| radix(&["0o", "0O"], 8)).or_else(|| radix(&["0b", "0B"], 2)) {
        return n;
    }
    match t {
        "Infinity" | "+Infinity" => f64::INFINITY,
        "-Infinity" => f64::NEG_INFINITY,
        _ if t.bytes().all(|b| b.is_ascii_digit() || matches!(b, b'.' | b'e' | b'E' | b'+' | b'-')) => {
            t.parse().unwrap_or(f64::NAN)
        }
        _ => f64::NAN,
    }
}

/// A number as `JSON.stringify` writes it: whole numbers without a fraction, and null for what is not one.
fn json_number(n: f64) -> Value {
    if !n.is_finite() {
        return Value::Null;
    }
    #[allow(clippy::cast_possible_truncation)] // whole, and within what a double holds exactly
    if n.fract() == 0.0 && n.abs() < 9_007_199_254_740_992.0 {
        return Value::from(n as i64);
    }
    serde_json::Number::from_f64(n).map_or(Value::Null, Value::Number)
}

/// The command.
#[derive(Debug)]
pub struct Cli {
    io: Io,
    paths: Paths,
    config: Config,
}

impl Cli {
    /// The command, in this environment.
    pub fn new(io: Io) -> Self {
        let paths = Paths::resolve(&io.env, &io.cwd);
        let config = Config::load(Some(&paths.config_file));
        Self { io, paths, config }
    }

    fn env(&self, key: &str) -> Option<&str> {
        self.io.env.get(key).map(String::as_str).filter(|v| !v.is_empty())
    }

    fn current(&self) -> Option<&str> {
        self.env("NMUX_ID")
    }

    /// Where kept histories are: the configuration says, or else the user's state directory.
    fn history_root(&self) -> PathBuf {
        self.config.text("history", "dir").map_or_else(|| self.paths.history_dir.clone(), PathBuf::from)
    }

    /// Runs a subcommand.
    pub fn dispatch(&mut self, cmd: Option<&str>, args: &[String]) -> Result<i32, CliError> {
        if cmd != Some("doctor") {
            // doctor is how a bad one gets explained.
            ensure_runtime(&self.paths)?;
        }
        let Some(cmd) = cmd else { return self.bare() };
        match cmd {
            "events" => self.events(args),
            "search" => self.search(args),
            "view" => self.view(args),
            "new" => self.new_session(args),
            "a" | "attach" => self.a(args),
            "ls" | "list" => self.ls(args),
            "stop" => self.stop(args),
            "restart" => self.restart(args),
            "rm" => self.rm(args),
            "rename" => self.rename(args),
            "clients" => self.clients(args),
            "kick" => self.kick(args),
            "send" => self.send(args),
            "capture" => self.capture(args),
            "run" => self.run(args),
            "last" => self.last(args),
            "wait" => self.wait(args),
            "demo" => self.demo(args),
            "doctor" => {
                let (text, code) = doctor(&self.paths, &self.io.env);
                out(&text);
                Ok(code)
            }
            other => Err(CliError::Usage(format!("unknown command '{other}'"))),
        }
    }

    // ---- sessions ----------------------------------------------------------------------------------------------------

    /// A named session, or the one this shell is running in.
    fn resolve(&self, name: Option<&str>) -> Result<Session, CliError> {
        let all = list_sessions(&self.paths);
        let found = match name {
            Some(name) => all.iter().find(|s| s.name == name),
            None => all.iter().find(|s| Some(s.id.as_str()) == self.current()),
        };
        if let Some(s) = found {
            return Ok(s.clone());
        }
        let Some(name) = name else {
            return Err(CliError::Usage("name a session (or run this inside one)".to_owned()));
        };
        let known: Vec<_> = all.iter().map(|s| s.name.as_str()).collect();
        let there = if known.is_empty() { String::new() } else { format!(" (there is {})", known.join(", ")) };
        Err(CliError::Error(format!("no session named '{name}'{there}")))
    }

    /// A session that can be talked to. A holder that gave up on its server gets a new one.
    fn live(&self, s: Session) -> Result<Session, CliError> {
        let name = &s.name;
        if !s.alive {
            return Err(CliError::Error(format!("session '{name}' has ended: nmux restart {name}, or nmux rm {name}")));
        }
        let locked = |p: &Path| is_locked(p).unwrap_or(false);
        if !locked(&self.paths.sessiond_lock(&s.id)) {
            // It may be on its way already.
            sleep(SERVER_GRACE_MS);
            // No holder: it is still being created.
            let orphan = locked(&self.paths.holder_lock(&s.id)) && !locked(&self.paths.sessiond_lock(&s.id));
            if orphan {
                start_server(&self.paths, &self.io.env, &s.id, true, false)?;
            }
            wait_running(&self.paths, &s.id)?;
        }
        Ok(s)
    }

    fn request(&self, s: &Session, op: &str, args: Value, timeout_ms: u64) -> Result<Reply, CliError> {
        let r = control_request(&self.paths.ctl_sock(&s.id), op, args, timeout_ms, "nmux")
            .map_err(|e| CliError::Error(e.message))?;
        if !r.ok {
            let error = r.error.clone().unwrap_or_else(|| "null".to_owned());
            return Err(CliError::Error(format!("session '{}': {error}", s.name)));
        }
        Ok(r)
    }

    fn ask(&self, s: &Session, op: &str, args: Value, timeout_ms: u64) -> Result<Value, CliError> {
        self.request(s, op, args, timeout_ms).map(|r| r.data)
    }

    /// The size of a session this terminal is about to attach to: all of it but the row nmux's bar takes there.
    fn attaching_size(&self) -> (u32, u32) {
        let (cols, rows) = self.size();
        if self.config.truthy("overlay", "bar") && rows >= MIN_BAR_ROWS { (cols, rows - 1) } else { (cols, rows) }
    }

    fn size(&self) -> (u32, u32) {
        let stdout = io::stdout();
        let (cols, rows) = if is_terminal(std::os::fd::AsFd::as_fd(&stdout)) {
            nmux_platform::window_size(std::os::fd::AsFd::as_fd(&stdout)).unwrap_or((0, 0))
        } else {
            (0, 0)
        };
        if cols > 0 && rows > 0 {
            (u32::from(cols), u32::from(rows))
        } else {
            let n = |k: &str| u32::try_from(self.config.count("size", k)).unwrap_or(0);
            (n("defaultCols"), n("defaultRows"))
        }
    }

    // ---- attaching ---------------------------------------------------------------------------------------------------

    #[allow(clippy::unnecessary_wraps)] // as every other way a command ends
    fn enter(&self, s: &Session, flags: AttachFlags) -> Result<i32, CliError> {
        let sock = self.paths.ctl_sock(&s.id);
        let words = Words::default();
        let commands = self.config.commands();
        let a = Attaching {
            sock: &sock,
            name: &s.name,
            config: &self.config,
            flags,
            env: &self.io.env,
            actions: ["history".to_owned()].into_iter().chain(commands.iter().map(|(n, _)| n.clone())).collect(),
            words: &words,
        };
        let mut actions = |action: &str, take: &mut dyn FnMut() -> bool| {
            if action != "history" {
                if let Some((_, argv)) = commands.iter().find(|(n, _)| n == action) {
                    run_lent(argv, &s.name, &sock, take);
                }
                return;
            }
            // It said why on the terminal, and the join draws the screen again.
            let Ok(kept) = self.history_of(None, Some(&s.id)) else { return };
            let zone = zone(self.env("TZ"));
            let v = View {
                kept: &kept,
                sock: Some(&sock),
                zone: &zone,
                target: Target::default(),
                grep: None,
                times: false,
                wait_ms: LEND_READ_WAIT_MS,
            };
            let output = Output { tty: true, pager: self.env("NMUX_PAGER").map(str::to_owned) };
            let _ = view(&v, &output, now_ms(), Some(take));
        };
        Ok(attach(&a, &mut actions))
    }

    /// Attach, create or pick.
    fn bare(&mut self) -> Result<i32, CliError> {
        let live: Vec<_> = list_sessions(&self.paths).into_iter().filter(|s| s.alive).collect();
        match live.len() {
            0 => self.start_and_attach(None, NewOptions::default()),
            1 => {
                let s = self.live(live[0].clone())?;
                self.enter(&s, AttachFlags::default())
            }
            _ => self.pick(&live, AttachFlags::default()),
        }
    }

    fn pick(&self, live: &[Session], flags: AttachFlags) -> Result<i32, CliError> {
        if !is_terminal(std::os::fd::AsFd::as_fd(&io::stdin())) {
            let names: Vec<_> = live.iter().map(|s| s.name.as_str()).collect();
            return Err(CliError::Usage(format!("several sessions: name one of {}", names.join(", "))));
        }
        let list = live.iter().enumerate().fold(String::new(), |mut list, (i, s)| {
            let _ = writeln!(list, "  {}  {}", i + 1, s.name);
            list
        });
        out(&list);
        // readline edits the answer where the output is a terminal, and otherwise reads a line as the terminal gives it
        let answer = if is_terminal(std::os::fd::AsFd::as_fd(&io::stdout())) {
            let dumb = self.io.env.get("TERM").is_some_and(|t| t == "dumb");
            ask(PICK_PROMPT, dumb).map_err(|e| CliError::Error(e.to_string()))?.unwrap_or_else(|| "q".to_owned())
        } else {
            out(PICK_PROMPT);
            let mut typed = String::new();
            match io::stdin().lock().read_line(&mut typed) {
                Ok(0) | Err(_) => "q".to_owned(),
                Ok(_) => typed.trim_end_matches(['\n', '\r']).to_owned(),
            }
        };
        let answer = answer.as_str();
        if answer.starts_with(['q', 'Q']) {
            return Ok(0);
        }
        let trimmed = answer.trim();
        let by_number = if trimmed.is_empty() {
            Some(0)
        } else {
            let n = js_number(answer);
            #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)] // checked to be a whole index first
            (n.fract() == 0.0 && n >= 1.0).then(|| n as usize - 1)
        };
        let chosen = by_number.and_then(|i| live.get(i)).or_else(|| live.iter().find(|s| s.name == trimmed));
        let Some(chosen) = chosen else { return Err(CliError::Error(format!("no such session: {answer}"))) };
        let s = self.live(chosen.clone())?;
        self.enter(&s, flags)
    }

    fn start_and_attach(&mut self, name: Option<&str>, o: NewOptions) -> Result<i32, CliError> {
        let (stdin, stdout) = (io::stdin(), io::stdout());
        let tty = |fd: std::os::fd::BorrowedFd<'_>| is_terminal(fd);
        if let Some((code, message)) = attach_precheck(
            tty(std::os::fd::AsFd::as_fd(&stdin)),
            tty(std::os::fd::AsFd::as_fd(&stdout)),
            &self.io.env,
            &Words::default(),
        ) {
            err(&format!("{message}\n"));
            return Ok(code);
        }
        let o = NewOptions { size: o.size.or_else(|| Some(self.attaching_size())), ..o };
        let (id, name) = self.create(name, o, true)?;
        let spec = read_json(&self.paths.spec_file(&id)).unwrap_or(Value::Null);
        let s = Session { id, name, spec, state: None, alive: true };
        self.enter(&s, AttachFlags::default())
    }

    fn create(&self, name: Option<&str>, o: NewOptions, attaching: bool) -> Result<(String, String), CliError> {
        let env = &self.io.env;
        let command = if o.argv.is_empty() {
            vec![self.env("SHELL").unwrap_or("/bin/sh").to_owned(), SHELL_ARG.to_owned()]
        } else {
            o.argv.clone()
        };
        let cwd = o.cwd.unwrap_or_else(|| self.io.cwd.clone());
        if !cwd.exists() {
            return Err(CliError::Error(format!("no such directory: {}", cwd.display())));
        }
        // The environment in the order it came, as the spread of process.env keeps it.
        let mut child_env = Map::new();
        for (k, v) in std::env::vars_os() {
            child_env.insert(k.to_string_lossy().into_owned(), Value::from(v.to_string_lossy().into_owned()));
        }
        let integration = o.integration && self.config.truthy("shell", "integration");
        let marked =
            if integration { with_marks(&command, &child_env, || shell_dir(self.paths.runtime_dir())) } else { None };
        let argv = marked.as_ref().map_or(command, |m| m.argv.clone());
        if let Some(m) = &marked {
            for (k, v) in &m.env {
                child_env.insert(k.clone(), v.clone());
            }
        }
        let keep = o.keep.unwrap_or_else(|| self.config.truthy("history", "keep"));
        let spool_bytes = o.spool.unwrap_or_else(|| self.config.count("history", "spoolBytes"));
        let spool = if keep {
            Some(Spool::Keep(self.history_root()))
        } else {
            (spool_bytes > 0).then_some(Spool::Bytes(spool_bytes))
        };
        let (cols, rows) = o.size.unwrap_or_else(|| self.size());
        let base = name_for_directory(&cwd);
        let new = NewSession {
            name,
            base: &base,
            argv,
            cwd: &cwd,
            env: child_env,
            cols,
            rows,
            term: self.env("TERM").unwrap_or("xterm-256color"),
            attaching,
            shell: marked.map(|m| m.shell),
            spool,
        };
        create_session(&self.paths, env, &new)
    }

    fn new_session(&mut self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &["-d", "--no-integration", "--keep"], &["--cwd", "--size", "--spool"])?;
        if a.rest.len() > 1 {
            return Err(CliError::Usage("nmux new takes one name".to_owned()));
        }
        let name = a.rest.first().map(String::as_str);
        if let Some(name) = name.filter(|n| !valid_name(n)) {
            return Err(CliError::Usage(format!("bad session name '{name}': letters, digits, '.', '_' and '-'")));
        }
        let cwd = a.option("--cwd").filter(|c| !c.is_empty()).map(|c| resolve_path(&self.io.cwd, c));
        let size = match a.option("--size").filter(|s| !s.is_empty()) {
            Some(text) => {
                let parsed = text.split_once('x').and_then(|(c, r)| {
                    let digits = |s: &str| !s.is_empty() && s.bytes().all(|b| b.is_ascii_digit());
                    (digits(c) && digits(r))
                        .then(|| (c.parse::<u32>().unwrap_or(u32::MAX), r.parse::<u32>().unwrap_or(u32::MAX)))
                });
                Some(parsed.ok_or_else(|| CliError::Usage("--size takes COLSxROWS".to_owned()))?)
            }
            None => None,
        };
        let spool = a.option("--spool").filter(|s| !s.is_empty()).map(parse_bytes).transpose()?;
        let o = NewOptions {
            argv: a.command.clone(),
            cwd,
            size,
            integration: !a.flag("--no-integration"),
            spool,
            keep: a.flag("--keep").then_some(true),
        };
        if a.flag("-d") {
            let (_, name) = self.create(name, o, false)?;
            say(&name);
            return Ok(0);
        }
        self.start_and_attach(name, o)
    }

    fn a(&mut self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &["--view", "--full"], &[])?;
        let flags = AttachFlags { view: a.flag("--view"), full: a.flag("--full"), ..AttachFlags::default() };
        if let Some(name) = a.rest.first() {
            let s = self.live(self.resolve(Some(name))?)?;
            return self.enter(&s, flags);
        }
        let live: Vec<_> = list_sessions(&self.paths).into_iter().filter(|s| s.alive).collect();
        match live.len() {
            0 => Err(CliError::Error("no sessions; nmux new starts one".to_owned())),
            1 => {
                let s = self.live(live[0].clone())?;
                self.enter(&s, flags)
            }
            _ => self.pick(&live, flags),
        }
    }

    // ---- looking at sessions -----------------------------------------------------------------------------------------

    fn ls(&self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &["--json"], &[])?;
        let paths = &self.paths;
        let rows = at_once(list_sessions(paths), |s| {
            let mut status = if s.alive { status_of(paths, &s.id) } else { None };
            if let Some(Value::Object(st)) = &mut status {
                let foreground = foreground_of(st);
                let cwd = foreground.as_ref().and_then(|f| f.get("cwd").cloned()).unwrap_or(Value::Null);
                st.insert("foreground".to_owned(), foreground.map_or(Value::Null, Value::Object));
                st.insert("cwd".to_owned(), cwd);
            }
            (s, status)
        });
        if a.flag("--json") {
            let list: Vec<Value> = rows
                .iter()
                .map(|(s, status)| {
                    let mut row = Map::new();
                    row.insert("id".to_owned(), Value::from(s.id.clone()));
                    row.insert("name".to_owned(), Value::from(s.name.clone()));
                    row.insert("alive".to_owned(), Value::from(s.alive));
                    if let Some(at) = s.spec.get("createdAt") {
                        row.insert("createdAt".to_owned(), at.clone());
                    }
                    row.insert("status".to_owned(), status.clone().unwrap_or(Value::Null));
                    row.insert("lastExit".to_owned(), s.last_exit().cloned().unwrap_or(Value::Null));
                    Value::Object(row)
                })
                .collect();
            say(&Value::Array(list).to_string());
            return Ok(0);
        }
        if rows.is_empty() {
            say("no sessions");
            return Ok(0);
        }
        let now = now_ms();
        let home = self.env("HOME");
        let table: Vec<Vec<String>> = rows
            .iter()
            .map(|(s, status)| {
                let mark = if Some(s.id.as_str()) == self.current() { '*' } else { ' ' };
                let clients = status
                    .as_ref()
                    .and_then(|st| st.get("clients"))
                    .and_then(Value::as_array)
                    .map(Vec::len)
                    .filter(|&n| n > 0)
                    .map_or_else(|| "–".to_owned(), |n| n.to_string());
                let cwd = status
                    .as_ref()
                    .and_then(|st| st.get("cwd"))
                    .and_then(Value::as_str)
                    .filter(|c| !c.is_empty())
                    .or_else(|| s.spec.get("child").and_then(|c| c.get("cwd")).and_then(Value::as_str));
                vec![
                    format!("{mark} {}", s.name),
                    state_text(s.alive, s.state.as_ref(), status.as_ref(), now),
                    clients,
                    age(s.spec.get("createdAt"), now),
                    short_path(cwd, home),
                ]
            })
            .collect();
        let mut text = String::new();
        print_table(&mut text, &["  NAME", "STATE", "CLIENTS", "AGE", "CWD"], &table);
        out(&text);
        Ok(0)
    }

    fn clients(&self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &["--json"], &[])?;
        let s = self.live(self.resolve(a.rest.first().map(String::as_str))?)?;
        let data = self.ask(&s, "CLIENTS", json!({}), 5000)?;
        let clients = data.get("clients").cloned().unwrap_or_else(|| json!([]));
        if a.flag("--json") {
            say(&clients.to_string());
            return Ok(0);
        }
        let list = clients.as_array().cloned().unwrap_or_default();
        if list.is_empty() {
            say(&format!("nobody is attached to {}", s.name));
            return Ok(0);
        }
        let now = now_ms();
        let text = |c: &Value, k: &str| c.get(k).map(js_text).unwrap_or_default();
        let since = |c: &Value, k: &str| -> Option<Value> {
            #[allow(clippy::cast_precision_loss)] // a time in ms
            let ms = c.get(k)?.as_f64()?;
            #[allow(clippy::cast_precision_loss)]
            Some(json_number(now as f64 - ms))
        };
        let rows: Vec<Vec<String>> = list
            .iter()
            .map(|c| {
                let view = if c.get("view").is_some_and(nmux_client::config::truthy) { " (view)" } else { "" };
                let idle = if c.get("idleMs").is_none_or(Value::is_null) {
                    "–".to_owned()
                } else {
                    age(since(c, "idleMs").as_ref(), now)
                };
                vec![
                    format!("{}{view}", text(c, "id")),
                    text(c, "label"),
                    format!("{}x{}", text(c, "cols"), text(c, "rows")),
                    age(since(c, "attachedMs").as_ref(), now),
                    idle,
                ]
            })
            .collect();
        let mut out_text = String::new();
        print_table(&mut out_text, &["ID", "LABEL", "SIZE", "ATTACHED", "IDLE"], &rows);
        out(&out_text);
        Ok(0)
    }

    fn capture(&self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &["--ansi"], &["--lines"])?;
        let s = self.live(self.resolve(a.rest.first().map(String::as_str))?)?;
        let lines = a.option("--lines").map_or(Value::Null, |l| json_number(js_number(l)));
        let r = self.request(&s, "CAPTURE", json!({ "lines": lines, "ansi": a.flag("--ansi") }), 5000)?;
        out_bytes(&r.output);
        Ok(0)
    }

    fn last(&self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &["--ansi", "--json"], &[])?;
        let s = self.live(self.resolve(a.rest.first().map(String::as_str))?)?;
        let r = control_request(
            &self.paths.ctl_sock(&s.id),
            "LAST",
            json!({ "ansi": a.flag("--ansi") }),
            READ_BACK_WAIT_MS,
            "nmux",
        )
        .map_err(|e| CliError::Error(e.message))?;
        if !r.ok {
            let error = r.error.unwrap_or_else(|| "null".to_owned());
            return Err(CliError::Error(refusal(&s.name, &error, &error)));
        }
        if a.flag("--json") {
            let mut shown = r.data.as_object().cloned().unwrap_or_default();
            shown.insert("output".to_owned(), Value::from(String::from_utf8_lossy(&r.output).into_owned()));
            say(&Value::Object(shown).to_string());
            return Ok(0);
        }
        out_bytes(&r.output);
        if !r.data.get("complete").is_some_and(nmux_client::config::truthy) {
            err("nmux: the start of its output has already left the history\n");
        }
        Ok(0)
    }

    // ---- changing sessions -------------------------------------------------------------------------------------------

    fn stop(&self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &["--all"], &[])?;
        let targets = if a.flag("--all") {
            list_sessions(&self.paths)
        } else {
            vec![self.resolve(a.rest.first().map(String::as_str))?]
        };
        let paths = &self.paths;
        at_once(targets, |s| stop_one(paths, &s)).into_iter().collect::<Result<Vec<()>, CliError>>()?;
        Ok(0)
    }

    fn restart(&self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &[], &[])?;
        let s = self.resolve(a.rest.first().map(String::as_str))?;
        if s.alive {
            self.ask(&s, "RESTART", json!({}), STOP_WAIT_MS)?;
            return Ok(0);
        }
        start_server(&self.paths, &self.io.env, &s.id, false, false)?;
        wait_running(&self.paths, &s.id)?;
        Ok(0)
    }

    fn rm(&self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &[], &[])?;
        let s = self.resolve(a.rest.first().map(String::as_str))?;
        if s.alive {
            return Err(CliError::Error(format!("session '{}' is running: nmux stop {}", s.name, s.name)));
        }
        remove_session(&self.paths, &s.id);
        Ok(0)
    }

    fn rename(&self, args: &[String]) -> Result<i32, CliError> {
        let rest = parse_args(args, &[], &[])?.rest;
        if rest.is_empty() || rest.len() > 2 {
            return Err(CliError::Usage("nmux rename [OLD] NEW".to_owned()));
        }
        let to = &rest[rest.len() - 1];
        if !valid_name(to) {
            return Err(CliError::Usage(format!("bad session name '{to}': letters, digits, '.', '_' and '-'")));
        }
        let s = self.resolve(if rest.len() == 2 { Some(&rest[0]) } else { None })?;
        rename_session(&self.paths, &s.id, to)?;
        if s.alive {
            self.ask(&s, "RENAME", json!({ "name": to }), 5000)?;
        }
        Ok(0)
    }

    fn kick(&self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &["--others"], &[])?;
        let all = list_sessions(&self.paths);
        let named = a.rest.first().and_then(|n| all.iter().find(|x| &x.name == n)).cloned();
        let s = match &named {
            Some(n) => self.live(n.clone())?,
            None => self.live(self.resolve(None)?)?,
        };
        let ids: Vec<String> = if named.is_some() { a.rest[1..].to_vec() } else { a.rest.clone() };
        let others = a.flag("--others");
        if others != ids.is_empty() {
            return Err(CliError::Usage("nmux kick [NAME] ID…|--others".to_owned()));
        }
        let args = if others {
            json!({ "allExcept": [self.own_client(&s)?], "by": "nmux kick" })
        } else {
            json!({ "clients": ids, "by": "nmux kick" })
        };
        let data = self.ask(&s, "KICK", args, 5000)?;
        let list = |k: &str| data.get(k).and_then(Value::as_array).cloned().unwrap_or_default();
        for c in list("kicked") {
            say(&format!(
                "detached {} ({})",
                c.get("id").map(js_text).unwrap_or_default(),
                c.get("label").map(js_text).unwrap_or_default()
            ));
        }
        let unknown = list("unknown");
        for id in &unknown {
            err(&format!("nmux: no client {} on {}\n", js_text(id), s.name));
        }
        Ok(i32::from(!unknown.is_empty()))
    }

    /// The terminal this command was typed in, which is the one that typed last. Only a shell inside the session can say that
    /// of itself: from anywhere else there is no telling, so --others is refused rather than guessed.
    fn own_client(&self, s: &Session) -> Result<String, CliError> {
        if self.current() != Some(s.id.as_str()) {
            let n = &s.name;
            return Err(CliError::Error(format!(
                "--others keeps your own terminal, which only a command typed inside '{n}' can tell: name the clients (nmux clients {n})"
            )));
        }
        let data = self.ask(s, "CLIENTS", json!({}), 5000)?;
        let clients = data.get("clients").and_then(Value::as_array).cloned().unwrap_or_default();
        let typed = clients
            .iter()
            .filter_map(|c| Some((c.get("idleMs")?.as_f64()?, c)))
            .min_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));
        let Some((_, typed)) = typed else {
            return Err(CliError::Error(
                "nobody has typed yet, so there is no telling which terminal is yours".to_owned(),
            ));
        };
        Ok(typed.get("id").map(js_text).unwrap_or_default())
    }

    fn send(&self, args: &[String]) -> Result<i32, CliError> {
        // The text is the caller's: nothing in it is an option.
        let mut words: Vec<&String> = args.iter().skip(1).collect();
        let name = args.first();
        let enter = words.first().is_none_or(|w| *w != "--no-enter");
        if !enter {
            words.remove(0);
        }
        if words.first().is_some_and(|w| *w == "--") {
            words.remove(0);
        }
        let (Some(name), false) = (name, words.is_empty()) else {
            return Err(CliError::Usage("nmux send NAME [--no-enter] [--] TEXT…".to_owned()));
        };
        let text = words.iter().map(|w| w.as_str()).collect::<Vec<_>>().join(" ");
        if text.len() > SEND_MAX_BYTES {
            return Err(CliError::Error(format!(
                "that is too much to type at once: the limit is {SEND_MAX_BYTES} bytes"
            )));
        }
        let s = self.live(self.resolve(Some(name))?)?;
        self.ask(&s, "SEND", json!({ "text": text, "enter": enter }), 5000)?;
        Ok(0)
    }

    // ---- following a session -----------------------------------------------------------------------------------------

    /// A control connection that hears the given events, and what it said once it was subscribed.
    fn subscribed(&self, s: &Session, events: &[&str], label: &str) -> SessionClient {
        let mut client = SessionClient::new(&self.paths.ctl_sock(&s.id), label, Some(json!({ "events": events })));
        client.open();
        client
    }

    /// Runs a line in a session's shell and exits as it did.
    fn run(&self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &["--queue", "--ansi", "--json"], &["--timeout"])?;
        let text = a.command.join(" ");
        if a.rest.len() != 1 || text.is_empty() {
            return Err(CliError::Usage("nmux run NAME [--queue] [--timeout T] [--ansi] [--json] -- CMD…".to_owned()));
        }
        let timeout = parse_time(a.option("--timeout"))?;
        let s = self.live(self.resolve(Some(&a.rest[0]))?)?;
        let o =
            RunIn { queue: a.flag("--queue"), ansi: a.flag("--ansi"), json: a.flag("--json"), quiet: false, timeout };
        self.run_in(&s, &text, o)
    }

    /// Runs a line in a session's shell and says what it printed. The exit code it ended with.
    fn run_in(&self, s: &Session, text: &str, o: RunIn) -> Result<i32, CliError> {
        let deadline = o.timeout.map(|ms| Instant::now() + Duration::from_millis(ms));
        let mut client = self.subscribed(s, &["command", "prompt", "stopped"], "nmux");
        let mut running = Running::new(&s.name, text, o.queue, o.ansi, o.json);
        let result = self.drive(s, &mut client, &mut running, deadline, o.quiet);
        client.close();
        result
    }

    fn drive(
        &self,
        s: &Session,
        client: &mut SessionClient,
        running: &mut Running,
        deadline: Option<Instant>,
        quiet: bool,
    ) -> Result<i32, CliError> {
        let stood = |r: &Running| {
            let (t, n) = (&r_text(r), &s.name);
            if r.progress.started {
                format!("'{t}': it is still running in {n}")
            } else if r.progress.queued {
                format!("a prompt in {n}: '{t}' has not run, and now will not")
            } else {
                format!("'{t}' to start in {n}")
            }
        };
        let timed_out = |r: &Running| {
            CliError::Failure(Failure::new(format!("timed out waiting for {}", stood(r)), EXIT_TIMED_OUT))
        };
        // Ready: subscribed.
        loop {
            match client.next(deadline) {
                Some(Incoming::Subscribed(_)) => break,
                Some(_) => {}
                None => return Err(timed_out(running)),
            }
        }
        running.start(client);
        let mut not_started_at: Option<Instant> = None;
        loop {
            Self::flush_said(running, quiet);
            if let Some(outcome) = running.outcome.take() {
                return outcome.map_err(CliError::Failure);
            }
            if running.not_started && not_started_at.is_none() {
                not_started_at = Some(Instant::now() + Duration::from_millis(NOT_STARTED_MS));
            } else if !running.not_started {
                not_started_at = None;
            }
            let wake = [deadline, not_started_at].into_iter().flatten().min();
            let next = client.next(wake);
            let now = Instant::now();
            match next {
                Some(Incoming::Answer { id, result }) => running.on_answer(id, result, client),
                Some(Incoming::Event(e)) => running.on_event(&e, client),
                Some(Incoming::Subscribed(_)) => running.on_subscribed(client),
                Some(Incoming::Down) => {
                    let alive = is_alive(&self.paths, &s.id);
                    let state = read_json(&self.paths.state_file(&s.id));
                    let last_exit = state.as_ref().and_then(|st| st.get("restarts")).and_then(|r| r.get("lastExit"));
                    running.on_down(alive, last_exit);
                }
                Some(Incoming::Up | Incoming::Refused) => {}
                None => {
                    if deadline.is_some_and(|d| now >= d) {
                        Self::flush_said(running, quiet);
                        return Err(timed_out(running));
                    }
                    if not_started_at.is_some_and(|t| now >= t) {
                        not_started_at = None;
                        running.on_not_started();
                    }
                    if client.stopped() {
                        return Err(timed_out(running));
                    }
                }
            }
        }
    }

    /// What the run has to say, said: unless `quiet`, when nothing is.
    fn flush_said(running: &mut Running, quiet: bool) {
        let said = std::mem::take(&mut running.said);
        if quiet {
            return;
        }
        if !said.stdout.is_empty() {
            out(&said.stdout);
        }
        if !said.stderr.is_empty() {
            err(&said.stderr);
        }
    }

    /// Blocks until a session gets there.
    fn wait(&self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &["--prompt", "--exit", "--new"], &["--text", "--timeout"])?;
        let wanted: Vec<&str> =
            ["--prompt", "--exit", "--text"].into_iter().filter(|f| a.flag(f) || a.option(f).is_some()).collect();
        if a.rest.len() != 1 || wanted.len() != 1 {
            return Err(CliError::Usage("nmux wait NAME --prompt|--exit|--text RE [--new] [--timeout T]".to_owned()));
        }
        let timeout = parse_time(a.option("--timeout"))?;
        let re = match a.option("--text") {
            Some(text) => {
                Some(Pattern::new(text, false, true).map_err(|e| CliError::Usage(format!("bad pattern: {e}")))?)
            }
            None => None,
        };
        let named = self.resolve(Some(&a.rest[0]))?;
        if !named.alive && wanted[0] == "--exit" {
            return Ok(exit_code_of(named.last_exit()));
        }
        let s = self.live(named)?;
        let deadline = timeout.map(|ms| Instant::now() + Duration::from_millis(ms));
        let mut client = self.subscribed(&s, &["prompt", "stopped"], "nmux");
        let what = format!("{} in {}", &wanted[0][2..], s.name);
        let timed_out = || CliError::Failure(Failure::new(format!("timed out waiting for {what}"), EXIT_TIMED_OUT));
        loop {
            match client.next(None) {
                Some(Incoming::Subscribed(_)) => break,
                Some(_) => {}
                None => return Err(timed_out()),
            }
        }
        let result = match (wanted[0], re) {
            ("--prompt", _) => Self::until_prompt(&mut client, &s, deadline),
            ("--exit", _) => self.until_exit(&mut client, &s, deadline),
            (_, Some(re)) => self.until_text(&mut client, &s, &re, a.flag("--new"), deadline),
            _ => Ok(None),
        };
        client.close();
        result?.ok_or_else(timed_out)
    }

    fn until_prompt(
        client: &mut SessionClient,
        s: &Session,
        deadline: Option<Instant>,
    ) -> Result<Option<i32>, CliError> {
        let mut check = client.request("COMMANDS", json!({}), READ_BACK_WAIT_MS);
        loop {
            let Some(next) = client.next(deadline) else { return Ok(None) };
            match next {
                Incoming::Answer { id, result } => {
                    if id != check {
                        continue;
                    }
                    match must("COMMANDS", result) {
                        Ok(data) if data.get("state").and_then(Value::as_str) == Some("prompt") => return Ok(Some(0)),
                        Ok(_) => {}
                        Err(e) if e.code == "DOWN" => {}
                        Err(e) => return Err(CliError::Error(refusal(&s.name, &e.code, &e.message))),
                    }
                }
                Incoming::Event(e) => match e.get("event").and_then(Value::as_str) {
                    Some("prompt") => return Ok(Some(0)),
                    Some("stopped") => return Err(CliError::Error(format!("'{}' ended", s.name))),
                    _ => {}
                },
                Incoming::Subscribed(_) => check = client.request("COMMANDS", json!({}), READ_BACK_WAIT_MS),
                _ => {}
            }
        }
    }

    fn until_exit(
        &self,
        client: &mut SessionClient,
        s: &Session,
        deadline: Option<Instant>,
    ) -> Result<Option<i32>, CliError> {
        loop {
            let Some(next) = client.next(deadline) else { return Ok(None) };
            match next {
                Incoming::Event(e) if e.get("event").and_then(Value::as_str) == Some("stopped") => {
                    return Ok(Some(exit_code_of(e.get("lastExit"))));
                }
                Incoming::Down if !is_alive(&self.paths, &s.id) => {
                    // A clean exit leaves nothing behind.
                    let state = read_json(&self.paths.state_file(&s.id));
                    let last = state.as_ref().and_then(|st| st.get("restarts")).and_then(|r| r.get("lastExit"));
                    return Ok(Some(exit_code_of(last)));
                }
                _ => {}
            }
        }
    }

    /// Asks for text, and waits for the answer while whatever else comes is let by.
    fn text_answer(
        client: &mut SessionClient,
        op: &str,
        args: Value,
        deadline: Option<Instant>,
    ) -> Result<Option<Value>, CtlError> {
        let id = client.request_text(op, args, 5000);
        loop {
            let Some(next) = client.next(deadline) else { return Ok(None) };
            if let Incoming::Answer { id: got, result } = next {
                if got != id {
                    continue;
                }
                let r = result?;
                if !r.ok {
                    let code = r.error.unwrap_or_else(|| "null".to_owned());
                    return Err(CtlError::new(&code, format!("{op}: {code}")));
                }
                let mut data = r.data.as_object().cloned().unwrap_or_default();
                data.insert("text".to_owned(), Value::from(String::from_utf8_lossy(&r.output).into_owned()));
                return Ok(Some(Value::Object(data)));
            }
        }
    }

    /// Text is read back rather than matched as it passes: a match then cannot fall between two reads of a program's output,
    /// or depend on how it coloured it. What is on the screen counts, because what a script waits for may arrive before it
    /// starts waiting; --new is for when that would be a stale answer.
    fn until_text(
        &self,
        client: &mut SessionClient,
        s: &Session,
        re: &Pattern,
        only_new: bool,
        deadline: Option<Instant>,
    ) -> Result<Option<i32>, CliError> {
        let number = |v: &Value, k: &str| v.get(k).and_then(Value::as_f64);
        let text_of = |v: &Value| v.get("text").and_then(Value::as_str).unwrap_or("").to_owned();
        let mut from: Option<f64> = None;
        let mut seen = String::new();
        if only_new {
            match Self::text_answer(client, "SINCE", json!({ "row": null }), deadline) {
                Ok(Some(first)) => {
                    from = number(&first, "cursor");
                    let t = text_of(&first);
                    t[t.rfind('\n').map_or(0, |i| i + 1)..].clone_into(&mut seen);
                }
                Ok(None) => return Ok(None),
                Err(e) => return Err(CliError::Error(e.message)),
            }
        }
        while !client.stopped() {
            let row = from.map_or(Value::Null, json_number);
            match Self::text_answer(client, "SINCE", json!({ "row": row }), deadline) {
                Ok(None) => return Ok(None),
                Ok(Some(r)) => {
                    let text = text_of(&r);
                    let looked = if only_new && text.starts_with(&seen) { &text[seen.len()..] } else { &text[..] };
                    if re.is_match(looked) {
                        return Ok(Some(0));
                    }
                    let (cursor, top) = (number(&r, "cursor"), number(&r, "top"));
                    // It went up the screen, past where this was reading from.
                    let came_back = only_new && from.is_some() && cursor.zip(from).is_some_and(|(c, f)| c < f);
                    if from != if only_new { cursor } else { top } {
                        seen.clear();
                    }
                    from = if only_new && !came_back { cursor } else { top };
                    if came_back {
                        continue;
                    }
                }
                Err(e) if e.code == "DOWN" || e.code == "TIMEOUT" => {
                    if !is_alive(&self.paths, &s.id) {
                        return Err(CliError::Error(format!("'{}' ended", s.name)));
                    }
                }
                Err(e) => return Err(CliError::Error(e.message)),
            }
            let pause = Instant::now() + Duration::from_millis(WAIT_POLL_MS);
            let until = deadline.map_or(pause, |d| d.min(pause));
            while client.next(Some(until)).is_some() {}
            if deadline.is_some_and(|d| Instant::now() >= d) {
                return Ok(None);
            }
        }
        // Given up on: nobody is listening.
        Ok(Some(0))
    }

    /// Sessions full of what nmux shows, to look at: a shell that has printed text of every kind, a program that has the
    /// whole screen, and a history of three days. Nothing that is there already is touched, but a history an earlier demo
    /// made.
    fn demo(&mut self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &[], &[])?;
        if a.rest.len() > 1 {
            return Err(CliError::Usage("nmux demo [NAME]".to_owned()));
        }
        let name = a.rest.first().map_or("demo", String::as_str).to_owned();
        if !valid_name(&name) {
            return Err(CliError::Usage(format!("bad session name '{name}': letters, digits, '.', '_' and '-'")));
        }
        let (screen, past) = (format!("{name}-screen"), format!("{name}-days"));
        for n in [&name, &screen] {
            if find_session(&self.paths, n).is_some() {
                return Err(CliError::Error(format!(
                    "a session named '{n}' already exists: nmux stop {n}, or nmux demo ANOTHER"
                )));
            }
        }
        let root = self.history_root();
        let earlier: Vec<Kept> = kept_under(&root).into_iter().filter(|k| k.name == past).collect();
        let by_demo = |k: &Kept| {
            let program = read_json(&k.dir.join("meta.json")).and_then(|m| m.get("argv").cloned());
            program == Some(json!(["nmux", "demo"]))
        };
        if !earlier.iter().all(by_demo) {
            return Err(CliError::Error(format!("a history named '{past}' is kept already: nmux demo ANOTHER")));
        }
        let dir = self.paths.runtime_dir().join("run").join("demo").join(&name);
        let size = self.size();
        demo::write_files(&dir, size.0 as usize).map_err(|e| CliError::Error(format!("{}: {e}", dir.display())))?;
        for k in &earlier {
            let _ = std::fs::remove_dir_all(&k.dir);
        }
        let id = random_hex(4);
        let lines = demo::days(now_ms(), &zone(self.env("TZ")));
        demo::keep(&root.join(&id), &id, &past, &dir, &lines)
            .map_err(|e| CliError::Error(format!("{}: {e}", root.display())))?;
        let shell = NewOptions {
            argv: Vec::new(),
            cwd: Some(dir.clone()),
            size: Some(size),
            integration: true,
            spool: None,
            keep: None,
        };
        self.create(Some(&name), shell.clone(), false)?;
        let program = vec!["/bin/sh".to_owned(), "screen".to_owned()];
        let program = NewOptions { argv: program, integration: false, ..shell };
        self.create(Some(&screen), program, false)?;
        let s = self.live(self.resolve(Some(&name))?)?;
        let prompt = ["--prompt", "--timeout", "30"].map(str::to_owned);
        if self.wait(&[[name.clone()].as_slice(), &prompt].concat())? != 0 {
            return Err(CliError::Error(format!("'{name}' never came to a prompt")));
        }
        for line in demo::LINES {
            let o = RunIn { queue: false, ansi: false, json: false, quiet: true, timeout: Some(30_000) };
            self.run_in(&s, line, o)?;
        }
        let mut table = String::new();
        let rows = [
            [
                &name,
                "a shell that has printed colours, styles, characters, wrapping and links, set a title and failed once",
                &format!("nmux a {name}"),
            ],
            [&screen, "a program that has the whole screen, on the other one", &format!("nmux a {screen}")],
            [
                &past,
                "the history of three days, with errors in it",
                &format!("nmux view {past} --times, nmux search ERROR {past}"),
            ],
        ];
        let rows: Vec<Vec<String>> = rows.iter().map(|r| r.iter().map(|c| (*c).to_owned()).collect()).collect();
        print_table(&mut table, &["NAME", "WHAT IT IS", "TO SEE IT"], &rows);
        out(&table);
        say(&format!("Their files are in {}. nmux stop {name}; nmux stop {screen} ends the sessions.", dir.display()));
        Ok(0)
    }

    /// Follows a session until it ends.
    fn events(&self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &[], &[])?;
        let s = self.live(self.resolve(a.rest.first().map(String::as_str))?)?;
        let mut client = self.subscribed(&s, &EVENTS, "nmux events");
        while let Some(next) = client.next(None) {
            match next {
                Incoming::Event(e) => {
                    let mut shown = Map::new();
                    shown.insert("at".to_owned(), Value::from(nmux_time::iso(now_ms())));
                    let stopped = e.get("event").and_then(Value::as_str) == Some("stopped");
                    shown.extend(e);
                    say(&Value::Object(shown).to_string());
                    if stopped {
                        break;
                    }
                }
                Incoming::Down if !is_alive(&self.paths, &s.id) => break,
                _ => {}
            }
        }
        client.close();
        Ok(0)
    }

    // ---- kept histories ----------------------------------------------------------------------------------------------

    /// The history of a name: the one kept for it, whether its session is running or has ended, or else what a running
    /// session still has, in its spool and on its screen. `id`: a running session's own.
    fn history_of(&self, name: Option<&str>, id: Option<&str>) -> Result<Kept, CliError> {
        let all = kept_under(&self.history_root());
        let live = list_sessions(&self.paths);
        let want = match (id, name) {
            (Some(id), _) => Some(id.to_owned()),
            (None, None) => self.current().map(str::to_owned),
            (None, Some(name)) => live.iter().find(|s| s.name == name).map(|s| s.id.clone()),
        };
        let found = all.iter().rev().find(|k| match &want {
            Some(want) => &k.id == want,
            None => Some(k.name.as_str()) == name,
        });
        if let Some(found) = found {
            return Ok(found.clone());
        }
        if let Some(running) = want.as_ref().and_then(|w| live.iter().find(|s| &s.id == w)) {
            let n = if running.name.is_empty() { running.id.clone() } else { running.name.clone() };
            return Ok(Kept {
                id: running.id.clone(),
                name: n,
                dir: self.paths.session_dir(&running.id),
                created_at: None,
                cwd: None,
            });
        }
        let Some(name) = name else {
            return Err(CliError::Error(
                "name a session, or one whose history is kept (nmux new --keep keeps one)".to_owned(),
            ));
        };
        let mut known: Vec<&str> = Vec::new();
        for k in &all {
            if !known.contains(&k.name.as_str()) {
                known.push(&k.name);
            }
        }
        let there = if known.is_empty() { String::new() } else { format!(" (there is {})", known.join(", ")) };
        Err(CliError::Error(format!("'{name}' is not running and has no kept history{there}")))
    }

    /// A running session's socket, so that what it has not written is read too.
    fn sock_of(&self, k: &Kept) -> Option<PathBuf> {
        self.paths.layout.session_dir(&k.id).ok()?;
        is_alive(&self.paths, &k.id).then(|| self.paths.ctl_sock(&k.id))
    }

    fn zone_for(&self, a: &Args) -> Zone {
        zone(a.option("--zone").filter(|z| !z.is_empty()).or_else(|| self.env("TZ")))
    }

    /// Every line in kept histories that matches, or in these sessions'.
    fn search(&self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &["-i", "--json"], &["--since", "--until", "--zone"])?;
        let Some((pattern, names)) = a.rest.split_first().filter(|(p, _)| !p.is_empty()) else {
            return Err(CliError::Usage(
                "nmux search PATTERN [NAME…] [--since T] [--until T] [-i] [--json]".to_owned(),
            ));
        };
        let re =
            Pattern::new(pattern, a.flag("-i"), false).map_err(|e| CliError::Usage(format!("bad pattern: {e}")))?;
        let tz = self.zone_for(&a);
        let when = |flag: &str| -> Result<Option<i64>, CliError> {
            let Some(t) = a.option(flag) else { return Ok(None) };
            parse_when(t, now_ms(), &tz).map(Some).ok_or_else(|| {
                CliError::Usage(format!(
                    "{flag}: no time in '{t}': for example 2026-11-01, '2026-11-01 14:00', 14:00, yesterday or 2h"
                ))
            })
        };
        let window = Window { since: when("--since")?, until: when("--until")? };
        let kept: Vec<Kept> = if names.is_empty() {
            kept_under(&self.history_root())
        } else {
            names.iter().map(|n| self.history_of(Some(n), None)).collect::<Result<_, _>>()?
        };
        let color = is_terminal(std::os::fd::AsFd::as_fd(&io::stdout()));
        let json = a.flag("--json");
        let mut found = 0;
        for k in &kept {
            let unwritten = self
                .sock_of(k)
                .and_then(|sock| nmux_client::pager::unwritten_of(&sock, false, READ_BACK_WAIT_MS, now_ms()));
            for read in all_lines_of(k, unwritten, false) {
                let line = read?;
                if matches(&line, &re, window) {
                    found += 1;
                    say(&if json { match_json(k, &line) } else { match_text(k, &line, &tz, &re, color) });
                }
            }
        }
        Ok(i32::from(found == 0))
    }

    /// A history in a pager, opened at a time, a row, or the first match.
    fn view(&self, args: &[String]) -> Result<i32, CliError> {
        let a = parse_args(args, &["--times"], &["--at", "--row", "--grep", "--zone"])?;
        let tz = self.zone_for(&a);
        let at = match a.option("--at") {
            Some(t) => {
                Some(parse_when(t, now_ms(), &tz).ok_or_else(|| CliError::Usage(format!("--at: no time in '{t}'")))?)
            }
            None => None,
        };
        let row = match a.option("--row") {
            Some(t) => {
                let n = js_number(t);
                if !(n.is_finite() && n.fract() == 0.0 && n.abs() <= 9_007_199_254_740_991.0) {
                    return Err(CliError::Usage(format!("--row: not a number: '{t}'")));
                }
                #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)]
                // whole; a row before the first is the first
                Some(n.max(0.0) as u64)
            }
            None => None,
        };
        let k = self.history_of(a.rest.first().map(String::as_str), None)?;
        let sock = self.sock_of(&k);
        let v = View {
            kept: &k,
            sock: sock.as_deref(),
            zone: &tz,
            target: Target { at, row },
            grep: a.option("--grep").filter(|g| !g.is_empty()).map(str::to_owned),
            times: a.flag("--times"),
            wait_ms: READ_BACK_WAIT_MS,
        };
        let output = Output {
            tty: is_terminal(std::os::fd::AsFd::as_fd(&io::stdout())),
            pager: self.env("NMUX_PAGER").map(str::to_owned),
        };
        Ok(view(&v, &output, now_ms(), None)?)
    }
}

fn r_text(r: &Running) -> String {
    r.text().to_owned()
}

impl Default for NewOptions {
    fn default() -> Self {
        Self { argv: Vec::new(), cwd: None, size: None, integration: true, spool: None, keep: None }
    }
}

/// What a request that must succeed gives: its data, or `OP: error` with the error as its code.
fn must(op: &str, result: Result<Reply, CtlError>) -> Result<Value, CtlError> {
    let r = result?;
    if r.ok {
        return Ok(r.data);
    }
    let code = r.error.unwrap_or_else(|| "null".to_owned());
    Err(CtlError::new(&code, format!("{op}: {code}")))
}

/// What is in a session's foreground. Asked here, not of the server: this can take a while, and a session must not wait for
/// it. The holder's answer can be a moment old, so the child is asked after it.
fn foreground_of(status: &Map<String, Value>) -> Option<Map<String, Value>> {
    let pid_of = |v: Option<&Value>| v.and_then(Value::as_i64).and_then(|p| i32::try_from(p).ok()).filter(|&p| p != 0);
    let candidates = [pid_of(status.get("foregroundPid")), pid_of(status.get("child").and_then(|c| c.get("pid")))];
    for pid in candidates.into_iter().flatten() {
        if let Some(command) = command_line(pid) {
            let mut f = Map::new();
            f.insert("pid".to_owned(), Value::from(pid));
            f.insert("command".to_owned(), Value::from(command));
            f.insert("cwd".to_owned(), cwd_of(pid).map_or(Value::Null, Value::from));
            return Some(f);
        }
    }
    None
}

/// How a line is run: `nmux run`'s flags, its timeout in ms, and `quiet`, for a run nothing is said about.
#[derive(Clone, Copy, Debug)]
#[allow(clippy::struct_excessive_bools)] // the flags of a command
struct RunIn {
    queue: bool,
    ansi: bool,
    json: bool,
    quiet: bool,
    timeout: Option<u64>,
}

/// What `nmux new` was asked for.
#[derive(Clone, Debug)]
struct NewOptions {
    argv: Vec<String>,
    cwd: Option<PathBuf>,
    size: Option<(u32, u32)>,
    integration: bool,
    spool: Option<u64>,
    keep: Option<bool>,
}

/// Asks until the session has gone: a server that is restarting will be back within moments.
fn stop_one(paths: &Paths, s: &Session) -> Result<(), CliError> {
    if !s.alive {
        remove_session(paths, &s.id);
        return Ok(());
    }
    let deadline = Instant::now() + Duration::from_millis(STOP_WAIT_MS);
    while is_alive(paths, &s.id) && Instant::now() < deadline {
        // the connection may go, which it does as a session ends
        if let Ok(r) = control_request(&paths.ctl_sock(&s.id), "STOP", json!({}), STOP_WAIT_MS, "nmux")
            && !r.ok
        {
            let error = r.error.unwrap_or_else(|| "null".to_owned());
            return Err(CliError::Error(format!("session '{}': {error}", s.name)));
        }
        sleep(STOP_RETRY_MS);
    }
    if is_alive(paths, &s.id) {
        return Err(CliError::Error(format!("session '{}' did not stop", s.name)));
    }
    remove_session(paths, &s.id);
    Ok(())
}
