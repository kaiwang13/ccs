//! Rows as text: `src/server/output/cells.js`, which turns rows into strings that recreate the same cells when written at
//! column 1 of a line with default attributes. What it writes is the same byte for byte, mistakes included (see
//! [`cut_line`]), and with [`Extras`] it writes more, which `cells.js` cannot see: the hyperlinks cells are in, and the
//! prompt marks before them.

use std::fmt::Write;

use crate::attr::{Attr, CM_MASK, CM_P16, CM_P256, CM_RGB, PCOLOR_MASK, RGB_MASK, bg, fg};
use crate::line::{CODEPOINT_MASK, IS_COMBINED, WIDTH_SHIFT, push_codepoint, signed};

/// One cell as read out: its content word and its attributes.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct CellView {
    /// xterm's content word: code point, combined flag, width.
    pub content: u32,
    /// The attributes.
    pub attr: Attr,
}

impl CellView {
    /// `getWidth`: 0 for the right half of a wide character, 1 or 2 otherwise.
    pub fn width(self) -> u32 {
        self.content >> WIDTH_SHIFT
    }

    /// The cell holds text.
    pub fn has_content(self) -> bool {
        self.content & (CODEPOINT_MASK | IS_COMBINED) != 0
    }
}

/// What a row is written with besides its text and colours.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Extras {
    /// The hyperlinks cells are in, as OSC 8: a cell underlined only by being in one is not underlined.
    pub links: bool,
    /// The prompt marks before cells, as OSC 133.
    pub marks: bool,
}

impl Extras {
    /// What `cells.js` writes.
    pub const NONE: Extras = Extras { links: false, marks: false };
    /// Links, for text that is kept or read: a mark means nothing outside the terminal the session draws in.
    pub const LINKS: Extras = Extras { links: true, marks: false };
    /// Everything, for a terminal shown the rows again.
    pub const ALL: Extras = Extras { links: true, marks: true };
}

/// A row read out of a buffer, to be looked at a cell at a time. One is reused for many rows, so reading them allocates
/// nothing once it has grown. The links and marks of its cells are numbered in its own list of strings, from 1.
#[derive(Clone, Debug, Default)]
pub struct LineBuf {
    cells: Vec<CellView>,
    combined: Vec<(u32, String)>,
    combined_len: usize,
    strings: Vec<String>,
    strings_len: usize,
    wrapped: bool,
}

impl LineBuf {
    /// An empty one.
    pub fn new() -> LineBuf {
        LineBuf::default()
    }

    pub(crate) fn clear(&mut self, length: usize, wrapped: bool) {
        self.cells.clear();
        self.cells.resize(length, CellView { content: 1 << WIDTH_SHIFT, attr: Attr::DEFAULT });
        self.combined_len = 0;
        self.strings_len = 0;
        self.wrapped = wrapped;
    }

    /// The number for a link or marks in this row, 0 for none: rows have few, so they are looked for one by one.
    pub(crate) fn add_string(&mut self, s: &str) -> u32 {
        if s.is_empty() {
            return 0;
        }
        let at = if let Some(at) = self.strings[..self.strings_len].iter().position(|k| k == s) {
            at
        } else {
            if self.strings_len < self.strings.len() {
                let slot = &mut self.strings[self.strings_len];
                slot.clear();
                slot.push_str(s);
            } else {
                self.strings.push(s.to_owned());
            }
            self.strings_len += 1;
            self.strings_len - 1
        };
        u32::try_from(at + 1).unwrap_or(0)
    }

    /// A link's `params;uri`, or a cell's marks, by the number a cell has for it; empty for 0.
    pub fn string(&self, id: u32) -> &str {
        (id as usize).checked_sub(1).and_then(|i| self.strings[..self.strings_len].get(i)).map_or("", String::as_str)
    }

    pub(crate) fn set(&mut self, col: usize, content: u32, attr: Attr) {
        if let Some(c) = self.cells.get_mut(col) {
            *c = CellView { content, attr };
        }
    }

    pub(crate) fn add_combined(&mut self, key: usize, text: &str) {
        let key = u32::try_from(key).unwrap_or(u32::MAX);
        if self.combined_len < self.combined.len() {
            let slot = &mut self.combined[self.combined_len];
            slot.0 = key;
            slot.1.clear();
            slot.1.push_str(text);
        } else {
            self.combined.push((key, text.to_owned()));
        }
        self.combined_len += 1;
    }

    /// The row's length in cells.
    pub fn len(&self) -> usize {
        self.cells.len()
    }

    /// Whether it has no cells.
    pub fn is_empty(&self) -> bool {
        self.cells.is_empty()
    }

    /// `isWrapped`: the row carries on the one above it.
    pub fn is_wrapped(&self) -> bool {
        self.wrapped
    }

    /// The cell at `x`, which must be in the row.
    pub fn cell(&self, x: usize) -> CellView {
        self.cells[x]
    }

    fn combined_at(&self, x: usize) -> &str {
        let key = u32::try_from(x).unwrap_or(u32::MAX);
        self.combined[..self.combined_len].iter().find(|e| e.0 == key).map_or("undefined", |e| e.1.as_str())
    }

    /// `getChars`: the cell's text, empty for a cell with none.
    pub fn chars(&self, x: usize, out: &mut String) {
        let c = self.cells[x].content;
        if c & IS_COMBINED != 0 {
            out.push_str(self.combined_at(x));
        } else if c & CODEPOINT_MASK != 0 {
            push_codepoint(out, c & CODEPOINT_MASK);
        }
    }

    fn chars_empty(&self, x: usize) -> bool {
        let c = self.cells[x].content;
        if c & IS_COMBINED != 0 { self.combined_at(x).is_empty() } else { c & CODEPOINT_MASK == 0 }
    }

    /// `getTrimmedLength`.
    pub fn trimmed_length(&self) -> usize {
        for i in (0..self.cells.len()).rev() {
            let c = self.cells[i];
            if c.has_content() {
                return i + c.width() as usize;
            }
        }
        0
    }

    /// `translateToString(trimRight, startCol, endCol)`.
    pub fn translate(&self, trim_right: bool, start: usize, end: Option<usize>, out: &mut String) {
        let mut end = end.unwrap_or(self.cells.len());
        if trim_right {
            end = end.min(self.trimmed_length());
        }
        let mut col = start;
        while col < end {
            let c = self.cells.get(col).map_or(0, |c| c.content);
            if c & IS_COMBINED != 0 {
                out.push_str(self.combined_at(col));
            } else if c & CODEPOINT_MASK != 0 {
                push_codepoint(out, c & CODEPOINT_MASK);
            } else {
                out.push(' ');
            }
            col += ((c >> WIDTH_SHIFT) as usize).max(1);
        }
    }

    /// The same, as a new string.
    pub fn to_string(&self, trim_right: bool) -> String {
        let mut s = String::new();
        self.translate(trim_right, 0, None, &mut s);
        s
    }
}

/// Something with rows to read: a buffer of a terminal.
pub trait Lines {
    /// How many rows there are.
    fn line_count(&self) -> usize;
    /// Reads row `y` into `into`, or returns false when there is none.
    fn read_line(&self, y: usize, into: &mut LineBuf) -> bool;
}

fn color_sgr(word: u32, foreground: bool, out: &mut String) -> bool {
    let (base, bright, ext) = if foreground { (30, 90, 38) } else { (40, 100, 48) };
    match word & CM_MASK {
        CM_P16 => {
            let color = word & PCOLOR_MASK;
            if color < 8 {
                let _ = write!(out, "{}", base + color);
            } else {
                let _ = write!(out, "{}", bright + color - 8);
            }
        }
        CM_P256 => {
            let _ = write!(out, "{ext};5;{}", word & PCOLOR_MASK);
        }
        CM_RGB => {
            let c = word & RGB_MASK;
            let _ = write!(out, "{ext};2;{};{};{}", (c >> 16) & 255, (c >> 8) & 255, c & 255);
        }
        _ => return false,
    }
    true
}

/// `attrKey`: the attributes as SGR parameters, empty for none. Appended to `out`.
pub fn attr_key(a: Attr, out: &mut String) {
    if a.fg == 0 && a.bg == 0 {
        return;
    }
    let start = out.len();
    let push = |s: &str, out: &mut String| {
        if out.len() > start {
            out.push(';');
        }
        out.push_str(s);
    };
    if a.fg & fg::BOLD != 0 {
        push("1", out);
    }
    if a.bg & bg::DIM != 0 {
        push("2", out);
    }
    if a.bg & bg::ITALIC != 0 {
        push("3", out);
    }
    if a.is_underline() {
        push("4", out);
    }
    if a.fg & fg::BLINK != 0 {
        push("5", out);
    }
    if a.fg & fg::INVERSE != 0 {
        push("7", out);
    }
    if a.fg & fg::INVISIBLE != 0 {
        push("8", out);
    }
    if a.fg & fg::STRIKETHROUGH != 0 {
        push("9", out);
    }
    if a.bg & bg::OVERLINE != 0 {
        push("53", out);
    }
    for (word, foreground) in [(a.fg, true), (a.bg, false)] {
        let mark = out.len();
        if out.len() > start {
            out.push(';');
        }
        if !color_sgr(word, foreground, out) {
            out.truncate(mark);
        }
    }
}

/// Whether `attr_key` would be empty.
fn key_empty(a: Attr) -> bool {
    if a.fg == 0 && a.bg == 0 {
        return true;
    }
    let flags = fg::BOLD | fg::BLINK | fg::INVERSE | fg::INVISIBLE | fg::STRIKETHROUGH;
    a.fg & flags == 0
        && a.bg & (bg::DIM | bg::ITALIC | bg::OVERLINE) == 0
        && !a.is_underline()
        && a.fg & CM_MASK == 0
        && a.bg & CM_MASK == 0
}

/// `getCell(x, cell)`: a column outside the row leaves `cell` as it was.
fn load(line: &LineBuf, x: isize, cell: &mut CellView, at: &mut isize) {
    if let Some(&c) = usize::try_from(x).ok().and_then(|i| line.cells.get(i)) {
        *cell = c;
        *at = x;
    }
}

/// `lastUsedColumn`: the last column of a row that must be written, or -1. `at` is where `cell` was last loaded from.
fn last_used_column(line: &LineBuf, width: usize, cell: &mut CellView, at: &mut isize) -> isize {
    for x in (0..signed(width)).rev() {
        load(line, x, cell, at);
        if cell.width() == 0 {
            continue;
        }
        if !chars_empty(line, *at, *cell) || !key_empty(cell.attr) {
            return x + signed(cell.width()).max(1) - 1;
        }
    }
    -1
}

/// Whether the cell loaded from `at` has no text. A cell loaded long ago can only be told by its content word.
fn chars_empty(line: &LineBuf, at: isize, cell: CellView) -> bool {
    if let Some(at) = usize::try_from(at).ok().filter(|&at| cell.content & IS_COMBINED != 0 && at < line.len()) {
        return line.chars_empty(at);
    }
    cell.content & (CODEPOINT_MASK | IS_COMBINED) == 0
}

/// `serializeRows` for one row: `max_cols` truncates it.
pub fn serialize_row(line: &LineBuf, max_cols: Option<usize>, out: &mut String) {
    serialize_row_with(line, max_cols, Extras::NONE, out);
}

/// [`attr_key`] for a cell written with `extras`.
pub fn attr_key_with(a: Attr, extras: Extras, out: &mut String) {
    attr_key(as_shown(a, extras), out);
}

/// What opens the link with this `params;uri`.
pub fn link_start(link: &str, out: &mut String) {
    let _ = write!(out, "\x1b]8;{link}\x1b\\");
}

/// What ends a hyperlink.
pub const LINK_END: &str = "\x1b]8;;\x1b\\";

/// The attributes as SGR shows them, written with `extras`: a cell underlined only by the link it is in is not
/// underlined where the link is written as one. Every underline SGR makes sets the flag.
fn as_shown(a: Attr, extras: Extras) -> Attr {
    if extras.links && a.link != 0 && a.fg & fg::UNDERLINE == 0 {
        Attr { bg: a.bg & !bg::HAS_EXTENDED, ..a }
    } else {
        a
    }
}

/// [`serialize_row`], with `extras`. A link is closed where the row ends.
pub fn serialize_row_with(line: &LineBuf, max_cols: Option<usize>, extras: Extras, out: &mut String) {
    let width = max_cols.map_or(line.len(), |m| m.min(line.len()));
    let mut cell = CellView::default();
    let mut at = -1;
    let last = last_used_column(line, width, &mut cell, &mut at);
    let mut cur = String::new();
    let mut key = String::new();
    let mut key_of = None;
    let mut skip = 0usize;
    let mut open = 0u32;
    let mut x = 0usize;
    while signed(x) <= last && x < width {
        let c = line.cells[x];
        let w = c.width();
        if w == 0 {
            x += 1;
            continue;
        }
        if w == 2 && x + 1 >= width {
            break;
        }
        if key_of != Some(c.attr) {
            key.clear();
            attr_key(as_shown(c.attr, extras), &mut key);
            key_of = Some(c.attr);
        }
        let marks = if extras.marks { line.string(c.attr.mark) } else { "" };
        let empty = line.chars_empty(x);
        if empty && key.is_empty() && marks.is_empty() {
            skip += 1;
            x += 1;
            continue;
        }
        if skip > 0 {
            let _ = write!(out, "\x1b[{skip}C");
            skip = 0;
        }
        out.push_str(marks);
        if extras.links && c.attr.link != open {
            if open != 0 {
                out.push_str(LINK_END);
            }
            open = c.attr.link;
            if open != 0 {
                link_start(line.string(open), out);
            }
        }
        if empty && key.is_empty() {
            skip += 1; // the mark is where it goes, and the cell has nothing to write
            x += 1;
            continue;
        }
        if key != cur {
            out.push_str("\x1b[0");
            if !key.is_empty() {
                out.push(';');
                out.push_str(&key);
            }
            out.push('m');
            cur.clear();
            cur.push_str(&key);
        }
        if empty {
            out.push_str("\x1b[X\x1b[C");
        } else {
            line.chars(x, out);
        }
        x += 1;
    }
    if open != 0 {
        out.push_str(LINK_END);
    }
    if !cur.is_empty() {
        out.push_str("\x1b[0m");
    }
}

/// `serializeRows`: rows `from..to`, each as the bytes that draw it, with `extras`.
pub fn serialize_rows<L: Lines + ?Sized>(
    lines: &L,
    from: usize,
    to: usize,
    max_cols: Option<usize>,
    extras: Extras,
) -> Vec<String> {
    let mut buf = LineBuf::new();
    (from..to)
        .map(|y| {
            let mut s = String::new();
            if lines.read_line(y, &mut buf) {
                serialize_row_with(&buf, max_cols, extras, &mut s);
            }
            s
        })
        .collect()
}

/// `firstWrittenLine`: the first row before `limit` with any text, or `limit`.
pub fn first_written_line<L: Lines + ?Sized>(lines: &L, limit: usize) -> usize {
    let mut buf = LineBuf::new();
    (0..limit)
        .find(|&y| lines.read_line(y, &mut buf) && buf.trimmed_length() > 0 && has_visible_text(&buf))
        .unwrap_or(limit)
}

/// `translateToString(true) !== ''`.
fn has_visible_text(line: &LineBuf) -> bool {
    let mut s = String::new();
    line.translate(true, 0, None, &mut s);
    !s.is_empty()
}

/// `continues`: whether row `y` is really carried on by the next, full to its last column as xterm leaves a row it wrapped.
pub fn continues<L: Lines + ?Sized>(lines: &L, y: usize, cols: usize) -> bool {
    let mut next = LineBuf::new();
    if !lines.read_line(y + 1, &mut next) || !next.is_wrapped() {
        return false;
    }
    let mut cell = CellView::default();
    let mut at = -1;
    load(&next, 0, &mut cell, &mut at);
    if chars_empty(&next, at, cell) {
        return false;
    }
    let wide_next = cell.width() == 2;
    let mut line = LineBuf::new();
    if !lines.read_line(y, &mut line) {
        return false;
    }
    // `cell` still holds what was read from `next`, and a column outside `line` leaves it so.
    let mut at_line = isize::MIN;
    let last = last_used_column(&line, cols, &mut cell, &mut at_line);
    if last < 0 {
        return false;
    }
    load(&line, last, &mut cell, &mut at_line);
    if cell.width() == 0 {
        load(&line, last - 1, &mut cell, &mut at_line);
    }
    let empty = if at_line == isize::MIN { chars_empty(&next, at, cell) } else { chars_empty(&line, at_line, cell) };
    if empty {
        return false;
    }
    let cols = signed(cols);
    last >= cols - 1 || (last == cols - 2 && wide_next)
}

/// `serializeFlow`: rows as one stream, with no break where a row is carried on by the next, with `extras`.
pub fn serialize_flow<L: Lines + ?Sized>(lines: &L, from: usize, to: usize, cols: usize, extras: Extras) -> String {
    let rows = serialize_rows(lines, from, to, None, extras);
    let mut out = String::new();
    for (i, row) in rows.iter().enumerate() {
        out.push_str(row);
        if i + 1 < rows.len() && !continues(lines, from + i, cols) {
            out.push_str("\r\n");
        }
    }
    out
}

/// `logicalLines`: rows as whole lines, however they wrapped, with their colours and links when `ansi`.
pub fn logical_lines<L: Lines + ?Sized>(lines: &L, from: usize, to: usize, ansi: bool) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    let mut buf = LineBuf::new();
    for y in from..to {
        let found = lines.read_line(y, &mut buf);
        let mut text = String::new();
        if found {
            if ansi {
                serialize_row_with(&buf, None, Extras::LINKS, &mut text);
            } else {
                buf.translate(true, 0, None, &mut text);
            }
        }
        match out.last_mut() {
            Some(last) if found && buf.is_wrapped() => last.push_str(&text),
            _ => out.push(text),
        }
    }
    out
}

/// `cutLine`: the first `chars` characters of a line, colours taking no room and a cursor move the room it crosses.
///
/// It counts as JavaScript does, in UTF-16 units, and has the same mistake: its pattern only knows sequences with one
/// number, so in the `\e[0;1;31m` that starts every coloured run each byte counts as a character and the line is cut
/// short. A character cut in half becomes U+FFFD, as a lone surrogate does when it is written out. An OSC, which `cells.js`
/// never wrote, takes no room and is never cut, and a link open where the line is cut is closed.
pub fn cut_line(line: &str, chars: u64) -> String {
    let mut seen = 0u64;
    let mut out = String::new();
    let mut styled = false;
    let mut linked = false;
    let bytes = line.as_bytes();
    let mut i = 0;
    while i < line.len() {
        if seen >= chars {
            break;
        }
        if let Some(len) = osc_len(&bytes[i..]) {
            let piece = &line[i..i + len];
            if let Some(link) = piece.strip_prefix("\x1b]8;") {
                linked = !link.split(';').nth(1).is_some_and(|uri| uri.starts_with(['\x07', '\x1b']));
            }
            out.push_str(piece);
            i += len;
            continue;
        }
        if bytes[i] == 0x1b && bytes.get(i + 1) == Some(&b'[') {
            // A whole CSI: `\e[0;1;31m` is one escape, not nine characters.
            let params =
                bytes[i + 2..].iter().take_while(|b| b.is_ascii_digit() || matches!(b, b';' | b':' | b'?')).count();
            if bytes.get(i + 2 + params).is_some_and(|b| (0x40..=0x7e).contains(b)) {
                let end = i + 3 + params;
                let piece = &line[i..end];
                if bytes[end - 1] == b'C' {
                    let gap = &line[i + 2..i + 2 + params];
                    let n = gap.trim_start_matches('0');
                    // Node's `Number(gap) || 1`: anything but digits is NaN, so one.
                    let n = if n.is_empty() || !n.bytes().all(|b| b.is_ascii_digit()) {
                        0
                    } else {
                        n.parse::<u64>().unwrap_or(u64::MAX)
                    };
                    seen = seen.saturating_add(if n == 0 { 1 } else { n });
                } else {
                    styled = true;
                }
                out.push_str(piece);
                i = end;
                continue;
            }
        }
        let Some(ch) = line[i..].chars().next() else { break };
        if ch.len_utf16() == 2 {
            seen += 1;
            if seen >= chars {
                out.push('\u{FFFD}');
                break;
            }
            seen += 1;
        } else {
            seen += 1;
        }
        out.push(ch);
        i += ch.len_utf8();
    }
    if linked {
        out.push_str(LINK_END);
    }
    if styled {
        out.push_str("\x1b[0m");
    }
    out
}

/// The length of the OSC `s` starts with, ended by BEL or ST, if it does.
fn osc_len(s: &[u8]) -> Option<usize> {
    let rest = s.strip_prefix(b"\x1b]")?;
    let end = rest.iter().position(|&b| b == 0x07 || b == 0x1b)?;
    match rest[end] {
        0x07 => Some(2 + end + 1),
        _ => (rest.get(end + 1) == Some(&b'\\')).then_some(2 + end + 2),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn keys() {
        let mut s = String::new();
        attr_key(Attr::words(fg::BOLD | CM_P16 | 1, CM_RGB | 0x0001_0203), &mut s);
        assert_eq!(s, "1;31;48;2;1;2;3");
        s.clear();
        attr_key(Attr::words(0, bg::PROTECTED), &mut s);
        assert_eq!(s, "");
        assert!(key_empty(Attr::words(0, bg::PROTECTED)));
    }

    #[test]
    fn cutting() {
        assert_eq!(cut_line("abcdef", 3), "abc");
        assert_eq!(cut_line("a\x1b[3Cb", 3), "a\x1b[3C");
        assert_eq!(cut_line("\x1b[0;1mab\x1b[0m", 3), "\x1b[0;1mab\x1b[0m\x1b[0m");
        assert_eq!(cut_line("\x1b[0mab", 1), "\x1b[0ma\x1b[0m");
        assert_eq!(cut_line("a😀b", 2), "a\u{FFFD}");
    }
}
