//! The terminal emulator of nmux: what `@xterm/headless` 6 is to the Node server, built for this job. See
//! `docs/DESIGN.md` and `docs/ROUTE.md`.
//!
//! [`Terminal`] takes the tokens of `nmux-vt`'s lexer, so output is parsed once, and ends where xterm.js with the Unicode
//! 11 widths ends for the same bytes and resizes: the same cells, wrapped flags, cursor and modes, its mistakes
//! included, because that is what the conformance suite and the files shared with the Node server compare. A cell on a
//! screen is eight bytes, its attributes a number in a table, and a line that scrolls off is packed into the history as
//! it leaves. A cell also keeps what xterm does not: the hyperlink it is in, and the prompt marks printed just before it.
//!
//! [`cells`] is `cells.js`: rows as the bytes that draw them, which the spool writes and joins send, with the links and
//! marks when asked.
//!
//! ```
//! use nmux_term::{Terminal, cells};
//!
//! let mut term = Terminal::new(20, 3, 100);
//! term.write(b"\x1b[1;31mred\x1b[m plain\r\nnext");
//! let rows = cells::serialize_rows(&term.normal(), 0, 2, None, cells::Extras::NONE);
//! assert_eq!(rows[0], "\x1b[0;1;31mred\x1b[0m plain");
//! assert_eq!((term.active().cursor_x(), term.active().cursor_y()), (4, 1));
//! ```

mod attr;
mod buffer;
pub mod cells;
mod charset;
mod handlers;
mod history;
mod line;
mod params;
mod parser;
mod reflow;
mod terminal;
mod utf8;
mod view;
mod width;

pub use attr::{Attr, CM_MASK, CM_P16, CM_P256, CM_RGB, PCOLOR_MASK, RGB_MASK, bg, fg};
pub use cells::{CellView, LineBuf, Lines};
pub use terminal::{CursorShape, MIN_COLS, MIN_ROWS, Modes, MouseEncoding, MouseProtocol, Terminal};
pub use view::{BufferView, LineId};
pub use width::wcwidth;
