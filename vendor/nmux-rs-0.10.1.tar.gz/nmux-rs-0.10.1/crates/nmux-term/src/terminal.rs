//! The terminal: xterm.js's `InputHandler.ts` and the state around it, driven by the lexer's tokens.
//!
//! A token in the ground state is acted on as it is: text is printed, a control sequence is dispatched with the
//! parameters the lexer found. Anything else goes through xterm's own parser (`parser.rs`) a code point at a time: a
//! sequence the lexer let go of half way (`Partial`), the strings, text with a C1 control in it, and every token until the
//! parser is back on the ground. Both ways end in the same handlers, so the result is xterm's either way.

use nmux_vt::{Kind, Lexer, Token};

use crate::attr::{Attr, Attrs, Pen};
use crate::buffer::Buffer;
use crate::charset::Charset;
use crate::line::{Cell, NULL_CONTENT};
use crate::params::Params;
use crate::parser::{NON_ASCII_PRINTABLE, Osc, State, TABLE, action};
use crate::utf8::Utf8Decoder;
use crate::width::JoinState;

/// xterm refuses a terminal narrower than this.
pub const MIN_COLS: usize = 2;
/// Or shorter than this.
pub const MIN_ROWS: usize = 1;
/// The bytes of links and marks kept before the table of attributes is compacted, at the least.
const STRING_LIMIT: usize = 1 << 20;

/// The cursor's shape, as DECSCUSR sets it.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CursorShape {
    /// 1 and 2.
    Block,
    /// 3 and 4.
    Underline,
    /// 5 and 6.
    Bar,
}

/// Which mouse events are reported (`CoreMouseService.activeProtocol`).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum MouseProtocol {
    /// None.
    #[default]
    None,
    /// ?9
    X10,
    /// ?1000
    Vt200,
    /// ?1002
    Drag,
    /// ?1003
    Any,
}

/// How mouse events are reported (`activeEncoding`).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum MouseEncoding {
    /// The X10 bytes.
    #[default]
    Default,
    /// ?1006
    Sgr,
    /// ?1016
    SgrPixels,
}

/// The modes, as xterm keeps them.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)] // they are the modes, each one a flag
pub struct Modes {
    /// IRM, `CSI 4 h`.
    pub insert: bool,
    /// LNM, `CSI 20 h`: a line feed also returns the carriage. An option in xterm, so a reset keeps it.
    pub convert_eol: bool,
    /// DECCKM, ?1.
    pub application_cursor_keys: bool,
    /// DECOM, ?6.
    pub origin: bool,
    /// DECAWM, ?7.
    pub wraparound: bool,
    /// ?12. An option in xterm, so a reset keeps it.
    pub cursor_blink_option: bool,
    /// ?45.
    pub reverse_wraparound: bool,
    /// DECNKM, ?66, and DECKPAM.
    pub application_keypad: bool,
    /// ?1004.
    pub send_focus: bool,
    /// ?2004.
    pub bracketed_paste: bool,
    /// ?2026.
    pub synchronized_output: bool,
    /// The mouse protocol.
    pub mouse_protocol: MouseProtocol,
    /// The mouse encoding.
    pub mouse_encoding: MouseEncoding,
    /// DECSCUSR's shape, `None` until one is set or after `CSI 0 SP q`.
    pub cursor_style: Option<CursorShape>,
    /// DECSCUSR's blinking.
    pub cursor_blink: Option<bool>,
    /// DECTCEM, ?25, reset. xterm keeps it through a reset.
    pub cursor_hidden: bool,
}

impl Default for Modes {
    fn default() -> Self {
        Modes {
            insert: false,
            convert_eol: false,
            application_cursor_keys: false,
            origin: false,
            wraparound: true,
            cursor_blink_option: false,
            reverse_wraparound: false,
            application_keypad: false,
            send_focus: false,
            bracketed_paste: false,
            synchronized_output: false,
            mouse_protocol: MouseProtocol::None,
            mouse_encoding: MouseEncoding::Default,
            cursor_style: None,
            cursor_blink: None,
            cursor_hidden: false,
        }
    }
}

/// A headless terminal that ends up where `@xterm/headless` 6 with the Unicode 11 widths does, for the same bytes and the
/// same resizes.
#[derive(Debug)]
pub struct Terminal {
    pub(crate) normal: Buffer,
    pub(crate) alt: Buffer,
    pub(crate) alt_active: bool,
    pub(crate) cols: usize,
    pub(crate) rows: usize,
    pub(crate) scrollback: usize,
    pub(crate) attrs: Attrs,
    pub(crate) pen: Pen,
    /// `pen.attr()` interned, or `u32::MAX` when the pen changed since.
    pub(crate) pen_id: u32,
    pub(crate) erase_id: u32,
    pub(crate) charsets: [Charset; 4],
    pub(crate) glevel: usize,
    pub(crate) charset: Charset,
    pub(crate) modes: Modes,
    pub(crate) state: State,
    pub(crate) collect: u32,
    pub(crate) params: Params,
    pub(crate) join: JoinState,
    pub(crate) osc: Osc,
    pub(crate) decoder: Utf8Decoder,
    pub(crate) codes: Vec<u32>,
    pub(crate) next_id: u64,
    /// Lines of earlier normal buffers that a reset threw away, so that row numbers go on.
    pub(crate) trimmed_before: u64,
    pub(crate) attr_limit: usize,
    /// The bytes of links and marks the table of attributes may keep before it is compacted.
    pub(crate) string_limit: usize,
    /// Prompt marks (OSC 133) waiting for the next character printed, as a terminal is sent them.
    pub(crate) waiting_marks: String,
    /// For [`Terminal::write`] only.
    pub(crate) lexer: Lexer,
    /// Printing has just stopped and nothing else has happened since, so more text carries on the same run; and what
    /// the end of the run did, to be undone if it does carry on.
    pub(crate) print_run: Option<PrintEnd>,
    /// Rows of the normal screen printed on, or that a line feed left or reached, by number, both ends included: kept only
    /// once [`Terminal::note_printed`] has asked for them.
    pub(crate) printed: Option<Vec<(u64, u64)>>,
}

/// Where a run of printing ended: xterm looks at the cells around the cursor when it starts and ends printing a run,
/// and a run cut in two would look twice.
#[derive(Clone, Copy, Debug)]
pub(crate) struct PrintEnd {
    pub y: usize,
    pub x: usize,
    /// The cell the end of the run replaced, if it replaced one.
    pub old: Option<Cell>,
}

impl Terminal {
    /// A terminal of this size, keeping this many lines above the screen.
    pub fn new(cols: usize, rows: usize, scrollback: usize) -> Terminal {
        let cols = cols.max(MIN_COLS);
        let rows = rows.max(MIN_ROWS);
        let mut next_id = 1;
        let mut normal = Buffer::new(cols, rows, scrollback, true);
        normal.fill_viewport(Cell::NULL, &mut next_id);
        Terminal {
            normal,
            alt: Buffer::new(cols, rows, scrollback, false),
            alt_active: false,
            cols,
            rows,
            scrollback,
            attrs: Attrs::default(),
            pen: Pen::default(),
            pen_id: 0,
            erase_id: 0,
            charsets: [None; 4],
            glevel: 0,
            charset: None,
            modes: Modes::default(),
            state: State::Ground,
            collect: 0,
            params: Params::default(),
            join: 0,
            osc: Osc::default(),
            decoder: Utf8Decoder::default(),
            codes: Vec::new(),
            next_id,
            trimmed_before: 0,
            attr_limit: 4096,
            string_limit: STRING_LIMIT,
            waiting_marks: String::new(),
            lexer: crate::view::new_lexer(),
            print_run: None,
            printed: None,
        }
    }

    /// The number of columns.
    pub fn cols(&self) -> usize {
        self.cols
    }

    /// The number of rows.
    pub fn rows(&self) -> usize {
        self.rows
    }

    /// The modes.
    pub fn modes(&self) -> Modes {
        self.modes
    }

    /// Whether the alternate screen is shown.
    pub fn alternate_active(&self) -> bool {
        self.alt_active
    }

    /// Rows that have left the normal buffer for good, ever, a full reset counting all it held: a row's number is this
    /// plus its index, and stays its number as long as the row is kept.
    pub fn trimmed(&self) -> u64 {
        self.trimmed_before + self.normal.trimmed
    }

    /// From now on, the rows of the normal screen that text is printed on, or that a line feed leaves or reaches, are kept
    /// for [`Terminal::take_printed`]. They are every row a write can have printed on, seen as it happens, so the same bytes
    /// give the same rows however they were cut into writes.
    pub fn note_printed(&mut self) {
        self.printed.get_or_insert_with(Vec::new);
    }

    /// The rows kept since the last time, as ranges of row numbers with both ends included, in the order they were printed.
    pub fn take_printed(&mut self) -> Vec<(u64, u64)> {
        self.printed.as_mut().map(std::mem::take).unwrap_or_default()
    }

    /// The normal screen's cursor as a row number, when that screen is shown and its rows are being kept.
    #[inline]
    pub(crate) fn printing_row(&self) -> Option<u64> {
        if self.alt_active || self.printed.is_none() {
            return None;
        }
        Some(self.trimmed() + (self.normal.ybase() + self.normal.y) as u64)
    }

    /// The rows from `from` to where the cursor is now were printed on.
    pub(crate) fn printed_to(&mut self, from: Option<u64>) {
        let (Some(from), Some(to)) = (from, self.printing_row()) else { return };
        let (lo, hi) = (from.min(to), from.max(to));
        let Some(rows) = &mut self.printed else { return };
        match rows.last_mut() {
            Some(last) if lo <= last.1 + 1 && hi + 1 >= last.0 => *last = (last.0.min(lo), last.1.max(hi)),
            _ => rows.push((lo, hi)),
        }
    }

    /// The parser is in the ground state: no sequence is half read.
    pub fn at_ground(&self) -> bool {
        self.state == State::Ground
    }

    /// The interned attributes of the pen.
    #[inline]
    pub(crate) fn pen_id(&mut self) -> u32 {
        if self.pen_id == u32::MAX {
            self.pen_id = self.attrs.intern(self.pen.attr());
        }
        self.pen_id
    }

    /// The cell erasing leaves.
    #[inline]
    pub(crate) fn erase_cell(&mut self) -> Cell {
        if self.erase_id == u32::MAX {
            self.erase_id = self.attrs.intern(self.pen.erase_attr());
        }
        Cell { content: NULL_CONTENT, attr: self.erase_id }
    }

    pub(crate) fn pen_changed(&mut self) {
        self.pen_id = u32::MAX;
        self.erase_id = u32::MAX;
    }

    /// Takes this size, as xterm's `resize` does: nothing happens for the size it has, and a smaller one than
    /// [`MIN_COLS`] by [`MIN_ROWS`] is taken as that. The normal buffer reflows its lines; the parser carries on where it
    /// was, so a sequence cut by the resize is finished after it.
    pub fn resize(&mut self, cols: usize, rows: usize) {
        self.print_run = None;
        if cols == self.cols && rows == self.rows {
            return;
        }
        let cols = cols.max(MIN_COLS);
        let rows = rows.max(MIN_ROWS);
        self.cols = cols;
        self.rows = rows;
        let scrollback = self.scrollback;
        self.normal.resize(cols, rows, scrollback, &mut self.attrs, &mut self.next_id);
        self.alt.resize(cols, rows, scrollback, &mut self.attrs, &mut self.next_id);
        self.normal.setup_tabs(Some(cols));
        self.alt.setup_tabs(Some(cols));
        if self.attrs.len() > self.attr_limit {
            self.compact_attrs();
        }
    }

    /// Compacts the table of attributes when its links and marks have grown past what is allowed them: they grow only when
    /// one is added.
    pub(crate) fn strings_added(&mut self) {
        if self.attrs.string_bytes() > self.string_limit {
            self.compact_attrs();
        }
    }

    /// Renumbers the attributes, keeping only those cells on the two screens use, and the strings they and the pen use.
    fn compact_attrs(&mut self) {
        let mut remap = vec![u32::MAX; self.attrs.len()];
        remap[0] = 0;
        let mut used: Vec<Attr> = Vec::new();
        for b in [&self.normal, &self.alt] {
            for row in &b.screen {
                for c in &row.cells[..row.used.min(row.cells.len())] {
                    let slot = &mut remap[c.attr as usize];
                    if *slot == u32::MAX {
                        used.push(self.attrs.get(c.attr));
                        *slot = u32::try_from(used.len()).unwrap_or(0);
                    }
                }
            }
        }
        [self.pen.link, self.pen.mark] = self.attrs.rebuild(&used, [self.pen.link, self.pen.mark]);
        for b in [&mut self.normal, &mut self.alt] {
            for row in &mut b.screen {
                let n = row.used.min(row.cells.len());
                for c in &mut row.cells[..n] {
                    c.attr = remap[c.attr as usize];
                }
            }
        }
        self.pen_changed();
        self.attr_limit = (self.attrs.len() * 2).max(4096);
        self.string_limit = (self.attrs.string_bytes() * 2).max(STRING_LIMIT);
    }

    /// Where a write to xterm would end. xterm prints a run of text in one go when it arrives in one write, and in two
    /// when a write ends inside it, which can differ when a wide character does not fit at the end of a line with
    /// autowrap off. Text here is one run however the lexer cut it, until this is called; the differential tests call it
    /// where they ended a write to xterm. Nothing else depends on it.
    pub fn end_write(&mut self) {
        self.print_run = None;
    }

    /// Acts on one token of the output stream.
    pub fn advance(&mut self, token: &Token<'_>) {
        if self.attrs.len() > self.attr_limit {
            self.compact_attrs();
        }
        if self.state != State::Ground {
            self.parse_bytes(token.raw);
            return;
        }
        match token.kind {
            Kind::Text { ascii: true } => {
                self.decoder.clear();
                self.print_ascii(token.raw);
            }
            Kind::Text { ascii: false }
            | Kind::Partial
            | Kind::Osc(_)
            | Kind::Dcs(_)
            | Kind::Sos(_)
            | Kind::Pm(_)
            | Kind::Apc(_) => {
                self.parse_bytes(token.raw);
            }
            Kind::C0(b) => {
                self.print_run = None;
                self.decoder.clear();
                if b != 0x7f {
                    self.execute(u32::from(b));
                    self.join = 0;
                }
            }
            Kind::Csi(csi) => {
                self.print_run = None;
                self.decoder.clear();
                if !csi.malformed {
                    self.params.parse(csi.params.as_bytes());
                    let mut collect = 0u32;
                    if let Some(p) = csi.prefix {
                        collect = u32::from(p);
                    }
                    for &b in csi.intermediates {
                        collect = collect.wrapping_shl(8) | u32::from(b);
                    }
                    self.csi_dispatch(collect.wrapping_shl(8) | u32::from(csi.final_byte));
                    self.join = 0;
                }
            }
            Kind::Esc { intermediates, final_byte } => {
                self.print_run = None;
                self.decoder.clear();
                let mut collect = 0u32;
                for &b in intermediates {
                    collect = collect.wrapping_shl(8) | u32::from(b);
                }
                self.esc_dispatch(collect.wrapping_shl(8) | u32::from(final_byte));
                self.join = 0;
            }
            Kind::Ss3 { final_byte } => {
                // xterm has no use for ESC O, and prints what follows it
                self.print_run = None;
                self.decoder.clear();
                self.esc_dispatch(u32::from(b'O'));
                self.join = 0;
                self.print(&[u32::from(final_byte)]);
            }
        }
    }

    /// Bytes through xterm's decoder and parser.
    pub(crate) fn parse_bytes(&mut self, bytes: &[u8]) {
        let mut codes = std::mem::take(&mut self.codes);
        codes.clear();
        self.decoder.decode(bytes, &mut codes);
        self.run(&codes);
        self.codes = codes;
    }

    /// `EscapeSequenceParser.parse`.
    pub(crate) fn run(&mut self, codes: &[u32]) {
        let len = codes.len();
        let mut i = 0;
        while i < len {
            let code = codes[i];
            let column = if code < NON_ASCII_PRINTABLE { code as usize } else { NON_ASCII_PRINTABLE as usize };
            let transition = TABLE[(self.state as usize) << 8 | column];
            let mut next = State::from_index(transition & 15);
            let act = transition >> 4;
            if act != action::PRINT {
                self.print_run = None;
            }
            match act {
                action::PRINT => {
                    let mut j = i + 1;
                    while j < len && !(codes[j] < 0x20 || (codes[j] > 0x7e && codes[j] < NON_ASCII_PRINTABLE)) {
                        j += 1;
                    }
                    self.print(&codes[i..j]);
                    i = j - 1;
                }
                action::EXECUTE => {
                    self.execute(code);
                    self.join = 0;
                }
                action::CSI_DISPATCH => {
                    self.csi_dispatch(self.collect.wrapping_shl(8) | code);
                    self.join = 0;
                }
                action::PARAM => {
                    // only digits, colons and semicolons reach here
                    #[allow(clippy::cast_possible_truncation)]
                    self.params.put(code as u8);
                    while i + 1 < len && codes[i + 1] > 0x2f && codes[i + 1] < 0x3c {
                        i += 1;
                        #[allow(clippy::cast_possible_truncation)]
                        self.params.put(codes[i] as u8);
                    }
                }
                action::COLLECT => self.collect = self.collect.wrapping_shl(8) | code,
                action::ESC_DISPATCH => {
                    self.esc_dispatch(self.collect.wrapping_shl(8) | code);
                    self.join = 0;
                }
                action::CLEAR => {
                    self.params.clear();
                    self.collect = 0;
                }
                action::DCS_PUT => {
                    let mut j = i + 1;
                    while j < len && !matches!(codes[j], 0x18 | 0x1a | 0x1b | 0x80..=0x9f) {
                        j += 1;
                    }
                    i = j - 1;
                }
                action::DCS_UNHOOK => {
                    if code == 0x1b {
                        next = State::Escape;
                    }
                    self.params.clear();
                    self.collect = 0;
                    self.join = 0;
                }
                action::OSC_START => self.osc.start(),
                action::OSC_PUT => {
                    let mut j = i + 1;
                    while j < len && !(codes[j] < 0x20 || (codes[j] > 0x7f && codes[j] < NON_ASCII_PRINTABLE)) {
                        j += 1;
                    }
                    self.osc.put(&codes[i..j]);
                    i = j - 1;
                }
                action::OSC_END => {
                    let change = self.osc.end(code != 0x18 && code != 0x1a);
                    if let Some(change) = change {
                        self.osc_done(change);
                    }
                    if code == 0x1b {
                        next = State::Escape;
                    }
                    self.params.clear();
                    self.collect = 0;
                    self.join = 0;
                }
                // IGNORE, ERROR, DCS_HOOK
                _ => {}
            }
            self.state = next;
            i += 1;
        }
    }
}
