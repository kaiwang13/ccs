//! Reading a terminal: its buffers, their lines and cells, the way the server reads xterm's.

use nmux_vt::Lexer;

use crate::attr::Attr;
use crate::buffer::Buffer;
use crate::cells::{LineBuf, Lines};
use crate::terminal::Terminal;

/// Which line of a buffer, for as long as the line lasts: through scrolling into the history and through a reflow,
/// which moves lines and makes some of them one, as xterm moves its line objects. A line that leaves the buffer takes
/// its number with it, and no other line ever has it.
pub type LineId = u64;

/// One buffer of a terminal, to read: what `term.buffer.normal`, `.alternate` and `.active` give in xterm.
#[derive(Clone, Copy, Debug)]
pub struct BufferView<'a> {
    term: &'a Terminal,
    buf: &'a Buffer,
    alternate: bool,
}

impl BufferView<'_> {
    /// Whether this is the alternate buffer.
    pub fn is_alternate(&self) -> bool {
        self.alternate
    }

    /// `length`: lines in the buffer, history and screen. The alternate buffer has none while it is not shown.
    pub fn len(&self) -> usize {
        self.buf.len()
    }

    /// Whether it has no lines.
    pub fn is_empty(&self) -> bool {
        self.buf.len() == 0
    }

    /// `baseY`: lines above the screen. The alternate buffer can have some too, as xterm's can.
    pub fn base_y(&self) -> usize {
        self.buf.ybase()
    }

    /// `cursorX`: it can be the number of columns, when a character just filled the last one, and more in odd cases.
    pub fn cursor_x(&self) -> usize {
        self.buf.x
    }

    /// `cursorY`, on the screen.
    pub fn cursor_y(&self) -> usize {
        self.buf.y
    }

    /// The scroll margins, 0-based and inclusive.
    pub fn scroll_region(&self) -> (usize, usize) {
        (self.buf.scroll_top, self.buf.scroll_bottom)
    }

    /// Where DECSC last saved the cursor: its column, and its line counted from the top of the buffer then.
    pub fn saved_cursor(&self) -> (usize, usize) {
        (self.buf.saved_x, self.buf.saved_y)
    }

    /// `isWrapped` of line `y`: it carries on the line before it.
    pub fn is_wrapped(&self, y: usize) -> Option<bool> {
        let h = self.buf.history.len();
        if y < h { Some(self.buf.history.entry(y).wrapped) } else { self.buf.screen.get(y - h).map(|r| r.wrapped) }
    }

    /// The identity of line `y`.
    pub fn line_id(&self, y: usize) -> Option<LineId> {
        let h = self.buf.history.len();
        if y < h { Some(self.buf.history.entry(y).id) } else { self.buf.screen.get(y - h).map(|r| r.id) }
    }

    /// Where the line with this identity is now, if it is still in the buffer.
    pub fn find_line(&self, id: LineId) -> Option<usize> {
        let h = self.buf.history.len();
        (0..h)
            .find(|&i| self.buf.history.entry(i).id == id)
            .or_else(|| self.buf.screen.iter().position(|r| r.id == id).map(|i| i + h))
    }

    /// Reads line `y` into `into`; false when there is none.
    pub fn read_line(&self, y: usize, into: &mut LineBuf) -> bool {
        let h = self.buf.history.len();
        if y < h {
            self.buf.history.visit(y, into);
            return true;
        }
        let Some(row) = self.buf.screen.get(y - h) else { return false };
        into.clear(row.len(), row.wrapped);
        for (key, text) in &row.combined {
            into.add_combined(*key as usize, text);
        }
        let attrs = &self.term.attrs;
        let mut last = u32::MAX;
        let mut attr = Attr::DEFAULT;
        for (x, c) in row.cells[..row.used.min(row.len())].iter().enumerate() {
            if c.attr != last {
                last = c.attr;
                attr = attrs.get(c.attr);
                if attr.link != 0 || attr.mark != 0 {
                    attr.link = into.add_string(attrs.string(attr.link));
                    attr.mark = into.add_string(attrs.string(attr.mark));
                }
            }
            into.set(x, c.content, attr);
        }
        true
    }

    /// `translateToString` of line `y`.
    pub fn line_text(&self, y: usize, trim_right: bool, start: usize, end: Option<usize>) -> Option<String> {
        let mut buf = LineBuf::new();
        if !self.read_line(y, &mut buf) {
            return None;
        }
        let mut s = String::new();
        buf.translate(trim_right, start, end, &mut s);
        Some(s)
    }
}

impl Lines for BufferView<'_> {
    fn line_count(&self) -> usize {
        self.len()
    }

    fn read_line(&self, y: usize, into: &mut LineBuf) -> bool {
        BufferView::read_line(self, y, into)
    }
}

impl Terminal {
    /// The normal buffer, with the history, whichever is shown.
    pub fn normal(&self) -> BufferView<'_> {
        BufferView { term: self, buf: &self.normal, alternate: false }
    }

    /// The alternate buffer.
    pub fn alternate(&self) -> BufferView<'_> {
        BufferView { term: self, buf: &self.alt, alternate: true }
    }

    /// The buffer shown.
    pub fn active(&self) -> BufferView<'_> {
        if self.alt_active { self.alternate() } else { self.normal() }
    }

    /// Bytes this terminal holds for its lines and attributes, roughly: what grows with what it is given.
    pub fn memory(&self) -> usize {
        let rows = |b: &Buffer| -> usize {
            b.screen
                .iter()
                .map(|r| r.cells.capacity() * 8 + r.combined.iter().map(|c| c.1.capacity() + 32).sum::<usize>() + 80)
                .sum()
        };
        self.normal.history.memory()
            + self.alt.history.memory()
            + rows(&self.normal)
            + rows(&self.alt)
            + self.attrs.len() * 40
            + self.attrs.strings_memory()
    }

    /// Feeds bytes through a lexer of the terminal's own, for when nothing else lexes the stream. A server, which has
    /// the tokens already, gives them to [`Terminal::advance`] instead.
    pub fn write(&mut self, bytes: &[u8]) {
        let mut lexer = std::mem::take(&mut self.lexer);
        lexer.feed(bytes, |t| self.advance(&t));
        self.lexer = lexer;
        self.end_write();
    }

    /// Lets go of a sequence the terminal's own lexer holds unfinished, as the pipeline does after a pause.
    pub fn flush(&mut self) {
        let mut lexer = std::mem::take(&mut self.lexer);
        lexer.flush_partial(|t| self.advance(&t));
        self.lexer = lexer;
    }
}

/// So that `Terminal` can hold one.
pub(crate) fn new_lexer() -> Lexer {
    Lexer::new(0)
}
