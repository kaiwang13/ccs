//! What each control does: the handlers of `InputHandler.ts`, in its order, with its names.

use crate::attr::{Attr, CM_MASK, CM_P16, CM_P256, CM_RGB, PCOLOR_MASK, Pen, RGB_MASK, bg, fg};
use crate::buffer::{Buffer, LineRef, take_id};
use crate::charset;
use crate::line::{Cell, NULL_CONTENT, Row, WIDTH_SHIFT, signed};
use crate::parser::{KEPT_MAX, Osc, OscChange};
use crate::terminal::{CursorShape, MouseEncoding, MouseProtocol, PrintEnd, Terminal};
use crate::width::{char_properties, join_width, joins};

/// The active buffer, as a place rather than a method, so the other fields stay free to borrow.
macro_rules! active {
    ($t:expr) => {
        if $t.alt_active { &mut $t.alt } else { &mut $t.normal }
    };
}

const fn id(collected: &[u8], final_byte: u8) -> u32 {
    let mut v = 0u32;
    let mut i = 0;
    while i < collected.len() {
        // `u32::from` is not const
        #[allow(clippy::cast_lossless)]
        let b = collected[i] as u32;
        v = (v << 8) | b;
        i += 1;
    }
    #[allow(clippy::cast_lossless)]
    let f = final_byte as u32;
    (v << 8) | f
}

/// The most characters REP prints: see `Terminal::rep`.
const REP_LIMIT: u64 = 1 << 24;

/// What `print` does first: a wide character whose right half the cursor is on loses its left half. A run that carries
/// on the last one does not do this, and takes back what the last one did at its end.
fn begin_run(b: &mut Buffer, carry: Option<PrintEnd>, attr: u32) {
    if let Some(end) = carry {
        if let Some(old) = end.old {
            if let Some(cell) = b.screen.get_mut(end.y).and_then(|row| row.cells.get_mut(end.x)) {
                *cell = old;
            }
        }
        return;
    }
    let x = b.x;
    let row = &mut b.screen[b.y];
    if x != 0 && row.width_at(signed(x) - 1) == 2 {
        row.set_codepoint(x - 1, 0, 1, attr);
    }
}

/// What `print` does last: the cursor on the right half of a wide character that lost its left half makes it empty.
fn end_run(b: &mut Buffer, cols: usize, attr: u32) -> PrintEnd {
    let (x, y) = (b.x, b.y);
    let row = &mut b.screen[y];
    let mut old = None;
    if x < cols && row.width_at(signed(x)) == 0 && !row.has_content(x) {
        old = Some(row.cell(x));
        row.set_codepoint(x, 0, 1, attr);
    }
    PrintEnd { y, x, old }
}

/// A position as a wide signed number, for xterm's arithmetic on cursor positions, which can go below zero and past any
/// screen before it is clamped.
fn wide(x: usize) -> i64 {
    i64::try_from(x).unwrap_or(i64::MAX)
}

/// `params.params[i] || 1`.
fn or_one(p: i32) -> i64 {
    if p == 0 { 1 } else { i64::from(p) }
}

impl Terminal {
    // ---- printing

    /// `print`: code points of printable text.
    pub(crate) fn print(&mut self, codes: &[u32]) {
        let from = self.printing_row();
        let codes = if self.waiting_marks.is_empty() || codes.is_empty() { codes } else { self.place_marks(codes) };
        self.put_codes(codes);
        self.printed_to(from);
    }

    /// The first character takes the marks waiting for it; the rest is left to print.
    #[cold]
    #[inline(never)]
    fn place_marks<'a>(&mut self, codes: &'a [u32]) -> &'a [u32] {
        self.marks_taken(|t| t.put_codes(&codes[..1]));
        &codes[1..]
    }

    /// Prints with the pen holding the marks waiting, which the character printed takes.
    fn marks_taken(&mut self, print: impl FnOnce(&mut Self)) {
        let marks = std::mem::take(&mut self.waiting_marks);
        self.pen.mark = self.attrs.intern_string(&marks);
        self.strings_added();
        self.pen_changed();
        print(self);
        self.pen.mark = 0;
        self.pen_changed();
        self.waiting_marks = marks;
        self.waiting_marks.clear(); // its room is kept for the next
    }

    fn put_codes(&mut self, codes: &[u32]) {
        if codes.is_empty() {
            return;
        }
        let attr = self.pen_id();
        let erase = self.erase_cell();
        let cols = self.cols;
        let rows = self.rows;
        let wrap = self.modes.wraparound;
        let insert = self.modes.insert;
        let charset = self.charset;
        let mut join = self.join;
        let carry = self.print_run.take();
        let b = active!(self);
        begin_run(b, carry, attr);
        for &c in codes {
            let mut code = c;
            if code < 127 {
                if let Some(set) = charset {
                    if let Some(m) = charset::map(set, code) {
                        code = m;
                    }
                }
            }
            let info = char_properties(code, join);
            let mut width = join_width(info);
            let should_join = joins(info);
            let old_width = if should_join { join_width(join) } else { 0 };
            join = info;
            if b.x + (width - old_width) as usize > cols {
                if wrap {
                    let old_col = b.x - old_width as usize;
                    let row = &mut b.screen[b.y];
                    for col in old_col..cols {
                        row.set_codepoint(col, 0, 1, attr);
                    }
                    b.x = old_width as usize;
                    b.y += 1;
                    if b.y == b.scroll_bottom + 1 {
                        b.y -= 1;
                        b.scroll(erase, true, &self.attrs, &mut self.next_id);
                    } else {
                        if b.y >= rows {
                            b.y = rows - 1;
                        }
                        b.screen[b.y].wrapped = true;
                    }
                } else {
                    b.x = cols - 1;
                    if width == 2 {
                        continue;
                    }
                }
            }
            let x = b.x;
            let row = &mut b.screen[b.y];
            if should_join && x != 0 {
                let offset = if row.width_at(signed(x) - 1) != 0 { 1 } else { 2 };
                row.add_codepoint(signed(x) - offset, code, width);
                // A joining character takes the width of the one it joins, so this writes nothing.
                for _ in 0..width.saturating_sub(old_width) {
                    row.set_codepoint(b.x, 0, 0, attr);
                    b.x += 1;
                }
                continue;
            }
            if insert {
                row.insert_cells(x, (width - old_width) as usize, Cell { content: NULL_CONTENT, attr });
                if row.width_at(signed(cols) - 1) == 2 {
                    row.set_codepoint(cols - 1, 0, 1, attr);
                }
            }
            row.set_codepoint(x, code, width, attr);
            b.x += 1;
            while width > 1 {
                width -= 1;
                row.set_codepoint(b.x, 0, 0, attr);
                b.x += 1;
            }
        }
        self.join = join;
        let b = active!(self);
        self.print_run = Some(end_run(b, cols, attr));
    }

    /// `print` for printable ASCII, a row at a time where `print` would go a character at a time to the same end.
    pub(crate) fn print_ascii(&mut self, bytes: &[u8]) {
        let from = self.printing_row();
        let bytes =
            if self.waiting_marks.is_empty() || bytes.is_empty() { bytes } else { self.place_marks_ascii(bytes) };
        self.put_ascii(bytes);
        self.printed_to(from);
    }

    /// [`Terminal::place_marks`] for ASCII.
    #[cold]
    #[inline(never)]
    fn place_marks_ascii<'a>(&mut self, bytes: &'a [u8]) -> &'a [u8] {
        self.marks_taken(|t| t.put_ascii(&bytes[..1]));
        &bytes[1..]
    }

    fn put_ascii(&mut self, bytes: &[u8]) {
        if bytes.is_empty() {
            return;
        }
        if self.charset.is_some() || self.modes.insert {
            let mut codes = std::mem::take(&mut self.codes);
            codes.clear();
            codes.extend(bytes.iter().map(|&b| u32::from(b)));
            self.put_codes(&codes);
            self.codes = codes;
            return;
        }
        let attr = self.pen_id();
        let erase = self.erase_cell();
        let cols = self.cols;
        let rows = self.rows;
        let wrap = self.modes.wraparound;
        let carry = self.print_run.take();
        let b = active!(self);
        begin_run(b, carry, attr);
        let mut rest = bytes;
        while let Some(&last) = rest.last() {
            if b.x >= cols {
                if !wrap {
                    // each character from here lands on the last column, and the last of them stays
                    b.screen[b.y].set_codepoint(cols - 1, u32::from(last), 1, attr);
                    b.x = cols;
                    break;
                }
                b.x = 0;
                b.y += 1;
                if b.y == b.scroll_bottom + 1 {
                    b.y -= 1;
                    b.scroll(erase, true, &self.attrs, &mut self.next_id);
                } else {
                    if b.y >= rows {
                        b.y = rows - 1;
                    }
                    b.screen[b.y].wrapped = true;
                }
            }
            let n = (cols - b.x).min(rest.len());
            b.screen[b.y].write_ascii(b.x, &rest[..n], attr);
            b.x += n;
            rest = &rest[n..];
        }
        // width 1, joining nothing
        self.join = 2;
        self.print_run = Some(end_run(b, cols, attr));
    }

    // ---- C0 and C1

    pub(crate) fn execute(&mut self, code: u32) {
        match code {
            0x0a..=0x0c => self.line_feed(),
            0x0d => active!(self).x = 0,
            0x08 => self.backspace(),
            0x09 => self.tab(),
            0x0e => self.set_glevel(1),
            0x0f => self.set_glevel(0),
            0x84 => self.index(),
            0x85 => self.next_line(),
            0x88 => self.tab_set(),
            _ => {}
        }
    }

    fn line_feed(&mut self) {
        let from = self.printing_row();
        self.feed_line();
        self.printed_to(from);
    }

    fn feed_line(&mut self) {
        let erase = self.erase_cell();
        let (cols, rows, eol) = (self.cols, self.rows, self.modes.convert_eol);
        let b = active!(self);
        if eol {
            b.x = 0;
        }
        b.y += 1;
        if b.y == b.scroll_bottom + 1 {
            b.y -= 1;
            b.scroll(erase, false, &self.attrs, &mut self.next_id);
        } else if b.y >= rows {
            b.y = rows - 1;
        } else {
            b.screen[b.y].wrapped = false;
        }
        if b.x >= cols {
            b.x -= 1;
        }
    }

    fn backspace(&mut self) {
        let cols = self.cols;
        if !self.modes.reverse_wraparound {
            self.restrict_cursor(cols - 1);
            let b = active!(self);
            if b.x > 0 {
                b.x -= 1;
            }
            return;
        }
        self.restrict_cursor(cols);
        let b = active!(self);
        if b.x > 0 {
            b.x -= 1;
        } else if b.y > b.scroll_top && b.y <= b.scroll_bottom && b.screen[b.y].wrapped {
            b.screen[b.y].wrapped = false;
            b.y -= 1;
            b.x = cols - 1;
            let line = &b.screen[b.y];
            if line.cell(b.x).width() != 0 && !line.has_content(b.x) {
                b.x -= 1;
            }
        }
        self.restrict_cursor(cols - 1);
    }

    fn tab(&mut self) {
        let cols = self.cols;
        let b = active!(self);
        if b.x >= cols {
            return;
        }
        b.x = b.next_stop(signed(b.x));
    }

    fn set_glevel(&mut self, level: usize) {
        self.glevel = level;
        self.charset = self.charsets[level];
    }

    fn set_gcharset(&mut self, g: usize, set: charset::Charset) {
        self.charsets[g] = set;
        if self.glevel == g {
            self.charset = set;
        }
    }

    // ---- the cursor

    /// `_restrictCursor`: on the screen, and within the margins in origin mode.
    pub(crate) fn restrict_cursor(&mut self, max_col: usize) {
        let (origin, rows) = (self.modes.origin, self.rows);
        let b = active!(self);
        b.x = b.x.min(max_col);
        b.y = if origin { b.y.max(b.scroll_top).min(b.scroll_bottom) } else { b.y.min(rows - 1) };
    }

    /// `_setCursor`.
    fn set_cursor(&mut self, x: i64, y: i64) {
        let (origin, rows, cols) = (self.modes.origin, wide(self.rows), wide(self.cols));
        let b = active!(self);
        let y = if origin { wide(b.scroll_top) + y } else { y };
        let x = x.max(0).min(cols - 1);
        let y = if origin { y.max(wide(b.scroll_top)).min(wide(b.scroll_bottom)) } else { y.max(0).min(rows - 1) };
        b.x = usize::try_from(x).unwrap_or(0);
        b.y = usize::try_from(y).unwrap_or(0);
    }

    /// `_moveCursor`.
    fn move_cursor(&mut self, dx: i64, dy: i64) {
        self.restrict_cursor(self.cols - 1);
        let b = active!(self);
        let (x, y) = (wide(b.x), wide(b.y));
        self.set_cursor(x + dx, y + dy);
    }

    fn cursor_up(&mut self, p: i32) {
        let b = active!(self);
        let diff = wide(b.y) - wide(b.scroll_top);
        if diff >= 0 {
            self.move_cursor(0, -diff.min(or_one(p)));
        } else {
            self.move_cursor(0, -or_one(p));
        }
    }

    fn cursor_down(&mut self, p: i32) {
        let b = active!(self);
        let diff = wide(b.scroll_bottom) - wide(b.y);
        if diff >= 0 {
            self.move_cursor(0, diff.min(or_one(p)));
        } else {
            self.move_cursor(0, or_one(p));
        }
    }

    fn cursor_position(&mut self) {
        let col = if self.params.len() >= 2 { or_one(self.params.get(1)) - 1 } else { 0 };
        let row = or_one(self.params.get(0)) - 1;
        self.set_cursor(col, row);
    }

    fn cursor_x(&self) -> i64 {
        wide(if self.alt_active { self.alt.x } else { self.normal.x })
    }

    fn cursor_y(&self) -> i64 {
        wide(if self.alt_active { self.alt.y } else { self.normal.y })
    }

    fn tab_clear(&mut self, p: i32) {
        let b = active!(self);
        if p == 0 {
            b.tabs.unset(b.x);
        } else if p == 3 {
            b.tabs.clear();
        }
    }

    fn tab_set(&mut self) {
        let b = active!(self);
        b.tabs.set(b.x);
    }

    fn cursor_forward_tab(&mut self, p: i32, back: bool) {
        let cols = self.cols;
        let b = active!(self);
        if b.x >= cols {
            return;
        }
        for _ in 0..or_one(p) {
            let next = if back { b.prev_stop(signed(b.x)) } else { b.next_stop(signed(b.x)) };
            if next == b.x {
                break;
            }
            b.x = next;
        }
    }

    // ---- erasing

    fn erase_in_line_of(&mut self, y: usize, start: usize, end: usize, clear_wrap: bool, respect: bool) {
        let fill = self.erase_cell();
        let b = active!(self);
        let line = &mut b.screen[y];
        line.replace_cells(start, end, fill, respect, &self.attrs);
        if clear_wrap {
            line.wrapped = false;
        }
    }

    fn reset_line(&mut self, y: usize, respect: bool) {
        let fill = self.erase_cell();
        let b = active!(self);
        if let Some(line) = b.screen.get_mut(y) {
            line.fill(fill, respect, &self.attrs);
            line.wrapped = false;
        }
    }

    fn erase_in_display(&mut self, respect: bool) {
        let cols = self.cols;
        let rows = self.rows;
        self.restrict_cursor(cols);
        let (x, y) = (active!(self).x, active!(self).y);
        match self.params.get(0) {
            0 => {
                self.erase_in_line_of(y, x, cols, x == 0, respect);
                for j in y + 1..rows {
                    self.reset_line(j, respect);
                }
            }
            1 => {
                self.erase_in_line_of(y, 0, x + 1, true, respect);
                if x + 1 >= cols {
                    // xterm takes y + 1 as an index into the whole list rather than the screen
                    let b = active!(self);
                    if let Some(at) = b.line_at_circular(y + 1) {
                        b.set_wrapped_at(at, false);
                    }
                }
                for j in (0..y).rev() {
                    self.reset_line(j, respect);
                }
            }
            2 => {
                for j in (0..rows).rev() {
                    self.reset_line(j, respect);
                }
            }
            3 => {
                let b = active!(self);
                let n = b.ybase();
                if n > 0 {
                    b.history.clear();
                    b.trimmed += n as u64;
                    b.start = (b.start + n) % b.max_length.max(1);
                }
            }
            _ => {}
        }
    }

    fn erase_in_line(&mut self, respect: bool) {
        let cols = self.cols;
        self.restrict_cursor(cols);
        let (x, y) = (active!(self).x, active!(self).y);
        match self.params.get(0) {
            0 => self.erase_in_line_of(y, x, cols, x == 0, respect),
            1 => self.erase_in_line_of(y, 0, x + 1, false, respect),
            2 => self.erase_in_line_of(y, 0, cols, true, respect),
            _ => {}
        }
    }

    /// A blank row for the screen, from a row that has left it when there is one.
    fn blank(&mut self, recycled: Option<Row>, fill: Cell) -> Row {
        let id = take_id(&mut self.next_id);
        let cols = self.cols;
        match recycled {
            Some(mut row) => {
                row.reset(cols, fill, false, id);
                row
            }
            None => Row::new(cols, fill, false, id),
        }
    }

    fn insert_lines(&mut self, p: i32) {
        self.restrict_cursor(self.cols - 1);
        let fill = self.erase_cell();
        let b = active!(self);
        if b.y > b.scroll_bottom || b.y < b.scroll_top {
            return;
        }
        let (y, bottom) = (b.y, b.scroll_bottom);
        let n = usize::try_from(or_one(p)).unwrap_or(1).min(bottom - y + 1);
        for _ in 0..n {
            let b = active!(self);
            let old = b.screen.remove(bottom);
            let row = self.blank(old, fill);
            active!(self).screen.insert(y, row);
        }
        active!(self).x = 0;
    }

    fn delete_lines(&mut self, p: i32) {
        self.restrict_cursor(self.cols - 1);
        let fill = self.erase_cell();
        let b = active!(self);
        if b.y > b.scroll_bottom || b.y < b.scroll_top {
            return;
        }
        let (y, bottom) = (b.y, b.scroll_bottom);
        let n = usize::try_from(or_one(p)).unwrap_or(1).min(bottom - y + 1);
        for _ in 0..n {
            let b = active!(self);
            let old = b.screen.remove(y);
            let row = self.blank(old, fill);
            active!(self).screen.insert(bottom, row);
        }
        active!(self).x = 0;
    }

    fn insert_chars(&mut self, p: i32, delete: bool) {
        self.restrict_cursor(self.cols - 1);
        let fill = self.erase_cell();
        let b = active!(self);
        let x = b.x;
        let n = usize::try_from(or_one(p)).unwrap_or(1);
        let row = b.cursor_row();
        if delete {
            row.delete_cells(x, n, fill);
        } else {
            row.insert_cells(x, n, fill);
        }
    }

    fn scroll_up(&mut self, p: i32) {
        let fill = self.erase_cell();
        let b = active!(self);
        let (top, bottom) = (b.scroll_top, b.scroll_bottom);
        let n = usize::try_from(or_one(p)).unwrap_or(1).min(bottom - top + 1);
        for _ in 0..n {
            let old = active!(self).screen.remove(top);
            let row = self.blank(old, fill);
            active!(self).screen.insert(bottom, row);
        }
    }

    fn scroll_down(&mut self, p: i32) {
        let b = active!(self);
        let (top, bottom) = (b.scroll_top, b.scroll_bottom);
        let n = usize::try_from(or_one(p)).unwrap_or(1).min(bottom - top + 1);
        for _ in 0..n {
            let old = active!(self).screen.remove(bottom);
            let row = self.blank(old, Cell::NULL);
            active!(self).screen.insert(top, row);
        }
    }

    /// SL, SR, DECIC and DECDC: every line of the region, cells in or out at a column.
    fn shift_columns(&mut self, p: i32, at_cursor: bool, delete: bool) {
        let fill = self.erase_cell();
        let b = active!(self);
        if b.y > b.scroll_bottom || b.y < b.scroll_top {
            return;
        }
        let n = usize::try_from(or_one(p)).unwrap_or(1);
        let x = if at_cursor { b.x } else { 0 };
        for y in b.scroll_top..=b.scroll_bottom {
            let line = &mut b.screen[y];
            if delete {
                line.delete_cells(x, n, fill);
            } else {
                line.insert_cells(x, n, fill);
            }
            line.wrapped = false;
        }
    }

    fn erase_chars(&mut self, p: i32) {
        self.restrict_cursor(self.cols - 1);
        let fill = self.erase_cell();
        let b = active!(self);
        let x = b.x;
        let n = usize::try_from(or_one(p)).unwrap_or(1);
        b.cursor_row().replace_cells(x, x.saturating_add(n), fill, false, &self.attrs);
    }

    /// REP: the character printed last, again. xterm builds the whole run before printing it and throws when that is too
    /// big to allocate, after which it parses nothing more; this stops at `REP_LIMIT` characters instead.
    fn rep(&mut self, p: i32) {
        let state = self.join;
        if state == 0 {
            return;
        }
        let count = u64::try_from(or_one(p)).unwrap_or(1).min(REP_LIMIT);
        let width = signed(join_width(state));
        let b = active!(self);
        let x = signed(b.x) - width;
        let mut text = String::new();
        if let Ok(x) = usize::try_from(x) {
            b.cursor_row().text(x, &mut text);
        }
        if text.is_empty() {
            self.print(&[]);
            return;
        }
        let one: Vec<u32> = text.chars().map(u32::from).collect();
        let per = (4096 / one.len()).max(1) as u64;
        let mut chunk = Vec::new();
        let mut left = count;
        while left > 0 {
            let n = left.min(per);
            chunk.clear();
            for _ in 0..n {
                chunk.extend_from_slice(&one);
            }
            self.print(&chunk);
            left -= n;
        }
    }

    // ---- modes

    fn set_mode(&mut self, on: bool) {
        for i in 0..self.params.len() {
            match self.params.get(i) {
                4 => self.modes.insert = on,
                20 => self.modes.convert_eol = on,
                _ => {}
            }
        }
    }

    fn set_mode_private(&mut self, on: bool) {
        for i in 0..self.params.len() {
            match self.params.get(i) {
                1 => self.modes.application_cursor_keys = on,
                2 if on => {
                    for g in 0..4 {
                        self.set_gcharset(g, None);
                    }
                }
                6 => {
                    self.modes.origin = on;
                    self.set_cursor(0, 0);
                }
                7 => self.modes.wraparound = on,
                12 => self.modes.cursor_blink_option = on,
                45 => self.modes.reverse_wraparound = on,
                66 => self.modes.application_keypad = on,
                9 if on => self.modes.mouse_protocol = MouseProtocol::X10,
                1000 if on => self.modes.mouse_protocol = MouseProtocol::Vt200,
                1002 if on => self.modes.mouse_protocol = MouseProtocol::Drag,
                1003 if on => self.modes.mouse_protocol = MouseProtocol::Any,
                9 | 1000 | 1002 | 1003 => self.modes.mouse_protocol = MouseProtocol::None,
                1004 => self.modes.send_focus = on,
                1006 if on => self.modes.mouse_encoding = MouseEncoding::Sgr,
                1016 if on => self.modes.mouse_encoding = MouseEncoding::SgrPixels,
                1006 | 1016 => self.modes.mouse_encoding = MouseEncoding::Default,
                25 => self.modes.cursor_hidden = !on,
                1048 if on => self.save_cursor(),
                1048 => self.restore_cursor(),
                1049 if on => {
                    self.save_cursor();
                    self.activate_alt();
                }
                47 | 1047 if on => self.activate_alt(),
                47 | 1047 | 1049 => {
                    self.activate_normal();
                    if self.params.get(i) == 1049 {
                        self.restore_cursor();
                    }
                }
                2004 => self.modes.bracketed_paste = on,
                2026 => self.modes.synchronized_output = on,
                _ => {}
            }
        }
    }

    /// `activateAltBuffer`.
    fn activate_alt(&mut self) {
        if self.alt_active {
            return;
        }
        let fill = self.erase_cell();
        self.alt.fill_viewport(fill, &mut self.next_id);
        self.alt.x = self.normal.x;
        self.alt.y = self.normal.y;
        self.alt_active = true;
    }

    /// `activateNormalBuffer`: the alternate screen is cleared on the way out.
    fn activate_normal(&mut self) {
        if !self.alt_active {
            return;
        }
        self.normal.x = self.alt.x;
        self.normal.y = self.alt.y;
        self.alt.clear(self.scrollback);
        self.alt_active = false;
    }

    // ---- attributes

    fn sgr0(&mut self) {
        self.pen.fg = 0;
        self.pen.bg = 0;
        self.pen.underline_style = 0;
        self.pen.update_extended();
    }

    fn process_underline(&mut self, style: i32) {
        let style = if style == -1 || style > 5 { 1 } else { style };
        // set as xterm sets it, into three bits
        #[allow(clippy::cast_sign_loss, clippy::cast_possible_truncation)]
        let bits = ((style as u32) & 7) as u8;
        self.pen.underline_style = bits;
        self.pen.fg |= fg::UNDERLINE;
        if style == 0 {
            self.pen.fg &= !fg::UNDERLINE;
        }
        self.pen.update_extended();
    }

    /// `_extractColor`: a colour given with semicolons or colons, and how many parameters it took.
    fn extract_color(&mut self, pos: usize) -> usize {
        let p = &self.params;
        let mut accu = [0i64, 0, -1, 0, 0, 0];
        let mut c_space = 0usize;
        let mut advance = 0usize;
        loop {
            if advance + c_space < accu.len() {
                accu[advance + c_space] = i64::from(p.get(pos + advance));
            }
            if p.has_sub_params(pos + advance) {
                let sub = p.sub_params(pos + advance);
                let mut i = 0usize;
                loop {
                    if accu[1] == 5 {
                        c_space = 1;
                    }
                    let at = advance + i + 1 + c_space;
                    if at < accu.len() {
                        accu[at] = i64::from(sub[i]);
                    }
                    i += 1;
                    if !(i < sub.len() && i + advance + 1 + c_space < accu.len()) {
                        break;
                    }
                }
                break;
            }
            if (accu[1] == 5 && advance + c_space >= 2) || (accu[1] == 2 && advance + c_space >= 5) {
                break;
            }
            if accu[1] != 0 {
                c_space = 1;
            }
            advance += 1;
            if !(advance + pos < p.len() && advance + c_space < accu.len()) {
                break;
            }
        }
        for v in &mut accu[2..] {
            if *v == -1 {
                *v = 0;
            }
        }
        let update = |color: u32| -> u32 {
            let (mode, c1, c2, c3) = (accu[1], accu[3], accu[4], accu[5]);
            #[allow(clippy::cast_sign_loss, clippy::cast_possible_truncation)]
            let byte = |v: i64| (v & 255) as u32;
            match mode {
                2 => ((color | CM_RGB) & !RGB_MASK) | (byte(c1) << 16 | byte(c2) << 8 | byte(c3)),
                5 => (color & !(CM_MASK | PCOLOR_MASK)) | CM_P256 | byte(c1),
                _ => color,
            }
        };
        match accu[0] {
            38 => self.pen.fg = update(self.pen.fg),
            48 => self.pen.bg = update(self.pen.bg),
            // 58 sets the underline colour, which nothing here shows
            _ => {}
        }
        advance
    }

    fn char_attributes(&mut self) {
        self.pen_changed();
        if self.params.len() == 1 && self.params.get(0) == 0 {
            self.sgr0();
            return;
        }
        let len = self.params.len();
        let mut i = 0;
        while i < len {
            let p = self.params.get(i);
            #[allow(clippy::cast_sign_loss)]
            let u = p as u32;
            let pen = &mut self.pen;
            match p {
                30..=37 => pen.fg = (pen.fg & !(CM_MASK | PCOLOR_MASK)) | CM_P16 | (u - 30),
                40..=47 => pen.bg = (pen.bg & !(CM_MASK | PCOLOR_MASK)) | CM_P16 | (u - 40),
                90..=97 => pen.fg = (pen.fg & !(CM_MASK | PCOLOR_MASK)) | CM_P16 | (u - 90) | 8,
                100..=107 => pen.bg = (pen.bg & !(CM_MASK | PCOLOR_MASK)) | CM_P16 | (u - 100) | 8,
                0 => self.sgr0(),
                1 => pen.fg |= fg::BOLD,
                3 => pen.bg |= bg::ITALIC,
                4 => {
                    pen.fg |= fg::UNDERLINE;
                    let style = if self.params.has_sub_params(i) { self.params.sub_params(i)[0] } else { 1 };
                    self.process_underline(style);
                }
                5 => pen.fg |= fg::BLINK,
                7 => pen.fg |= fg::INVERSE,
                8 => pen.fg |= fg::INVISIBLE,
                9 => pen.fg |= fg::STRIKETHROUGH,
                2 => pen.bg |= bg::DIM,
                21 => self.process_underline(2),
                22 => {
                    pen.fg &= !fg::BOLD;
                    pen.bg &= !bg::DIM;
                }
                23 => pen.bg &= !bg::ITALIC,
                24 => {
                    pen.fg &= !fg::UNDERLINE;
                    self.process_underline(0);
                }
                25 => pen.fg &= !fg::BLINK,
                27 => pen.fg &= !fg::INVERSE,
                28 => pen.fg &= !fg::INVISIBLE,
                29 => pen.fg &= !fg::STRIKETHROUGH,
                39 => pen.fg &= !(CM_MASK | RGB_MASK),
                49 => pen.bg &= !(CM_MASK | RGB_MASK),
                38 | 48 | 58 => i += self.extract_color(i),
                53 => pen.bg |= bg::OVERLINE,
                55 => pen.bg &= !bg::OVERLINE,
                59 => pen.update_extended(),
                _ => {}
            }
            i += 1;
        }
    }

    /// OSC 8 opened or closed a hyperlink, or OSC 133 marked where the next character goes. xterm keeps a link in the
    /// extended attributes, and a cell in a link reads as underlined. It ignores marks, which wait here in the pen for the
    /// next character printed: the cell that takes them is where they were.
    pub(crate) fn osc_done(&mut self, change: OscChange) {
        match change {
            OscChange::Open(link) => {
                self.pen.url = true;
                self.pen.link = link.map_or(0, |l| self.attrs.intern_string(&l));
                self.strings_added();
            }
            OscChange::Close => {
                self.pen.url = false;
                self.pen.link = 0;
            }
            OscChange::Mark(mark) => {
                let waiting = &mut self.waiting_marks;
                if mark.starts_with("\x1b]133;A") {
                    // where the input of a prompt that took none would have started: drawn again, it starts anew
                    *waiting = waiting.split_inclusive('\x07').filter(|m| !m.starts_with("\x1b]133;B")).collect();
                }
                if !waiting.ends_with(&mark) {
                    // the same again is a prompt drawn again before anything was printed
                    if waiting.len() + mark.len() > KEPT_MAX {
                        waiting.clear(); // a program that marks and never prints: only the last are kept
                    }
                    waiting.push_str(&mark);
                }
                return;
            }
        }
        self.pen.update_extended();
        self.pen_changed();
    }

    // ---- saving and resetting

    pub(crate) fn save_cursor(&mut self) {
        let (fg, bg, charset) = (self.pen.fg, self.pen.bg, self.charset);
        let b = active!(self);
        b.saved_x = b.x;
        b.saved_y = b.ybase() + b.y;
        b.saved_fg = fg;
        b.saved_bg = bg;
        b.saved_charset = charset;
    }

    pub(crate) fn restore_cursor(&mut self) {
        let b = active!(self);
        b.x = b.saved_x;
        b.y = b.saved_y.saturating_sub(b.ybase());
        let (fg, bg, charset) = (b.saved_fg, b.saved_bg, b.saved_charset);
        self.pen.fg = fg;
        self.pen.bg = bg;
        self.charset = charset;
        self.pen_changed();
        self.restrict_cursor(self.cols - 1);
    }

    /// DECSTR.
    fn soft_reset(&mut self) {
        let rows = self.rows;
        self.modes.cursor_hidden = false;
        let b = active!(self);
        b.scroll_top = 0;
        b.scroll_bottom = rows - 1;
        self.pen = Pen::default();
        self.waiting_marks.clear();
        self.pen_changed();
        self.reset_core_modes();
        self.charsets = [None; 4];
        self.glevel = 0;
        self.charset = None;
        let b = active!(self);
        b.saved_x = 0;
        b.saved_y = b.ybase();
        b.saved_fg = 0;
        b.saved_bg = 0;
        b.saved_charset = None;
        self.modes.origin = false;
    }

    /// `CoreService.reset`: the modes go back, except those xterm keeps as options, and the cursor's visibility.
    fn reset_core_modes(&mut self) {
        let m = &mut self.modes;
        m.insert = false;
        m.application_cursor_keys = false;
        m.application_keypad = false;
        m.bracketed_paste = false;
        m.cursor_blink = None;
        m.cursor_style = None;
        m.origin = false;
        m.reverse_wraparound = false;
        m.send_focus = false;
        m.synchronized_output = false;
        m.wraparound = true;
    }

    /// RIS: new buffers and defaults, all the terminal's own state but its options and the cursor's visibility.
    fn full_reset(&mut self) {
        self.osc = Osc::default();
        self.params.clear();
        self.collect = 0;
        self.join = 0;
        self.trimmed_before += self.normal.trimmed + self.normal.len() as u64;
        let (cols, rows, scrollback) = (self.cols, self.rows, self.scrollback);
        self.normal = Buffer::new(cols, rows, scrollback, true);
        self.normal.fill_viewport(Cell::NULL, &mut self.next_id);
        self.alt = Buffer::new(cols, rows, scrollback, false);
        self.alt_active = false;
        self.pen = Pen::default();
        self.waiting_marks.clear();
        self.pen_changed();
        self.charsets = [None; 4];
        self.glevel = 0;
        self.charset = None;
        self.reset_core_modes();
        self.modes.mouse_protocol = MouseProtocol::None;
        self.modes.mouse_encoding = MouseEncoding::Default;
    }

    fn set_cursor_style(&mut self) {
        let p = self.params.get(0);
        if p == 0 {
            self.modes.cursor_style = None;
            self.modes.cursor_blink = None;
            return;
        }
        match p {
            1 | 2 => self.modes.cursor_style = Some(CursorShape::Block),
            3 | 4 => self.modes.cursor_style = Some(CursorShape::Underline),
            5 | 6 => self.modes.cursor_style = Some(CursorShape::Bar),
            _ => {}
        }
        self.modes.cursor_blink = Some(p % 2 == 1);
    }

    fn set_scroll_region(&mut self) {
        let rows = wide(self.rows);
        let top = or_one(self.params.get(0));
        let mut bottom = i64::from(self.params.get(1));
        if self.params.len() < 2 || bottom > rows || bottom == 0 {
            bottom = rows;
        }
        if bottom > top {
            let b = active!(self);
            b.scroll_top = usize::try_from(top - 1).unwrap_or(0);
            b.scroll_bottom = usize::try_from(bottom - 1).unwrap_or(0);
            self.set_cursor(0, 0);
        }
    }

    fn select_protected(&mut self) {
        match self.params.get(0) {
            1 => self.pen.bg |= bg::PROTECTED,
            0 | 2 => self.pen.bg &= !bg::PROTECTED,
            _ => {}
        }
        self.pen_changed();
    }

    // ---- ESC

    pub(crate) fn index(&mut self) {
        let from = self.printing_row();
        self.move_down();
        self.printed_to(from);
    }

    fn move_down(&mut self) {
        let cols = self.cols;
        self.restrict_cursor(cols - 1);
        let erase = self.erase_cell();
        let rows = self.rows;
        let b = active!(self);
        b.y += 1;
        if b.y == b.scroll_bottom + 1 {
            b.y -= 1;
            b.scroll(erase, false, &self.attrs, &mut self.next_id);
        } else if b.y >= rows {
            b.y = rows - 1;
        }
        self.restrict_cursor(cols - 1);
    }

    fn next_line(&mut self) {
        active!(self).x = 0;
        self.index();
    }

    fn reverse_index(&mut self) {
        let cols = self.cols;
        self.restrict_cursor(cols - 1);
        let fill = self.erase_cell();
        let b = active!(self);
        if b.y == b.scroll_top {
            let (top, bottom) = (b.scroll_top, b.scroll_bottom);
            let old = b.screen.remove(bottom);
            let row = self.blank(old, fill);
            active!(self).screen.insert(top, row);
        } else {
            // above the margins it can go to -1, which the restriction takes back
            b.y = b.y.saturating_sub(1);
            self.restrict_cursor(cols - 1);
        }
    }

    fn select_default_charset(&mut self) {
        self.set_glevel(0);
        self.set_gcharset(0, None);
    }

    /// DECALN: the screen full of E, from the cursor's line, which origin mode puts at the top margin.
    fn screen_alignment(&mut self) {
        let a = Attr::words(self.pen.fg, self.pen.bg & !bg::HAS_EXTENDED);
        let cell = Cell { content: u32::from(b'E') | (1 << WIDTH_SHIFT), attr: self.attrs.intern(a) };
        self.set_cursor(0, 0);
        let rows = self.rows;
        let cols = self.cols;
        let b = active!(self);
        let start = b.ybase() + b.y;
        for offset in 0..rows {
            match b.line_at_circular(start + offset) {
                Some(LineRef::Screen(i)) => {
                    let line = &mut b.screen[i];
                    line.fill(cell, false, &self.attrs);
                    line.wrapped = false;
                }
                Some(LineRef::History(i)) => {
                    let mut row = Row::default();
                    b.history.read(i, &mut row, &mut self.attrs);
                    row.resize(cols);
                    row.fill(cell, false, &self.attrs);
                    row.wrapped = false;
                    b.history.replace(i, &row, &self.attrs);
                }
                None => {}
            }
        }
        self.set_cursor(0, 0);
    }

    pub(crate) fn esc_dispatch(&mut self, ident: u32) {
        const SAVE: u32 = id(b"", b'7');
        const RESTORE: u32 = id(b"", b'8');
        const IND: u32 = id(b"", b'D');
        const NEL: u32 = id(b"", b'E');
        const HTS: u32 = id(b"", b'H');
        const RI: u32 = id(b"", b'M');
        const DECKPAM: u32 = id(b"", b'=');
        const DECKPNM: u32 = id(b"", b'>');
        const RIS: u32 = id(b"", b'c');
        const LS2: u32 = id(b"", b'n');
        const LS3: u32 = id(b"", b'o');
        const LS3R: u32 = id(b"", b'|');
        const LS2R: u32 = id(b"", b'}');
        const LS1R: u32 = id(b"", b'~');
        const UTF8_AT: u32 = id(b"%", b'@');
        const UTF8_G: u32 = id(b"%", b'G');
        const DECALN: u32 = id(b"#", b'8');
        match ident {
            SAVE => self.save_cursor(),
            RESTORE => self.restore_cursor(),
            IND => self.index(),
            NEL => self.next_line(),
            HTS => self.tab_set(),
            RI => self.reverse_index(),
            DECKPAM => self.modes.application_keypad = true,
            DECKPNM => self.modes.application_keypad = false,
            RIS => self.full_reset(),
            LS2 | LS2R => self.set_glevel(2),
            LS3 | LS3R => self.set_glevel(3),
            LS1R => self.set_glevel(1),
            UTF8_AT | UTF8_G => self.select_default_charset(),
            DECALN => self.screen_alignment(),
            _ => {
                let (Ok(collected), Ok(final_byte)) = (u8::try_from(ident >> 8), u8::try_from(ident & 0xff)) else {
                    return;
                };
                let g = match collected {
                    b'(' => 0,
                    b')' | b'-' => 1,
                    b'*' | b'.' => 2,
                    b'+' => 3,
                    _ => return,
                };
                if let Some(set) = charset::designated(final_byte) {
                    self.set_gcharset(g, set);
                }
            }
        }
    }

    pub(crate) fn csi_dispatch(&mut self, ident: u32) {
        const ICH: u32 = id(b"", b'@');
        const SL: u32 = id(b" ", b'@');
        const CUU: u32 = id(b"", b'A');
        const SR: u32 = id(b" ", b'A');
        const CUD: u32 = id(b"", b'B');
        const CUF: u32 = id(b"", b'C');
        const CUB: u32 = id(b"", b'D');
        const CNL: u32 = id(b"", b'E');
        const CPL: u32 = id(b"", b'F');
        const CHA: u32 = id(b"", b'G');
        const CUP: u32 = id(b"", b'H');
        const CHT: u32 = id(b"", b'I');
        const ED: u32 = id(b"", b'J');
        const DECSED: u32 = id(b"?", b'J');
        const EL: u32 = id(b"", b'K');
        const DECSEL: u32 = id(b"?", b'K');
        const IL: u32 = id(b"", b'L');
        const DL: u32 = id(b"", b'M');
        const DCH: u32 = id(b"", b'P');
        const SU: u32 = id(b"", b'S');
        const SD: u32 = id(b"", b'T');
        const ECH: u32 = id(b"", b'X');
        const CBT: u32 = id(b"", b'Z');
        const HPA: u32 = id(b"", b'`');
        const HPR: u32 = id(b"", b'a');
        const REP: u32 = id(b"", b'b');
        const VPA: u32 = id(b"", b'd');
        const VPR: u32 = id(b"", b'e');
        const HVP: u32 = id(b"", b'f');
        const TBC: u32 = id(b"", b'g');
        const SM: u32 = id(b"", b'h');
        const DECSET: u32 = id(b"?", b'h');
        const RM: u32 = id(b"", b'l');
        const DECRST: u32 = id(b"?", b'l');
        const SGR: u32 = id(b"", b'm');
        const DECSTR: u32 = id(b"!", b'p');
        const DECSCUSR: u32 = id(b" ", b'q');
        const DECSTBM: u32 = id(b"", b'r');
        const SCOSC: u32 = id(b"", b's');
        const SCORC: u32 = id(b"", b'u');
        const DECIC: u32 = id(b"'", b'}');
        const DECDC: u32 = id(b"'", b'~');
        const DECSCA: u32 = id(b"\"", b'q');
        let p0 = self.params.get(0);
        match ident {
            ICH => self.insert_chars(p0, false),
            SL => self.shift_columns(p0, false, true),
            CUU => self.cursor_up(p0),
            SR => self.shift_columns(p0, false, false),
            CUD => self.cursor_down(p0),
            CUF | HPR => self.move_cursor(or_one(p0), 0),
            CUB => self.move_cursor(-or_one(p0), 0),
            CNL => {
                self.cursor_down(p0);
                active!(self).x = 0;
            }
            CPL => {
                self.cursor_up(p0);
                active!(self).x = 0;
            }
            CHA | HPA => {
                let y = self.cursor_y();
                self.set_cursor(or_one(p0) - 1, y);
            }
            CUP | HVP => self.cursor_position(),
            CHT => self.cursor_forward_tab(p0, false),
            ED => self.erase_in_display(false),
            DECSED => self.erase_in_display(true),
            EL => self.erase_in_line(false),
            DECSEL => self.erase_in_line(true),
            IL => self.insert_lines(p0),
            DL => self.delete_lines(p0),
            DCH => self.insert_chars(p0, true),
            SU => self.scroll_up(p0),
            SD => self.scroll_down(p0),
            ECH => self.erase_chars(p0),
            CBT => self.cursor_forward_tab(p0, true),
            REP => self.rep(p0),
            VPA => {
                let x = self.cursor_x();
                self.set_cursor(x, or_one(p0) - 1);
            }
            VPR => self.move_cursor(0, or_one(p0)),
            TBC => self.tab_clear(p0),
            SM => self.set_mode(true),
            DECSET => self.set_mode_private(true),
            RM => self.set_mode(false),
            DECRST => self.set_mode_private(false),
            SGR => self.char_attributes(),
            DECSTR => self.soft_reset(),
            DECSCUSR => self.set_cursor_style(),
            DECSTBM => self.set_scroll_region(),
            SCOSC => self.save_cursor(),
            SCORC => self.restore_cursor(),
            DECIC => self.shift_columns(p0, true, false),
            DECDC => self.shift_columns(p0, true, true),
            DECSCA => self.select_protected(),
            // reports, which the holder answers, and window operations, which xterm does not allow by default
            _ => {}
        }
    }
}

impl Row {
    /// Printable ASCII written from column `x`, as `setCellFromCodepoint` would one at a time.
    #[inline]
    pub(crate) fn write_ascii(&mut self, x: usize, bytes: &[u8], attr: u32) {
        let end = (x + bytes.len()).min(self.cells.len());
        if x >= end {
            return;
        }
        for (cell, &b) in self.cells[x..end].iter_mut().zip(bytes) {
            *cell = Cell { content: u32::from(b) | (1 << WIDTH_SHIFT), attr };
        }
        if end > self.used {
            self.used = end;
        }
    }
}
