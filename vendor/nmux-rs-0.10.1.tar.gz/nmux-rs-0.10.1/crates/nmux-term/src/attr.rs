//! Character attributes in the two words xterm.js keeps them in (`Constants.ts`, `AttributeData.ts`), the pen that writes
//! them, and the table that interns them so a cell needs only a number for them.
//!
//! Beside the two words a cell keeps what xterm has no use for and a terminal shown the cell again does: the hyperlink it is
//! in (OSC 8), and the prompt marks (OSC 133) that came just before it was printed, each as a number for a string the table
//! keeps. A mark goes where its cell goes, and goes when the cell is written over or erased: a line editor that prints what
//! was typed again takes the mark of where the typing started with it.

use std::collections::HashMap;
use std::hash::{BuildHasherDefault, Hash, Hasher};

/// The colour mode bits of either word.
pub const CM_MASK: u32 = 0x0300_0000;
/// One of the 16 colours.
pub const CM_P16: u32 = 0x0100_0000;
/// One of the 256 colours.
pub const CM_P256: u32 = 0x0200_0000;
/// A colour given as red, green and blue.
pub const CM_RGB: u32 = 0x0300_0000;
/// The colour of a palette mode.
pub const PCOLOR_MASK: u32 = 0xFF;
/// The colour of the RGB mode.
pub const RGB_MASK: u32 = 0x00FF_FFFF;

/// Flags of the foreground word.
pub mod fg {
    /// SGR 7.
    pub const INVERSE: u32 = 0x0400_0000;
    /// SGR 1.
    pub const BOLD: u32 = 0x0800_0000;
    /// SGR 4.
    pub const UNDERLINE: u32 = 0x1000_0000;
    /// SGR 5.
    pub const BLINK: u32 = 0x2000_0000;
    /// SGR 8.
    pub const INVISIBLE: u32 = 0x4000_0000;
    /// SGR 9.
    pub const STRIKETHROUGH: u32 = 0x8000_0000;
}

/// Flags of the background word.
pub mod bg {
    /// SGR 3.
    pub const ITALIC: u32 = 0x0400_0000;
    /// SGR 2.
    pub const DIM: u32 = 0x0800_0000;
    /// The cell has extended attributes. In a cell here it means more than in xterm: that they make it underlined, which
    /// is all that can be seen of them. See [`super::Pen::cell_bg`].
    pub const HAS_EXTENDED: u32 = 0x1000_0000;
    /// DECSCA: selective erase leaves the cell alone.
    pub const PROTECTED: u32 = 0x2000_0000;
    /// SGR 53.
    pub const OVERLINE: u32 = 0x4000_0000;
}

/// The attributes of a cell: xterm's two words, and the strings of its link and marks.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Attr {
    /// Foreground colour and the flags kept with it.
    pub fg: u32,
    /// Background colour and the flags kept with it.
    pub bg: u32,
    /// The hyperlink the cell is in, `params;uri`, by its number in the table that read the cell; 0 for none, or one too
    /// long to keep.
    pub link: u32,
    /// The prompt marks that came just before the cell was printed, as a terminal is sent them, by number the same way.
    pub mark: u32,
}

/// Most attributes have no link and no marks, and every change of the pen is looked up: those two go in only when set.
impl Hash for Attr {
    fn hash<H: Hasher>(&self, state: &mut H) {
        state.write_u32(self.fg);
        state.write_u32(self.bg);
        if self.link | self.mark != 0 {
            state.write_u32(self.link);
            state.write_u32(self.mark);
        }
    }
}

impl Attr {
    /// No attributes at all.
    pub const DEFAULT: Attr = Attr { fg: 0, bg: 0, link: 0, mark: 0 };

    /// The two words alone.
    pub fn words(fg: u32, bg: u32) -> Attr {
        Attr { fg, bg, ..Attr::DEFAULT }
    }

    /// Whether a cell with these attributes looks underlined, as `isUnderline` answers.
    pub fn is_underline(self) -> bool {
        self.fg & fg::UNDERLINE != 0 || self.bg & bg::HAS_EXTENDED != 0
    }

    /// Whether DECSCA protects the cell.
    pub fn is_protected(self) -> bool {
        self.bg & bg::PROTECTED != 0
    }
}

/// What writes characters: the current attributes, with the extended ones xterm keeps beside them.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Pen {
    /// The foreground word.
    pub fg: u32,
    /// The background word, with `HAS_EXTENDED` as xterm sets it.
    pub bg: u32,
    /// The underline style of SGR 4:n, 0 to 7.
    pub underline_style: u8,
    /// A hyperlink is open (OSC 8).
    pub url: bool,
    /// Its string, by number: 0 when it was too long to keep.
    pub link: u32,
    /// The marks the character being printed takes, by number: only while it is printed.
    pub mark: u32,
}

impl Pen {
    /// Whether the extended attributes hold anything, as `ExtendedAttrs.isEmpty` answers.
    fn extended_empty(&self) -> bool {
        self.underline_style == 0 && !self.url
    }

    /// `updateExtended`: the flag follows whether there is anything to keep.
    pub fn update_extended(&mut self) {
        if self.extended_empty() {
            self.bg &= !bg::HAS_EXTENDED;
        } else {
            self.bg |= bg::HAS_EXTENDED;
        }
    }

    /// The background word a cell written with this pen gets. A cell keeps a reference to the pen's extended attributes,
    /// and `isUnderline` looks at them only when the flag is set. They are not always in agreement: DECRC brings back the
    /// flag without them. So a cell keeps the flag only when the two together make it underlined.
    pub fn cell_bg(&self) -> u32 {
        if self.bg & bg::HAS_EXTENDED != 0 && self.extended_empty() { self.bg & !bg::HAS_EXTENDED } else { self.bg }
    }

    /// The attributes of a cell written with this pen.
    pub fn attr(&self) -> Attr {
        Attr { fg: self.fg, bg: self.cell_bg(), link: self.link, mark: self.mark }
    }

    /// The attributes erasing fills with: the background colour only (`_eraseAttrData`).
    pub fn erase_attr(&self) -> Attr {
        Attr::words(0, self.bg & (CM_MASK | RGB_MASK))
    }
}

/// A hasher for two words, which is all this table hashes.
#[derive(Default)]
pub(crate) struct WordHasher(u64);

impl Hasher for WordHasher {
    fn finish(&self) -> u64 {
        self.0
    }

    fn write(&mut self, bytes: &[u8]) {
        for &b in bytes {
            self.write_u64(u64::from(b));
        }
    }

    fn write_u32(&mut self, n: u32) {
        self.write_u64(u64::from(n));
    }

    fn write_u64(&mut self, n: u64) {
        self.0 = (self.0.rotate_left(5) ^ n).wrapping_mul(0x517c_c1b7_2722_0a95);
    }
}

/// The attributes cells on the screens use, each once, so that a cell holds a number for them, and the strings of their
/// links and marks. History keeps the words and the strings themselves, so this table only has to cover two screens and is
/// compacted when it holds many more than that.
#[derive(Debug)]
pub(crate) struct Attrs {
    list: Vec<Attr>,
    index: HashMap<Attr, u32, BuildHasherDefault<WordHasher>>,
    /// The strings, the first of them none.
    strings: Vec<String>,
    string_index: HashMap<String, u32>,
    /// Their bytes.
    string_bytes: usize,
}

impl Default for Attrs {
    fn default() -> Self {
        Attrs {
            list: vec![Attr::DEFAULT],
            index: HashMap::default(),
            strings: vec![String::new()],
            string_index: HashMap::new(),
            string_bytes: 0,
        }
    }
}

impl std::fmt::Debug for WordHasher {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("WordHasher")
    }
}

impl Attrs {
    /// The number for these attributes; 0 is the default.
    #[inline]
    pub fn intern(&mut self, a: Attr) -> u32 {
        if a == Attr::DEFAULT {
            return 0;
        }
        if let Some(&id) = self.index.get(&a) {
            return id;
        }
        let id = u32::try_from(self.list.len()).unwrap_or(u32::MAX);
        self.list.push(a);
        self.index.insert(a, id);
        id
    }

    /// The attributes with this number.
    #[inline]
    pub fn get(&self, id: u32) -> Attr {
        self.list.get(id as usize).copied().unwrap_or_default()
    }

    /// How many there are.
    pub fn len(&self) -> usize {
        self.list.len()
    }

    /// The number for this string; the empty one is 0.
    pub fn intern_string(&mut self, s: &str) -> u32 {
        if s.is_empty() {
            return 0;
        }
        if let Some(&id) = self.string_index.get(s) {
            return id;
        }
        let id = u32::try_from(self.strings.len()).unwrap_or(u32::MAX);
        self.strings.push(s.to_owned());
        self.string_index.insert(s.to_owned(), id);
        self.string_bytes += s.len();
        id
    }

    /// The string with this number, empty for none.
    pub fn string(&self, id: u32) -> &str {
        self.strings.get(id as usize).map_or("", String::as_str)
    }

    /// The bytes of the strings: they are kept twice, and each costs a little more.
    pub fn string_bytes(&self) -> usize {
        self.string_bytes
    }

    /// The bytes the strings take, roughly.
    pub fn strings_memory(&self) -> usize {
        2 * self.string_bytes + 48 * self.strings.len()
    }

    /// Keeps only `used`, renumbered in that order, and the strings they and `keep` use; the default stays 0. Returns
    /// the new numbers of `keep`'s strings.
    pub fn rebuild(&mut self, used: &[Attr], keep: [u32; 2]) -> [u32; 2] {
        let old = std::mem::take(&mut self.strings);
        self.string_index.clear();
        self.string_bytes = 0;
        self.strings.push(String::new());
        let renumber = |id: u32, this: &mut Attrs| this.intern_string(old.get(id as usize).map_or("", String::as_str));
        let keep = [renumber(keep[0], self), renumber(keep[1], self)];
        self.list.clear();
        self.index.clear();
        self.list.push(Attr::DEFAULT);
        for &a in used {
            let a = Attr { link: renumber(a.link, self), mark: renumber(a.mark, self), ..a };
            self.intern(a);
        }
        keep
    }
}
