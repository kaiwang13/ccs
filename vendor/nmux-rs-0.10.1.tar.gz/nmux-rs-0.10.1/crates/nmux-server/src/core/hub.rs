//! The attached clients, `hub.js` and `heartbeat.js`: who is here, what reaches them, their sizes and the floor, leaving,
//! being sent away, and where each terminal that left had got.

use nmux_holder::Level;
use nmux_io::{OutBuf, Time, TimerId};
use nmux_vt::seq::SCHEME_MODE;
use nmux_wire::{ClientInfo, Control, Frame, Hello, Size, State};
use serde_json::{Map, Value, json};

use super::join::Join;
use super::{Bookmark, ConnId, Due, Server};
use crate::clients::arbiter::Seat;
use crate::input::router::{Ctx, Event as RouterEvent};
use crate::output::{ByeExtra, Chunk, ClientAdapter, ClientFlags, Clipboard, Context, Phase};
use crate::session::shell::ShellEvent;

/// Terminals that left, remembered. Each one holds two pins.
const MAX_DEPARTURES: usize = 32;
/// The longest name a terminal may call itself.
const MAX_TERMINAL_ID: usize = 512;

/// An attached terminal.
#[derive(Debug)]
pub struct Client {
    /// Its id, `c1` and on.
    pub id: String,
    /// What it said when it came.
    pub hello: Hello,
    /// What lists of clients call it.
    pub label: String,
    /// Its view of the output, and what is queued for it.
    pub adapter: ClientAdapter,
    pub(super) last_pong_at: Time,
    ping_seq: u64,
    pub(super) ping_timer: Option<TimerId>,
    notice_timer: Option<(TimerId, Time)>,
    /// When it last typed, on the monotonic clock, if it has.
    pub(super) last_input_at: Option<Time>,
    /// A join or a redraw for it is under way.
    pub(super) joining: Option<Join>,
    /// A redraw it asked for while something else was being sent to it.
    pub(super) asked: Option<(Option<bool>, u64, u8)>,
    pub(super) attached_at: Time,
    /// What has been drawn behind its screen.
    pub(super) ambient: super::ambient::Drawn,
}

impl Server {
    /// A context for the clients' adapters.
    pub(super) fn cx(&self) -> Context<'_> {
        Context { titles: &self.titles, tracker: &self.tracker, queue_cap: self.config.clients.queue_cap_bytes }
    }

    pub(super) fn next_client_id(&mut self) -> String {
        self.client_seq += 1;
        format!("c{}", self.client_seq)
    }

    /// A terminal said hello and was let in: it is added, and its join starts.
    pub(super) fn add_client(&mut self, conn: ConnId, hello: Hello, id: &str, out: OutBuf) {
        let flags = ClientFlags {
            shrink: hello.flags.shrink(),
            allow_gated: hello.flags.allow_gated(),
            view: hello.flags.view(),
            clipboard: Clipboard::of(hello.clipboard.as_deref()),
        };
        let mut adapter = ClientAdapter::new(hello.cols, hello.rows, flags);
        adapter.keyboard = hello.keyboard.unwrap_or(0);
        adapter.out = out;
        adapter.bar = hello.flags.bar();
        if self.attention {
            let cx = Context {
                titles: &self.titles,
                tracker: &self.tracker,
                queue_cap: self.config.clients.queue_cap_bytes,
            };
            adapter.set_attention(true, &cx);
        }
        let label = if hello.label.is_empty() { id.to_owned() } else { hello.label.clone() };
        let agent = hello.agent.clone().flatten();
        let colors = hello.colors.clone();
        let client = Client {
            id: id.to_owned(),
            hello,
            label,
            adapter,
            last_pong_at: self.now.time,
            ping_seq: 0,
            ping_timer: None,
            notice_timer: None,
            last_input_at: None,
            joining: None,
            asked: None,
            attached_at: self.now.time,
            ambient: super::ambient::Drawn::default(),
        };
        self.clients.insert(conn, client);
        if !flags.view {
            self.agent_arrived(id, agent.as_deref()); // a viewer is watching, not lending its keys
            self.colors_arrived(colors.as_ref()); // nor its colours
        }
        self.router.add_client(id, flags.allow_gated);
        let timer = self.set_timer(self.config.clients.ping_ms, Due::ClientPing(conn));
        if let Some(c) = self.clients.get_mut(&conn) {
            c.ping_timer = Some(timer);
        }
        self.broadcast_state();
        self.client_arrived();
        self.start_join(conn);
    }

    fn conn_of(&self, id: &str) -> Option<ConnId> {
        self.clients.iter().find(|(_, c)| c.id == id).map(|(k, _)| *k)
    }

    /// A frame from an attached terminal.
    pub(super) fn client_frame(&mut self, conn: ConnId, frame: &Frame<'_>) {
        let Some(c) = self.clients.get_mut(&conn) else { return };
        if c.adapter.closed {
            return;
        }
        match frame {
            Frame::Input(bytes) => {
                let a = &c.adapter;
                if !a.flags.view && (a.phase == Phase::Live || a.resyncing) {
                    c.last_input_at = Some(self.now.time);
                    let id = c.id.clone();
                    self.route_input(&id, bytes, false);
                }
            }
            Frame::Control(m) => match m {
                Control::Ping { seq } => c.adapter.send_control(&Control::Pong { seq: *seq }),
                Control::Pong { .. } => {
                    c.last_pong_at = self.now.time;
                    if c.adapter.stalled {
                        c.adapter.stalled = false;
                        self.arbiter_changed();
                        self.broadcast_state();
                    }
                }
                Control::Resize { cols, rows, bar } => {
                    let (cols, rows) = (*cols, *rows);
                    // the bar came or went with the row it takes
                    let had = c.adapter.bar;
                    if let Some(bar) = bar {
                        c.adapter.bar = *bar;
                    }
                    let toggled = had != c.adapter.bar;
                    self.client_resize(conn, cols, rows);
                    self.ambient_moved(conn, toggled);
                }
                Control::Redraw => self.ambient_moved(conn, false),
                Control::Detach { received, drain } => {
                    self.remember(conn, *received, *drain == Some(true));
                    self.bye(conn, "USER", false, "", ByeExtra::default());
                }
                Control::Resync { alt, skipped, keyboard } => {
                    self.request_resync(conn, *alt, skipped.unwrap_or(0), keyboard.unwrap_or(0));
                }
                _ => {}
            },
            _ => {}
        }
    }

    /// A client's input, through the router; `whole` when nothing more of it will come, as with a control request's text.
    pub(super) fn route_input(&mut self, id: &str, bytes: &[u8], whole: bool) {
        let gates = self.gates();
        let focus_wanted = self.controller.forwards_focus() && self.tracker.modes.raw(1004) == 1;
        let scheme_wanted = self.tracker.modes.raw(SCHEME_MODE) == 1;
        let closed = self.machine.exited;
        let mut writer =
            super::session::HolderWriter { holder: self.holder.as_mut(), total: &mut self.writes_total, closed };
        let mut cx = Ctx {
            gates: &gates,
            policy: &mut self.controller,
            writer: &mut writer,
            focus_wanted,
            scheme: &mut self.tracker.scheme,
            scheme_wanted,
        };
        self.router.on_input(id, bytes, self.now.time, &mut cx);
        if whole {
            self.router.flush(id, self.now.time, &mut cx);
        }
    }

    pub(super) fn router_due(&mut self) {
        self.component_timers[1] = None;
        let gates = self.gates();
        let focus_wanted = self.controller.forwards_focus() && self.tracker.modes.raw(1004) == 1;
        let scheme_wanted = self.tracker.modes.raw(SCHEME_MODE) == 1;
        let closed = self.machine.exited;
        let mut writer =
            super::session::HolderWriter { holder: self.holder.as_mut(), total: &mut self.writes_total, closed };
        let mut cx = Ctx {
            gates: &gates,
            policy: &mut self.controller,
            writer: &mut writer,
            focus_wanted,
            scheme: &mut self.tracker.scheme,
            scheme_wanted,
        };
        self.router.on_time(self.now.time, &mut cx);
    }

    /// A client of the router leaves it; one in the middle of a paste has it closed.
    pub(super) fn router_remove(&mut self, id: &str) {
        let gates = self.gates();
        let closed = self.machine.exited;
        let mut writer =
            super::session::HolderWriter { holder: self.holder.as_mut(), total: &mut self.writes_total, closed };
        let mut cx = Ctx {
            gates: &gates,
            policy: &mut self.controller,
            writer: &mut writer,
            focus_wanted: false,
            scheme: &mut self.tracker.scheme,
            scheme_wanted: false,
        };
        self.router.remove_client(id, self.now.time, &mut cx);
    }

    /// What the router asked for.
    pub(super) fn take_router_events(&mut self) -> bool {
        let events = std::mem::take(&mut self.router.events);
        let any = !events.is_empty();
        for e in events {
            match e {
                RouterEvent::Detach(id) => {
                    if let Some(conn) = self.conn_of(&id) {
                        self.bye(conn, "USER", false, "", ByeExtra::default());
                    }
                }
                RouterEvent::Notice(to, level, code) => {
                    let text = if code == "INPUT_DROPPED" {
                        self.messages.input_dropped()
                    } else {
                        self.messages.esc_hold_expired()
                    };
                    match to.and_then(|id| self.conn_of(&id)) {
                        Some(conn) => self.notice_client(conn, level, code, &text),
                        None => self.notice_all(level, code, &text),
                    }
                }
                RouterEvent::SchemeChanged(id) => {
                    let cap = self.config.clients.queue_cap_bytes;
                    let client = self.conn_of(&id).and_then(|conn| self.clients.get_mut(&conn));
                    if let Some(c) = client.filter(|c| !c.hello.flags.view()) {
                        c.adapter.ask_colors(cap);
                    }
                }
                RouterEvent::Colors(id, colors) => {
                    let client = self.conn_of(&id).and_then(|conn| self.clients.get(&conn));
                    if client.is_some_and(|c| !c.hello.flags.view()) {
                        self.colors_arrived(Some(&colors)); // a viewer's are not the program's
                    }
                }
                RouterEvent::Held(id, class) => {
                    let code = self
                        .controller
                        .remote
                        .as_ref()
                        .and_then(|r| r.managed.guards.first())
                        .and_then(|g| g.code.clone())
                        .unwrap_or_else(|| "KEY_HELD".to_owned());
                    let text = self.messages.held_key(class.as_str(), &self.name());
                    if let Some(conn) = self.conn_of(&id) {
                        self.notice_client(conn, "warn", &code, &text);
                    }
                }
            }
        }
        any
    }

    /// What the shell said.
    pub(super) fn take_shell_events(&mut self) -> bool {
        let Some(shell) = self.shell.as_mut() else { return false };
        let events = std::mem::take(&mut shell.events);
        let cancel = std::mem::take(&mut shell.cancel_line);
        if cancel {
            self.write(b"\x03", false, false);
        }
        let any = !events.is_empty() || cancel;
        for e in events {
            match e {
                ShellEvent::Prompt => {
                    self.publish(&json!({ "event": "prompt" }));
                    self.next_run();
                }
                ShellEvent::Command(fields) => {
                    let mut e = Map::new();
                    e.insert("event".into(), json!("command"));
                    if let Value::Object(f) = fields {
                        e.extend(f);
                    }
                    self.publish(&Value::Object(e));
                }
            }
        }
        any
    }

    pub(super) fn shell_due(&mut self) {
        self.component_timers[3] = None;
        if let Some(shell) = self.shell.as_mut() {
            shell.now = (self.now.wall_ms, self.now.time);
            shell.on_time(self.now.time);
        }
    }

    /// What the controller has said.
    pub(super) fn take_controller_events(&mut self) -> bool {
        let said = std::mem::take(&mut self.controller.said);
        let any = !said.is_empty();
        for e in said {
            self.publish(&e);
        }
        any
    }

    /// What the clients' adapters left: one fell behind, one was let go, a notice to end in time.
    pub(super) fn take_client_work(&mut self) -> bool {
        let mut any = false;
        let conns: Vec<ConnId> = self.clients.keys().copied().collect();
        for conn in conns {
            let Some(c) = self.clients.get_mut(&conn) else { continue };
            if std::mem::take(&mut c.adapter.became_behind) && c.adapter.dropped.is_none() {
                any = true;
                self.start_resync(conn, true, false);
            }
            let Some(c) = self.clients.get_mut(&conn) else { continue };
            if let Some(reason) = c.adapter.dropped.take() {
                any = true;
                let id = c.id.clone();
                self.log(Level::Info, "client.bye", &[("client", json!(id)), ("reason", json!(reason))]);
                self.close_client(conn);
                continue;
            }
            let due = c.adapter.notice_until;
            if due != c.notice_timer.map(|t| t.1) {
                if let Some((id, _)) = c.notice_timer.take() {
                    self.timers.cancel(id);
                }
                if let Some(at) = due {
                    let id = self.timers.set_at(at, Due::NoticeEnd(conn));
                    if let Some(c) = self.clients.get_mut(&conn) {
                        c.notice_timer = Some((id, at));
                    }
                }
            }
        }
        any
    }

    pub(super) fn notice_end(&mut self, conn: ConnId) {
        let cap = self.config.clients.queue_cap_bytes;
        let Some(c) = self.clients.get_mut(&conn) else { return };
        c.notice_timer = None;
        let cx = Context { titles: &self.titles, tracker: &self.tracker, queue_cap: cap };
        c.adapter.notice_ended(&cx);
    }

    /// A chunk of output, to every client. A clipboard write in it goes to the terminals given it as it is written.
    pub(super) fn render_all(&mut self, chunk: &Chunk) {
        let cx =
            Context { titles: &self.titles, tracker: &self.tracker, queue_cap: self.config.clients.queue_cap_bytes };
        let typist = self.router.last_typist.as_deref();
        let mut hit = Vec::new();
        for (conn, c) in &mut self.clients {
            c.adapter.clipboard = c.adapter.flags.clipboard.given(typist == Some(c.id.as_str()));
            c.adapter.render(chunk, &cx);
            c.adapter.clipboard = false;
            if std::mem::take(&mut c.adapter.bar_hit) {
                hit.push(*conn);
            }
        }
        for conn in hit {
            self.bar_hit(conn);
        }
    }

    /// A terminal is leaving. It is remembered only if it has everything sent to it: what was on its way when it stopped
    /// reading is not in its scrollback, and treating it as seen would leave a hole there. One that drains reads on until
    /// it is told goodbye, which comes after everything sent to it.
    fn remember(&mut self, conn: ConnId, received: Option<u64>, drain: bool) {
        let Some(c) = self.clients.get(&conn) else { return };
        let key = c.hello.terminal.clone().flatten();
        let a = &c.adapter;
        let caught_up = received == Some(self.output_frames_bytes(conn)) || drain;
        let ok = key.as_ref().is_some_and(|k| k.len() <= MAX_TERMINAL_ID);
        if !ok || a.phase != Phase::Live || a.behind || a.has_gaps || !caught_up {
            let fields = [
                ("client", json!(c.id)),
                ("identified", json!(key.is_some())),
                ("phase", json!(a.phase.as_str())),
                ("behind", json!(a.behind)),
                ("gaps", json!(a.has_gaps)),
                ("caughtUp", json!(caught_up)),
            ];
            self.log(Level::Info, "client.not_remembered", &fields);
            return;
        }
        let Some(key) = key else { return };
        self.forget(&key);
        let b = self.bookmark();
        self.departures.push_back((key, b));
        if self.departures.len() > MAX_DEPARTURES
            && let Some((k, _)) = self.departures.front().cloned()
        {
            self.forget(&k);
        }
    }

    /// The OUTPUT bytes sent to a client, as it counts what it received.
    fn output_frames_bytes(&self, conn: ConnId) -> u64 {
        self.clients.get(&conn).map_or(0, |c| c.adapter.sent_output)
    }

    fn forget(&mut self, key: &str) {
        let Some(i) = self.departures.iter().position(|(k, _)| k == key) else { return };
        if let Some((_, b)) = self.departures.remove(i) {
            self.emulator.unpin(b.top);
            self.emulator.unpin(b.cursor);
        }
    }

    /// Where a terminal that came back had got, once: it is here now. `None` for one not seen before.
    pub(super) fn returning(&mut self, key: Option<&str>) -> Option<Bookmark> {
        let key = key?;
        let i = self.departures.iter().position(|(k, _)| k == key)?;
        let (_, b) = self.departures.remove(i)?;
        if self.emulator.pin_row(b.top).is_none() {
            self.emulator.unpin(b.top);
            self.emulator.unpin(b.cursor);
            return None;
        }
        Some(b)
    }

    /// Lets go of a bookmark's pins.
    pub(super) fn unpin_bookmark(&mut self, b: &Bookmark) {
        self.emulator.unpin(b.top);
        self.emulator.unpin(b.cursor);
    }

    /// What arbitration needs to know of every client.
    pub(super) fn seats(&self) -> Vec<Seat> {
        self.clients
            .values()
            .map(|c| Seat {
                cols: c.adapter.cols,
                rows: c.adapter.rows,
                phase: c.adapter.phase,
                stalled: c.adapter.stalled,
                unresponsive: c.adapter.unresponsive,
                shrink: c.adapter.flags.shrink,
                view: c.adapter.flags.view,
            })
            .collect()
    }

    pub(super) fn arbiter_changed(&mut self) {
        let seats = self.seats();
        self.arbiter.on_change(self.now.time, &seats, self.pty);
    }

    pub(super) fn arbiter_due(&mut self) {
        self.component_timers[2] = None;
        let seats = self.seats();
        let Some(size) = self.arbiter.on_time(self.now.time, &seats, self.pty) else { return };
        self.resize_pty(size);
        let narrowest = self
            .clients
            .values()
            .filter(|c| !c.adapter.stalled && c.adapter.phase != Phase::Paused)
            .min_by_key(|c| c.adapter.cols)
            .map(|c| c.label.clone());
        let limited = narrowest.map_or(String::new(), |l| format!(" — limited by {l}"));
        self.notice_all("info", "SIZE", &format!("{}x{}{limited}", size.cols, size.rows));
        self.arbiter_changed();
    }

    /// A terminal's new size: below the floor it is paused and leaves arbitration, and growing back it is joined again.
    fn client_resize(&mut self, conn: ConnId, cols: u32, rows: u32) {
        if cols < 1 || rows < 1 {
            return;
        }
        let size = self.config.size.clone();
        let brand = self.titles.brand.clone();
        let Some(c) = self.clients.get_mut(&conn) else { return };
        let floor = if c.adapter.flags.shrink { size.hard_min_cols } else { size.floor_cols };
        c.adapter.set_size(cols, rows);
        if cols < floor || rows < size.floor_rows {
            if c.adapter.phase != Phase::Paused {
                // below the floor: no output, and out of arbitration
                c.adapter.phase = Phase::Paused;
                let line = format!(
                    "\r\n\x1b[2m── {brand} · paused: this terminal is {cols}x{rows}, below the {floor}x{} floor — enlarge it to resume ──\x1b[0m\r\n",
                    size.floor_rows
                );
                c.adapter.send_output(line.as_bytes());
                let text = format!("paused below the {floor}x{} floor", size.floor_rows);
                c.adapter.send_control(&Control::Notice { level: "warn".into(), code: "PAUSED".into(), text });
            }
        } else if c.adapter.phase == Phase::Paused {
            if c.joining.is_some() {
                // growing back, with a join already on its way
                c.adapter.resume_join();
                self.arbiter_changed();
            } else {
                self.start_join(conn); // growing back: a whole join
            }
            self.broadcast_state();
            return;
        }
        self.arbiter_changed();
        self.broadcast_state();
    }

    /// Lets a client go with a BYE; it is closed once that is written.
    pub(super) fn bye(&mut self, conn: ConnId, reason: &str, auto_rejoin: bool, text: &str, extra: ByeExtra) {
        if let Some(c) = self.clients.get_mut(&conn)
            && !c.adapter.closed
        {
            c.adapter.drop_with(reason, auto_rejoin, text, extra);
        }
    }

    /// Every client goes.
    pub(super) fn bye_all(&mut self, reason: &str, auto_rejoin: bool, text: &str, extra: &ByeExtra) {
        let conns: Vec<ConnId> = self.clients.keys().copied().collect();
        for conn in conns {
            self.bye(conn, reason, auto_rejoin, text, extra.clone());
        }
        self.take_client_work();
    }

    /// A client is gone: its connection ends after what is queued.
    fn close_client(&mut self, conn: ConnId) {
        let Some(mut c) = self.clients.remove(&conn) else { return };
        if let Some(id) = c.ping_timer.take() {
            self.timers.cancel(id);
        }
        if let Some((id, _)) = c.notice_timer.take() {
            self.timers.cancel(id);
        }
        if let Some(j) = c.joining.take() {
            j.cancel(&mut self.timers);
        }
        self.agent_left(&c.id);
        self.router_remove(&c.id);
        // what is still queued, the BYE included, goes out before the connection ends
        self.closing.insert(conn, std::mem::take(&mut c.adapter.out));
        self.effects.push(super::Effect::Close { conn, now: false });
        self.arbiter_changed();
        self.log(Level::Info, "client.closed", &[("client", json!(c.id))]);
        self.broadcast_state();
    }

    /// The connection of a client closed.
    pub(super) fn client_gone(&mut self, conn: ConnId) {
        if let Some(c) = self.clients.get_mut(&conn) {
            c.adapter.closed = true;
            c.adapter.dropped.get_or_insert_with(|| "CLOSED".to_owned());
            c.adapter.out.clear();
        }
        self.take_client_work();
        self.closing.remove(&conn);
    }

    /// A client that left asked to: it is told so, and the session goes on.
    pub(super) fn client_exit(&mut self, id: &str) {
        if let Some(conn) = self.conn_of(id) {
            let text = self.messages.client_exit(&self.name());
            self.bye(conn, "CLIENT_EXIT", false, &text, ByeExtra::default());
        }
    }

    /// Sends the named clients away, or with `all_except` every other one. Ids not attached are reported back.
    pub(super) fn kick(&mut self, ids: Option<&[String]>, all_except: Option<&[String]>, by: &str) -> Value {
        let who =
            format!("detached by {}", if by.is_empty() { self.messages.default_kicked_by() } else { by.to_owned() });
        let (targets, unknown): (Vec<ConnId>, Vec<String>) = match (ids, all_except) {
            (_, Some(except)) => {
                (self.clients.iter().filter(|(_, c)| !except.contains(&c.id)).map(|(k, _)| *k).collect(), Vec::new())
            }
            (ids, None) => {
                let ids = ids.unwrap_or(&[]);
                let targets = self.clients.iter().filter(|(_, c)| ids.contains(&c.id)).map(|(k, _)| *k).collect();
                let unknown = ids.iter().filter(|id| self.conn_of(id).is_none()).cloned().collect();
                (targets, unknown)
            }
        };
        let text = self.messages.kicked(&who, &self.name());
        let mut kicked = Vec::new();
        for conn in targets {
            let Some(c) = self.clients.get(&conn) else { continue };
            kicked.push(json!({ "id": c.id, "label": c.label }));
            let fields = [("client", json!(c.id)), ("label", json!(c.label)), ("by", json!(by))];
            self.log(Level::Info, "client.kicked", &fields);
            self.bye(conn, "KICKED", false, &text, ByeExtra { by: Some(by.to_owned()), ..ByeExtra::default() });
        }
        json!({ "kicked": kicked, "unknown": unknown })
    }

    /// These terminals asked to leave, which is not being sent away: they are told so, and the session goes on.
    pub(super) fn leave(&mut self, ids: &[String]) -> Value {
        let text = self.messages.client_exit(&self.name());
        let mut kicked = Vec::new();
        for id in ids {
            if let Some(conn) = self.conn_of(id)
                && let Some(c) = self.clients.get(&conn)
            {
                kicked.push(json!({ "id": c.id, "label": c.label }));
                self.bye(conn, "CLIENT_EXIT", false, &text, ByeExtra::default());
            }
        }
        let unknown: Vec<&String> = ids.iter().filter(|id| !kicked.iter().any(|k| k["id"] == ***id)).collect();
        json!({ "kicked": kicked, "unknown": unknown })
    }

    /// The clients as STATE lists them.
    pub(super) fn client_info(&self) -> Vec<ClientInfo> {
        self.clients
            .values()
            .map(|c| {
                #[allow(clippy::cast_precision_loss)] // milliseconds of a monotonic clock
                let last = c.last_input_at.map_or(0.0, |t| t.ms() as f64);
                ClientInfo {
                    id: c.id.clone(),
                    label: c.label.clone(),
                    view: c.adapter.flags.view,
                    cols: c.adapter.cols,
                    rows: c.adapter.rows,
                    phase: c.adapter.phase.as_str().to_owned(),
                    stalled: c.adapter.stalled,
                    unresponsive: c.adapter.unresponsive,
                    last_input_at: last,
                    extra: Map::new(),
                }
            })
            .collect()
    }

    /// The clients as `nmux clients` lists them. Ages are relative, as the clock is monotonic.
    pub(super) fn listing(&self) -> Vec<Value> {
        let now = self.now.time;
        self.clients
            .values()
            .map(|c| {
                let h = &c.hello;
                json!({
                    "id": c.id, "label": c.label, "view": c.adapter.flags.view, "tty": h.tty,
                    "pid": (h.pid > 0).then_some(h.pid), "termProgram": h.term_program,
                    "cols": c.adapter.cols, "rows": c.adapter.rows, "phase": c.adapter.phase.as_str(),
                    "stalled": c.adapter.stalled, "unresponsive": c.adapter.unresponsive,
                    "attachedMs": now.since(c.attached_at), "idleMs": c.last_input_at.map(|t| now.since(t)),
                })
            })
            .collect()
    }

    /// The STATE message.
    pub(super) fn state_message(&self) -> Control {
        let status = self.status();
        let mut extra = self.controller.state_fields();
        extra.remove("name");
        let alt = status.get("alt").and_then(Value::as_bool).unwrap_or(false);
        Control::State(State {
            lifecycle: self.machine.lifecycle.as_str().to_owned(),
            name: Some(self.name()),
            extra,
            pty: Size { cols: self.pty.cols, rows: self.pty.rows },
            alt,
            clients: self.client_info(),
        })
    }

    /// STATE to every client and every control connection.
    pub(super) fn broadcast_state(&mut self) {
        let msg = self.state_message();
        for c in self.clients.values_mut().filter(|c| !c.adapter.closed) {
            c.adapter.send_control(&msg);
        }
        for w in self.controls.values_mut() {
            let _ = w.out.control(&msg);
        }
    }

    /// This server is going and another takes over: a terminal that is up to date is told how far it has got.
    pub(super) fn restarting(&mut self) {
        let text = self.messages.restarting();
        let at = self.resume_point();
        let conns: Vec<ConnId> = self.clients.keys().copied().collect();
        for conn in conns {
            let Some(c) = self.clients.get(&conn) else { continue };
            let a = &c.adapter;
            let resume = at.filter(|_| a.phase == Phase::Live && !a.behind).map(
                |(generation, offset)| json!({ "gen": generation, "offset": offset, "cols": a.cols, "rows": a.rows }),
            );
            self.bye(conn, "SESSION_ENDING", true, &text, ByeExtra { resume, ..ByeExtra::default() });
        }
        self.take_client_work();
    }

    /// A notice to every client, and to subscribers.
    pub(super) fn notify(&mut self, level: &str, code: &str, text: &str) {
        self.notice_all(level, code, text);
        self.publish(&json!({ "event": "notice", "level": level, "code": code, "text": text }));
    }

    /// A notice to every client.
    pub(super) fn notice_all(&mut self, level: &str, code: &str, text: &str) {
        let conns: Vec<ConnId> = self.clients.keys().copied().collect();
        for conn in conns {
            self.notice_client(conn, level, code, text);
        }
    }

    /// A notice to one client.
    pub(super) fn notice_client(&mut self, conn: ConnId, level: &str, code: &str, text: &str) {
        let cap = self.config.clients.queue_cap_bytes;
        let now = self.now.time;
        let Some(c) = self.clients.get_mut(&conn) else { return };
        let cx = Context { titles: &self.titles, tracker: &self.tracker, queue_cap: cap };
        c.adapter.notice(level, code, text, now, &cx);
    }

    /// The session's attention changed: every title says so.
    pub(super) fn publish_attention(&mut self, attention: bool) {
        self.attention = attention;
        let cap = self.config.clients.queue_cap_bytes;
        let cx = Context { titles: &self.titles, tracker: &self.tracker, queue_cap: cap };
        for c in self.clients.values_mut() {
            c.adapter.set_attention(attention, &cx);
        }
        self.broadcast_state();
    }

    /// Pings a client. No pong for `stall_ms` stalls it, out of arbitration; for `drop_ms`, it is let go.
    pub(super) fn heartbeat(&mut self, conn: ConnId) {
        let (stall, drop) = (self.config.clients.stall_ms, self.config.clients.drop_ms);
        let Some(c) = self.clients.get_mut(&conn) else { return };
        c.ping_timer = None;
        if c.adapter.closed {
            return;
        }
        let silent = self.now.time.since(c.last_pong_at);
        if drop.is_some_and(|d| silent > d) {
            self.bye(conn, "STALLED", true, "no heartbeat from this terminal", ByeExtra::default());
            return;
        }
        let Some(c) = self.clients.get_mut(&conn) else { return };
        if silent > stall && !c.adapter.stalled {
            c.adapter.stalled = true;
            let (id, label) = (c.id.clone(), c.label.clone());
            self.log(Level::Warn, "client.stalled", &[("client", json!(id))]);
            self.arbiter_changed();
            let text = format!("{label} is not responding and no longer limits the size");
            let others: Vec<ConnId> = self.clients.keys().copied().filter(|k| *k != conn).collect();
            for o in others {
                self.notice_client(o, "info", "CLIENT_STALLED", &text);
            }
            self.broadcast_state();
        }
        let Some(c) = self.clients.get_mut(&conn) else { return };
        c.ping_seq += 1;
        let seq = c.ping_seq;
        c.adapter.send_control(&Control::Ping { seq });
        let timer = self.set_timer(self.config.clients.ping_ms, Due::ClientPing(conn));
        if let Some(c) = self.clients.get_mut(&conn) {
            c.ping_timer = Some(timer);
        }
    }

    // ---- what the session's events mean to the clients -------------------------------------------------------

    /// The pty took a new size: the session's screen has changed under every bar.
    pub(super) fn on_pty(&mut self) {
        self.broadcast_state();
        self.joins_hear_pty();
        let barred: Vec<ConnId> = self.clients.iter().filter(|(_, c)| c.adapter.bar).map(|(k, _)| *k).collect();
        for conn in barred {
            self.ambient_moved(conn, false);
        }
    }

    /// The lifecycle changed.
    pub(super) fn on_lifecycle(&mut self, to: &str) {
        self.broadcast_state();
        self.publish(&json!({ "event": "lifecycle", "lifecycle": to }));
        self.joins_hear_start();
        self.requests_hear_settled();
    }

    /// The session has started, or will not.
    pub(super) fn on_started(&mut self) {
        self.stop_hears_started();
        self.joins_hear_start();
        self.requests_hear_settled();
    }
}
