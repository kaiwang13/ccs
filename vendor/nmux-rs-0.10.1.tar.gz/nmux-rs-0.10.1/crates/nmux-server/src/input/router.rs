//! The input router, `input.js`: each client's bytes go through its own tokenizer, then the key decoder, the policy and the
//! gates, to the holder. In order: the policy's detach keys, by class, never forwarded and their release and repeat events
//! swallowed for half a second; keys that decode to nothing; what only looks like a terminal's own reply, but for a
//! colour-scheme report the program is to hear; focus reports, only to a program that asked; the gates; Ctrl+C and Ctrl+D through the policy's guard when it has one; and the rest forwarded.
//! While one client is in a bracketed paste, others' keys wait for its end, at most two seconds.

use std::collections::HashMap;

use nmux_io::Time;
use nmux_vt::keys::{KeyClass, KeyState, classify, decode_input_token};
use nmux_vt::seq::{color_report, scheme_report};
use nmux_vt::{InputKind, InputToken, InputTokenizer};
use nmux_wire::Colors;

use crate::config::InputConfig;
use crate::output::Scheme;

/// `c_cc` bytes: in cooked mode, SIGINT, EOF, SIGTSTP, SIGQUIT, XON and XOFF.
const CC_BYTES: [u8; 6] = [0x03, 0x04, 0x1a, 0x1c, 0x11, 0x13];
const SWALLOW_MS: u64 = 500;
const PASTE_HOLD_MS: u64 = 2000;
const OVERFLOW_GATE_MS: u64 = 1000;

/// What a gate does to a client's input.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum GateEffect {
    /// Nothing gets through.
    Drop,
    /// Everything but the `c_cc` bytes gets through.
    Filter,
    /// Everything gets through.
    Open,
}

/// The program's side of the session's input, which a controller decides.
pub trait Policy {
    /// The key classes that detach a terminal.
    fn detach_keys(&self) -> &[KeyClass] {
        &[]
    }
    /// What a gate does to a client that may or may not type through gates.
    fn gate_effect(&self, gate: &str, allow_gated: bool) -> GateEffect {
        let _ = (gate, allow_gated);
        GateEffect::Drop
    }
    /// Whether presses of this class go through [`Policy::offer_signal_key`] rather than straight to the program.
    fn guards_key(&self, class: KeyClass) -> bool {
        let _ = class;
        false
    }
    /// A guarded press: forwarded with `write`, which says the id of the watched write, or held. True when forwarded.
    fn offer_signal_key(&mut self, class: KeyClass, now: Time, writer: &mut dyn Writer) -> bool {
        let _ = (class, now, writer);
        true
    }
    /// A paste was forwarded.
    fn on_paste(&mut self) {}
    /// A token was forwarded for a client, with the session's byte total after it.
    fn on_forwarded(&mut self, client: &str, tok: &InputToken<'_>, total: u64) {
        let _ = (client, tok, total);
    }
}

/// A session with no controller: every gate drops, and every key belongs to the program.
#[derive(Clone, Copy, Debug, Default)]
pub struct Plain;

impl Policy for Plain {}

/// Where input goes: the holder, through the session.
pub trait Writer {
    /// Writes to the program. `watch`: the holder says when it has been read; the id it will say it with.
    fn write(&mut self, bytes: &[u8], lone_esc: bool, watch: bool) -> u32;
    /// Every byte written to the program so far, whoever wrote it.
    fn total(&self) -> u64;
}

/// What the router asks of the session.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Event {
    /// A client asked to detach.
    Detach(String),
    /// Something for one client, or every one: level, code, text.
    Notice(Option<String>, &'static str, &'static str),
    /// A guarded key was held back for this client.
    Held(String, KeyClass),
    /// This client's terminal reported another colour scheme than it did before: its colours changed with it.
    SchemeChanged(String),
    /// This client's terminal said one of its default colours, which is kept for the program.
    Colors(String, Colors),
}

/// What routing needs from the session, each time.
pub struct Ctx<'a> {
    /// The gates that apply, most important first.
    pub gates: &'a [String],
    /// The controller.
    pub policy: &'a mut dyn Policy,
    /// The holder.
    pub writer: &'a mut dyn Writer,
    /// The program asked for focus reports.
    pub focus_wanted: bool,
    /// What the program has asked and been told of the terminal's colour scheme.
    pub scheme: &'a mut Scheme,
    /// The program asked to be told when the colour scheme changes: mode 2031.
    pub scheme_wanted: bool,
}

impl std::fmt::Debug for Ctx<'_> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Ctx")
            .field("gates", &self.gates)
            .field("focus_wanted", &self.focus_wanted)
            .field("scheme", &self.scheme)
            .field("scheme_wanted", &self.scheme_wanted)
            .finish_non_exhaustive()
    }
}

#[derive(Debug)]
struct ClientInput {
    tok: InputTokenizer,
    keys: KeyState,
    swallow_until: Option<Time>,
    allow_gated: bool,
    /// The colour scheme its terminal reported last.
    scheme: Option<u8>,
}

/// A token kept while another client pastes.
#[derive(Debug)]
struct Held {
    client: String,
    kind: InputKind,
    bytes: Vec<u8>,
}

/// See the module.
#[derive(Debug)]
pub struct Router {
    config: InputConfig,
    clients: HashMap<String, ClientInput>,
    paste_owner: Option<String>,
    held: Vec<Held>,
    held_due: Option<Time>,
    drop_until: Option<Time>,
    /// The client that typed last.
    pub last_typist: Option<String>,
    last_esc_client: Option<String>,
    /// What the session is asked to do.
    pub events: Vec<Event>,
}

/// What `\s` is in what looks like a terminal's reply: none of these reach the program.
fn reply_shaped(seq: &[u8]) -> bool {
    let csi = seq.strip_prefix(b"\x1b[");
    let body_is = |body: &[u8], f: fn(u8) -> bool| body.iter().all(|&b| f(b));
    let digits_semi = |b: u8| b.is_ascii_digit() || b == b';';
    if let Some(rest) = csi {
        let (Some(&last), Some(body)) = (rest.last(), rest.get(..rest.len().saturating_sub(1))) else { return false };
        return match (rest.first(), last) {
            (Some(b'?' | b'>'), b'c') => body_is(&body[1..], digits_semi),
            (Some(b'?'), b'y') => body.ends_with(b"$") && body_is(&body[1..body.len() - 1], digits_semi),
            (Some(b'?'), b'n') => {
                body.starts_with(b"?997;") && body.len() > 5 && body_is(&body[5..], |b| b.is_ascii_digit())
            }
            (Some(b'?'), b'u') => body.len() > 1 && body_is(&body[1..], |b| b.is_ascii_digit()), // kitty keyboard flags
            (_, b'R') => {
                let b = body.strip_prefix(b"?").unwrap_or(body);
                let mut parts = b.split(|&c| c == b';');
                let ok = |p: Option<&[u8]>| p.is_some_and(|p| !p.is_empty() && p.iter().all(u8::is_ascii_digit));
                ok(parts.next()) && ok(parts.next()) && parts.next().is_none()
            }
            (_, b'n') => body == b"0",
            _ => false,
        };
    }
    if let Some(rest) = seq.strip_prefix(b"\x1bP") {
        return rest.ends_with(b"\x1b\\");
    }
    if let Some(rest) = seq.strip_prefix(b"\x1b]") {
        let number_ok = [&b"4;"[..], b"10;", b"11;", b"12;"].iter().any(|p| rest.starts_with(p));
        return number_ok && (rest.ends_with(b"\x07") || rest.ends_with(b"\x1b\\"));
    }
    false
}

fn is_focus(seq: &[u8]) -> bool {
    seq == b"\x1b[I" || seq == b"\x1b[O"
}

impl Router {
    /// A router for these settings.
    pub fn new(config: InputConfig) -> Self {
        Self {
            config,
            clients: HashMap::new(),
            paste_owner: None,
            held: Vec::new(),
            held_due: None,
            drop_until: None,
            last_typist: None,
            last_esc_client: None,
            events: Vec::new(),
        }
    }

    /// A client that may type: an attached terminal, or a control connection that sent INPUT.
    pub fn add_client(&mut self, id: &str, allow_gated: bool) {
        let tok = InputTokenizer::new(self.config.esc_flush_ms, self.config.paste_idle_close_ms);
        self.clients.insert(
            id.to_owned(),
            ClientInput { tok, keys: KeyState::default(), swallow_until: None, allow_gated, scheme: None },
        );
    }

    /// A client left. One in the middle of a paste has it closed.
    pub fn remove_client(&mut self, id: &str, now: Time, cx: &mut Ctx<'_>) {
        let Some(mut st) = self.clients.remove(id) else { return };
        let mut closing = Vec::new();
        st.tok.close(|t| closing.push((t.kind, t.bytes.to_vec())));
        self.clients.insert(id.to_owned(), st);
        for (kind, bytes) in closing {
            self.route(id, kind, &bytes, now, cx);
        }
        self.clients.remove(id);
        if self.paste_owner.as_deref() == Some(id) {
            self.end_paste(now, cx);
        }
        self.held.retain(|h| h.client != id);
    }

    /// Bytes a client typed.
    pub fn on_input(&mut self, id: &str, bytes: &[u8], now: Time, cx: &mut Ctx<'_>) {
        let Some(st) = self.clients.get_mut(id) else { return };
        let mut toks = Vec::new();
        st.tok.feed(bytes, now.ms(), |t| toks.push((t.kind, t.bytes.to_vec())));
        for (kind, bytes) in toks {
            self.route(id, kind, &bytes, now, cx);
        }
    }

    /// What a client typed is whole, as a control request's text is: a lone ESC it ends with is typed now, not after the
    /// wait for more that a terminal's needs, which a client that leaves at once would never see the end of.
    pub fn flush(&mut self, id: &str, now: Time, cx: &mut Ctx<'_>) {
        let Some(st) = self.clients.get_mut(id) else { return };
        let mut toks = Vec::new();
        st.tok.flush(|t| toks.push((t.kind, t.bytes.to_vec())));
        for (kind, bytes) in toks {
            self.route(id, kind, &bytes, now, cx);
        }
    }

    /// When [`Router::on_time`] has something to do.
    pub fn deadline(&self) -> Option<Time> {
        self.clients.values().filter_map(|c| c.tok.deadline().map(Time::from_ms)).chain(self.held_due).min()
    }

    /// What is due at `now`: a lone ESC let go, an idle paste closed, keys held behind a paste let go.
    pub fn on_time(&mut self, now: Time, cx: &mut Ctx<'_>) {
        let due: Vec<String> = self
            .clients
            .iter()
            .filter(|(_, c)| c.tok.deadline().is_some_and(|d| d <= now.ms()))
            .map(|(k, _)| k.clone())
            .collect();
        for id in due {
            let mut toks = Vec::new();
            if let Some(st) = self.clients.get_mut(&id) {
                st.tok.on_timer(now.ms(), |t| toks.push((t.kind, t.bytes.to_vec())));
            }
            for (kind, bytes) in toks {
                self.route(&id, kind, &bytes, now, cx);
            }
        }
        if self.held_due.is_some_and(|d| d <= now) {
            self.held_due = None;
            self.end_paste(now, cx);
        }
    }

    /// The holder dropped what was queued for the program, which is not reading: input closes for a second, and everyone
    /// is told.
    pub fn on_write_overflow(&mut self, now: Time) {
        self.drop_until = Some(now.after(OVERFLOW_GATE_MS));
        self.events.push(Event::Notice(None, "warn", "INPUT_DROPPED"));
    }

    /// The holder let go of what it held behind an ESC the program did not read: whoever typed the ESC is told.
    pub fn on_esc_hold_expired(&mut self) {
        self.events.push(Event::Notice(self.last_esc_client.clone(), "warn", "ESC_HOLD_EXPIRED"));
    }

    fn route(&mut self, id: &str, kind: InputKind, bytes: &[u8], now: Time, cx: &mut Ctx<'_>) {
        if self.paste_owner.as_deref().is_some_and(|owner| owner != id) {
            self.held.push(Held { client: id.to_owned(), kind, bytes: bytes.to_vec() });
            self.held_due.get_or_insert(now.after(PASTE_HOLD_MS));
            return;
        }
        self.handle(id, kind, bytes, now, cx);
    }

    fn end_paste(&mut self, now: Time, cx: &mut Ctx<'_>) {
        self.paste_owner = None;
        self.held_due = None;
        for h in std::mem::take(&mut self.held) {
            self.route(&h.client, h.kind, &h.bytes, now, cx);
        }
    }

    /// The strongest effect of the gates that apply.
    fn gate(&self, allow_gated: bool, now: Time, cx: &Ctx<'_>) -> GateEffect {
        if self.drop_until.is_some_and(|until| now < until) {
            return GateEffect::Drop;
        }
        let effects: Vec<GateEffect> = cx.gates.iter().map(|g| cx.policy.gate_effect(g, allow_gated)).collect();
        if effects.contains(&GateEffect::Drop) {
            GateEffect::Drop
        } else if effects.contains(&GateEffect::Filter) {
            GateEffect::Filter
        } else {
            GateEffect::Open
        }
    }

    fn handle(&mut self, id: &str, kind: InputKind, bytes: &[u8], now: Time, cx: &mut Ctx<'_>) {
        let allow_gated = self.clients.get(id).is_some_and(|c| c.allow_gated);
        if matches!(kind, InputKind::PasteStart | InputKind::PasteData | InputKind::PasteEnd) {
            if kind == InputKind::PasteStart {
                self.paste_owner = Some(id.to_owned());
            }
            let gate = self.gate(allow_gated, now, cx);
            let bytes: Vec<u8> = if gate == GateEffect::Filter {
                bytes.iter().copied().filter(|b| !CC_BYTES.contains(b)).collect()
            } else {
                bytes.to_vec()
            };
            if gate != GateEffect::Drop && !bytes.is_empty() {
                cx.writer.write(&bytes, false, false);
                cx.policy.on_paste();
                self.last_typist = Some(id.to_owned());
            }
            if kind == InputKind::PasteEnd {
                self.end_paste(now, cx);
            }
            return;
        }
        if let Some((n, said)) = color_report(bytes) {
            // never the program's input: what it is told when it asks is the holder's to answer
            let said = Some(String::from_utf8_lossy(said).into_owned());
            let colors = if n == 10 { Colors { fg: said, bg: None } } else { Colors { fg: None, bg: said } };
            self.events.push(Event::Colors(id.to_owned(), colors));
            return;
        }
        if let Some(scheme) = scheme_report(bytes)
            && let Some(st) = self.clients.get_mut(id)
            && st.scheme.replace(scheme).is_some_and(|was| was != scheme)
        {
            self.events.push(Event::SchemeChanged(id.to_owned()));
        }
        let tok = InputToken { kind, bytes };
        let seq = tok.seq();
        let events = match self.clients.get_mut(id) {
            Some(st) => decode_input_token(&seq, &mut st.keys),
            None => decode_input_token(&seq, &mut KeyState::default()),
        };
        let classes: Vec<KeyClass> = events.iter().map(classify).collect();
        if classes.iter().any(|c| cx.policy.detach_keys().contains(c)) {
            // 1. detach
            if let Some(st) = self.clients.get_mut(id) {
                st.swallow_until = Some(now.after(SWALLOW_MS));
            }
            self.events.push(Event::Detach(id.to_owned()));
            return;
        }
        let swallowing = self.clients.get(id).and_then(|c| c.swallow_until).is_some_and(|until| now < until);
        if swallowing && events.iter().all(|e| e.name.as_deref().is_none_or(str::is_empty)) {
            return; // its release and repeat events
        }
        if events.is_empty() || classes.contains(&KeyClass::Ignored) {
            return; // 2. nothing for the program, or a signal byte that decodes to nothing
        }
        let heard = scheme_report(bytes).is_some_and(|scheme| cx.scheme.hear(scheme, cx.scheme_wanted));
        if (reply_shaped(bytes) && !heard) || (is_focus(bytes) && !cx.focus_wanted) {
            return; // 3, 4
        }
        let gate = self.gate(allow_gated, now, cx); // 8. gates, before C and D: the guard's writes are gated too
        if gate == GateEffect::Drop {
            return;
        }
        if let Some(&cd) = classes.iter().find(|c| matches!(c, KeyClass::C | KeyClass::D))
            && cx.policy.guards_key(cd)
        {
            // 5. one offer per token
            if gate != GateEffect::Filter && !cx.policy.offer_signal_key(cd, now, cx.writer) {
                self.events.push(Event::Held(id.to_owned(), cd));
            }
            return;
        }
        if gate == GateEffect::Filter && bytes.len() == 1 && CC_BYTES.contains(&bytes[0]) {
            return;
        }
        let lone_esc = kind == InputKind::LoneEsc; // 9. forward
        cx.writer.write(bytes, lone_esc, false);
        if lone_esc {
            self.last_esc_client = Some(id.to_owned());
        }
        self.last_typist = Some(id.to_owned());
        let total = cx.writer.total();
        cx.policy.on_forwarded(id, &tok, total);
    }
}
