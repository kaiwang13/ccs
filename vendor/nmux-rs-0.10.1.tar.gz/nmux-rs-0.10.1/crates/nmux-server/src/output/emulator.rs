//! The session's emulator, `emulator.js`: what joins, captures, cursor reports and the kept history are made from.
//!
//! It is one of two shapes. Tracking: the pty's size, resized at the offset the pty was, so that what wrapped or scrolled
//! in a terminal wrapped and scrolled here too. Fixed: 240 by 150, aligned once so that the pty's screen is its bottom rows,
//! never resized, and fed the same row rewrite as a client 150 rows tall, for a program that repaints its whole screen,
//! which survives no reflow.
//!
//! Rows are numbered for good: a row's number is the rows that have ever left the buffer plus its index, so it stays true as
//! history is trimmed, and a [`Pin`] keeps one true through a reflow too. Each row also keeps when it was last printed on.
//! Rows that leave the screen go to a [`Keeper`], the kept history, a whole line at a time.

use std::collections::{HashMap, VecDeque};

use nmux_term::{BufferView, LineId, Terminal, cells};
use nmux_vt::marks::Mark;
use nmux_vt::seq::QueryKind;

use super::pipeline::{Chunk, EditKind, rewrite_row};

/// xterm refuses anything narrower.
const MIN_COLS: usize = 2;
/// A right prompt is this far from what the prompt ends with, and from the edge, or less far from the edge.
const RIGHT_PROMPT_GAP: usize = 2;
/// What goes to the terminal in one write, as xterm is given it in Node.
const WRITE_SLICE: usize = 65536;
/// Cursor positions kept for queries not answered yet.
const CPR_KEPT: usize = 64;
/// A fixed emulator's size.
pub const FIXED_COLS: usize = 240;
/// See [`FIXED_COLS`].
pub const FIXED_ROWS: usize = 150;

/// Where a cut at `end` has to go so as not to split a UTF-8 character: xterm loses some characters whose bytes come in
/// two writes.
fn char_start(bytes: &[u8], end: usize) -> usize {
    let continuation = |i: usize| bytes.get(i).is_some_and(|b| b & 0xc0 == 0x80);
    let mut e = end;
    while e + 3 > end && e > 0 && e < bytes.len() && continuation(e) {
        e -= 1;
    }
    if continuation(e) { end } else { e } // not a character at all: cut where asked
}

/// How much of `bytes` from `from` can go in without more than `rows` new rows: an overestimate, cheap to work out. A row
/// needs a line feed of some kind, an escape sequence, or a line's worth of text.
fn bytes_for_rows(bytes: &[u8], from: usize, rows: usize, cols: usize) -> usize {
    let end = bytes.len().min(from + WRITE_SLICE);
    let mut breaks = 0usize;
    for (i, &b) in bytes.iter().enumerate().take(end).skip(from) {
        if matches!(b, 0x0a | 0x0b | 0x0c | 0x1b | 0x84 | 0x85) {
            breaks += 1;
        }
        if breaks * cols + (i - from) >= rows * cols {
            return (i - from).max(1);
        }
    }
    end - from
}

/// UTF-16 units, which is what a length means in the Node code.
fn utf16_len(s: &str) -> usize {
    s.chars().map(char::len_utf16).sum()
}

/// What `\s` matches in a JavaScript pattern.
fn js_space(c: char) -> bool {
    matches!(c, '\t' | '\n' | '\u{b}' | '\u{c}' | '\r' | ' ' | '\u{a0}' | '\u{1680}' | '\u{2000}'..='\u{200a}')
        || matches!(c, '\u{2028}' | '\u{2029}' | '\u{202f}' | '\u{205f}' | '\u{3000}' | '\u{feff}')
}

/// A row and column of the normal screen, the row by number.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct At {
    /// The row's number.
    pub row: u64,
    /// The column, 0-based.
    pub col: usize,
}

/// A row something relies on, kept on its row through a reflow. See [`Emulator::pin`].
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Pin(usize);

impl Pin {
    /// A pin numbered by something other than the emulator, such as a screen a test stands in for it with.
    pub fn numbered(n: usize) -> Self {
        Self(n)
    }
}

/// What the shell's marks are read against: the rows and the cursor of the normal screen, and pins that keep rows. The
/// emulator is one; a test can stand in for it.
pub trait Screen {
    /// See [`Emulator::pin`].
    fn pin(&mut self, row: u64) -> Pin;
    /// See [`Emulator::unpin`].
    fn unpin(&mut self, pin: Pin);
    /// See [`Emulator::pin_row`].
    fn pin_row(&self, pin: Pin) -> Option<u64>;
    /// See [`Emulator::set_pin`].
    fn set_pin(&mut self, pin: Pin, row: Option<u64>);
    /// See [`Emulator::cursor_row`].
    fn cursor_row(&self) -> u64;
    /// See [`Emulator::line_before_cursor`].
    fn line_before_cursor(&self) -> String;
    /// See [`Emulator::right_of_cursor`].
    fn right_of_cursor(&self) -> String;
    /// See [`Emulator::text_at_cursor`].
    fn text_at_cursor(&self, drawn: Option<&str>) -> bool;
    /// See [`Emulator::on_alternate`].
    fn on_alternate(&self) -> bool;
    /// See [`Emulator::trimmed`].
    fn trimmed(&self) -> u64;
    /// See [`Emulator::screen_top`].
    fn screen_top(&self, screen_rows: usize) -> u64;
    /// See [`Emulator::line_up_to`].
    fn line_up_to(&self, at: At) -> u64;
    /// See [`Emulator::line_end`].
    fn line_end(&self, row: u64) -> u64;
    /// See [`Emulator::text`].
    fn text(&self, from: u64, to: u64, ansi: bool, last_chars: Option<u64>) -> (Vec<String>, bool);
}

impl Screen for Emulator {
    fn pin(&mut self, row: u64) -> Pin {
        Emulator::pin(self, row)
    }
    fn unpin(&mut self, pin: Pin) {
        Emulator::unpin(self, pin);
    }
    fn pin_row(&self, pin: Pin) -> Option<u64> {
        Emulator::pin_row(self, pin)
    }
    fn set_pin(&mut self, pin: Pin, row: Option<u64>) {
        Emulator::set_pin(self, pin, row);
    }
    fn cursor_row(&self) -> u64 {
        Emulator::cursor_row(self)
    }
    fn line_before_cursor(&self) -> String {
        Emulator::line_before_cursor(self)
    }
    fn right_of_cursor(&self) -> String {
        Emulator::right_of_cursor(self)
    }
    fn text_at_cursor(&self, drawn: Option<&str>) -> bool {
        Emulator::text_at_cursor(self, drawn)
    }
    fn on_alternate(&self) -> bool {
        Emulator::on_alternate(self)
    }
    fn trimmed(&self) -> u64 {
        Emulator::trimmed(self)
    }
    fn screen_top(&self, screen_rows: usize) -> u64 {
        Emulator::screen_top(self, screen_rows)
    }
    fn line_up_to(&self, at: At) -> u64 {
        Emulator::line_up_to(self, at)
    }
    fn line_end(&self, row: u64) -> u64 {
        Emulator::line_end(self, row)
    }
    fn text(&self, from: u64, to: u64, ansi: bool, last_chars: Option<u64>) -> (Vec<String>, bool) {
        Emulator::text(self, from, to, ansi, last_chars)
    }
}

/// The kept history, as the emulator gives it rows: what `spool.js` is to `emulator.js`.
pub trait Keeper {
    /// Rows that left the screen, with whether each carries on the one before it, how far into the program's output they
    /// go, and when each was printed (0: not known). Returns the history's number for the first.
    fn append(&mut self, rows: Vec<String>, wrapped: Vec<bool>, offset: u64, times: Vec<i64>) -> u64;
    /// An earlier server wrote what goes as far as this.
    fn already_has(&self, offset: u64) -> bool;
    /// How far into this program's output an earlier server wrote, if it did.
    fn through(&self) -> Option<u64>;
    /// The number the next row gets.
    fn lines(&self) -> u64;
    /// Nothing more is written.
    fn failed(&self) -> bool;
}

/// What needs to hear, at the moment it happens, of what the emulator finds in the output.
pub trait Observer {
    /// A mark of the session's shell, with the cursor where it fell and the offset just past it.
    fn on_mark(&mut self, emulator: &mut Emulator, mark: &Mark, at: At, offset: u64) {
        let _ = (emulator, mark, at, offset);
    }
    /// The screen was wiped, and this is its first row.
    fn on_erased(&mut self, emulator: &mut Emulator, top: u64) {
        let _ = (emulator, top);
    }
    /// Rows `from..to` went to the history, which numbers the first `line`.
    fn on_spooled(&mut self, emulator: &Emulator, from: u64, to: u64, line: u64) {
        let _ = (emulator, from, to, line);
    }
}

/// Nothing is listening.
impl Observer for () {}

/// A line not in the history yet, for `UNWRITTEN`.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct UnwrittenLine {
    /// The rows it takes.
    pub rows: u64,
    /// When it was last printed on, in ms since the epoch, 0 if not known.
    pub at: i64,
    /// The line.
    pub text: String,
}

/// What has not gone to the history, numbered as the history will number it.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Unwritten {
    /// The lines.
    pub lines: Vec<UnwrittenLine>,
    /// The history's number for the first row of the first.
    pub first: u64,
}

/// A cursor position recorded where a CPR query fell.
#[derive(Clone, Copy, Debug)]
struct CprAt {
    x: usize,
    y: usize,
    alt: bool,
}

/// A place for a pin.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Slot {
    Free,
    /// On this row, or on none any more.
    Pinned(Option<u64>),
}

/// Bytes on their way into the terminal, and where in the output they came from.
#[derive(Debug, Default)]
struct Pending {
    bytes: Vec<u8>,
    pieces: usize,
    at: u64,
    next: u64,
}

impl Pending {
    fn add(&mut self, bytes: &[u8], offset: u64) {
        if self.pieces == 0 {
            self.at = offset;
        }
        self.pieces += 1;
        self.bytes.extend_from_slice(bytes);
        self.next = offset + bytes.len() as u64;
    }
}

/// See the module.
#[derive(Debug)]
pub struct Emulator {
    term: Terminal,
    tracking: bool,
    scrollback: usize,
    /// DECSC slots per buffer as xterm stores them: the column, and the line from the top of the buffer then.
    saved_normal: Option<(usize, usize)>,
    saved_alternate: Option<(usize, usize)>,
    /// How far into the output the terminal has parsed.
    processed_offset: u64,
    cpr_at: VecDeque<(u64, CprAt)>,
    pins: Vec<Slot>,
    free_pins: Vec<usize>,
    /// When each row was last printed on, in ms since the epoch, 0 if never, by row number from `times_from`: the time of
    /// the last write that printed text on it or whose line feeds left or reached it.
    times: VecDeque<i64>,
    times_from: u64,
    /// The first row not in the history yet, once there is a history.
    unspooled: Option<Pin>,
    /// A row has gone to the history, or would have but for an earlier server having written it.
    begun: bool,
}

impl Emulator {
    /// A tracking emulator the pty's size, or with `None` a fixed one; `scrollback` lines of history.
    pub fn new(tracking: Option<(usize, usize)>, scrollback: usize) -> Self {
        let (cols, rows) = tracking.unwrap_or((FIXED_COLS, FIXED_ROWS));
        let mut term = Terminal::new(cols, rows, scrollback);
        term.note_printed();
        Self {
            term,
            tracking: tracking.is_some(),
            scrollback,
            saved_normal: None,
            saved_alternate: None,
            processed_offset: 0,
            cpr_at: VecDeque::new(),
            pins: Vec::new(),
            free_pins: Vec::new(),
            times: VecDeque::new(),
            times_from: 0,
            unspooled: None,
            begun: false,
        }
    }

    /// The terminal, to read.
    pub fn term(&self) -> &Terminal {
        &self.term
    }

    /// Whether this is the pty's size.
    pub fn tracking(&self) -> bool {
        self.tracking
    }

    /// Its columns.
    pub fn cols(&self) -> usize {
        self.term.cols()
    }

    /// Its rows.
    pub fn rows(&self) -> usize {
        self.term.rows()
    }

    /// How far into the output it has parsed.
    pub fn processed_offset(&self) -> u64 {
        self.processed_offset
    }

    /// Rows that have left the normal buffer, ever.
    pub fn trimmed(&self) -> u64 {
        self.term.trimmed()
    }

    /// Where DECSC or 1049 last saved the normal screen's cursor: its column and line from the top of the buffer then.
    pub fn saved_normal(&self) -> Option<(usize, usize)> {
        self.saved_normal
    }

    /// The same for the alternate screen.
    pub fn saved_alternate(&self) -> Option<(usize, usize)> {
        self.saved_alternate
    }

    /// Every row that leaves the screen goes to a keeper from now on.
    pub fn keep_rows(&mut self) {
        let pin = self.pin(0);
        self.unspooled = Some(pin);
    }

    /// The first row not in the history yet, if there is a history.
    pub fn unspooled_row(&self) -> Option<u64> {
        self.unspooled.and_then(|p| self.pin_row(p))
    }

    // ---- pins -----------------------------------------------------------------------------------------------------

    /// Keeps a row's number true for as long as it is needed. A row a reflow trimmed away has none any more.
    pub fn pin(&mut self, row: u64) -> Pin {
        if let Some(i) = self.free_pins.pop() {
            self.pins[i] = Slot::Pinned(Some(row));
            return Pin(i);
        }
        self.pins.push(Slot::Pinned(Some(row)));
        Pin(self.pins.len() - 1)
    }

    /// Lets go of a pin.
    pub fn unpin(&mut self, pin: Pin) {
        if let Some(slot @ Slot::Pinned(_)) = self.pins.get_mut(pin.0) {
            *slot = Slot::Free;
            self.free_pins.push(pin.0);
        }
    }

    /// The row a pin is on, or `None` once nothing can place it.
    pub fn pin_row(&self, pin: Pin) -> Option<u64> {
        match self.pins.get(pin.0) {
            Some(Slot::Pinned(row)) => *row,
            _ => None,
        }
    }

    /// Moves a pin.
    pub fn set_pin(&mut self, pin: Pin, row: Option<u64>) {
        if let Some(Slot::Pinned(slot)) = self.pins.get_mut(pin.0) {
            *slot = row;
        }
    }

    // ---- times ----------------------------------------------------------------------------------------------------

    /// Keeps the times in step with the history, which drops its oldest rows.
    fn sync_times(&mut self) {
        let trimmed = self.trimmed();
        let gone = trimmed.saturating_sub(self.times_from);
        if gone == 0 {
            return;
        }
        let n = usize::try_from(gone).unwrap_or(usize::MAX).min(self.times.len());
        self.times.drain(..n);
        self.times_from = trimmed;
    }

    /// When a row was last printed on, or 0 if that is not known.
    pub fn time_of(&mut self, row: u64) -> i64 {
        self.sync_times();
        row.checked_sub(self.times_from)
            .and_then(|i| usize::try_from(i).ok())
            .and_then(|i| self.times.get(i).copied())
            .unwrap_or(0)
    }

    /// Rows `from..=to` were printed on at `at`.
    fn stamp(&mut self, from: u64, to: u64, at: i64) {
        self.sync_times();
        let Some(last) = to.checked_sub(self.times_from).and_then(|i| usize::try_from(i).ok()) else { return };
        if self.times.len() <= last {
            self.times.resize(last + 1, 0);
        }
        let first = usize::try_from(from.saturating_sub(self.times_from)).unwrap_or(usize::MAX);
        for i in first..=last {
            self.times[i] = at;
        }
    }

    /// When the rows from `from` were printed, every row of a line at the latest of them, since a line is read back whole.
    fn times_of(&mut self, from: u64, wrapped: &[bool]) -> Vec<i64> {
        let mut times: Vec<i64> = (0..wrapped.len() as u64).map(|i| self.time_of(from + i)).collect();
        for i in (1..times.len()).rev() {
            if wrapped[i] {
                times[i - 1] = times[i - 1].max(times[i]);
            }
        }
        for i in 1..times.len() {
            if wrapped[i] {
                times[i] = times[i - 1];
            }
        }
        times
    }

    /// After a write: the rows it printed on, which the terminal saw as it went, were printed on at `at`. Nothing is
    /// printed on the normal screen while a program has the other.
    fn printed(&mut self, at: i64) {
        for (from, to) in self.term.take_printed() {
            self.stamp(from, to, at);
        }
    }

    // ---- feeding --------------------------------------------------------------------------------------------------

    /// Starts the buffer. Fixed: aligns the pty's screen with the bottom `pty_rows`. Tracking: takes the pty's size and
    /// gives the buffer blank history, as any real terminal has, which decides where text lands when a resize reflows it.
    pub fn init(&mut self, pty_rows: usize, pty_cols: Option<usize>) {
        if !self.tracking {
            let lines = "\r\n".repeat(self.rows().saturating_sub(pty_rows));
            self.write_plain(lines.as_bytes());
            self.term.take_printed(); // nobody printed these
            return;
        }
        self.resize(pty_cols.unwrap_or(self.cols()), pty_rows);
        let lines = format!("{}\x1b[H", "\r\n".repeat(pty_rows));
        self.write_plain(lines.as_bytes());
        self.term.take_printed();
        if let Some(pin) = self.unspooled {
            let row = self.trimmed() + self.term.normal().base_y() as u64; // the blank history is nobody's output
            self.set_pin(pin, Some(row));
        }
    }

    /// Takes this size, with everything fed so far parsed at the old one.
    pub fn resize_to(&mut self, cols: usize, rows: usize) {
        if cols != self.cols() || rows != self.rows() {
            self.resize(cols, rows);
        }
    }

    /// Keeps pins and times on their rows through a resize. A reflow renumbers rows but keeps the identity of lines, so a
    /// row goes with its line, and one the reflow merged away goes by how far into its line it was. A pin nothing can place
    /// any more, because the reflow trimmed its line, is lost.
    fn resize(&mut self, cols: usize, rows: usize) {
        self.sync_times();
        let before = self.cols();
        let trimmed = self.trimmed();
        let normal = self.term.normal();
        let len = normal.len();
        let wrapped = |y: usize| normal.is_wrapped(y) == Some(true);
        let mut timed: HashMap<LineId, i64> = HashMap::new();
        let mut head = 0;
        while head < len.min(self.times.len()) {
            let mut end = head + 1;
            while end < len && wrapped(end) {
                end += 1;
            }
            let at = (head..end).map(|y| self.times.get(y).copied().unwrap_or(0)).max().unwrap_or(0);
            if at != 0 {
                timed.extend((head..end).filter_map(|y| normal.line_id(y)).map(|id| (id, at)));
            }
            head = end;
        }
        let pinned: Vec<(usize, Option<LineId>, Option<LineId>, usize)> = self
            .pins
            .iter()
            .enumerate()
            .filter_map(|(i, slot)| {
                let Slot::Pinned(row) = *slot else { return None };
                let row = row?;
                let y = usize::try_from(row.checked_sub(trimmed)?).ok()?;
                let mut head = y.min(len.saturating_sub(1));
                while head > 0 && wrapped(head) {
                    head -= 1;
                }
                Some((i, normal.line_id(y), normal.line_id(head), y.saturating_sub(head)))
            })
            .collect();
        self.term.resize(cols.max(MIN_COLS), rows);
        let trimmed = self.trimmed();
        let normal = self.term.normal();
        self.times_from = trimmed;
        self.times.clear();
        if !timed.is_empty() {
            for y in 0..normal.len() {
                let own = normal.line_id(y).and_then(|id| timed.get(&id).copied());
                let carried = if normal.is_wrapped(y) == Some(true) && y > 0 { self.times[y - 1] } else { 0 };
                self.times.push_back(own.unwrap_or(carried)); // a row a reflow made is its line's
            }
        }
        if pinned.is_empty() {
            return;
        }
        let at: HashMap<LineId, usize> =
            (0..normal.len()).filter_map(|y| normal.line_id(y).map(|id| (id, y))).collect();
        let cols = self.cols();
        for (i, own, head, into) in pinned {
            let row = own.and_then(|id| at.get(&id).copied());
            let start = head.and_then(|id| at.get(&id).copied());
            let placed = match (row, start) {
                (Some(row), start) if start.is_none_or(|s| row.checked_sub(s) == Some(into)) => {
                    Some(trimmed + row as u64)
                }
                (_, None) => None,
                (_, Some(start)) => Some(trimmed + (start + into * before / cols) as u64),
            };
            self.pins[i] = Slot::Pinned(placed);
        }
    }

    /// A chunk of the program's output, `now` being when it arrived in ms since the epoch. A history, if there is one, is
    /// given what leaves the screen; `observer` hears of marks, wipes and rows written to the history where they happen.
    pub fn feed(&mut self, chunk: &Chunk, now: i64, mut keeper: Option<&mut dyn Keeper>, observer: &mut dyn Observer) {
        let spooling = keeper.is_some() && self.unspooled.is_some();
        let mut p = Pending::default();
        // A history has to know where in the output each byte came from, so only stretches that adjoin go in together.
        let breaks = |p: &Pending, offset: u64| spooling && p.pieces > 0 && offset != p.next;
        let base = chunk.start_offset;
        let mut pos = 0;
        for e in &chunk.edits {
            let here = base + pos as u64;
            if breaks(&p, here) {
                self.flush(&mut p, now, keeper.as_deref_mut(), observer);
            }
            p.add(&chunk.bytes[pos..e.start], here);
            pos = e.end;
            let start = base + e.start as u64;
            let raw = chunk.raw(e);
            match &e.kind {
                EditKind::Resize { cols, rows } => {
                    self.flush(&mut p, now, keeper.as_deref_mut(), observer);
                    self.resize(*cols as usize, *rows as usize);
                    continue;
                }
                EditKind::Drop(query) => {
                    if matches!(query, QueryKind::Cpr | QueryKind::Decxcpr) {
                        // the cursor exactly where the query was
                        self.flush(&mut p, now, keeper.as_deref_mut(), observer);
                        let b = self.term.active();
                        let at = CprAt { x: b.cursor_x(), y: b.cursor_y(), alt: b.is_alternate() };
                        self.cpr_at.push_back((base + e.end as u64, at));
                        if self.cpr_at.len() > CPR_KEPT {
                            self.cpr_at.pop_front();
                        }
                    }
                    continue;
                }
                EditKind::Erase => {
                    p.add(raw, start);
                    self.flush(&mut p, now, keeper.as_deref_mut(), observer);
                    self.erased(observer);
                    continue;
                }
                EditKind::Mark { mark, standard } => {
                    // where it fell is the whole point; the terminal is given what a terminal is sent, for the next
                    // character to keep
                    self.flush(&mut p, now, keeper.as_deref_mut(), observer);
                    let at = self.cursor();
                    observer.on_mark(self, mark, at, base + e.end as u64);
                    self.term.write(standard);
                    continue;
                }
                EditKind::Row { form, row, col, render_rows } => {
                    let d = self.rows().saturating_sub(*render_rows as usize);
                    if breaks(&p, start) {
                        self.flush(&mut p, now, keeper.as_deref_mut(), observer);
                    }
                    if d > 0 {
                        p.add(&rewrite_row(*form, *col, row + u32::try_from(d).unwrap_or(0)), start);
                    } else {
                        p.add(raw, start);
                    }
                    continue;
                }
                EditKind::Decsc | EditKind::AltEnter { saves_cursor: true } => {
                    // DECSC and 1049 save the cursor of the screen shown before them: parse up to them, then record it
                    self.flush(&mut p, now, keeper.as_deref_mut(), observer);
                    let b = self.term.active();
                    let saved = Some((b.cursor_x(), b.base_y() + b.cursor_y()));
                    if b.is_alternate() {
                        self.saved_alternate = saved;
                    } else {
                        self.saved_normal = saved;
                    }
                }
                _ => {}
            }
            if breaks(&p, start) {
                self.flush(&mut p, now, keeper.as_deref_mut(), observer);
            }
            p.add(raw, start);
        }
        let here = base + pos as u64;
        if breaks(&p, here) {
            self.flush(&mut p, now, keeper.as_deref_mut(), observer);
        }
        p.add(&chunk.bytes[pos..], here);
        self.flush(&mut p, now, keeper, observer);
        self.processed_offset = chunk.end_offset;
    }

    fn flush(
        &mut self,
        p: &mut Pending,
        now: i64,
        keeper: Option<&mut (dyn Keeper + '_)>,
        observer: &mut dyn Observer,
    ) {
        let bytes = std::mem::take(&mut p.bytes);
        p.pieces = 0;
        if bytes.is_empty() {
            return;
        }
        match keeper {
            Some(keeper) if self.unspooled.is_some() => self.write_spooled(&bytes, p.at, now, keeper, observer),
            _ => {
                self.write_plain(&bytes);
                self.printed(now);
            }
        }
    }

    /// Into the terminal in the slices Node gives xterm, never splitting a character.
    fn write_plain(&mut self, bytes: &[u8]) {
        let mut at = 0;
        while at + WRITE_SLICE < bytes.len() {
            let end = char_start(bytes, at + WRITE_SLICE).max(at + 1);
            self.term.write(&bytes[at..end]);
            at = end;
        }
        self.term.write(&bytes[at..]);
    }

    /// In pieces too small to scroll a row past both the screen and the history, so that none leaves unseen. A piece ends
    /// exactly where an earlier server stopped writing, so that each row is written once.
    fn write_spooled(&mut self, bytes: &[u8], at: u64, now: i64, keeper: &mut dyn Keeper, observer: &mut dyn Observer) {
        let rows = (self.scrollback / 2).max(1);
        let mut done = 0;
        while done < bytes.len() {
            let fits = bytes_for_rows(bytes, done, rows, self.cols());
            let to_edge = keeper.through().and_then(|t| t.checked_sub(at + done as u64)).filter(|&e| e > 0);
            let n = match to_edge.and_then(|e| usize::try_from(e).ok()).filter(|&e| e <= fits) {
                Some(edge) => edge, // where an earlier server stopped
                None => (char_start(bytes, done + fits) - done).max(1),
            };
            self.term.write(&bytes[done..done + n]);
            self.printed(now);
            done += n;
            self.spool_rows(at + done as u64, keeper, observer);
        }
    }

    /// Rows that have left the screen go to the history before the buffer can trim them, a whole line at a time: rows are
    /// only rows until the next reflow, and a line half in the history could not be told from one not in it. Only a line
    /// too long to wait for is divided.
    fn spool_rows(&mut self, offset: u64, keeper: &mut dyn Keeper, observer: &mut dyn Observer) {
        let Some(unspooled) = self.unspooled else { return };
        let trimmed = self.trimmed();
        let normal = self.term.normal();
        let mut end = normal.base_y();
        let stop = end.saturating_sub(self.scrollback / 4);
        while end > stop && normal.is_wrapped(end) == Some(true) {
            end -= 1;
        }
        if end == stop && stop > 0 {
            end = normal.base_y();
        }
        let to = trimmed + end as u64;
        // its line has gone, so nothing still here has been written
        let row = self.pin_row(unspooled).unwrap_or(trimmed);
        let from = self.history_from(row.max(trimmed), to);
        if from < to && !keeper.already_has(offset) {
            self.append(from, to, offset, keeper, observer);
        }
        self.set_pin(unspooled, Some(row.max(to))); // a taller screen brings back rows already written
    }

    /// Rows `from..to` to the history.
    fn append(&mut self, from: u64, to: u64, offset: u64, keeper: &mut dyn Keeper, observer: &mut dyn Observer) {
        let trimmed = self.trimmed();
        let first = usize::try_from(from - trimmed).unwrap_or(usize::MAX);
        let end = usize::try_from(to - trimmed).unwrap_or(usize::MAX);
        let normal = self.term.normal();
        let texts = cells::serialize_rows(&normal, first, end, None, cells::Extras::LINKS);
        let wrapped: Vec<bool> = (first..first + texts.len()).map(|y| normal.is_wrapped(y) == Some(true)).collect();
        let times = self.times_of(from, &wrapped);
        let line = keeper.append(texts, wrapped, offset, times);
        observer.on_spooled(self, from, to, line);
    }

    /// Everything still here goes to the history: the program is over, and nothing will scroll it out now.
    pub fn spool_rest(&mut self, offset: u64, keeper: &mut dyn Keeper, observer: &mut dyn Observer) {
        let Some(unspooled) = self.unspooled else { return };
        let trimmed = self.trimmed();
        let end = self.written_end();
        let to = trimmed + end as u64;
        let row = self.pin_row(unspooled).unwrap_or(trimmed);
        let from = self.history_from(row.max(trimmed), to);
        if from >= to {
            return;
        }
        self.append(from, to, offset, keeper, observer);
        self.set_pin(unspooled, Some(to));
    }

    /// The end of the normal buffer without its blank rows at the bottom.
    fn written_end(&self) -> usize {
        let normal = self.term.normal();
        let mut end = normal.len();
        while end > 0 && normal.line_text(end - 1, true, 0, None).unwrap_or_default().is_empty() {
            end -= 1;
        }
        end
    }

    /// The first row from index `from` on that anything was printed on or that shows anything: those above it are only
    /// where the screen started, blank rows that were there before the program.
    fn written(&mut self, mut from: usize, end: usize) -> usize {
        let trimmed = self.trimmed();
        while from < end
            && self.time_of(trimmed + from as u64) == 0
            && self.term.normal().line_text(from, true, 0, None).unwrap_or_default().is_empty()
        {
            from += 1;
        }
        from
    }

    /// Where rows `from..to` going to the history start. Until any have, blank rows nothing printed on are only where the
    /// screen started, such as the rows above a fixed emulator's screen, and no part of the history.
    fn history_from(&mut self, from: u64, to: u64) -> u64 {
        if self.begun {
            return from;
        }
        let trimmed = self.trimmed();
        let index = |row: u64| usize::try_from(row - trimmed).unwrap_or(usize::MAX);
        let start = trimmed + self.written(index(from), index(to)) as u64;
        if start < to {
            self.begun = true;
        }
        start
    }

    /// The screen was wiped: whatever is on it from now on is new, even at rows already written.
    fn erased(&mut self, observer: &mut dyn Observer) {
        let top = self.screen_top(self.rows());
        if let Some(pin) = self.unspooled
            && self.pin_row(pin).is_some_and(|row| row > top)
        {
            self.set_pin(pin, Some(top));
        }
        observer.on_erased(self, top);
    }

    /// The first row still to go to the history carries on a line that started in it.
    pub fn unspooled_continues(&self) -> bool {
        self.unspooled_row().is_some_and(|row| self.term.normal().is_wrapped(self.index(row)) == Some(true))
    }

    /// What has not gone to the history yet, as whole lines, each with the rows it takes and when it was last printed on.
    /// The history numbers rows its own way, from the first it was given, so those after it are numbered on from there. A
    /// history that has failed did not write what it was given, so then it is all that is still here, numbered as the
    /// history numbered it.
    pub fn unwritten(&mut self, ansi: bool, keeper: Option<&dyn Keeper>) -> Unwritten {
        let end = self.written_end();
        let mut from = self.written(0, end);
        let mut first = 0;
        if let (Some(keeper), Some(row)) = (keeper, self.unspooled_row()) {
            let next = self.index(row).min(end);
            from = if keeper.failed() {
                from.min(next)
            } else if self.begun {
                next
            } else {
                self.written(next, end)
            };
            // rows before `next` again only once the history failed
            first = keeper.lines().saturating_sub(next.saturating_sub(from) as u64);
        }
        let texts = cells::logical_lines(&self.term.normal(), from, from.max(end), ansi);
        let trimmed = self.trimmed();
        let mut lines: Vec<UnwrittenLine> = Vec::new();
        for y in from..end {
            let at = self.time_of(trimmed + y as u64);
            let wrapped = self.term.normal().is_wrapped(y) == Some(true);
            match lines.last_mut() {
                Some(last) if wrapped => {
                    last.rows += 1;
                    last.at = last.at.max(at);
                }
                _ => {
                    lines.push(UnwrittenLine {
                        rows: 1,
                        at,
                        text: texts.get(lines.len()).cloned().unwrap_or_default(),
                    });
                }
            }
        }
        Unwritten { lines, first }
    }

    // ---- reading --------------------------------------------------------------------------------------------------

    /// The cursor on the normal screen, wherever a program has gone since.
    pub fn cursor(&self) -> At {
        let b = self.term.normal();
        At { row: self.trimmed() + (b.base_y() + b.cursor_y()) as u64, col: b.cursor_x() }
    }

    /// The row the cursor is on.
    pub fn cursor_row(&self) -> u64 {
        self.cursor().row
    }

    /// What is on the cursor's row from the cursor on.
    pub fn right_of_cursor(&self) -> String {
        let b = self.term.normal();
        b.line_text(b.base_y() + b.cursor_y(), false, b.cursor_x(), None).unwrap_or_default()
    }

    /// Whether what is typed at the cursor has anything after it. What was there when the prompt was drawn does not
    /// count, and neither does what stands apart against the right edge, which is how a right prompt drawn later looks.
    pub fn text_at_cursor(&self, drawn: Option<&str>) -> bool {
        let right = self.right_of_cursor();
        if Some(right.as_str()) == drawn {
            return false;
        }
        let Some(start) = right.chars().position(|c| !js_space(c)) else { return false };
        let start: usize = right.chars().take(start).map(char::len_utf16).sum();
        let x = self.term.normal().cursor_x();
        start < RIGHT_PROMPT_GAP || utf16_len(right.trim_end_matches(js_space)) + x + RIGHT_PROMPT_GAP < self.cols()
    }

    /// A program has the screen, so nothing about the shell's cursor can be told from it.
    pub fn on_alternate(&self) -> bool {
        self.term.alternate_active()
    }

    /// The whole lines of the normal buffer between two rows, or `None` if any of them have gone.
    pub fn lines_between(&self, from: u64, to: u64) -> Option<Vec<String>> {
        let trimmed = self.trimmed();
        let first = usize::try_from(from.checked_sub(trimmed)?).ok()?;
        let end = usize::try_from(to.max(from) - trimmed).unwrap_or(usize::MAX);
        Some(cells::logical_lines(&self.term.normal(), first, end, false))
    }

    /// The length of a line, in UTF-16 units, as far as a place on its last row.
    pub fn line_up_to(&self, at: At) -> u64 {
        let b = self.term.normal();
        let y = self.index(at.row);
        let mut head = y;
        while head > 0 && b.is_wrapped(head) == Some(true) {
            head -= 1;
        }
        let whole: usize = cells::logical_lines(&b, head, y + 1, false).iter().map(|l| utf16_len(l)).sum();
        let rest = utf16_len(&b.line_text(y, true, at.col, None).unwrap_or_default());
        whole.saturating_sub(rest) as u64
    }

    /// The row after the end of the line a row is on.
    pub fn line_end(&self, row: u64) -> u64 {
        let b = self.term.normal();
        let mut y = self.index(row) + 1;
        while y < b.len() && b.is_wrapped(y) == Some(true) {
            y += 1;
        }
        self.trimmed() + y as u64
    }

    /// Rows of the buffer above the pty's screen.
    fn above(&self, screen_rows: usize) -> usize {
        if self.tracking { 0 } else { self.rows().saturating_sub(screen_rows) }
    }

    /// The first row of the pty's screen.
    pub fn screen_top(&self, screen_rows: usize) -> u64 {
        self.trimmed() + (self.term.normal().base_y() + self.above(screen_rows)) as u64
    }

    /// Where a row is in the buffer now, or its start if it has gone.
    pub fn index(&self, row: u64) -> usize {
        usize::try_from(row.saturating_sub(self.trimmed())).unwrap_or(usize::MAX)
    }

    /// The line the cursor is on, up to the cursor, however it wrapped: at a prompt, the prompt and what is typed before
    /// the cursor.
    pub fn line_before_cursor(&self) -> String {
        let b = self.term.normal();
        let y = b.base_y() + b.cursor_y();
        let mut head = y;
        while head > 0 && b.is_wrapped(head) == Some(true) {
            head -= 1;
        }
        let mut text = String::new();
        for i in head..y {
            text.push_str(&b.line_text(i, false, 0, None).unwrap_or_default());
        }
        text + &b.line_text(y, false, 0, Some(b.cursor_x())).unwrap_or_default()
    }

    /// Whole lines between two rows, for as many as the buffer still holds, and whether none of them had gone. With
    /// `last_chars`, only that much of the last line.
    pub fn text(&self, from: u64, to: u64, ansi: bool, last_chars: Option<u64>) -> (Vec<String>, bool) {
        let first = self.index(from);
        let end = usize::try_from(to.saturating_sub(self.trimmed())).unwrap_or(usize::MAX).max(first);
        let mut lines = cells::logical_lines(&self.term.normal(), first, end, ansi);
        if let (Some(chars), Some(last)) = (last_chars, lines.last_mut()) {
            *last = cells::cut_line(last, chars);
        }
        (lines, from >= self.trimmed())
    }

    /// What has been shown from `row` on: the rows up to the cursor, or the alternate screen when a program is on it, which
    /// has no history. With where to carry on from: the top of the screen, and the start of the cursor's line.
    pub fn since(&self, row: Option<u64>) -> (String, u64, u64) {
        let trimmed = self.trimmed();
        let normal = self.term.normal();
        let top = trimmed + normal.base_y() as u64;
        let mut start = normal.base_y() + normal.cursor_y();
        if self.term.alternate_active() {
            let a = self.term.alternate();
            let text = cells::logical_lines(&a, a.base_y(), a.base_y() + self.rows(), false).join("\n");
            return (text, top, trimmed + start as u64);
        }
        let end = start;
        while start > 0 && normal.is_wrapped(start) == Some(true) {
            start -= 1;
        }
        let from = row.map_or(normal.base_y(), |r| self.index(r));
        let text = cells::logical_lines(&normal, from, from.max(end + 1), false).join("\n");
        (text, top, trimmed + start as u64)
    }

    /// The active buffer's scroll margins, 0-based and inclusive.
    pub fn margins(&self) -> (usize, usize) {
        self.term.active().scroll_region()
    }

    /// History and screen as text: [`Emulator::capture_lines`], a line feed after each.
    pub fn capture(&self, lines: Option<usize>, ansi: bool) -> String {
        let mut out = String::new();
        for line in self.capture_lines(lines, ansi, false) {
            out.push_str(&line);
            out.push('\n');
        }
        out
    }

    /// History and screen as whole lines; the alternate screen stands in for the normal one's screen while a program is on
    /// it. `unspooled`: only what has not gone to the history.
    pub fn capture_lines(&self, lines: Option<usize>, ansi: bool, unspooled: bool) -> Vec<String> {
        let normal = self.term.normal();
        let from = match self.unspooled_row() {
            Some(row) if unspooled => self.index(row),
            _ => cells::first_written_line(&normal, normal.base_y()),
        };
        let on_alt = self.term.alternate_active();
        let to = normal.base_y() + if on_alt { 0 } else { self.rows() };
        let mut held = cells::logical_lines(&normal, from, from.max(to), ansi);
        let mut all = if on_alt {
            let a = self.term.alternate();
            let mut screen = cells::logical_lines(&a, a.base_y(), a.base_y() + self.rows(), ansi);
            while screen.last().is_some_and(String::is_empty) {
                screen.pop();
            }
            held.extend(screen);
            held
        } else {
            while held.last().is_some_and(String::is_empty) {
                held.pop();
            }
            held
        };
        if let Some(n) = lines {
            let cut = all.len().saturating_sub(n);
            all.drain(..cut);
        }
        all
    }

    /// The text of the pty's screen: its rows of the buffer, or the top rows of the alternate screen.
    pub fn screen_text(&self, screen_rows: usize) -> String {
        let b = self.term.active();
        let first = if b.is_alternate() { 0 } else { b.base_y() + self.above(screen_rows) };
        let count = if self.tracking { self.rows() } else { screen_rows };
        (first..first + count).map(|y| b.line_text(y, true, 0, None).unwrap_or_default()).collect::<Vec<_>>().join("\n")
    }

    /// The cursor report the pty would get: where the query was, when it was recorded, or now.
    pub fn cpr(&mut self, screen_rows: usize, decx: bool, offset: Option<u64>) -> Vec<u8> {
        let recorded = offset.and_then(|o| {
            let i = self.cpr_at.iter().position(|(at, _)| *at == o)?;
            self.cpr_at.remove(i).map(|(_, at)| at)
        });
        let pos = recorded.unwrap_or_else(|| {
            let b = self.term.active();
            CprAt { x: b.cursor_x(), y: b.cursor_y(), alt: b.is_alternate() }
        });
        let row = if pos.alt { pos.y + 1 } else { (pos.y + 1).saturating_sub(self.above(screen_rows)) };
        format!("\x1b[{}{};{}R", if decx { "?" } else { "" }, row.max(1), pos.x + 1).into_bytes()
    }

    /// The normal buffer.
    pub fn normal(&self) -> BufferView<'_> {
        self.term.normal()
    }
}
