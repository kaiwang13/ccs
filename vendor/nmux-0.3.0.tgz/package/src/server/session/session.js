'use strict';
// @ts-check
const os = require('node:os');
const { EventEmitter } = require('node:events');
const procinfo = require('../../platform/procinfo');
const { isLocked } = require('../../platform/locks');
const { Tracker } = require('../output/tracker');
const { Pipeline } = require('../output/pipeline');
const { Emulator } = require('../output/emulator');
const { DEFAULT_MESSAGES, awayText } = require('../messages');
const { Controller } = require('./controller');
const { initialState, reduce } = require('./machine');
const { StateStore } = require('./state-store');
const { StopRunner, sleep } = require('./stop-runner');
const { ShellTracker } = require('./shell');
const { AgentLink } = require('./agent');
const { Spool } = require('../output/spool');

/** @typedef {import('../types').Lifecycle} Lifecycle */
/** @typedef {import('../output/pipeline').AnnotatedChunk} AnnotatedChunk */
/**
 * @typedef {{id: string, name: string, stateFile: string|null, child: {argv: string[], env: Record<string, string>, cwd: string},
 *   pty: {cols: number, rows: number}, termColors?: {fg: string|null, bg: string|null}|null, nestEnv?: string|null, term?: string, shell?: {token: string}|null, agent?: string|null, spool?: {maxBytes: number}|null}} SessionSpec
 */

/** @typedef {{top: {row: number}, cursor: {row: number}, shown: string[], seq: number}} Bookmark */

/** How much of what it has just read back a new server keeps, and for how long, for the terminals on their way back to it. */
const TAIL_BYTES = 1048576;
const TAIL_KEEP_MS = 15000;

const DEFAULT_TIMERS = Object.freeze({
  holderConnectMs: 10000, holderPingMs: 5000, holderUnresponsiveMs: 15000, orphanWaitMs: 60000, stateDebounceMs: 2000,
  quiesceTries: 5, syncFrameWaitMs: 200,
});

/** DECSTR, then what it leaves alone. */
const CLEAN_MODES = '\x1b[!p\x1b[?1000l\x1b[?1002l\x1b[?1003l\x1b[?1006l\x1b[?1004l\x1b[?2004l';

/**
 * The part of a chunk from a stream offset on. That offset is at a sequence's edge, so no edit is cut in two.
 * @param {AnnotatedChunk} c @param {number} offset @returns {AnnotatedChunk}
 */
function afterOffset(c, offset) {
  const cut = offset - c.startOffset;
  return { ...c, startOffset: offset, bytes: c.bytes.subarray(cut), resets: [], edits: c.edits.filter((e) => e.start >= cut).map((e) => ({ ...e, start: e.start - cut, end: e.end - cut })) };
}

/** @param {string[]} lines */
const joined = (lines) => (lines.length ? `${lines.join('\n')}\n` : '');

/**
 * Whether a terminal's old rows are still what is at those numbers. Whole lines, because a reflow changes rows and not what they say.
 * The last one may have grown: it is where the cursor was, and what is typed there now is new.
 * @param {string[]} shown @param {string[]|null} now
 */
function sameAsShown(shown, now) {
  if (!now || now.length !== shown.length) return false;
  const last = shown.length - 1;
  return shown.every((line, i) => (i === last ? now[i].startsWith(line) : now[i] === line));
}

/** @template T @param {() => T} fn @returns {T|null} */
function safe(fn) { try { return fn(); } catch { return null; } }

/**
 * One session: owns the holder connection, the output path (pipeline → emulator → 'chunk' listeners), the lifecycle and
 * the on-disk record. Everything the running program means to anyone is the controller's.
 *
 * Events: 'lifecycle'(Lifecycle), 'chunk'(AnnotatedChunk), 'reset'(offset), 'pty'({cols, rows}), 'attrs'(), 'gap'(bytes lost),
 * 'notice'({level, code, text}) for every client, 'clientNotice'({client, level, code, text}) for one client, 'clientExit'(clientId),
 * 'holderErr'({code}), 'stopped'(), 'shell'({event: 'prompt'|'command', ...}).
 */
class Session extends EventEmitter {
  /**
   * @param {{spec: SessionSpec, config: any, clock: import('../../base/types').Clock, log: any,
   *   layout: {ptySock(id: string): string, holderLock(id: string): string, sessionDir(id: string): string}, controller?: Controller,
   *   messages?: import('../messages').Messages, recover?: boolean,
   *   startHolder: (o: {gen: number, argv: string[], cols: number, rows: number}) => Promise<void>,
   *   connectHolder: (sockPath: string) => Promise<import('./holderclient').HolderClient>,
   *   clientsInfo?: () => object[], timers?: Partial<typeof DEFAULT_TIMERS>, stateWriter?: (file: string, st: object) => (void|Promise<void>),
   *   initialState?: any, wallNow?: () => number}} o
   */
  constructor({ spec, config, clock, log, layout, controller = new Controller(), messages = DEFAULT_MESSAGES, recover = false, startHolder, connectHolder, clientsInfo = () => [], timers = {}, stateWriter, initialState: persisted = null, wallNow = Date.now }) {
    super();
    this.spec = spec;
    this.config = config;
    this.clock = clock;
    // Timestamps other programs compare are Unix time; policy timers still use the monotonic clock.
    this.wallNow = wallNow;
    this.log = log;
    this.layout = layout;
    this.controller = controller;
    this.messages = messages;
    this.recover = recover;
    this.startHolder = startHolder;
    this.connectHolderFn = connectHolder;
    this.clientsInfo = clientsInfo;
    this.timers = { ...DEFAULT_TIMERS, ...timers };
    this.machine = initialState(recover);
    this.lifecycleSince = new Date().toISOString();
    /** @type {import('./holderclient').HolderClient|null} */
    this.holder = null;
    /** @type {any} */
    this.hello = null;
    this.gen = 0;
    /** the program repaints its whole screen, so the emulator stays one fixed size: see Emulator */
    this.repaint = !!(config.stream && config.stream.repaint);
    this.emulator = new Emulator(this.repaint ? { scrollback: config.snapshot.scrollback }
      : { scrollback: config.snapshot.scrollback, tracking: true, cols: spec.pty.cols, rows: spec.pty.rows });
    this.emulator.onParsed = (offset) => { if (this.holder) this.holder.ack(offset); };
    /** the marks of a shell that was started to give them, in an emulator that can place them */
    this.markToken = spec.shell && !this.repaint ? spec.shell.token : null;
    /** @type {ShellTracker|null} */
    this.shell = null;
    this.agent = spec.agent ? new AgentLink({ link: spec.agent, log }) : null;
    if (this.markToken) {
      const shell = new ShellTracker({ emulator: this.emulator, clock, cancelLine: () => this.write(Buffer.from('\x03')), wallNow });
      this.shell = shell;
      this.emulator.onMark = (mark, at, offset) => shell.onMark(mark, at, offset > this.replayUntil);
      this.emulator.onErased = (top) => shell.onErased(top);
      shell.on('prompt', () => this.emit('shell', { event: 'prompt' }));
      shell.on('command', (c) => this.emit('shell', { event: 'command', ...c }));
    }
    /** output that has left the emulator's history, kept on disk for a session that asked */
    this.spool = spec.spool && !this.repaint ? new Spool({ dir: layout.sessionDir(spec.id), maxBytes: spec.spool.maxBytes, log }) : null;
    if (this.spool) {
      this.emulator.keepRowsIn(this.spool);
      this.emulator.onSpooled = (from, to, line) => { if (this.shell) this.shell.spooled(from, to, line); };
    }
    this.emulatorReady = false;
    this.tracker = new Tracker({ cols: spec.pty.cols, rows: spec.pty.rows });
    /** @type {Pipeline|null} */
    this.pipeline = null;
    /** @type {AnnotatedChunk|null} */
    this.lastChunk = null;
    /** @type {AnnotatedChunk[]} output a terminal that was here before this server may still need, newest last */
    this.tail = [];
    this.tailBytes = 0;
    /** when to stop keeping it; a server that took over from another keeps it for a while */
    this.tailKeptUntil = recover && !this.repaint ? clock.now() + TAIL_KEEP_MS : 0;
    this.pty = { cols: spec.pty.cols, rows: spec.pty.rows };
    /** every byte written to the child, whoever wrote it */
    this.writes = { total: 0 };
    /** Seeded from the persisted record when rebuilt after a recover or a restart.
     *  @type {number|undefined} */
    this.launchedAtMs = (persisted && persisted.launchedAtMs) || undefined;
    this.currentName = spec.name;
    /** whether the session is asking for a person; shown in terminal titles */
    this.attention = false;
    /** @type {number|null} */
    this.historyTruncatedBefore = null;
    this.replayUntil = 0;
    this.detaching = false;
    /** output that never reached the emulator, because the holder had to overwrite it */
    this.lostBytes = 0;
    /** process group in the terminal's foreground, as the holder last saw it */
    /** @type {number|null} */
    this.fg = null;
    this.lastOutputAt = clock.now();
    /** @type {Array<{id: number, kind: string, offset: number}>} */
    this.pendingCpr = [];
    this.lastPongAt = clock.now();
    this.unresponsiveNotified = false;
    /** @type {any} */
    this.pingTimer = null;
    this.disposed = false;
    /** the holder is being started and adopted */
    this.starting = false;
    /** @type {() => void} */
    this.markStarted = () => {};
    /** resolves when the emulator is ready for a join, or there will be no session to join */
    this.started = new Promise((resolve) => { this.markStarted = () => resolve(undefined); });
    this.store = new StateStore({ file: spec.stateFile, ...(stateWriter ? { write: stateWriter } : {}), snapshot: () => this._record(), clock, log, debounceMs: this.timers.stateDebounceMs });
    this.stopper = new StopRunner({ session: this, clock, hangupWaitMs: config.stop.hangupWaitMs, termWaitMs: config.stop.termWaitMs });
    controller.bind(this);
  }

  get lifecycle() { return this.machine.lifecycle; }
  get blockedCode() { return this.machine.blockedCode; }
  get lastExit() { return this.machine.lastExit; }
  get restarts() { return { attributed: this.machine.attributed }; }
  /** The child is gone, or its exit is being handled. */
  get exited() { return this.machine.exited; }
  get name() { return this.currentName || this.spec.name; }

  // ---------------------------------------------------------------------------------------------------- startup
  /** New session: spawn the holder (gen 1). Recovery: adopt the live holder and rebuild from its ring. */
  async start() {
    this.starting = true;
    try {
      if (!this.recover) {
        this.gen = 1;
        this.launchedAtMs = this.wallNow();
        await this.startHolder({ gen: this.gen, argv: this.spec.child.argv, cols: this.spec.pty.cols, rows: this.spec.pty.rows });
      }
      const hc = await this._connect(this.timers.holderConnectMs);
      await this._adopt(hc, this.recover);
    } finally {
      this.starting = false;
      this.markStarted();
    }
  }

  /** @param {number} withinMs */
  async _connect(withinMs) {
    const deadline = this.clock.now() + withinMs;
    /** @type {any} */
    let lastErr = null;
    while (this.clock.now() <= deadline) {
      try { return await this.connectHolderFn(this.layout.ptySock(this.spec.id)); } catch (e) { lastErr = e; }
      await sleep(this.clock, 50);
    }
    throw Object.assign(new Error(`holder not reachable: ${lastErr && lastErr.message}`), { code: 'HOLDER_UNREACHABLE' });
  }

  /** @param {import('./holderclient').HolderClient} hc @param {boolean} replay */
  async _adopt(hc, replay) {
    const h = hc.hello;
    this.hello = h;
    this.holder = hc;
    this.gen = h.gen;
    this.dispatch({ t: 'adopted' });
    this.lastPongAt = this.clock.now();
    this.unresponsiveNotified = false;
    let from = 0;
    if (!this.emulatorReady) {
      const first = (h.resizeLog && h.resizeLog[0]) || { offset: 0, cols: h.pty.cols, rows: h.pty.rows };
      const log = h.resizeLog || [];
      if (replay && h.ring.start > 0 && this.repaint) {   // a wrapped ring is not replayed
        this.tracker = new Tracker({ cols: h.pty.cols, rows: h.pty.rows });
        await this.emulator.init(h.pty.rows);
        from = h.ring.end;
        this.historyTruncatedBefore = h.ring.end;
        this.log.warn('recover.ring_wrapped', { start: h.ring.start, end: h.ring.end });
      } else {                                            // rebuild from what the ring holds, with the holder's resize log
        from = replay ? h.ring.start : 0;
        const size = log.filter((r) => r.offset <= from).pop() || first;
        this.tracker = new Tracker({ cols: size.cols, rows: size.rows });
        for (const r of log) if (r.offset > from) this.tracker.noteResize(r.cols, r.rows, r.offset);
        if (this.spool && replay) this.spool.resume(h.gen);                  // what a server before this one wrote is not written twice
        if (this.spool) this.spool.stream(h.gen);
        await this.emulator.init(size.rows, size.cols);
        if (from > 0) {
          this.historyTruncatedBefore = from;
          this.log.warn('recover.ring_wrapped', { start: h.ring.start, end: h.ring.end });
          if (this.shell) this.shell.joinedMidway();
        }
      }
      this.emulatorReady = true;
    } else {
      this.tracker.rebase({ cols: h.pty.cols, rows: h.pty.rows });   // a new child after a restart
      if (this.spool) this.spool.newStream(h.gen);
      if (!this.repaint) this.emulator.resizeTo(h.pty.cols, h.pty.rows);  // a resize can be lost in the child's last moments
    }
    this.pty = { cols: h.pty.cols, rows: h.pty.rows };
    this.pipeline = new Pipeline({ tracker: this.tracker, clock: this.clock, detectResets: this.repaint, startOffset: from, markToken: this.markToken, notesErase: this.markToken !== null || this.spool !== null });
    this.pipeline.on('chunks', (chunks) => this._chunks(chunks));
    this.lastChunk = null;
    this.controller.onHolder(h);
    hc.on('data', ({ offset, bytes }) => { if (this.holder === hc && this.pipeline) this._chunks(this.pipeline.process(offset, bytes)); });
    hc.on('gap', (g) => {
      this.lostBytes += g.to - g.from;
      this.log.warn('holder.gap', g);
      this.emit('gap', g.to - g.from);
    });
    hc.on('consumed', (id) => this.controller.onConsumed(id));
    hc.on('lflag', (l) => { if (this.holder === hc) { this.fg = l.fg; this.controller.onLflag(l); } });
    hc.on('queryFwd', (q) => { this.pendingCpr.push(q); this._answerCpr(); });
    hc.on('resized', (r) => {
      this.tracker.noteResize(r.cols, r.rows, r.offset);
      if (this.pipeline) this._chunks(this.pipeline.settle());
      this.pty = { cols: r.cols, rows: r.rows };
      this.emit('pty', { ...this.pty });
      this.saveState(false);
    });
    hc.on('err', (m) => { this.log.warn('holder.err', { code: m.code }); this.emit('holderErr', m); });
    hc.on('pong', () => { this.lastPongAt = this.clock.now(); this.unresponsiveNotified = false; });
    hc.on('exit', (e) => { if (this.holder === hc) this._onExit(e); });
    hc.on('close', () => { if (this.holder === hc && !this.exited && !this.detaching) this._onHolderLost(); });
    this.replayUntil = replay ? h.ring.end : 0;
    if (this.replayUntil <= from) this.dispatch({ t: 'replayed' });
    hc.attach(from);
    this.controller.onAttached();
    this._armPing();
    this.saveState(true);
  }

  // ---------------------------------------------------------------------------------------------------- output path
  /** @param {AnnotatedChunk[]} chunks */
  _chunks(chunks) {
    if (chunks.length) this.lastOutputAt = this.clock.now();
    for (const chunk of chunks) {
      this.emulator.feed(chunk);
      this.lastChunk = chunk;
      this._keepTail(chunk);
      this.controller.onChunk(chunk);
      this.emit('chunk', chunk);
      for (const r of chunk.resets) this.emit('reset', r.offset);
      if (this.lifecycle === 'RECOVERING' && chunk.endOffset >= this.replayUntil) {
        this.dispatch({ t: 'replayed' });
        this.controller.onReplayed();
      }
    }
    if (chunks.length) this._answerCpr();
  }

  /** @param {AnnotatedChunk} chunk */
  _keepTail(chunk) {
    if (this.tailKeptUntil === 0) return;
    if (this.clock.now() > this.tailKeptUntil) { this.tailKeptUntil = 0; this.tail = []; this.tailBytes = 0; return; }
    this.tail.push(chunk);
    this.tailBytes += chunk.bytes.length;
    while (this.tailBytes > TAIL_BYTES) this.tailBytes -= /** @type {AnnotatedChunk} */ (this.tail.shift()).bytes.length;
  }

  /**
   * How far a terminal has got that is here as this server goes, or null if that cannot be said: stream offsets mean nothing
   * in the middle of a sequence, or to a program that repaints.
   * @returns {{gen: number, offset: number}|null}
   */
  resumePoint() {
    const { lastChunk, pipeline } = this;
    if (this.repaint || !lastChunk || !lastChunk.groundAfter || !pipeline || !pipeline.quiescent) return null;
    return { gen: this.gen, offset: lastChunk.endOffset };
  }

  /**
   * What a terminal coming back from an earlier server has not seen, or null if it cannot be helped: then it needs a join.
   * @param {any} from what that server told it @param {number} cols @param {number} rows @returns {AnnotatedChunk[]|null}
   */
  outputSince(from, cols, rows) {
    if (!from || from.gen !== this.gen || from.cols !== cols || from.rows !== rows || !Number.isSafeInteger(from.offset)) return null;
    const { tail, lastChunk } = this;
    if (!lastChunk || lastChunk.endOffset < from.offset || tail.length === 0 || tail[0].startOffset > from.offset) return null;
    return tail.filter((c) => c.endOffset > from.offset).map((c) => (c.startOffset >= from.offset ? c : afterOffset(c, from.offset)));
  }

  /** QUERY_FWD{CPR} arrives before the DATA holding the query: answer once the emulator has parsed up to its offset. */
  async _answerCpr() {
    if (!this.pendingCpr.length || !this.holder) return;
    const end = this.lastChunk ? this.lastChunk.endOffset : 0;
    const ready = this.pendingCpr.filter((q) => q.offset <= end);
    if (!ready.length) return;
    this.pendingCpr = this.pendingCpr.filter((q) => q.offset > end);
    const hc = this.holder;
    await this.emulator.tail;
    for (const q of ready) hc.queryReply(q.id, this.emulator.cpr(this.tracker.screenRows, { decx: q.kind === 'DECXCPR', offset: q.offset }));
  }

  /**
   * Stops reading the holder and waits for a quiescent ground-state boundary: the emulator has parsed everything, the
   * last chunk ended at ground, the pipeline holds nothing, and no ?2026 frame is open (else let data flow 200 ms and
   * retry; after the retries snapshot anyway, since the state is byte-consistent). Returns release().
   * @returns {Promise<() => void>}
   */
  async quiesce() {
    const hc = this.holder;
    if (hc) hc.pause();
    for (let i = 0; i < this.timers.quiesceTries; i++) {
      await this.emulator.tail;
      const ground = (!this.lastChunk || this.lastChunk.groundAfter) && (!this.pipeline || this.pipeline.quiescent);
      if (ground && this.tracker.modes.raw(2026) !== 1) break;
      if (hc) hc.resume();
      await sleep(this.clock, this.timers.syncFrameWaitMs);
      if (hc) hc.pause();
    }
    await this.emulator.tail;
    let released = false;
    return () => { if (!released) { released = true; if (hc && this.holder === hc) hc.resume(); } };
  }

  // ---------------------------------------------------------------------------------------------------- acting on the child
  /** @param {Buffer} bytes @param {{loneEsc?: boolean, watch?: boolean}} [opts] @returns {number} watchId or 0 */
  write(bytes, opts = {}) {
    if (!this.holder || this.exited) return 0;
    const id = this.holder.write(bytes, opts);
    this.writes.total += bytes.length;
    return id;
  }

  /** @param {'SIGCONT'|'SIGTERM'} sig */
  signal(sig) { if (this.holder) this.holder.signal(sig); }

  /** Applies the size chosen by the arbiter (one RESIZE carries both dimensions). */
  resize(cols, rows) {
    if (!this.holder || this.exited) return;
    this.holder.resize(cols, rows);
    this.pty = { cols, rows };
  }

  /** Text of the PTY screen rows only (never scrollback). */
  screenText() { return this.emulator.screenText(this.tracker.screenRows); }

  /** Resolves once anything a new server has to read back has been read, so that what it says is what is true now. */
  async settled() {
    await this.started;
    while (this.lifecycle === 'RECOVERING') await new Promise((resolve) => { this.once('lifecycle', resolve); });
    await this.emulator.tail;
  }

  /**
   * History and screen as text, with everything printed so far. A spool answers for all it has been given, and the emulator only
   * for what it has not: the two cannot be told apart row by row once a reflow has renumbered one of them.
   * @param {{lines?: number|null, ansi?: boolean}} [o]
   */
  async capture(o = {}) {
    await this.emulator.tail;
    const { spool, emulator } = this;
    if (!spool || spool.failed) return joined(emulator.captureLines(o));
    const { lines = null, ansi = false } = o;
    const held = emulator.captureLines({ ansi, lines, unspooled: true });
    const short = lines === null ? null : lines - held.length;
    const early = short === null || short > 0 ? await spool.lastLines(short === null ? null : short + 1, { ansi }) : [];
    if (early.length && held.length && emulator.unspooledContinues()) held[0] = `${early.pop()}${held[0]}`;
    return joined(lines === null ? [...early, ...held] : [...early, ...held].slice(-lines));
  }

  /**
   * What a command printed, however long ago it left the emulator.
   * @param {import('./shell').ShellCommand} rec @param {{ansi?: boolean}} [o] @returns {Promise<{text: string, complete: boolean}>}
   */
  async outputOf(rec, o = {}) {
    await this.emulator.tail;
    const { spool, emulator } = this;
    const shell = /** @type {ShellTracker} */ (this.shell);
    if (!spool || spool.failed || rec.spoolStart === null) return shell.output(rec, o);
    const to = rec.spoolEnd === null ? spool.lines : rec.spoolEnd + (rec.endChars > 0 ? 1 : 0);
    const early = await spool.range(rec.spoolStart, to, { ansi: !!o.ansi, lastChars: rec.spoolEnd !== null && rec.endChars > 0 ? rec.endChars : null });
    if (early === null) return shell.output(rec, o);
    if (rec.spoolEnd !== null) return { text: joined(early), complete: true };
    const rest = shell.output(rec, { ...o, from: /** @type {{row: number}} */ (emulator.unspooled).row });
    return { text: `${joined(early)}${rest.text}`, complete: true };
  }

  /** What has been shown from a row on, with everything printed so far. @param {number|null} row null: the top of the screen */
  async since(row) {
    await this.emulator.tail;
    return this.emulator.since(row);
  }

  /**
   * How far a terminal that leaves now has got. It has everything down to the cursor, which goes up into its scrollback as it does
   * whatever it does next. But those rows can still change while it is away, so they are kept to compare with when it comes back.
   * A program that repaints will draw the screen again, so there it only has what is above that.
   * @returns {Bookmark}
   */
  bookmark() {
    const { emulator } = this;
    const top = emulator.screenTop(this.tracker.screenRows);
    const cursor = this.repaint ? top : emulator.cursorRow();
    const { shell } = this;
    const seq = !shell ? 0 : (shell.current ? shell.current.seq - 1 : shell.seq);      // what is running now will have finished while it was away
    return { top: emulator.pin(top), cursor: emulator.pin(cursor), shown: this.repaint ? [] : emulator.linesBetween(top, cursor + 1) || [], seq };
  }

  /**
   * The first row a terminal that has come back needs. Rows above the screen it left cannot have changed. Those on it can: a `clear`
   * rewrites the same rows, and treating them as seen would lose what is there now. So unless they still say the same, it gets them again.
   * @param {Bookmark} b
   */
  rowAfter(b) {
    if (this.repaint) return b.top.row;
    return b.cursor.row >= 0 && sameAsShown(b.shown, this.emulator.linesBetween(b.top.row, b.cursor.row + 1)) ? b.cursor.row : b.top.row;
  }

  /** What has happened since a bookmark, in a line, or null. @param {Bookmark} since @param {number} lines */
  awaySince(since, lines) {
    const { shell } = this;
    const finished = shell ? shell.records.filter((r) => r.seq > since.seq && r.end).map((r) => shell.describe(r)) : [];
    return awayText({ finished, running: shell ? shell.current : null, lines });
  }

  /** @returns {string[]} every gate that applies, most important first */
  gates() {
    /** @type {string[]} */
    const g = [];
    if (['STOPPING', 'STOPPED', 'STOP_STUCK'].includes(this.lifecycle)) g.push('STOPPING');
    if (this.lifecycle === 'EXITED' || this.lifecycle === 'RECOVERING' || !this.holder || this.exited) g.push('EXITED');
    g.push(...this.controller.gates());
    return g;
  }

  gateName() { return this.gates()[0] ?? 'OPEN'; }

  /** @returns {string[]} */
  blockingGates() { return ['STOPPING', 'EXITED', ...this.controller.blockingGates()]; }

  // ---------------------------------------------------------------------------------------------------- what a controller calls
  /** Moves to a controller's phase, from any of `from` when given. @param {Lifecycle} to @param {{from?: Lifecycle[]}} [o] */
  setPhase(to, { from } = {}) { this.dispatch({ t: 'phase', to, ...(from ? { from } : {}) }); }

  /** @param {string} code */
  block(code) { this.dispatch({ t: 'blocked', code }); }

  /** @param {string} name */
  rename(name) { this.currentName = name; }

  /** The rows of the PTY screen and the cursor, for something deciding what the program is showing. */
  async screen() {
    await this.emulator.tail;
    return this.screenText();
  }

  /** Publishes what the controller knows: clients hear of it at once. @param {{attention?: boolean}} [o] */
  publish({ attention = this.attention } = {}) {
    this.attention = attention;
    this.emit('attrs');
  }

  /** @param {'info'|'warn'} level @param {string} code @param {string} text */
  notify(level, code, text) { this.emit('notice', { level, code, text }); }

  /** @param {any} client @param {'info'|'warn'} level @param {string} code @param {string} text */
  notifyClient(client, level, code, text) { this.emit('clientNotice', { client, level, code, text }); }

  /** @param {boolean} immediate */
  saveState(immediate) { this.store.save(immediate); }

  // ---------------------------------------------------------------------------------------------------- holder health
  _armPing() {
    this._clearPing();
    this.pingTimer = this.clock.setTimeout(() => {
      this.pingTimer = null;
      if (!this.holder || this.exited || this.disposed) return;
      this.holder.ping(Math.floor(this.clock.now()));
      if (this.clock.now() - this.lastPongAt > this.timers.holderUnresponsiveMs && !this.unresponsiveNotified) {
        this.unresponsiveNotified = true;
        this.log.warn('holder.unresponsive');
        this.notify('warn', 'HOLDER_UNRESPONSIVE', 'the PTY holder is not answering; output may be delayed');
      }
      this._armPing();
    }, this.timers.holderPingMs);
  }

  _clearPing() { if (this.pingTimer !== null) { this.clock.clearTimeout(this.pingTimer); this.pingTimer = null; } }

  // ---------------------------------------------------------------------------------------------------- exits
  /** @param {{code: number|null, signal: string|null, at?: string, shuttingDown?: boolean, detectedBy?: string, error?: string}} e */
  _onExit(e) {
    if (this.exited) return;
    this.dispatch({ t: 'exit-seen' });
    if (this.pipeline) this._chunks(this.pipeline.flush());
    this._clearPing();
    this.controller.onChildExit();
    this.pendingCpr = [];
    this.log.info('child.exit', { code: e.code, signal: e.signal, shuttingDown: !!e.shuttingDown, detectedBy: e.detectedBy || null });
    const decided = this.machine.stopRequested || e.shuttingDown;
    this.dispatch({ t: 'exit', code: e.code, signal: e.signal, at: e.at || new Date().toISOString(), shuttingDown: e.shuttingDown,
      claimedBy: decided ? null : this.controller.claimExit({ code: e.code, signal: e.signal }), stays: this.controller.staysAfterExit, quiet: !this.controller.announcesExit });
    this.controller.onExited({ code: e.code, signal: e.signal, at: e.at || new Date().toISOString() });
  }

  /** Waits out the old holder, then starts `argv` in a new one. Clients stay attached. @param {string[]} argv */
  async respawn(argv) {
    if (this.machine.stopRequested || this.disposed) return;
    const lockFile = this.layout.holderLock(this.spec.id);
    for (let i = 0; i < 100 && isLocked(lockFile); i++) await sleep(this.clock, 50);   // the old holder (and so the old child) is gone
    this.gen += 1;
    this.launchedAtMs = this.wallNow();
    await this.startHolder({ gen: this.gen, argv, cols: this.pty.cols, rows: this.pty.rows });
    const hc = await this._connect(this.timers.holderConnectMs);
    this.controller.onRespawned();
    this.attention = false;                                                            // a new child has asked for nothing yet
    this.dispatch({ t: 'respawning' });
    await this.emulator.tail;                                                          // nothing left to acknowledge to the old child
    if (this.shell) this.shell.reset();
    if (!this.repaint) this._cleanSlate();
    await this._adopt(hc, false);
  }

  /** A new program starts on a line of its own, with nothing the last one left set. Everyone sees this, so the emulator does. */
  _cleanSlate() {
    const leaveAlt = this.tracker.alt ? Buffer.from('\x1b[?1049l') : Buffer.alloc(0);
    const b = this.emulator.term.buffer.normal;
    const bytes = Buffer.concat([leaveAlt, Buffer.from(`${CLEAN_MODES}${b.cursorX > 0 ? '\r\n' : ''}`)]);
    const edits = leaveAlt.length ? [{ kind: /** @type {const} */ ('alt-exit'), start: 0, end: leaveAlt.length, raw: leaveAlt }] : [];
    this._chunks([{ startOffset: 0, endOffset: 0, bytes, edits, groundAfter: true, resets: [], text: '' }]);
  }

  /** Replaces the child with a new one running the same command; clients stay attached. */
  async restart() {
    if (!this.holder || this.exited || this.machine.stopRequested) return;
    if (this.shell) this.shell.reset();                                                // nothing that shell says from here on is about the session
    this.dispatch({ t: 'restart-requested' });
    this.holder.closeMaster();                                                         // EIO + SIGHUP
    await sleep(this.clock, this.config.stop.hangupWaitMs);
    if (this.holder && !this.exited && this.machine.restartRequested) this.holder.signal('SIGTERM');
  }

  /** @param {Error} err */
  _respawnFailed(err) {
    this.log.error('restart.failed', { error: err.message });
    this.dispatch({ t: 'respawn-failed' });
    this.notify('warn', 'RESTART_FAILED', this.messages.respawnFailed(this.name));
  }

  /** pty.sock closed without EXIT: wait until the child's pid is gone; never start a second child beside it. */
  async _onHolderLost() {
    this.log.warn('holder.lost');
    const child = this.hello && this.hello.child;
    this.holder = null;
    const alive = () => !!child && procinfo.procState(child.pid) === 'alive' && procinfo.procStart(child.pid) === child.procStart;
    const deadline = this.clock.now() + this.timers.orphanWaitMs;
    while (alive() && this.clock.now() < deadline) await sleep(this.clock, 500);
    if (alive()) {
      this.dispatch({ t: 'orphaned' });
      this.notify('warn', 'ORPHAN_ALIVE', this.messages.orphanAlive(child.pid));
      try { process.kill(child.pid, 'SIGTERM'); } catch { /* gone */ }
      return;
    }
    this._onExit({ code: null, signal: null, detectedBy: 'holder-lost' });
  }

  stop() { return this.stopper.run(); }

  markStopped() {
    this.markStarted();
    this.dispatch({ t: 'stopped' });
    this.stopper.settled();
    this.emit('stopped');
  }

  // ---------------------------------------------------------------------------------------------------- lifecycle and state
  /** The one place a lifecycle changes. @param {import('./machine').Event} event */
  dispatch(event) {
    const from = this.machine.lifecycle;
    const { state, effects } = reduce(this.machine, event);
    this.machine = state;
    if (state.lifecycle !== from) {
      this.log.info('lifecycle', { from, to: state.lifecycle });
      this.lifecycleSince = new Date().toISOString();
      this.emit('lifecycle', state.lifecycle);
      this.saveState(true);
    }
    for (const effect of effects) this._apply(effect);
  }

  /** @param {import('./machine').Effect} effect */
  _apply(effect) {
    switch (effect.t) {
      case 'release': if (this.holder) this.holder.release(); break;
      case 'stopped': this.markStopped(); break;
      case 'client-exit': this.emit('clientExit', effect.client); break;
      case 'respawn-later':
        this.clock.setTimeout(() => { this.respawn(this.controller.respawnArgv()).catch((err) => this._respawnFailed(err)); }, this.controller.respawnDelayMs);
        break;
      case 'exit-notice': {
        const { code, text } = this.messages.childExited(this.name, effect.how);
        this.notify('warn', code, text);
        break;
      }
      default: throw new Error(`unknown session effect ${/** @type {any} */ (effect).t}`);
    }
  }

  status() {
    return this.controller.status({
      name: this.name, lifecycle: this.lifecycle, blockedCode: this.blockedCode, gate: this.gateName(), gates: this.gates(),
      child: { pid: this.hello ? this.hello.child.pid : null },
      pty: { ...this.pty }, alt: this.tracker.alt, lastExit: this.lastExit, restarts: { ...this.restarts }, census: { ...this.tracker.census },
      historyTruncatedBefore: this.historyTruncatedBefore, lostBytes: this.lostBytes, parsedBytes: this.emulator.processedOffset, idleMs: this.clock.now() - this.lastOutputAt,
      foregroundPid: this.fg, shell: this.shell ? this.shell.status() : null,
    });
  }

  /** The on-disk record, merged into the existing file. */
  _record() {
    const h = this.hello;
    return this.controller.persisted({
      schema: 'nmux.state/1', id: this.spec.id, bootId: safe(() => procinfo.bootId()),
      host: { hostname: os.hostname(), machineId: safe(() => procinfo.machineId()) },
      writer: { pid: process.pid, procStart: procinfo.procStart(process.pid) },
      lifecycle: this.lifecycle, lifecycleSince: this.lifecycleSince, blockedCode: this.blockedCode, gate: this.gateName(),
      holder: h ? { pid: h.pid, procStart: h.procStart, gen: h.gen, proto: h.proto } : null,
      child: h ? { pid: h.child.pid, procStart: h.child.procStart } : null,
      launchedAtMs: this.launchedAtMs || null,
      pty: this.pty, clients: this.clientsInfo(), restarts: { attributed: this.machine.attributed, lastExit: this.lastExit },
      census: { ...this.tracker.census }, historyTruncatedBefore: this.historyTruncatedBefore, updatedAt: new Date().toISOString(),
    });
  }

  /** Lets go of the holder without touching the child: the holder respawns the server. */
  detach() {
    this.detaching = true;
    this.dispose();
    if (this.holder) this.holder.close();
  }

  dispose() {
    if (this.disposed) return;
    this.saveState(true);
    this.disposed = true;
    this.store.close();
    if (this.spool) this.spool.close();
    this._clearPing();
    this.controller.dispose();
  }
}

module.exports = { Session, DEFAULT_TIMERS };
