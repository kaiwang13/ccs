'use strict';
// @ts-check
const fs = require('node:fs');
const path = require('node:path');
const { StringDecoder } = require('node:string_decoder');
const { cutLine } = require('./cells');

const PREFIX = 'spool-';
const WATERMARK = '=';
const FIRST_ROW = '.';
const CONTINUES = '+';
/** Reading goes this far between chances for anything else to run. */
const READ_BYTES = 1048576;
/** Every write ends with a watermark, so one is always this close to the end of a file. */
const TAIL_BYTES = 65536;

/** What a row looks like with its colours taken out. @param {string} row what serializeRows made */
const plain = (row) => row.replace(/\x1b\[(\d*)C/g, (_, n) => ' '.repeat(Number(n) || 1)).replace(/\x1b\[[0-9;]*[A-Za-z]/g, '');

/**
 * Rows that have left the screen, on disk, for a session that asked: it makes `capture` and `last` reach further back. Terminal
 * output often has secrets in it, so this is off unless asked for, and the files are private. Two files are kept, each up to half
 * of `maxBytes`, so the newest part is always there and the total stays within the limit.
 *
 * A row is one line, numbered from the first ever written, and a file's name says the number of its first. A line starting `=` says how
 * far into the program's output that takes things, and how many rows there are by then, so a server that starts after this one
 * carries on without reading it all and does not write the same rows twice. Something going wrong here ends the spool, not the session.
 */
class Spool {
  /** @param {{dir: string, maxBytes: number, log: any}} o */
  constructor({ dir, maxBytes, log }) {
    this.dir = dir;
    this.maxBytes = maxBytes;
    this.log = log;
    /** the number the next row gets */
    this.lines = 0;
    /** @type {number|null} */
    this.fd = null;
    this.fileBytes = 0;
    /** program's output up to here is already written @type {number} */
    this.through = -1;
    this.gen = 0;
    /** @type {{gen: number, offset: number}|null} */
    this.lastMark = null;
    this.failed = false;
    try { this._open(); } catch (e) { this._failed(e); }
  }

  /** @param {unknown} e */
  _failed(e) {
    this.failed = true;
    this.log.warn('spool.failed', { error: String(/** @type {Error} */ (e).message) });
  }

  /** @returns {Array<{file: string, first: number}>} oldest first */
  _files() {
    let names = [];
    try { names = fs.readdirSync(this.dir); } catch { return []; }
    return names.filter((n) => n.startsWith(PREFIX)).map((n) => ({ file: path.join(this.dir, n), first: Number(n.slice(PREFIX.length)) })).sort((a, b) => a.first - b.first);
  }

  /** Carries on from whatever is there. */
  _open() {
    const last = this._files().pop();
    if (!last) { this._startFile(); return; }
    const fd = fs.openSync(last.file, 'r');
    try {
      const size = fs.fstatSync(fd).size;
      const buf = Buffer.alloc(Math.min(size, TAIL_BYTES));
      fs.readSync(fd, buf, 0, buf.length, size - buf.length);
      const mark = buf.toString('utf8').split('\n').reverse().find((l) => l[0] === WATERMARK);
      if (size > 0 && !mark) throw new Error(`no watermark at the end of ${last.file}`);
      if (mark) {
        const [gen, offset, lines] = mark.slice(1).split(':').map(Number);
        this.lastMark = { gen, offset };
        this.lines = lines;
      } else this.lines = last.first;
      this.fileBytes = size;
    } finally {
      fs.closeSync(fd);
    }
    this.fd = fs.openSync(last.file, 'a', 0o600);
  }

  _startFile() {
    if (this.fd !== null) fs.closeSync(this.fd);
    this.fd = fs.openSync(path.join(this.dir, `${PREFIX}${this.lines}`), 'a', 0o600);
    fs.fchmodSync(this.fd, 0o600);
    this.fileBytes = 0;
    for (const old of this._files().slice(0, -2)) fs.rmSync(old.file, { force: true });
  }

  /** The program's output from here on is a new stream. @param {number} gen */
  stream(gen) { this.gen = gen; }

  /** A new program, whose stream starts again from nothing. @param {number} gen */
  newStream(gen) {
    this.gen = gen;
    this.through = -1;
  }

  /** The server before this one wrote what it read of this program. @param {number} gen */
  resume(gen) { if (this.lastMark && this.lastMark.gen === gen) this.through = this.lastMark.offset; }

  /** @param {number} offset how far into the program's output a row goes */
  alreadyHas(offset) { return offset <= this.through; }

  /**
   * @param {string[]} rows what serializeRows made @param {boolean[]} wrapped whether each carries on from the row before it
   * @param {number} offset how far into the output these go @returns {number} the number of the first
   */
  append(rows, wrapped, offset) {
    const first = this.lines;
    this.lines += rows.length;
    if (this.failed) return first;
    let text = '';
    for (let i = 0; i < rows.length; i++) text += `${wrapped[i] ? CONTINUES : FIRST_ROW}${rows[i]}\n`;
    text += `${WATERMARK}${this.gen}:${offset}:${this.lines}\n`;
    try {
      const bytes = Buffer.from(text, 'utf8');
      if (this.fileBytes + bytes.length > this.maxBytes / 2 && this.fileBytes > 0) this._rotateAt(first);
      fs.writeSync(/** @type {number} */ (this.fd), bytes);
      this.fileBytes += bytes.length;
    } catch (e) { this._failed(e); }
    return first;
  }

  /** @param {number} first the number of the row the new file starts with */
  _rotateAt(first) {
    const { lines } = this;
    this.lines = first;
    this._startFile();
    this.lines = lines;
  }

  /**
   * Hands over the rows with these numbers, a piece at a time, so that a big spool holds nothing up.
   * @param {number} from @param {number} to `to` excluded @param {(row: string, number: number) => void} visit
   */
  async _scan(from, to, visit) {
    const files = this._files();
    for (let i = 0; i < files.length; i++) {
      const next = files[i + 1];
      if ((next && next.first <= from) || files[i].first >= to) continue;
      try { await this._scanFile(files[i], from, to, visit); } catch (e) { if (/** @type {any} */ (e).code !== 'ENOENT') throw e; }   // rotated away just now
    }
  }

  /** @param {{file: string, first: number}} f @param {number} from @param {number} to @param {(row: string, number: number) => void} visit */
  async _scanFile({ file, first }, from, to, visit) {
    const handle = await fs.promises.open(file, 'r');
    try {
      const buf = Buffer.allocUnsafe(READ_BYTES);
      const decoder = new StringDecoder('utf8');
      let number = first;
      let rest = '';
      for (;;) {
        const { bytesRead } = await handle.read(buf, 0, READ_BYTES, null);
        if (bytesRead === 0) return;
        const lines = `${rest}${decoder.write(buf.subarray(0, bytesRead))}`.split('\n');
        rest = /** @type {string} */ (lines.pop());
        for (const line of lines) {
          if (line === '' || line[0] === WATERMARK) continue;
          if (number >= to) return;
          if (number >= from) visit(line, number);
          number += 1;
        }
      }
    } finally {
      await handle.close();
    }
  }

  /** Adds a row to whole lines, however they wrapped. @param {string[]} lines @param {string} row @param {boolean} ansi */
  _add(lines, row, ansi) {
    const text = ansi ? row.slice(1) : plain(row.slice(1));
    if (row[0] === CONTINUES && lines.length) lines[lines.length - 1] += text;
    else lines.push(text);
  }

  /**
   * The rows with these numbers, as whole lines, or null if some of them have gone.
   * @param {number} from @param {number} to `to` excluded @param {{ansi?: boolean, lastChars?: number|null}} [o] lastChars: only this much of the last line
   * @returns {Promise<string[]|null>}
   */
  async range(from, to, { ansi = false, lastChars = null } = {}) {
    const files = this._files();
    if (!files.length || files[0].first > from) return null;
    /** @type {string[]} */
    const lines = [];
    let seen = false;
    await this._scan(from, to, (row) => {
      this._add(lines, row, ansi);
      seen = true;
    });
    if (lastChars !== null && lines.length) lines[lines.length - 1] = cutLine(lines[lines.length - 1], lastChars);
    return !seen && to > from ? null : lines;
  }

  /**
   * The last lines there are.
   * @param {number|null} count null: all of them @param {{ansi?: boolean}} [o] @returns {Promise<string[]>}
   */
  async lastLines(count, { ansi = false } = {}) {
    /** @type {string[]} */
    let lines = [];
    await this._scan(0, this.lines, (row) => {
      this._add(lines, row, ansi);
      if (count !== null && lines.length > count * 2 + 1) lines = lines.slice(-count - 1);    // the last may yet be added to
    });
    return count === null ? lines : lines.slice(-count);
  }

  close() {
    if (this.fd === null) return;
    try { fs.closeSync(this.fd); } catch { /* already */ }
    this.fd = null;
  }
}

module.exports = { Spool, plain };
