'use strict';
// @ts-check
const { Terminal } = require('@xterm/headless');
const { Unicode11Addon } = require('@xterm/addon-unicode11');
const { rewriteRow } = require('./adapter');
const { logicalLines, firstWrittenLine, serializeRows, cutLine } = require('./cells');

/** @typedef {import('./pipeline').AnnotatedChunk} AnnotatedChunk */

/** xterm refuses anything narrower. */
const MIN_COLS = 2;

/** A right prompt is this far from what the prompt ends with, and from the edge, or less far from the edge. */
const RIGHT_PROMPT_GAP = 2;

/** How much xterm parses between chances for anything else to run. */
const WRITE_SLICE = 65536;

/**
 * How much of `bytes` from `from` can go in without more than `rows` new rows. An overestimate, cheap to work out: a row needs a line
 * feed of some kind, an escape sequence, or a line's worth of text.
 * @param {Buffer} bytes @param {number} from @param {number} rows @param {number} cols
 */
function bytesForRows(bytes, from, rows, cols) {
  const end = Math.min(bytes.length, from + WRITE_SLICE);
  let breaks = 0;
  for (let i = from; i < end; i++) {
    const b = bytes[i];
    if (b === 0x0a || b === 0x0b || b === 0x0c || b === 0x1b || b === 0x84 || b === 0x85) breaks += 1;
    if (breaks + (i - from) / cols >= rows) return Math.max(1, i - from);
  }
  return end - from;
}

/**
 * Snapshot emulator, in one of two geometries.
 *
 * Tracking: the emulator is the pty's size and is resized at the stream offset the pty was, so what wrapped or scrolled
 * in the terminal wrapped and scrolled here too. Live bytes never pass through it; it serves joins, capture and CPR.
 *
 * Fixed: one 240×150 xterm with Unicode 11, aligned ONCE so the PTY screen is its bottom rows, never resized, and fed
 * through the same Δ row rewrite as a client that is 150 rows tall. For a program that repaints its whole screen, which
 * survives no resize reflow.
 *
 * Chunks queue and are parsed a batch at a time, so a program printing a line at a time costs what the bytes cost rather
 * than a timer tick each. `onParsed` reports how far parsing has reached: that is what the holder's flow control runs on.
 */
class Emulator {
  /** @param {{cols?: number, rows?: number, scrollback?: number, tracking?: boolean}} [o] */
  constructor({ cols = 240, rows = 150, scrollback = 10000, tracking = false } = {}) {
    this.cols = cols;
    this.rows = rows;
    this.tracking = tracking;
    this.scrollback = scrollback;
    this.term = new Terminal({ cols, rows, scrollback, allowProposedApi: true });
    this.term.loadAddon(new Unicode11Addon());
    this.term.unicode.activeVersion = '11';
    /**
     * DECSC slots per buffer, recorded exactly as xterm stores them: x column and y ABSOLUTE line (baseY + cursorY), so a
     * later scroll moves the saved position with the content (xterm's restoreCursor subtracts the current ybase).
     * @type {{normal: {x: number, y: number}|null, alternate: {x: number, y: number}|null}}
     */
    this.saved = { normal: null, alternate: null };
    /** stream offset up to which xterm has parsed */
    this.processedOffset = 0;
    /** @type {Map<number, {x: number, y: number, alt: boolean}>} cursor at each CPR query, keyed by the query's end offset */
    this.cprAt = new Map();
    /** @type {AnnotatedChunk[]} */
    this.queue = [];
    this.draining = false;
    /** @type {Promise<void>} resolves when every chunk fed so far has been parsed */
    this.tail = Promise.resolve();
    /** @type {(offset: number) => void} */
    this.onParsed = () => {};
    /** @type {(mark: import('../../vt/marks').Mark, at: {row: number, col: number}, offset: number) => void} a shell's mark, exactly where it fell */
    this.onMark = () => {};
    /**
     * Rows of the normal buffer that have left it, ever. A row's number is this plus its index: unlike an index it stays true
     * as history is trimmed. It is what lets something say "this line" for longer than a moment.
     */
    this.trimmed = 0;
    /** @type {{lines: any}|null} */
    this.watched = null;
    /** @type {Set<{row: number}>} rows something is relying on: a reflow renumbers rows, and these have to follow */
    this.pins = new Set();
    /** @type {import('./spool').Spool|null} */
    this.spool = null;
    /** @type {{row: number}|null} the first row not in the spool yet */
    this.unspooled = null;
    /** @type {(from: number, to: number, line: number) => void} rows, and the spool's number for the first of them */
    this.onSpooled = () => {};
    /** @type {(top: number) => void} the screen was wiped, and this is its first row */
    this.onErased = () => {};
    this._watchTrims();
  }

  /** Every row that leaves the screen goes to `spool` from now on. @param {import('./spool').Spool} spool */
  keepRowsIn(spool) {
    this.spool = spool;
    this.unspooled = this.pin(0);
  }

  /** The screen was wiped: whatever is on it from now on is new, even at rows already written. */
  _erased() {
    const top = this.screenTop(this.rows);
    if (this.unspooled && this.unspooled.row > top) this.unspooled.row = top;
    this.onErased(top);
  }

  /** The first row still to go to the spool carries on a line that started in it. */
  unspooledContinues() {
    const { unspooled } = this;
    if (!unspooled) return false;
    const line = this.term.buffer.normal.getLine(this.index(unspooled.row));
    return !!line && line.isWrapped;
  }

  /**
   * Rows that have left the screen go to the spool, before the buffer can trim them, a whole line at a time: rows are only rows until
   * the next reflow, and a line half in the spool could not be told from one not in it. Only a line too long to wait for is divided.
   * @param {number} offset how far into the program's output they go
   */
  _spoolRows(offset) {
    const { spool, unspooled } = this;
    if (!spool || !unspooled) return;
    this._watchTrims();
    const b = this.term.buffer.normal;
    let end = b.baseY;
    const stop = Math.max(0, end - Math.floor(this.scrollback / 4));
    while (end > stop && /** @type {any} */ (b.getLine(end)).isWrapped) end -= 1;
    if (end === stop && stop > 0) end = b.baseY;
    const to = this.trimmed + end;
    if (unspooled.row < 0) unspooled.row = this.trimmed;                               // its line has gone, so nothing still here has been written
    const from = Math.max(unspooled.row, this.trimmed);
    if (from < to && !spool.alreadyHas(offset)) {
      const first = from - this.trimmed;
      const texts = serializeRows(b, first, end);
      const wrapped = texts.map((_, i) => /** @type {any} */ (b.getLine(first + i)).isWrapped);
      this.onSpooled(from, to, spool.append(texts, wrapped, offset));
    }
    unspooled.row = Math.max(unspooled.row, to);                                       // a taller screen brings rows back that are already written
  }

  /** xterm replaces the buffer on a full reset, and everything in the old one has gone. */
  _watchTrims() {
    const { normal } = /** @type {any} */ (this.term)._core.buffers;
    if (normal === this.watched) return;
    if (this.watched) this.trimmed += this.watched.lines.length;
    this.watched = normal;
    normal.lines.onTrim((/** @type {number} */ n) => { this.trimmed += n; });
  }

  /** @param {string|Buffer} data @returns {Promise<void>} */
  _write(data) {
    if (data.length <= WRITE_SLICE) return new Promise((resolve) => this.term.write(data, () => resolve(undefined)));
    const bytes = Buffer.isBuffer(data) ? data : Buffer.from(data);
    let at = 0;
    for (; at + WRITE_SLICE < bytes.length; at += WRITE_SLICE) this.term.write(bytes.subarray(at, at + WRITE_SLICE));
    return new Promise((resolve) => this.term.write(bytes.subarray(at), () => resolve(undefined)));
  }

  /**
   * In pieces too small to scroll a row past both the screen and the history, so that none leaves unseen. A piece ends exactly
   * where an earlier server stopped writing, so that each row is written once.
   * @param {Buffer} bytes @param {number} at how far into the program's output these start
   */
  async _writeSpooled(bytes, at) {
    const spool = /** @type {import('./spool').Spool} */ (this.spool);
    const rows = Math.max(1, Math.floor(this.scrollback / 2));
    for (let done = 0; done < bytes.length;) {
      const toEdge = spool.through - (at + done);
      const fits = bytesForRows(bytes, done, rows, this.cols);
      const n = toEdge > 0 ? Math.min(fits, toEdge) : fits;
      await new Promise((resolve) => this.term.write(bytes.subarray(done, done + n), () => resolve(undefined)));
      done += n;
      this._spoolRows(at + done);
    }
  }

  /**
   * Call exactly once. Fixed: aligns the PTY screen with the bottom `ptyRows` rows. Tracking: takes the pty's size and
   * gives the buffer blank history, as any real terminal has, because that decides where text lands when a resize reflows it.
   * @param {number} ptyRows @param {number} [ptyCols]
   */
  async init(ptyRows, ptyCols = this.cols) {
    if (!this.tracking) { await this._write('\r\n'.repeat(this.rows - ptyRows)); return; }
    this._resize(ptyCols, ptyRows);
    await this._write(`${'\r\n'.repeat(ptyRows)}\x1b[H`);
    if (this.unspooled) this.unspooled.row = this.trimmed + this.term.buffer.normal.baseY;   // the blank history is nobody's output
  }

  /** Takes this size, with everything fed so far parsed at the old one. @param {number} cols @param {number} rows */
  resizeTo(cols, rows) { if (cols !== this.cols || rows !== this.rows) this._resize(cols, rows); }

  /**
   * Keeps pins on their rows through a resize. A reflow renumbers rows, but it moves xterm's line objects rather than making new
   * ones, and those keep their place where its own markers do not once the buffer is full. A row the reflow merged away goes by
   * how far into its line it was. A pin nothing can place any more, because the reflow trimmed its line, is lost.
   * @param {number} cols @param {number} rows
   */
  _resize(cols, rows) {
    this._watchTrims();
    const { lines } = /** @type {any} */ (this.term)._core.buffers.normal;
    const before = this.cols;
    const held = [...this.pins].filter((pin) => pin.row >= this.trimmed).map((pin) => {
      const y = pin.row - this.trimmed;
      let head = Math.min(y, lines.length - 1);
      while (head > 0 && lines.get(head).isWrapped) head -= 1;
      return { pin, own: lines.get(y), head: lines.get(head), into: y - head };
    });
    this.term.resize(Math.max(MIN_COLS, cols), rows);
    this.cols = this.term.cols;
    this.rows = this.term.rows;
    if (held.length === 0) return;
    /** @type {Map<any, number>} */
    const at = new Map();
    for (let i = 0; i < lines.length; i++) at.set(lines.get(i), i);
    for (const { pin, own, head, into } of held) {
      const row = at.get(own);
      const start = at.get(head);
      if (row !== undefined && (start === undefined || row - start === into)) pin.row = this.trimmed + row;
      else pin.row = start === undefined ? -1 : this.trimmed + start + Math.floor((into * before) / this.cols);
    }
  }

  /** Keeps a row's number true for as long as it is needed. Gone from memory: `row` is below `trimmed`. @param {number} row @returns {{row: number}} */
  pin(row) {
    const p = { row };
    this.pins.add(p);
    return p;
  }

  /** @param {{row: number}} p */
  unpin(p) { this.pins.delete(p); }

  /** The cursor on the normal screen, wherever a program has gone since. */
  _cursor() {
    this._watchTrims();
    const b = this.term.buffer.normal;
    return { row: this.trimmed + b.baseY + b.cursorY, col: b.cursorX };
  }

  /** The row the cursor is on. */
  cursorRow() { return this._cursor().row; }

  /** What is on the cursor's row from the cursor on. */
  rightOfCursor() {
    const b = this.term.buffer.normal;
    const line = b.getLine(b.baseY + b.cursorY);
    return line ? line.translateToString(false, b.cursorX) : '';
  }

  /**
   * Whether what is typed at the cursor has anything after it. What was there when the prompt was drawn does not count, and neither
   * does what stands apart against the right edge, which is how a right prompt looks if it was drawn later.
   * @param {string} [drawn]
   */
  textAtCursor(drawn) {
    const b = this.term.buffer.normal;
    const right = this.rightOfCursor();
    if (right === drawn) return false;
    const start = right.search(/\S/);
    if (start < 0) return false;
    return start < RIGHT_PROMPT_GAP || right.trimEnd().length + b.cursorX < this.cols - RIGHT_PROMPT_GAP;
  }

  /** A program has the screen, so nothing about the shell's cursor can be told from it. */
  get onAlternate() { return this.term.buffer.active.type === 'alternate'; }

  /** The whole lines of the normal buffer between two rows, or null if any of them have gone. @param {number} from @param {number} to `to` excluded */
  linesBetween(from, to) {
    this._watchTrims();
    if (from < this.trimmed) return null;
    return logicalLines(this.term.buffer.normal, from - this.trimmed, Math.max(from, to) - this.trimmed);
  }

  /** The length of a line as far as a place on its last row. @param {{row: number, col: number}} at */
  lineUpTo({ row, col }) {
    const b = this.term.buffer.normal;
    const y = this.index(row);
    let head = y;
    while (head > 0 && /** @type {any} */ (b.getLine(head)).isWrapped) head -= 1;
    return logicalLines(b, head, y + 1).join('').length - /** @type {any} */ (b.getLine(y)).translateToString(true, col).length;
  }

  /** The row after the end of the line a row is on. @param {number} row */
  lineEnd(row) {
    const b = this.term.buffer.normal;
    let y = this.index(row) + 1;
    while (y < b.length && /** @type {any} */ (b.getLine(y)).isWrapped) y += 1;
    return this.trimmed + y;
  }

  /** The first row of the PTY screen. @param {number} screenRows */
  screenTop(screenRows) {
    this._watchTrims();
    return this.trimmed + this.term.buffer.normal.baseY + this._above(screenRows);
  }

  /** Where a row is in the buffer now, or its start if it has gone. @param {number} row */
  index(row) {
    this._watchTrims();
    return Math.max(row - this.trimmed, 0);
  }

  /** The line the cursor is on, up to the cursor, however it wrapped: at a prompt, that is the prompt and whatever is typed before the cursor. */
  lineBeforeCursor() {
    const b = this.term.buffer.normal;
    const y = b.baseY + b.cursorY;
    let head = y;
    while (head > 0 && /** @type {any} */ (b.getLine(head)).isWrapped) head -= 1;
    let text = '';
    for (let i = head; i < y; i++) text += /** @type {any} */ (b.getLine(i)).translateToString(false);
    return text + /** @type {any} */ (b.getLine(y)).translateToString(false, 0, b.cursorX);
  }

  /**
   * Whole lines of the normal buffer between two rows, for as many of them as it still holds.
   * @param {number} from @param {number} to row numbers, `to` excluded @param {{ansi?: boolean, lastChars?: number|null}} [o]
   *   lastChars: only this much of the last line
   * @returns {{lines: string[], complete: boolean}} complete: nothing asked for had gone
   */
  text(from, to, { ansi = false, lastChars = null } = {}) {
    this._watchTrims();
    const first = Math.max(from - this.trimmed, 0);
    const lines = logicalLines(this.term.buffer.normal, first, Math.max(first, to - this.trimmed), { ansi });
    if (lastChars !== null && lines.length) lines[lines.length - 1] = cutLine(lines[lines.length - 1], lastChars);
    return { lines, complete: from >= this.trimmed };
  }

  /**
   * What has been shown from `row` on: the rows up to the cursor, or the alternate screen when a program is on it, which has no
   * history. For following output as text: `top` and `cursor` are where to carry on from, to see what is on the screen again or
   * only what comes next.
   * @param {number|null} row null: the top of the screen @returns {{text: string, top: number, cursor: number}}
   */
  since(row) {
    this._watchTrims();
    const { normal, active } = this.term.buffer;
    const top = this.trimmed + normal.baseY;
    let start = normal.baseY + normal.cursorY;
    if (active.type === 'alternate') return { text: logicalLines(active, 0, this.rows).join('\n'), top, cursor: this.trimmed + start };
    const end = start;
    for (; start > 0 && /** @type {any} */ (normal.getLine(start)).isWrapped; start--);
    const from = row === null ? normal.baseY : Math.max(row - this.trimmed, 0);
    return { text: logicalLines(normal, from, Math.max(from, end + 1)).join('\n'), top, cursor: this.trimmed + start };
  }

  /** @param {AnnotatedChunk} chunk @returns {Promise<void>} resolves when xterm has parsed the chunk */
  feed(chunk) {
    this.queue.push(chunk);
    if (!this.draining) { this.draining = true; this.tail = this._drain(); }
    return this.tail;
  }

  async _drain() {
    while (this.queue.length) {
      const batch = this.queue;
      this.queue = [];
      await this._parse(batch);
      this.processedOffset = batch[batch.length - 1].endOffset;
      this.onParsed(this.processedOffset);
    }
    this.draining = false;
  }

  /** @param {AnnotatedChunk[]} batch */
  async _parse(batch) {
    /** @type {Buffer[]} */
    const parts = [];
    let at = 0;
    let next = 0;
    const flush = async () => {
      const bytes = Buffer.concat(parts);
      parts.length = 0;
      await (this.spool ? this._writeSpooled(bytes, at) : this._write(bytes));
    };
    /** A spool has to know where in the output each byte came from, so only stretches that adjoin go in together. @param {number} offset */
    const breaks = (offset) => this.spool !== null && parts.length > 0 && offset !== next;
    /** @param {Buffer} bytes @param {number} offset */
    const add = (bytes, offset) => {
      if (parts.length === 0) at = offset;
      parts.push(bytes);
      next = offset + bytes.length;
    };
    for (const chunk of batch) {
      let pos = 0;
      for (const e of chunk.edits) {
        if (breaks(chunk.startOffset + pos)) await flush();
        add(chunk.bytes.subarray(pos, e.start), chunk.startOffset + pos);
        pos = e.end;
        if (e.kind === 'resize') {
          await flush();
          this._resize(/** @type {number} */ (e.cols), /** @type {number} */ (e.rows));
          continue;
        }
        if (e.kind === 'drop') {
          if (e.query === 'CPR' || e.query === 'DECXCPR') {                    // record the cursor exactly where the query was
            await flush();
            const b = this.term.buffer.active;
            this.cprAt.set(chunk.startOffset + e.end, { x: b.cursorX, y: b.cursorY, alt: b.type === 'alternate' });
            if (this.cprAt.size > 64) this.cprAt.delete(/** @type {number} */ (this.cprAt.keys().next().value));
          }
          continue;
        }
        if (e.kind === 'erase') {
          add(e.raw, chunk.startOffset + e.start);
          await flush();
          this._erased();
          continue;
        }
        if (e.kind === 'mark') {                               // xterm has no use for it, and where it fell is the whole point
          await flush();
          this.onMark(/** @type {import('../../vt/marks').Mark} */ (e.mark), this._cursor(), chunk.startOffset + e.end);
          continue;
        }
        if (e.kind === 'row') {
          const d = Math.max(0, this.rows - /** @type {number} */ (e.renderRows));
          if (breaks(chunk.startOffset + e.start)) await flush();
          add(d ? rewriteRow(e, /** @type {number} */ (e.row) + d) : e.raw, chunk.startOffset + e.start);
          continue;
        }
        if (e.kind === 'decsc' || (e.kind === 'alt-enter' && (e.modes || []).includes(1049))) {
          // ?1049h and ESC 7 save the cursor of the buffer active BEFORE the token: parse up to it, then record
          await flush();
          const b = this.term.buffer.active;
          this.saved[b.type === 'alternate' ? 'alternate' : 'normal'] = { x: b.cursorX, y: b.baseY + b.cursorY };
        }
        if (breaks(chunk.startOffset + e.start)) await flush();
        add(e.raw, chunk.startOffset + e.start);              // alt-exit, title, clipboard and the rest: unchanged
      }
      if (breaks(chunk.startOffset + pos)) await flush();
      add(chunk.bytes.subarray(pos), chunk.startOffset + pos);
    }
    await flush();
    this._watchTrims();
  }

  /** The active buffer's scroll margins, 0-based and inclusive. xterm has no public way to read them. */
  margins() {
    const b = /** @type {any} */ (this.term)._core.buffer;
    return { top: b.scrollTop, bottom: b.scrollBottom };
  }

  /** Rows of the buffer below which the PTY screen starts. @param {number} screenRows */
  _above(screenRows) { return this.tracking ? 0 : this.rows - screenRows; }

  /**
   * Scrollback and screen as text, whole lines however they wrapped; the active screen stands in for the normal one
   * while a program is on the alternate screen.
   * @param {{lines?: number|null, ansi?: boolean}} [o] @returns {string}
   */
  capture(o = {}) {
    const wanted = this.captureLines(o);
    return wanted.length ? `${wanted.join('\n')}\n` : '';
  }

  /**
   * @param {{lines?: number|null, ansi?: boolean, unspooled?: boolean}} [o] unspooled: only what has not gone to the spool
   * @returns {string[]}
   */
  captureLines({ lines = null, ansi = false, unspooled = false } = {}) {
    this._watchTrims();
    const { normal, active } = this.term.buffer;
    const from = unspooled && this.unspooled ? this.index(this.unspooled.row) : firstWrittenLine(normal, normal.baseY);
    const onAlt = active.type === 'alternate';
    const held = logicalLines(normal, from, Math.max(from, normal.baseY + (onAlt ? 0 : this.rows)), { ansi });
    const screen = onAlt ? logicalLines(active, 0, this.rows, { ansi }) : held;
    while (screen.length && screen[screen.length - 1] === '') screen.pop();
    const all = onAlt ? [...held, ...screen] : held;
    return lines === null ? all : all.slice(-lines);
  }

  /** Text of the PTY screen: the bottom `screenRows` rows of the viewport (top rows when alt is active). */
  screenText(screenRows) {
    const b = this.term.buffer.active;
    const first = b.type === 'alternate' ? 0 : b.baseY + this._above(screenRows);
    const lines = [];
    const count = this.tracking ? this.rows : screenRows;
    for (let i = first; i < first + count; i++) { const l = b.getLine(i); lines.push(l ? l.translateToString(true) : ''); }
    return lines.join('\n');
  }

  /**
   * The cursor position report the PTY would get: at the query's end offset when given and recorded, else now.
   * @param {number} screenRows @param {{decx?: boolean, offset?: number}} [o] @returns {Buffer}
   */
  cpr(screenRows, { decx = false, offset } = {}) {
    let pos = offset !== undefined ? this.cprAt.get(offset) : undefined;
    if (offset !== undefined) this.cprAt.delete(offset);
    if (!pos) { const b = this.term.buffer.active; pos = { x: b.cursorX, y: b.cursorY, alt: b.type === 'alternate' }; }
    const row = pos.alt ? pos.y + 1 : pos.y - this._above(screenRows) + 1;
    return Buffer.from(`\x1b[${decx ? '?' : ''}${Math.max(1, row)};${pos.x + 1}R`);
  }
}

module.exports = { Emulator };
