'use strict';
// @ts-check
const { EventEmitter } = require('node:events');
const { T } = require('../../wire/proto');
const { DEFAULT_MESSAGES } = require('../messages');
const { ClientAdapter } = require('../output/adapter');
const { runJoin, runResync, waitEvent } = require('./join');

const JOIN_POLL_MS = 10;
/** Terminals that left, remembered. Each one holds a pin. */
const MAX_DEPARTURES = 32;
const MAX_TERMINAL_ID = 512;
const { armHeartbeat } = require('./heartbeat');

/**
 * @typedef {{id: string, fsock: import('../../wire/proto').FramedSocket, sock: import('node:net').Socket, hello: any, label: string,
 *   adapter: ClientAdapter, flags: {shrink: boolean, allowSetup: boolean, allowGated: boolean, view: boolean}, lastPongAt: number, pingSeq: number, pingTimer: any,
 *   closed: boolean, lastInputAt: number, joining: boolean, asked: any, attachedAt: number, sentOutput: number}} Client
 */

/**
 * The attached clients: who is here, what reaches them, resize and PAUSED, detach and overflow. The join and the
 * heartbeat have files of their own.
 */
class ClientHub extends EventEmitter {
  /** @param {{config: any, clock: import('../../base/types').Clock, log: any, session: import('../session/session').Session, messages?: import('../messages').Messages}} o */
  constructor({ config, clock, log, session, messages = DEFAULT_MESSAGES }) {
    super();
    this.config = config;
    this.clock = clock;
    this.log = log;
    this.session = session;
    this.messages = messages;
    /** @type {Client[]} */
    this.clients = [];
    /** @type {Set<import('../../wire/proto').FramedSocket>} control connections: they get STATE, never OUTPUT */
    this.watchers = new Set();
    /** @type {import('../input/input').InputRouter|null} */
    this.router = null;
    /** @type {import('./arbiter').Arbiter|null} */
    this.arbiter = null;
    this.seq = 0;
    /**
     * Where each terminal that left had got to, by what it calls itself. Kept here rather than given to the terminal: only this
     * side can follow a row through a reflow, and a terminal needs no file for a session it may never come back to.
     * @type {Map<string, import('../session/session').Bookmark>} oldest first
     */
    this.departures = new Map();
    session.on('chunk', (chunk) => { for (const c of this.clients) c.adapter.render(chunk); });
    session.on('gap', (bytes) => { for (const c of this.clients) c.adapter.skip(bytes, { lost: true }); });
    session.on('notice', ({ level, code, text }) => this.noticeAll(level, code, text));
    session.on('clientNotice', ({ client, level, code, text }) => { if (client && client.adapter) client.adapter.notice(level, code, text); });
    session.on('clientExit', (id) => {
      const c = this.clients.find((x) => x.id === id);
      if (c) this.bye(c, 'CLIENT_EXIT', false, this.messages.clientExit(this.session.name));
    });
    session.on('lifecycle', () => this.broadcastState());
    session.on('attrs', () => { for (const c of this.clients) c.adapter.setAttention(this.session.attention); this.broadcastState(); });
    session.on('pty', () => this.broadcastState());
  }

  nextId() { this.seq += 1; return `c${this.seq}`; }

  /** @param {Client} c @param {number} type @param {Buffer|object} payload */
  sendTo(c, type, payload) {
    if (type === T.OUTPUT) c.sentOutput += /** @type {Buffer} */ (payload).length;
    c.fsock.send(type, payload);
  }

  /**
   * A terminal is leaving. It is remembered only if it has everything sent to it: what was still on its way when it stopped reading
   * is not in its scrollback, and treating it as seen would leave a hole there.
   * @param {Client} c @param {{received?: number}} m
   */
  _remember(c, m) {
    const key = c.hello.terminal;
    const a = c.adapter;
    if (typeof key !== 'string' || key.length > MAX_TERMINAL_ID || a.phase !== 'LIVE' || a.behind || a.hasGaps || m.received !== c.sentOutput) return;
    this._forget(key);
    this.departures.set(key, this.session.bookmark());
    if (this.departures.size > MAX_DEPARTURES) this._forget(/** @type {string} */ (this.departures.keys().next().value));
  }

  /** @param {string} key */
  _forget(key) {
    const b = this.departures.get(key);
    if (!b) return;
    this.departures.delete(key);
    this.session.emulator.unpin(b.top);
    this.session.emulator.unpin(b.cursor);
  }

  /**
   * Where a terminal that has come back had got to, once: it is here now. Null for one not seen before.
   * @param {string|null|undefined} key @returns {import('../session/session').Bookmark|null}
   */
  returning(key) {
    const b = typeof key === 'string' ? this.departures.get(key) : undefined;
    if (!b) return null;
    this._forget(/** @type {string} */ (key));
    return b.top.row < 0 ? null : b;
  }

  /** The adapters the arbiter measures. */
  adapters() { return this.clients.map((c) => c.adapter); }

  info() {
    return this.clients.map((c) => ({ id: c.id, label: c.label, view: c.flags.view, cols: c.adapter.cols, rows: c.adapter.rows, phase: c.adapter.phase,
      stalled: c.adapter.stalled, unresponsive: c.adapter.unresponsive, lastInputAt: c.lastInputAt }));
  }

  /**
   * The attached clients with what a listing shows. Ages are relative (ms) because the clock is monotonic;
   * `idleMs` is null for a client that has never typed.
   */
  listing() {
    const now = this.clock.now();
    return this.clients.map((c) => ({ id: c.id, label: c.label, view: c.flags.view, tty: typeof c.hello.tty === 'string' ? c.hello.tty : null,
      pid: Number.isInteger(c.hello.pid) && c.hello.pid > 0 ? c.hello.pid : null, termProgram: typeof c.hello.termProgram === 'string' ? c.hello.termProgram : null,
      cols: c.adapter.cols, rows: c.adapter.rows, phase: c.adapter.phase, stalled: c.adapter.stalled, unresponsive: c.adapter.unresponsive,
      attachedMs: now - c.attachedAt, idleMs: c.lastInputAt > 0 ? now - c.lastInputAt : null }));
  }

  /**
   * Detaches the named clients (BYE KICKED, no auto-rejoin), or with `allExcept` every client not named. The session
   * itself is untouched. Ids that are not attached are reported back rather than failing the others.
   * @param {{clients?: string[], allExcept?: string[], by?: string}} o
   * @returns {{kicked: Array<{id: string, label: string}>, unknown: string[]}}
   */
  kick({ clients, allExcept, by = '' }) {
    const who = `detached by ${by || this.messages.defaultKickedBy}`;
    let targets;
    /** @type {string[]} */
    let unknown = [];
    if (allExcept) {
      targets = this.clients.filter((c) => !allExcept.includes(c.id));
    } else {
      const ids = clients || [];
      targets = this.clients.filter((c) => ids.includes(c.id));
      unknown = ids.filter((id) => !targets.some((c) => c.id === id));
    }
    for (const c of targets) {
      this.log.info('client.kicked', { client: c.id, label: c.label, by });
      // `text` is for attach clients that predate KICKED (they print it after "ended (kicked)"); current ones use `by`.
      this.bye(c, 'KICKED', false, this.messages.kicked(who, this.session.name), { by });
    }
    return { kicked: targets.map((c) => ({ id: c.id, label: c.label })), unknown };
  }

  /**
   * These terminals asked to leave, which is not the same as being thrown off: they are told so, and the session goes on.
   * @param {string[]} ids @returns {{kicked: Array<{id: string, label: string}>, unknown: string[]}}
   */
  leave(ids) {
    const targets = this.clients.filter((c) => ids.includes(c.id));
    for (const c of targets) this.bye(c, 'CLIENT_EXIT', false, this.messages.clientExit(this.session.name));
    return { kicked: targets.map((c) => ({ id: c.id, label: c.label })), unknown: ids.filter((id) => !targets.some((c) => c.id === id)) };
  }

  /**
   * Registers a validated HELLO{role:'attach'} and starts its join.
   * @param {import('../../wire/proto').FramedSocket} fsock @param {import('node:net').Socket} sock @param {any} hello @param {string} id @returns {Client}
   */
  add(fsock, sock, hello, id) {
    const allowGated = !!(hello.flags && (hello.flags.allowGated || hello.flags.allowSetup));
    const flags = { shrink: !!(hello.flags && hello.flags.shrink), allowSetup: allowGated, allowGated, view: !!(hello.flags && hello.flags.view) };
    /** @type {Client} */
    const c = /** @type {any} */ ({ id, fsock, sock, hello, label: String(hello.label || id), flags, lastPongAt: this.clock.now(), pingSeq: 0, pingTimer: null, closed: false, lastInputAt: 0, joining: false, asked: null, attachedAt: this.clock.now(), sentOutput: 0 });
    c.adapter = new ClientAdapter({ id, cols: hello.cols, rows: hello.rows, flags, label: c.label, config: this.config, tracker: this.session.tracker, clock: this.clock, messages: this.messages,
      send: (type, payload) => { this.sendTo(c, type, payload); }, writableLength: () => fsock.writableLength,
      onDrop: (reason) => { this.log.info('client.bye', { client: id, reason }); this._close(c); },
      onBehind: () => this._startResync(c) });
    if (this.session.attention) c.adapter.setAttention(true);
    this.clients.push(c);
    if (this.session.agent && !flags.view) this.session.agent.arrived(id, hello.agent);  // a viewer is watching, not lending its keys
    this.emit('client', c);
    if (this.router) this.router.addClient(c);
    fsock.on('frame', (/** @type {{type: number, payload: any}} */ f) => this._frame(c, f));
    fsock.on('close', () => this._close(c));
    fsock.on('error', () => {});
    armHeartbeat(this, c);
    this.broadcastState();
    this._startJoin(c);
    return c;
  }

  /**
   * Starts a join for `c`, unless one is already running for it (never two concurrent joins for the same client —
   * task-14 fix). `_resize()` mutates `a.cols`/`a.rows` unconditionally, before any phase check, so an in-flight
   * join always reads the client's CURRENT geometry once it reaches `buildJoinBytes`:
   * a second join requested while one is already running would only re-deliver the same (or, at best, a
   * marginally fresher) snapshot, so it is simply dropped rather than queued — see the task-14 fix report for the
   * reasoning and the case that ruled out queuing a follow-up join.
   * @param {Client} c
   */
  _startJoin(c) {
    if (c.closed || c.joining) return;
    c.joining = true;
    runJoin(this, c)
      .catch((e) => { this.log.error('join.failed', { client: c.id, error: String(e && e.message) }); this.bye(c, 'SESSION_ENDING', true, 'join failed'); })
      .finally(() => { c.joining = false; this._settle(c); });
  }

  /** Whatever was asked of a client while something else was being sent to it. @param {Client} c */
  _settle(c) {
    if (c.closed) return;
    const { asked } = c;
    c.asked = null;
    if (asked) this._requestResync(c, asked);
    else if (c.adapter.behind) this._startResync(c);
  }

  /** The client wants its screen drawn again. @param {Client} c @param {{alt?: boolean, skipped?: number}} m */
  _requestResync(c, m) {
    const a = c.adapter;
    if (c.joining) { c.asked = m; return; }
    if (m.alt === false) a.alt = false;
    const skipped = Number(m.skipped) || 0;
    if (skipped > 0) a.hasGaps = true;
    a.behind = true;
    a.skipped += skipped;
    this._startResync(c, { announce: skipped > 0, keepMain: skipped === 0 });
  }

  /** Resolves when no client is in the middle of a join, or after `ms`: what a session printed last must reach them. @param {number} ms */
  async joinsDone(ms) {
    const deadline = this.clock.now() + ms;
    while (this.clients.some((c) => c.joining) && this.clock.now() < deadline) await new Promise((r) => { this.clock.setTimeout(() => r(undefined), JOIN_POLL_MS); });
  }

  /** Resolves when a client has arrived, or after `ms`. @param {number} ms */
  whenClient(ms) { return this.clients.length ? Promise.resolve() : waitEvent(this, 'client', ms, this.clock); }

  /**
   * Skips a client ahead on its own connection, unless a join for it is running: that one ends in `_settle`.
   * @param {Client} c @param {{announce?: boolean, keepMain?: boolean}} [o] see runResync
   */
  _startResync(c, o = {}) {
    if (c.closed || c.joining) return;
    c.joining = true;
    this.log.info('client.behind', { client: c.id, skipped: c.adapter.skipped });
    runResync(this, c, o)
      .catch((e) => { this.log.error('resync.failed', { client: c.id, error: String(e && e.message) }); this.bye(c, 'SESSION_ENDING', true, 'resync failed'); })
      .finally(() => { c.joining = false; this._settle(c); });
  }

  /** @param {Client} c @param {{type: number, payload: any}} f */
  _frame(c, f) {
    if (c.closed) return;
    if (f.type === T.INPUT) {
      if (!c.flags.view && (c.adapter.phase === 'LIVE' || c.adapter.resyncing) && this.router) { c.lastInputAt = this.clock.now(); this.router.onInput(c, /** @type {Buffer} */ (f.payload)); }
      return;
    }
    if (f.type !== T.CONTROL) return;
    const m = f.payload;
    switch (m.t) {
      case 'PING': c.fsock.sendControl({ t: 'PONG', seq: m.seq }); break;
      case 'PONG':
        c.lastPongAt = this.clock.now();
        if (c.adapter.stalled) { c.adapter.stalled = false; if (this.arbiter) this.arbiter.onChange('unstall'); this.broadcastState(); }
        break;
      case 'RESIZE': this._resize(c, Number(m.cols) | 0, Number(m.rows) | 0); break;
      case 'DETACH': this._remember(c, m); this.bye(c, 'USER', false, ''); break;
      case 'RESYNC': this._requestResync(c, m); break;
      default: break;
    }
  }

  /** @param {Client} c @param {number} cols @param {number} rows */
  _resize(c, cols, rows) {
    if (cols < 1 || rows < 1) return;
    const a = c.adapter;
    const size = this.config.size;
    const floorC = c.flags.shrink ? size.hardMinCols : size.floorCols;
    a.setSize(cols, rows);
    if (cols < floorC || rows < size.floorRows) {
      if (a.phase !== 'PAUSED') {                                                  // below the floor: stop output, leave arbitration
        a.phase = 'PAUSED';
        this.sendTo(c, T.OUTPUT, Buffer.from(`\r\n\x1b[2m── ${this.messages.brand} · paused: this terminal is ${cols}x${rows}, below the ${floorC}x${size.floorRows} floor — enlarge it to resume ──\x1b[0m\r\n`));
        c.fsock.sendControl({ t: 'NOTICE', level: 'warn', code: 'PAUSED', text: `paused below the ${floorC}x${size.floorRows} floor` });
      }
    } else if (a.phase === 'PAUSED') {
      if (c.joining) {                                                                // growing back, with a snapshot already on its way
        a.resumeJoin();
        if (this.arbiter) this.arbiter.onChange('resize');
      } else this._startJoin(c);                                                      // growing back: full snapshot
      this.broadcastState();
      return;
    }
    if (this.arbiter) this.arbiter.onChange('resize');
    this.broadcastState();
  }

  /** @param {Client} c @param {string} reason @param {boolean} autoRejoin @param {string} text @param {object} [extra] */
  bye(c, reason, autoRejoin, text, extra) { if (!c.closed) c.adapter.drop(reason, autoRejoin, text, extra); }

  /** @param {Client} c */
  _close(c) {
    if (c.closed) return;
    c.closed = true;
    if (c.pingTimer !== null) { this.clock.clearTimeout(c.pingTimer); c.pingTimer = null; }
    this.clients = this.clients.filter((x) => x !== c);
    if (this.session.agent) this.session.agent.left(c.id);
    if (this.router) this.router.removeClient(c);
    try { c.fsock.end(); } catch { /* closed */ }
    if (this.arbiter) this.arbiter.onChange('leave');
    this.log.info('client.closed', { client: c.id });
    this.broadcastState();
  }

  /** @param {'info'|'warn'} level @param {string} code @param {string} text */
  noticeAll(level, code, text) { for (const c of this.clients) c.adapter.notice(level, code, text); }

  stateMessage() {
    const s = this.session.status();
    return { t: 'STATE', lifecycle: s.lifecycle, name: this.session.name, ...this.session.controller.stateFields(s), pty: s.pty, alt: s.alt, clients: this.info() };
  }

  broadcastState() {
    const msg = this.stateMessage();
    for (const c of this.clients) if (!c.closed) c.fsock.sendControl(msg);
    for (const w of this.watchers) w.sendControl(msg);
  }

  /** This server is going and another takes over: a terminal that is up to date is told how far it has got. @param {string} text */
  restarting(text) {
    const at = this.session.resumePoint();
    for (const c of [...this.clients]) {
      const { phase, behind, cols, rows } = c.adapter;
      this.bye(c, 'SESSION_ENDING', true, text, at && phase === 'LIVE' && !behind ? { resume: { ...at, cols, rows } } : {});
    }
  }

  /** @param {string} reason @param {boolean} autoRejoin @param {string} text @param {object} [extra] */
  byeAll(reason, autoRejoin, text, extra) { for (const c of [...this.clients]) this.bye(c, reason, autoRejoin, text, extra); }
}

module.exports = { ClientHub };
