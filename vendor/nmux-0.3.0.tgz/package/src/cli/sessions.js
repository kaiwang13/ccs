'use strict';
// @ts-check
/**
 * Which sessions exist. A session is a directory under the runtime dir, named by a random id that never changes;
 * its name is a field of `session.json`, so a rename moves no socket. The dir is `/tmp/nmux-<uid>` and not
 * `$XDG_RUNTIME_DIR`, because logging out removes the latter while the sessions in it keep running.
 */
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { writeAtomic } = require('../base/atomic');
const { tryLock, isLocked } = require('../platform/locks');
const { ensureRuntime } = require('../platform/runtime');
const { controlRequest, probeSocket } = require('../wire/ctlclient');
const { sessionLayout } = require('../wire/layout');
const sdk = require('../sdk');

const NAME = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
const LOCK_TRIES = 200;
const START_WAIT_MS = 10000;
const STATUS_WAIT_MS = 1500;
const sleep = (/** @type {number} */ ms) => new Promise((r) => setTimeout(r, ms));

/** @param {Record<string, string|undefined>} [env] */
function resolvePaths(env = process.env) {
  const uid = /** @type {() => number} */ (process.getuid)();
  const runtimeDir = path.resolve(env.NMUX_RUNTIME_DIR || `/tmp/nmux-${uid}`);
  const layout = sessionLayout(runtimeDir);
  const configHome = env.XDG_CONFIG_HOME || path.join(env.HOME || '/', '.config');
  return { ...layout, configFile: env.NMUX_CONFIG || path.join(configHome, 'nmux', 'config.json'),
    namesLock: path.join(runtimeDir, 'locks', 'names.lock'),
    specFile: (/** @type {string} */ id) => path.join(layout.sessionDir(id), 'session.json'),
    stateFile: (/** @type {string} */ id) => path.join(layout.sessionDir(id), 'state.json'),
    startingLock: (/** @type {string} */ id) => path.join(layout.sessionDir(id), 'starting.lock') };
}

/** @typedef {ReturnType<typeof resolvePaths>} Paths */

/** @param {string} name */
const validName = (name) => NAME.test(name);

/** @param {string} file @returns {any} */
function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; }
}

/** Something holds this session: its holder, its server, or the command still creating it. @param {Paths} paths @param {string} id */
const isAlive = (paths, id) => isLocked(paths.holderLock(id)) || isLocked(paths.sessiondLock(id)) || isLocked(paths.startingLock(id));

/** @param {Paths} paths @returns {Array<{id: string, name: string, spec: any, state: any, alive: boolean}>} */
function listSessions(paths) {
  let ids;
  try { ids = fs.readdirSync(path.join(paths.runtimeDir, 's')); } catch { return []; }
  const out = [];
  for (const id of ids) {
    const spec = readJson(paths.specFile(id));
    if (!spec) continue;
    out.push({ id, name: spec.name, spec, state: readJson(paths.stateFile(id)), alive: isAlive(paths, id) });
  }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}

/** @param {Paths} paths @param {string} name */
const findSession = (paths, name) => listSessions(paths).find((s) => s.name === name) || null;

/** Who else may be choosing a name right now. @template T @param {Paths} paths @param {() => T} fn @returns {Promise<T>} */
async function withNames(paths, fn) {
  ensureRuntime(paths);
  for (let i = 0; i < LOCK_TRIES; i++) {
    const lock = tryLock(paths.namesLock);
    if (lock) { try { return fn(); } finally { lock.release(); } }
    await sleep(10);
  }
  throw new Error('another nmux has held the session list for too long');
}

/** The first of `base`, `base-2`, `base-3`… no session uses. @param {Paths} paths @param {string} base */
function freeName(paths, base) {
  const taken = new Set(listSessions(paths).map((s) => s.name));
  if (!taken.has(base)) return base;
  for (let n = 2; ; n++) if (!taken.has(`${base}-${n}`)) return `${base}-${n}`;
}

/** @param {Paths} paths @param {string} id @param {{recover?: boolean, waitForClient?: boolean}} [o] */
function startServer(paths, id, o = {}) { sdk.startServer(paths.specFile(id), o); }

/** Resolves with the session's status once it answers. @param {Paths} paths @param {string} id */
async function waitRunning(paths, id) {
  const deadline = Date.now() + START_WAIT_MS;
  for (;;) {
    try {
      const r = await controlRequest(paths.ctlSock(id), 'STATUS', {}, { timeoutMs: 1000 });
      if (r.ok && r.data.lifecycle !== 'STARTING' && r.data.lifecycle !== 'RECOVERING') return r.data;
    } catch { /* not listening yet */ }
    if (Date.now() > deadline) throw new Error(`the session did not start; see ${paths.logFile(id, 'sessiond')}`);
    await sleep(20);
  }
}

/** Resolves once the server is listening. @param {Paths} paths @param {string} id */
async function waitListening(paths, id) {
  const deadline = Date.now() + START_WAIT_MS;
  while (!(await probeSocket(paths.ctlSock(id)))) {
    if (Date.now() > deadline) throw new Error(`the session did not start; see ${paths.logFile(id, 'sessiond')}`);
    await sleep(10);
  }
}

/**
 * The program starts at once, unless a terminal is about to attach (`attaching`): then it starts when that terminal
 * arrives, so nothing it prints, however briefly it runs, can go unseen.
 * @param {Paths} paths
 * @param {{name: string|null, base: string, argv: string[], cwd: string, env: Record<string, string|undefined>, cols: number, rows: number, term: string, attaching?: boolean, shell?: {token: string}|null, spool?: {maxBytes: number}|null}} o
 * @returns {Promise<{id: string, name: string}>}
 */
async function createSession(paths, { name, base, argv, cwd, env, cols, rows, term, attaching = false, shell = null, spool = null }) {
  const id = crypto.randomBytes(4).toString('hex');
  /** @type {{release(): void}|null} */
  let starting = null;
  const chosen = await withNames(paths, () => {
    if (name && findSession(paths, name)) throw Object.assign(new Error(`a session named '${name}' already exists`), { code: 'NAME_TAKEN' });
    const n = name || freeName(paths, base);
    fs.mkdirSync(paths.sessionDir(id), { recursive: true, mode: 0o700 });
    starting = tryLock(paths.startingLock(id));
    // A shell keeps the agent it started with long after that connection has gone. So it is given one name for it, which follows whoever attaches.
    const agent = env.SSH_AUTH_SOCK ? paths.agentLink(id) : null;
    if (agent) fs.symlinkSync(/** @type {string} */ (env.SSH_AUTH_SOCK), agent);
    writeAtomic(paths.specFile(id), { schema: 'nmux.session/1', id, name: n, runtimeDir: paths.runtimeDir, stateFile: paths.stateFile(id), configFile: paths.configFile,
      child: { argv, env: { ...env, NMUX_ID: id, NMUX_SESSION: n, ...(agent ? { SSH_AUTH_SOCK: agent } : {}) }, cwd }, pty: { cols, rows }, term, nestEnv: 'NMUX_ID', shell, agent, spool, createdAt: new Date().toISOString() });
    return n;
  });
  try {
    startServer(paths, id, { waitForClient: attaching });
    await (attaching ? waitListening : waitRunning)(paths, id);
  } finally {
    if (starting) /** @type {{release(): void}} */ (starting).release();
  }
  return { id, name: chosen };
}

/** @param {Paths} paths @param {string} id @param {string} name */
async function renameSession(paths, id, name) {
  await withNames(paths, () => {
    if (findSession(paths, name)) throw Object.assign(new Error(`a session named '${name}' already exists`), { code: 'NAME_TAKEN' });
    const spec = readJson(paths.specFile(id));
    spec.name = name;
    spec.child.env.NMUX_SESSION = name;
    writeAtomic(paths.specFile(id), spec);
  });
}

/** @param {Paths} paths @param {string} id */
function removeSession(paths, id) {
  fs.rmSync(paths.sessionDir(id), { recursive: true, force: true });
  fs.rmSync(path.join(paths.logDir, id), { recursive: true, force: true });
}

/** What a live session says about itself, or null when it does not answer in time. @param {Paths} paths @param {string} id */
async function statusOf(paths, id) {
  try {
    const r = await controlRequest(paths.ctlSock(id), 'STATUS', {}, { timeoutMs: STATUS_WAIT_MS });
    return r.ok ? r.data : null;
  } catch { return null; }
}

module.exports = { resolvePaths, validName, isAlive, listSessions, findSession, freeName, createSession, renameSession, removeSession, startServer, statusOf, waitRunning, readJson };
