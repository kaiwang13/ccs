'use strict';
// @ts-check
const { EventEmitter } = require('node:events');
const { Controller } = require('./controller');
const { KeyGuard } = require('../input/guard');
const { LastLine } = require('../input/lastline');

/**
 * @typedef {{attrs?: Record<string, unknown>, welcome?: Record<string, unknown>, stays?: boolean, detachKeys?: string[], forwardFocus?: boolean, heldKey?: string,
 *   guards?: Array<{keys: string[], marginMs: number, code?: string}>, match?: string[], stopGraceMs?: number, pingMs?: number, silentMs?: number,
 *   command?: {argv: string[], env?: Record<string, string>}}} Managed
 */

/** How long a stop waits for a controller that does not answer. */
const DEFAULT_STOP_GRACE_MS = 15000;
/** How long a stop waits for a controller to turn up, if one is expected. */
const ARRIVAL_WAIT_MS = 1500;

/**
 * A session whose program is understood by something outside this process: a controller reached over the control socket.
 * What has to happen on the keystroke path cannot wait for that, so it is declared in the session spec (`managed`) and
 * enforced here: which keys detach, which keys are guarded, whether the session outlives its child. Everything else is
 * told to the controller as events, and it answers with requests. If there is no controller the session keeps running and
 * stays attachable; only what the controller adds stops.
 *
 * Events on 'event': {event: 'holder'|'attached'|'replayed'|'tty'|'alt'|'match'|'exit'|'respawned'|'stopping'|'record', ...}.
 */
class RemoteController extends Controller {
  /** @param {Managed} managed */
  constructor(managed) {
    super();
    this.managed = managed;
    this.events = new EventEmitter();
    /** @type {Record<string, unknown>} */
    this.attrs = { ...(managed.attrs || {}) };
    /** @type {Map<string, {effect: 'drop'|'filter', passable: boolean, blocking: boolean, rank: number}>} */
    this.gateTable = new Map();
    this.lastLine = new LastLine();
    /** @type {KeyGuard|null} */
    this.guard = null;
    /** @type {RegExp[]} */
    this.patterns = (managed.match || []).map((m) => new RegExp(m));
    /** a controller is connected and listening */
    this.connected = false;
    /** @type {any} */
    this.controllerConn = null;
    /** @type {string[]|null} */
    this.nextArgv = null;
    this.lastAlt = false;
    /** @type {{icanon: boolean, isig: boolean, echo: boolean, fgIsChild: boolean, fg: number|null}|null} */
    this.tty = null;
    /** @type {(() => void)|null} the stop is waiting for the controller's first go */
    this.proceed = null;
    /** @type {(() => void)|null} the session is waiting for its last record to be written down */
    this.finished = null;
    this.recorded = false;
    /** @type {(() => void)|null} */
    this.arrived = null;
    /** An exit nobody was there to hear about. @type {object|null} */
    this.unheardExit = null;
  }

  /** @param {any} session */
  bind(session) {
    super.bind(session);
    const guards = this.managed.guards || [];
    if (guards.length === 0) return;
    this.guard = new KeyGuard({ clock: session.clock, marginMs: guards[0].marginMs, keys: guards.flatMap((g) => g.keys),
      write: (bytes, opts) => session.write(bytes, opts),
      held: (client, cls) => session.notifyClient(client, 'warn', guards[0].code || 'KEY_HELD', session.messages.heldKey(cls, session.name)) });
  }

  /** @param {string} event @param {object} [fields] */
  say(event, fields = {}) { this.events.emit('event', { event, ...fields }); }

  /** What a controller needs to know on arrival, whatever it missed, including what an earlier one left behind. */
  snapshot() {
    const s = this.session;
    const exit = this.unheardExit;
    this.unheardExit = null;
    return { holder: s.hello ? { gen: s.hello.gen, child: s.hello.child, pty: s.hello.pty } : null, tty: this.ttyEvent(), lifecycle: s.lifecycle, blockedCode: s.blockedCode,
      exited: s.exited, lastExit: s.lastExit, exit, gates: [...this.gateTable.keys()], launchedAtMs: s.launchedAtMs || null, name: s.name };
  }

  ttyEvent() { return this.tty ? { ...this.tty, alt: this.session.tracker.alt } : null; }

  // ---- facts -------------------------------------------------------------------------------------------------------
  /** @param {any} hello */
  onHolder(hello) {
    if (this.guard) this.guard.reset();
    this.say('holder', { gen: hello.gen, child: hello.child, pty: hello.pty });
  }

  onAttached() { this.say('attached'); }
  onReplayed() { this.say('replayed'); }

  /** @param {import('../output/pipeline').AnnotatedChunk} chunk */
  onChunk(chunk) {
    if (this.guard) this.guard.onData();
    const { alt } = this.session.tracker;
    if (alt !== this.lastAlt) { this.lastAlt = alt; this.say('alt', { alt }); }
    if (!chunk.text) return;
    for (const re of this.patterns) if (re.test(chunk.text)) this.say('match', { pattern: re.source });
  }

  /** @param {number} id */
  onConsumed(id) { if (this.guard) this.guard.onConsumed(id); }

  /** @param {any} l */
  onLflag(l) { this.tty = l; this.say('tty', /** @type {object} */ (this.ttyEvent())); }

  /** @param {{code: number|null, signal: string|null, at: string}} e */
  onExited(e) {
    const exit = { event: 'exit', code: e.code, signal: e.signal, at: e.at, lastLine: this.lastLine.take(this.session.writes.total) };
    if (this.connected) this.events.emit('event', exit); else this.unheardExit = exit;
  }

  onRespawned() { this.nextArgv = null; this.say('respawned'); }

  // ---- questions ---------------------------------------------------------------------------------------------------
  get staysAfterExit() { return !!this.managed.stays; }
  /** The controller says how an exit went: the host cannot tell a restart from a failure. */
  get announcesExit() { return false; }
  respawnArgv() { return this.nextArgv || super.respawnArgv(); }

  /** A controller connected, in place of any before it. @param {any} conn */
  connect(conn) {
    this.connected = true;
    this.controllerConn = conn;
    if (this.arrived) this.arrived();
  }

  /** @param {any} conn */
  disconnect(conn) {
    if (this.controllerConn !== conn) return;
    this.controllerConn = null;
    this.connected = false;
  }

  /** @param {number} ms @returns {Promise<void>} */
  _arrival(ms) {
    return new Promise((resolve) => {
      const timer = this.session.clock.setTimeout(() => { this.arrived = null; resolve(undefined); }, ms);
      this.arrived = () => { this.arrived = null; this.session.clock.clearTimeout(timer); resolve(undefined); };
    });
  }

  /**
   * The session has stopped: resolves when the controller has written down what it needs to, or after `ms`. A session that
   * is seen to have gone must already be recorded as gone.
   * @param {number} ms @returns {Promise<void>}
   */
  finish(ms) {
    if (!this.connected || this.recorded) return Promise.resolve();
    return new Promise((resolve) => {
      const timer = this.session.clock.setTimeout(() => { this.finished = null; resolve(undefined); }, ms);
      this.finished = () => { this.finished = null; this.session.clock.clearTimeout(timer); resolve(undefined); };
    });
  }

  /** The controller has written down that the session has gone. */
  markRecorded() {
    this.recorded = true;
    if (this.finished) this.finished();
  }

  /** A stop gives the controller first go, and carries on if it says so, takes too long, or is not there. @param {(ms: number) => Promise<boolean>} waitExit */
  async beforeHangup(waitExit) {
    if (!this.connected && this.managed.command) await this._arrival(ARRIVAL_WAIT_MS);  // a session this new may not have met it yet
    if (!this.connected) return false;
    const answered = new Promise((resolve) => { this.proceed = () => { this.proceed = null; resolve(false); }; });
    this.say('stopping');
    const exited = await Promise.race([waitExit(this.managed.stopGraceMs ?? DEFAULT_STOP_GRACE_MS), answered]);
    this.proceed = null;
    return /** @type {boolean} */ (exited);
  }

  gates() {
    return [...this.gateTable.entries()].sort((a, b) => a[1].rank - b[1].rank).map(([name]) => name);
  }

  blockingGates() { return this.gates().filter((g) => /** @type {any} */ (this.gateTable.get(g)).blocking); }

  /** @returns {import('../input/input').InputPolicy} */
  inputPolicy() {
    const { guard, lastLine, gateTable, managed } = this;
    return {
      detachKeys: managed.detachKeys || [],
      ...(managed.forwardFocus === false ? { forwardFocus: () => false } : {}),
      gateEffect(gate, client) {
        const g = gateTable.get(gate);
        if (!g) return 'drop';
        if (g.passable && client.flags && client.flags.allowGated) return 'open';
        return g.effect;
      },
      ...(guard ? { offerSignalKey: (/** @type {'C'|'D'} */ cls, /** @type {any} */ client) => guard.offer(cls, client), guardsKey: (/** @type {string} */ cls) => guard.covers(cls) } : {}),
      onPaste: () => lastLine.onPaste(),
      onForwarded: (id, tok, _cls, total) => lastLine.onForwarded(id, tok, total),
    };
  }

  // ---- answers -----------------------------------------------------------------------------------------------------
  /** @param {string} name @param {{effect?: 'drop'|'filter'|null, passable?: boolean, blocking?: boolean, rank?: number}} o effect null removes it */
  setGate(name, { effect = 'drop', passable = false, blocking = false, rank = 0 }) {
    if (effect === null) this.gateTable.delete(name);
    else this.gateTable.set(name, { effect, passable, blocking, rank });
  }

  /** @param {Record<string, unknown>} attrs */
  setAttrs(attrs) {
    Object.assign(this.attrs, attrs);
    this.session.saveState(false);
  }

  /** Beside the host's own fields, which win. @param {any} s */
  status(s) { return { ...this.attrs, ...s, controller: this.connected }; }
  stateFields() { return this.attrs; }
  welcomeFields() { return this.managed.welcome || {}; }
  /** @param {any} doc */
  persisted(doc) {
    const out = { ...doc, attrs: this.attrs };
    this.say('record', { doc: out });
    return out;
  }
}

module.exports = { RemoteController };
