# Where nmux-rs stands beside the Node nmux

nmux is made here from 0.5.0 on. The Node implementation in `../nmux` stopped at 0.5.0, level with this one but for what is
listed below, and stays as the SDK that programs written in Node reach sessions with, and as a host for one that cannot build
this binary. A change of behaviour is made here only; `tools/conformance.sh` still runs Node's suites against this binary, and
they must go on passing, or be changed where this binary is meant to differ.

Level with nmux 0.5.0 in what is not listed: nmux-vt, nmux-wire, the holder, the emulator, the kept history's writer, and the
server. All of them pass Node's conformance suite and its integration suites `cli`, `history`, `managed`, `flow` and
`plain-session`, with this binary as the command, the server and the holder. What the end of `plain-session.test.js` checks
inside Node's server is checked here in `crates/nmux-server/tests/core.rs` and `input.rs`; `drained.test.js` checks when Node's
sockets say they have drained, which the run loop here says itself.

Only here: `nmux __attach --json SPEC` (`crates/nmux-client/src/embed.rs`), the attach client in the words of a program that
embeds nmux and runs this binary. Node's client takes such words as functions, through its SDK.

Only here: the terminal's colour scheme and colours. A program that sets mode 2031 hears a terminal's reports of a new scheme
(`CSI ? 997 ; n n`), and one that asks with `CSI ? 996 n` is answered by a terminal (`Scheme` in
`crates/nmux-server/src/output/tracker.rs`); a terminal that attaches is asked for its scheme when the program wants it. The
holder answers OSC 10 and 11 with the colours of the terminal that attached last, and a terminal whose scheme changes is asked
its colours again. The server tells a holder that says `colors` among its caps with `COLORS` on pty.sock, and the attach client
passes on the colours its terminal says once it is attached. Node's server drops every report, and its holder answers with the
colours the session started with.

## For the server

- Output is lexed twice: once by the pipeline, and again by the emulator from the chunk's bytes. One parse, as `docs/DESIGN.md`
  has it, needs the chunk to carry its tokens, through the edits the emulator makes to them and the places it divides them.
  The second lex is about a tenth of the emulator's time on plain lines and a quarter on coloured ones (0.3 and 1.4 ms of
  CPU a MB, of 2.8 and 5.5).

## For the client and the command

The client and every subcommand are ported, and pass Node's conformance suite and `test/integration/cli.test.js` and
`history.test.js`, with this binary's server and with Node's (`NMUX_SERVER_BIN`). What still differs, and where it is in Node:

- `nmux doctor` (`src/cli/doctor.js`) has no `node` and `node-pty` lines: it says `nmux`, `native addon: built in` and
  `pty: built in`.
- A pattern for `search` or `wait --text` (`new RegExp` in `src/cli/main.js`) is read as V8 reads it, refused in V8's words,
  and matches what V8 matches, over 2,000 patterns V8 was asked about and 30,000 more at random. Three rare forms still
  differ, which `crates/nmux-history/src/read/pattern.rs` names.
- The shell start-up files are built into the binary and written to `run/shell` in the runtime directory, where Node uses its
  own `shell/` (`src/cli/shells.js`).
