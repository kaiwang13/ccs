//! The attach client's logic, with no I/O: `AttachClient` in `src/client/attach.js`, and the parts of `TerminalDriver` and
//! `SessionLink` that decide anything. The run loop hands it what happened ([`Event`]) and the time, and does what it asks
//! ([`Effect`]). The frames it sends are in a buffer it owns, which the run loop writes to the connection it asked for.
//!
//! Byte transparency: OUTPUT frames are written to the terminal unchanged. Raw mode keeps OPOST and ONLCR on, as Node's does,
//! so a bare LF would become CRLF; every byte the child writes already passed ONLCR on the holder's pty, so that is harmless.
//!
//! Native scrollback is the product. This client therefore never writes RIS (ESC c), ED2 (CSI 2J), ED3 (CSI 3J) or ED0 (CSI
//! J) to the main screen: each of those wipes or truncates the user's history in some terminal. Detaching only resets modes,
//! moves to the last row and prints one dim line.
//!
//! Keys go through the [`KeyTable`] first, so a detach works even while the host is hung; everything else is sent as INPUT
//! and filtered by the server.
//!
//! Overlays (help, who is attached) live on the alternate screen, so leaving one restores the main screen exactly and
//! nothing can reach scrollback. Output arriving meanwhile is held. If there is too much of it, or the session is on the
//! alternate screen itself so the overlay has drawn over it, the server redraws instead, and whatever was already on the way
//! is ignored until `RESYNC_BEGIN` marks the place in the stream.
//!
//! A key can lend the terminal to an action, such as a pager on the session's history, the way a window detaches and comes
//! back: the server is told this terminal is leaving, everything it sent before saying goodbye is shown, so it knows exactly
//! how far this terminal got, and the action has the terminal on its alternate screen with the program's modes off. Then
//! this terminal joins again over the screen it left. The run loop runs the action ([`Effect::Lend`]); just before it needs
//! the terminal it asks for it ([`Event::Take`]), and it says when it is done ([`Event::LendDone`]).

use nmux_io::{Now, OutBuf, Time, TimerId, Timers};
use nmux_time::{Zone, wall};
use nmux_vt::{InputKind, InputTokenizer};
use nmux_wire::{
    Bye, CTL_PROTO, ClientInfo, Colors as WireColors, Control, Flags, Frame, FrameType, Hello, name_of_state,
};
use serde_json::Value;

use crate::keytable::{Action, KeySpec, KeyTable};
use crate::reconnect::{ReconnectPolicy, RejoinPolicy};
use crate::termcolors::{Colors, QUERY, is_color_reply, parse_color_replies, without_replies};
use crate::terminal::{AltTracker, KittyTracker, bar_gone, detach_bytes, modes_off, parse_cpr};

/// A terminal shorter than this keeps every row for the session, and shows no bar.
pub const MIN_BAR_ROWS: u32 = 6;
use crate::text::{self, Leaving, Words};

const SILENCE_MS: u64 = 15_000;
const SILENCE_CHECK_MS: u64 = 1000;
const PENDING_INPUT_CAP: usize = 65_536;
const OVERLAY_HOLD_CAP: usize = 1_048_576;
const REDRAW_WAIT_MS: u64 = 3000;
const MEASURE_TIMEOUT_MS: u64 = 300;
const COLORS_TIMEOUT_MS: u64 = 200;
const MAX_NOTICES: usize = 50;
/// XTWINOPS: the terminal's title stack. A terminal without one ignores both.
const TITLE_SAVE: &str = "\x1b[22;2t";
const TITLE_RESTORE: &str = "\x1b[23;2t";

/// How this client takes part.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)] // the command's flags, one each
pub struct AttachFlags {
    /// May go below the usual floor.
    pub shrink: bool,
    /// May type through gates.
    pub allow_setup: bool,
    /// Only watches.
    pub view: bool,
    /// Repeats all history, as for a terminal never seen before.
    pub full: bool,
}

/// What a client is made with.
#[derive(Clone, Debug)]
pub struct Options {
    /// The session's name, until the server says otherwise.
    pub name: String,
    /// See [`AttachFlags`].
    pub flags: AttachFlags,
    /// The keys this client takes.
    pub keys: KeySpec,
    /// What a key can run with the terminal lent to it, by name, such as `history`.
    pub actions: Vec<String>,
    /// `clients.rejoinMax` and `clients.rejoinWindowMs`.
    pub rejoin_max: usize,
    /// See `rejoin_max`.
    pub rejoin_window_ms: u64,
    /// `size.floorCols` and `size.floorRows`, for a refusal that does not say.
    pub floor_cols: u32,
    /// See `floor_cols`.
    pub floor_rows: u32,
    /// `size.hardMinCols`: narrower than this, `--shrink` would not help.
    pub hard_min_cols: u32,
    /// What it says, in nmux's words or a program's that embeds it.
    pub words: Words,
    /// `input.escFlushMs`.
    pub esc_flush_ms: u64,
    /// `input.pasteIdleCloseMs`.
    pub paste_idle_close_ms: u64,
    /// The terminal's size at the start.
    pub cols: u32,
    /// See `cols`.
    pub rows: u32,
    /// Where times are shown, as `14:03` in the line left behind.
    pub zone: Zone,
    /// nmux's bar is wanted at the foot of the terminal: `overlay.bar`.
    pub bar: bool,
    /// The terminal shows any colour, as `COLORTERM` says.
    pub truecolor: bool,
}

/// Who this terminal is, as HELLO says it, read by the run loop as each connection opens.
#[derive(Clone, Debug, Default)]
pub struct Identity {
    /// The client's tty.
    pub tty: Option<String>,
    /// What lists of clients call it.
    pub label: String,
    /// `TERM_PROGRAM`.
    pub term_program: Option<String>,
    /// What tells this terminal from another, so that coming back to it is known to be coming back. None where that cannot
    /// be told.
    pub terminal: Option<String>,
    /// `SSH_AUTH_SOCK`.
    pub agent: Option<String>,
    /// This process.
    pub pid: u32,
}

/// What happened, for [`Attach::on_event`].
#[derive(Debug)]
#[allow(clippy::large_enum_variant)] // an event is handled where it is made, and never stored
pub enum Event<'a> {
    /// The client starts: ask the terminal its colours.
    Start,
    /// The terminal sent this.
    Input(&'a [u8]),
    /// The terminal's input ended.
    InputEnd,
    /// The terminal has this size now.
    Resized {
        /// Columns.
        cols: u32,
        /// Rows.
        rows: u32,
    },
    /// SIGHUP: the terminal has gone.
    Hangup,
    /// SIGTERM.
    Terminate,
    /// The connection asked for is open.
    Connected(&'a Identity),
    /// A frame came on it.
    Frame(Frame<'a>),
    /// It closed, or could not be made.
    Lost,
    /// Time passed.
    Tick,
    /// The action the terminal is lent to needs it now.
    Take,
    /// That action is done.
    LendDone,
}

/// What the run loop is asked to do, in order.
#[derive(Debug)]
pub enum Effect {
    /// Write this to the terminal.
    Write(Vec<u8>),
    /// Raw mode on, or the terminal's own modes back.
    Raw(bool),
    /// Raw mode once more, for a terminal something else had.
    RawAgain,
    /// Read the terminal, or stop reading it.
    Reading(bool),
    /// Open a new connection to the session, dropping any there is, and answer with [`Event::Connected`] or [`Event::Lost`].
    Connect,
    /// Write what is left to send, as far as the socket takes it now, and close the connection.
    Drop(OutBuf),
    /// Run this action with the terminal lent to it, and answer with [`Event::LendDone`].
    Lend(String),
    /// The client is done, with this exit code.
    Exit(i32),
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Phase {
    Init,
    Measuring,
    Connecting,
    Joining,
    Live,
    Lending,
    Lent,
    Refused,
    Reconnecting,
    Done,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Timer {
    Colors,
    Measure,
    Silence,
    Reconnect,
    Redraw,
    Lend,
}

#[derive(Debug)]
struct Overlay {
    held: Vec<Vec<u8>>,
    bytes: usize,
    over_alt: bool,
    skipped: usize,
}

#[derive(Debug)]
struct Notice {
    level: String,
    code: String,
    text: String,
}

/// A finish asked for while the terminal is lent, which happens once it is back.
#[derive(Debug)]
struct Finish {
    code: i32,
    kind: Leaving,
    reason: Option<String>,
    text: Option<String>,
}

/// The attach client.
#[derive(Debug)]
#[allow(clippy::struct_excessive_bools)] // what the Node client keeps, one flag each
pub struct Attach {
    name: String,
    flags: AttachFlags,
    actions: Vec<String>,
    floor_cols: u32,
    floor_rows: u32,
    hard_min_cols: u32,
    words: Words,
    zone: Zone,
    keys: KeyTable,
    tokenizer: InputTokenizer,
    phase: Phase,
    // ---- the terminal --------------------------------------------------------------------------------------------
    cols: u32,
    rows: u32,
    gone: bool,
    kitty: KittyTracker,
    screen: AltTracker,
    colors: Colors,
    colors_buf: Option<Vec<u8>>,
    measure: Option<Vec<u8>>,
    // ---- the session ---------------------------------------------------------------------------------------------
    connected: bool,
    out: OutBuf,
    last_rx: Time,
    hello_row: u32,
    same_screen: bool,
    pending_input: Vec<u8>,
    received: u64,
    others: usize,
    joined_once: bool,
    notices: Vec<Notice>,
    resume: Option<Value>,
    /// nmux's bar is wanted at the foot of this terminal: it has it once there are rows enough.
    bar: bool,
    /// The bar is on this terminal, as far as its size goes: a resize can take it away.
    bar_shown: bool,
    /// This connection's server draws the bar: it said so, or has not said yet.
    server_bar: bool,
    truecolor: bool,
    rejoin: RejoinPolicy,
    reconnect: ReconnectPolicy,
    attached: Vec<ClientInfo>,
    overlay: Option<Overlay>,
    awaiting_redraw: bool,
    silence_ms: u64,
    last_silence_check: Time,
    last_refused_size: String,
    title_saved: bool,
    // ---- lending -------------------------------------------------------------------------------------------------
    lend_action: Option<String>,
    handed: bool,
    deferred: Option<Finish>,
    // ---- time and what comes out ---------------------------------------------------------------------------------
    timers: Timers<Timer>,
    colors_timer: Option<TimerId>,
    measure_timer: Option<TimerId>,
    silence_timer: Option<TimerId>,
    reconnect_timer: Option<TimerId>,
    redraw_timer: Option<TimerId>,
    lend_timer: Option<TimerId>,
    effects: Vec<Effect>,
}

impl Attach {
    /// A client for a session, not yet started.
    pub fn new(o: Options) -> Self {
        Self {
            name: o.name,
            flags: o.flags,
            actions: o.actions,
            floor_cols: o.floor_cols,
            floor_rows: o.floor_rows,
            hard_min_cols: o.hard_min_cols,
            words: o.words,
            zone: o.zone,
            keys: KeyTable::new(o.keys),
            tokenizer: InputTokenizer::new(o.esc_flush_ms, o.paste_idle_close_ms),
            phase: Phase::Init,
            cols: o.cols,
            rows: o.rows,
            gone: false,
            kitty: KittyTracker::default(),
            screen: AltTracker::default(),
            colors: Colors::default(),
            colors_buf: None,
            measure: None,
            connected: false,
            out: OutBuf::new(),
            last_rx: Time::ZERO,
            hello_row: 0,
            same_screen: false,
            pending_input: Vec::new(),
            received: 0,
            others: 0,
            joined_once: false,
            notices: Vec::new(),
            resume: None,
            bar: o.bar,
            bar_shown: false,
            server_bar: true,
            truecolor: o.truecolor,
            rejoin: RejoinPolicy::new(o.rejoin_max, o.rejoin_window_ms),
            reconnect: ReconnectPolicy::default(),
            attached: Vec::new(),
            overlay: None,
            awaiting_redraw: false,
            silence_ms: SILENCE_MS,
            last_silence_check: Time::ZERO,
            last_refused_size: String::new(),
            title_saved: false,
            lend_action: None,
            handed: false,
            deferred: None,
            timers: Timers::new(),
            colors_timer: None,
            measure_timer: None,
            silence_timer: None,
            reconnect_timer: None,
            redraw_timer: None,
            lend_timer: None,
            effects: Vec::new(),
        }
    }

    /// What to do, in order, since this was last asked.
    pub fn take_effects(&mut self) -> Vec<Effect> {
        std::mem::take(&mut self.effects)
    }

    /// What waits to be sent on the connection.
    pub fn out(&mut self) -> &mut OutBuf {
        &mut self.out
    }

    /// When [`Event::Tick`] is next due.
    pub fn next_deadline(&mut self) -> Option<Time> {
        let timers = self.timers.next_due();
        let tokenizer = self.tokenizer.deadline().map(Time::from_ms);
        timers.into_iter().chain(tokenizer).min()
    }

    /// Whether the terminal was handed to the action that has it lent.
    pub fn handed(&self) -> bool {
        self.handed
    }

    /// Whether the client is done.
    pub fn done(&self) -> bool {
        self.phase == Phase::Done
    }

    /// Whether a connection is wanted: one it has asked for and not yet dropped.
    pub fn connected(&self) -> bool {
        self.connected
    }

    /// Takes in what happened.
    pub fn on_event(&mut self, event: Event<'_>, now: Now) {
        match event {
            Event::Start => self.start(now),
            Event::Input(bytes) => self.on_stdin(bytes, now),
            Event::InputEnd | Event::Terminate => self.detach(now),
            Event::Resized { cols, rows } => {
                self.cols = cols;
                self.rows = rows;
                if self.phase != Phase::Init {
                    self.on_resize();
                }
            }
            Event::Hangup => {
                self.gone = true;
                self.detach(now);
            }
            Event::Connected(identity) => {
                self.last_rx = now.time;
                self.hello(identity);
            }
            Event::Frame(frame) => {
                self.last_rx = now.time;
                match frame {
                    Frame::Control(msg) => self.on_control(msg, now),
                    Frame::Output(bytes) => self.on_output(bytes),
                    _ => {}
                }
            }
            Event::Lost => {
                self.connected = false;
                self.out.clear();
                self.on_socket_lost(now);
            }
            Event::Tick => self.tick(now),
            Event::Take => self.take(),
            Event::LendDone => self.lend_done(now),
        }
    }

    // ---- the terminal ------------------------------------------------------------------------------------------------

    fn write(&mut self, bytes: &[u8]) {
        if self.gone || bytes.is_empty() {
            return;
        }
        if let Some(Effect::Write(last)) = self.effects.last_mut() {
            last.extend_from_slice(bytes);
        } else {
            self.effects.push(Effect::Write(bytes.to_vec()));
        }
    }

    fn write_str(&mut self, s: &str) {
        self.write(s.as_bytes());
    }

    /// Output from the session, unchanged.
    fn output(&mut self, bytes: &[u8]) {
        self.kitty.feed(bytes);
        self.screen.feed(bytes);
        self.write(bytes);
    }

    /// Leaves an overlay: what was on the alternate screen, the overlay replaced.
    fn leave_overlay(&mut self) {
        self.write_str("\x1b[?1049l");
        self.screen.alt = false;
    }

    fn restore(&mut self) {
        let rows = if self.rows == 0 { 24 } else { self.rows };
        let bytes = detach_bytes(rows, self.screen.alt, self.kitty.depth, self.has_bar());
        self.write_str(&bytes);
        self.kitty.depth = 0;
        self.screen.alt = false;
    }

    fn measure_cursor(&mut self, now: Now) {
        self.measure = Some(Vec::new());
        self.measure_timer = Some(self.timers.set(now.time, MEASURE_TIMEOUT_MS, Timer::Measure));
        self.write_str("\x1b[6n");
    }

    /// The cursor's row, or `None` when it was not said in time: the measure is over, and the client connects.
    fn finish_measure(&mut self, row: Option<u32>) {
        if self.measure.take().is_none() {
            return;
        }
        self.cancel(Timer::Measure);
        self.connect(row);
    }

    fn on_stdin(&mut self, bytes: &[u8], now: Now) {
        if let Some(buf) = &mut self.colors_buf {
            buf.extend_from_slice(bytes);
            let c = parse_color_replies(buf);
            if c.fg.is_some() && c.bg.is_some() {
                self.colors_answered(now);
            }
            return;
        }
        if let Some(buf) = &mut self.measure {
            buf.extend_from_slice(bytes);
            if let Some(cpr) = parse_cpr(buf) {
                let mut rest = buf[..cpr.index].to_vec();
                rest.extend_from_slice(&buf[cpr.index + cpr.length..]);
                self.finish_measure(Some(cpr.row));
                if !rest.is_empty() {
                    self.on_bytes(&rest, now);
                }
            }
            return;
        }
        self.on_bytes(bytes, now);
    }

    fn on_bytes(&mut self, bytes: &[u8], now: Now) {
        let mut toks = Vec::new();
        self.tokenizer.feed(bytes, now.time.ms(), |t| toks.push((t.kind, t.bytes.to_vec())));
        self.on_tokens(toks, now);
    }

    // ---- starting ----------------------------------------------------------------------------------------------------

    /// Asks the terminal its colours, and waits a moment for the answer. What is typed meanwhile is the session's.
    fn start(&mut self, now: Now) {
        self.effects.push(Effect::Raw(true));
        self.effects.push(Effect::Reading(true));
        self.colors_buf = Some(Vec::new());
        self.colors_timer = Some(self.timers.set(now.time, COLORS_TIMEOUT_MS, Timer::Colors));
        self.write_str(QUERY);
    }

    fn colors_answered(&mut self, now: Now) {
        let Some(buf) = self.colors_buf.take() else { return };
        self.cancel(Timer::Colors);
        self.colors = parse_color_replies(&buf);
        let typed = without_replies(&buf);
        self.last_silence_check = now.time;
        self.silence_timer = Some(self.timers.set(now.time, SILENCE_CHECK_MS, Timer::Silence));
        self.phase = Phase::Measuring;
        if !typed.is_empty() {
            self.on_bytes(&typed, now);
        }
        if self.phase != Phase::Done {
            self.measure_cursor(now);
        }
    }

    // ---- keys --------------------------------------------------------------------------------------------------------

    /// The local detach check, then on to the session.
    fn on_tokens(&mut self, toks: Vec<(InputKind, Vec<u8>)>, now: Now) {
        if self.phase == Phase::Done {
            return;
        }
        if self.overlay.is_some() {
            if !toks.is_empty() {
                self.close_overlay(now);
            }
            return;
        }
        if matches!(self.phase, Phase::Lending | Phase::Lent) {
            // Only leaving counts until the terminal is lent.
            let keys = &mut self.keys;
            if toks
                .iter()
                .any(|(kind, bytes)| keys.action_for(*kind, &seq(bytes)) == Action::Named("detach".to_owned()))
            {
                self.finish(0, Leaving::Detached, None, None, now);
            }
            return;
        }
        let mut forward: Vec<u8> = Vec::new();
        for (kind, bytes) in toks {
            let s = seq(&bytes);
            if self.phase == Phase::Refused && KeyTable::is_interrupt(kind, &s) {
                self.finish(1, Leaving::GaveUp, Some("gave up waiting for a larger terminal".to_owned()), None, now);
                return;
            }
            if is_color_reply(&bytes) {
                // Its colours, which the server asked for when its colour scheme changed, or which it gave after it was
                // given up on: the server keeps them for the program, and never passes them on as typing.
                forward.extend_from_slice(&bytes);
                continue;
            }
            match self.keys.action_for(kind, &s) {
                Action::Ignore => {}
                Action::Program | Action::Literal => forward.extend_from_slice(&bytes),
                Action::Named(action) => {
                    if !forward.is_empty() {
                        self.send_input(&std::mem::take(&mut forward));
                    }
                    self.key_action(&action, now);
                    if self.phase == Phase::Done || self.overlay.is_some() {
                        return;
                    }
                }
            }
        }
        if !forward.is_empty() {
            self.send_input(&forward);
        }
    }

    /// Whether this terminal has the bar now: one too short for it keeps every row, and so does one whose server does not
    /// draw it.
    fn has_bar(&self) -> bool {
        self.bar && self.rows >= MIN_BAR_ROWS && self.server_bar
    }

    /// The rows the session has of this terminal: all of them but the bar's.
    fn session_rows(&self) -> u32 {
        self.rows - u32::from(self.has_bar())
    }

    /// The bar on or off, for this terminal: it gives its row back, and the session has one row more or less.
    fn toggle_bar(&mut self) {
        let had = self.has_bar();
        self.bar = !self.bar;
        if had {
            self.write_str(&bar_gone(self.rows));
        }
        if had != self.has_bar() {
            let bar = self.has_bar();
            self.bar_shown = bar;
            self.send_control(&Control::Resize { cols: self.cols, rows: self.session_rows(), bar: Some(bar) });
        }
    }

    fn key_action(&mut self, action: &str, now: Now) {
        match action {
            "detach" => self.detach(now),
            "bar" => self.toggle_bar(),
            "help" => {
                let lines = text::help(&self.words.brand, &self.name, self.keys.spec());
                self.open_overlay(&lines);
            }
            "clients" => {
                let lines = text::who_is_attached(&self.words.brand, &self.name, &self.attached);
                self.open_overlay(&lines);
            }
            other if self.actions.iter().any(|a| a == other) => self.lend(other.to_owned(), now),
            _ => {}
        }
    }

    fn send_input(&mut self, bytes: &[u8]) {
        if self.phase == Phase::Live && self.connected {
            let _ = self.out.frame(FrameType::Input, bytes);
        } else if matches!(self.phase, Phase::Measuring | Phase::Connecting | Phase::Joining)
            && self.pending_input.len() + bytes.len() <= PENDING_INPUT_CAP
        {
            // Typed while a join is on its way: delivered after SNAPSHOT_END.
            self.pending_input.extend_from_slice(bytes);
        }
        // While disconnected or refused, input is dropped: a stale draft is never replayed into a fresh join.
    }

    // ---- lending the terminal ----------------------------------------------------------------------------------------

    fn lend(&mut self, action: String, now: Now) {
        if self.phase != Phase::Live || self.overlay.is_some() {
            return;
        }
        self.phase = Phase::Lending;
        self.lend_action = Some(action);
        // Its BYE comes after what it has sent.
        self.send_control(&Control::Detach { received: Some(self.received), drain: Some(true) });
        // A server that never says goodbye.
        self.lend_timer = Some(self.timers.set(now.time, REDRAW_WAIT_MS, Timer::Lend));
    }

    /// The server has let this terminal go: the action has it, once it asks for it.
    fn lent(&mut self) {
        self.cancel(Timer::Lend);
        self.phase = Phase::Lent;
        self.handed = false;
        let action = self.lend_action.take().unwrap_or_default();
        self.effects.push(Effect::Lend(action));
    }

    /// Someone else reads the keyboard and draws, such as a pager. Nothing is read meanwhile, what the program had turned on
    /// is off, including the cursor keys' application mode, which a pager sets for itself, and it draws on the alternate
    /// screen, so the main one is as it was afterwards even for a pager told not to use it (`less -X`).
    fn take(&mut self) {
        if self.phase != Phase::Lent {
            self.handed = false;
            return;
        }
        self.handed = true;
        self.effects.push(Effect::Reading(false));
        let off = modes_off(self.screen.alt, self.kitty.depth);
        self.write_str(&format!("{off}\x1b[?1l\x1b>\x1b[?1049h\x1b[H\x1b[2J"));
        self.screen.alt = false;
        self.kitty.depth = 0;
    }

    fn lend_done(&mut self, now: Now) {
        if self.handed {
            self.handed = false;
            self.write_str("\x1b[?1049l");
            // A pager that died may have left the terminal cooked.
            self.effects.push(Effect::RawAgain);
            self.effects.push(Effect::Reading(true));
            if let Some(f) = self.deferred.take() {
                self.finish(f.code, f.kind, f.reason, f.text, now);
            }
        }
        if self.phase != Phase::Lent {
            return;
        }
        self.phase = Phase::Measuring;
        // The pager drew on the other screen.
        self.same_screen = true;
        self.measure_cursor(now);
    }

    // ---- overlays ----------------------------------------------------------------------------------------------------

    fn open_overlay(&mut self, lines: &[String]) {
        if self.phase != Phase::Live {
            return;
        }
        self.overlay = Some(Overlay { held: Vec::new(), bytes: 0, over_alt: self.screen.alt, skipped: 0 });
        self.write_str(&format!("\x1b[?1049h\x1b[H\x1b[2J{}", lines.join("\r\n")));
    }

    fn close_overlay(&mut self, now: Now) {
        let Some(o) = self.overlay.take() else { return };
        self.leave_overlay();
        if !o.over_alt && o.skipped == 0 {
            for b in o.held {
                self.show(&b);
            }
            return;
        }
        self.awaiting_redraw = true;
        // A server that never answers must not silence this terminal.
        self.redraw_timer = Some(self.timers.set(now.time, REDRAW_WAIT_MS, Timer::Redraw));
        self.send_control(&Control::Resync { alt: Some(false), skipped: Some(o.skipped as u64) });
    }

    fn redraw_arrived(&mut self) {
        self.awaiting_redraw = false;
        self.cancel(Timer::Redraw);
    }

    fn restore_title(&mut self) {
        if self.title_saved {
            self.title_saved = false;
            self.write_str(TITLE_RESTORE);
        }
    }

    fn show(&mut self, bytes: &[u8]) {
        self.received += bytes.len() as u64;
        self.output(bytes);
    }

    fn on_output(&mut self, bytes: &[u8]) {
        if self.awaiting_redraw {
            return;
        }
        let Some(o) = &mut self.overlay else {
            self.show(bytes);
            return;
        };
        if o.over_alt {
            // Redrawn on the way out.
            return;
        }
        o.bytes += bytes.len();
        if o.bytes <= OVERLAY_HOLD_CAP {
            o.held.push(bytes.to_vec());
        } else {
            o.held.clear();
            o.skipped = o.bytes;
        }
    }

    // ---- the connection ----------------------------------------------------------------------------------------------

    fn send_control(&mut self, msg: &Control) {
        if self.connected {
            let _ = self.out.control(msg);
        }
    }

    fn drop_link(&mut self) {
        if self.connected {
            self.connected = false;
            let last = std::mem::take(&mut self.out);
            self.effects.push(Effect::Drop(last));
        }
    }

    fn connect(&mut self, cursor_row: Option<u32>) {
        if self.phase == Phase::Done {
            return;
        }
        self.phase = Phase::Connecting;
        self.server_bar = true; // until this server says otherwise
        self.bar_shown = self.has_bar();
        self.hello_row = cursor_row.unwrap_or(self.rows);
        self.connected = true;
        self.out.clear();
        self.effects.push(Effect::Connect);
    }

    fn hello(&mut self, id: &Identity) {
        let hello = Hello {
            proto: CTL_PROTO,
            role: "attach".to_owned(),
            cols: self.cols,
            rows: self.session_rows(),
            cursor_row: self.hello_row,
            focus: true,
            tty: id.tty.clone(),
            pid: id.pid,
            label: id.label.clone(),
            term_program: id.term_program.clone(),
            terminal: Some(if self.flags.full { None } else { id.terminal.clone() }),
            agent: Some(id.agent.clone()),
            resume: Some(self.resume.clone().unwrap_or(Value::Null)),
            colors: Some(WireColors { fg: self.colors.fg.clone(), bg: self.colors.bg.clone() }),
            flags: Flags {
                shrink: Some(self.flags.shrink),
                allow_gated: Some(self.flags.allow_setup),
                allow_setup: Some(self.flags.allow_setup),
                view: Some(self.flags.view),
                bar: Some(self.has_bar()),
                truecolor: Some(self.truecolor),
                same_screen: self.same_screen.then_some(true),
            },
            extra: serde_json::Map::new(),
        };
        self.send_control(&Control::Hello(hello));
    }

    #[allow(clippy::too_many_lines)] // one arm per message, as the Node client has them
    fn on_control(&mut self, msg: Control, now: Now) {
        match msg {
            Control::Welcome(w) => {
                self.phase = Phase::Joining;
                self.received = 0;
                if self.has_bar() && w.bar != Some(true) {
                    // a server from before there was a bar: the terminal keeps its last row
                    self.server_bar = false;
                    self.bar_shown = false;
                    self.send_control(&Control::Resize { cols: self.cols, rows: self.rows, bar: Some(false) });
                }
                if let Some(name) = w.name.filter(|n| !n.is_empty()) {
                    self.name = name;
                }
                // The host's silence limit: never shorter than three of its ping intervals.
                self.silence_ms = SILENCE_MS.max(3 * w.ping.interval_ms);
            }
            Control::Refuse { code, need, text } => {
                if code == "BELOW_FLOOR" || code == "TOO_SHORT" {
                    self.on_refused_size(&code, need.map(|n| (n.cols, n.rows)));
                } else {
                    let why = if text.is_empty() { format!("refused: {code}") } else { text };
                    self.finish(1, Leaving::GaveUp, Some(why), None, now);
                }
            }
            Control::ResyncBegin => self.redraw_arrived(),
            Control::SnapshotBegin { .. } => {
                self.phase = Phase::Joining;
                self.redraw_arrived();
                self.joined_once = true;
                self.same_screen = false;
                // Before the join: it may set a newer one.
                self.restore_title();
            }
            Control::SnapshotEnd => {
                self.phase = Phase::Live;
                self.resume = None;
                self.reconnect.reset();
                self.rejoin.on_snapshot_end();
                let pending = std::mem::take(&mut self.pending_input);
                if !pending.is_empty() && self.connected {
                    let _ = self.out.frame(FrameType::Input, &pending);
                }
            }
            Control::State(state) => {
                self.others = state.clients.len().saturating_sub(1);
                if let Some(name) = name_of_state(&state) {
                    self.name = name.to_owned();
                }
                self.attached = state.clients;
            }
            Control::Notice { level, code, text } => {
                if self.notices.len() < MAX_NOTICES {
                    self.notices.push(Notice { level, code, text });
                }
            }
            Control::Ping { seq } => self.send_control(&Control::Pong { seq }),
            Control::Bye(bye) => self.on_bye(bye, now),
            Control::Err(e) => {
                let why = format!("host error {}", e.code).trim().to_owned();
                self.finish(1, Leaving::GaveUp, Some(why), None, now);
            }
            // Unknown control types are ignored, for forward compatibility.
            _ => {}
        }
    }

    fn on_bye(&mut self, msg: Bye, now: Now) {
        self.drop_link();
        if self.phase == Phase::Lending {
            self.lent();
            return;
        }
        let text = Some(msg.text).filter(|t| !t.is_empty());
        match msg.reason.as_str() {
            "CLIENT_EXIT" => return self.finish(0, Leaving::ClientExit, None, text, now),
            "KICKED" => return self.finish(0, Leaving::Kicked, msg.by.filter(|b| !b.is_empty()), None, now),
            "BELOW_FLOOR" => {
                self.restore_modes();
                let need = msg.need.map(|n| (n.cols, n.rows));
                return self.on_refused_size("BELOW_FLOOR", need);
            }
            "OVERFLOW" => {
                if self.rejoin.allow_overflow(now.time) {
                    return self.schedule_reconnect(true, now);
                }
                let minutes = (self.rejoin.window_ms + 30_000) / 60_000;
                let why = format!("this terminal fell behind {} times in {minutes} minutes", self.rejoin.max);
                return self.finish(1, Leaving::GaveUp, Some(why), None, now);
            }
            "SNAPSHOT_TIMEOUT" => {
                if self.rejoin.allow_snapshot_timeout() {
                    return self.schedule_reconnect(true, now);
                }
                let why = format!("the join snapshot timed out {} times in a row", self.rejoin.snapshot_timeout_max);
                return self.finish(1, Leaving::GaveUp, Some(why), None, now);
            }
            _ => {}
        }
        if msg.auto_rejoin {
            // What it held back goes, and only a join makes up for that.
            let resume = msg.resume.filter(crate::config::truthy);
            self.resume = if self.overlay.is_some() || self.awaiting_redraw { None } else { resume };
            return self.schedule_reconnect(false, now);
        }
        if let Some(ended) = msg.ended {
            let reason = match ended {
                Value::Number(n) if n.as_f64() == Some(0.0) => None,
                Value::Number(n) => Some(format!("exit {n}")),
                Value::String(s) if !s.is_empty() => Some(s),
                _ => None,
            };
            return self.finish(0, Leaving::Ended, reason, text, now);
        }
        let reason = Some(msg.reason.to_lowercase().replace('_', " ")).filter(|r| !r.is_empty());
        self.finish(0, Leaving::Ended, reason, text, now);
    }

    fn on_refused_size(&mut self, code: &str, need: Option<(u32, u32)>) {
        self.drop_link();
        self.phase = Phase::Refused;
        self.restore_title();
        if self.joined_once {
            // It may be a long time before this joins.
            self.pending_input.clear();
        }
        let size = format!("{}x{}", self.cols, self.rows);
        if self.last_refused_size.is_empty() {
            let (need_cols, need_rows) = need.unwrap_or((self.floor_cols, self.floor_rows));
            let need_cols = if need_cols == 0 { self.floor_cols } else { need_cols };
            let need_rows = if need_rows == 0 { self.floor_rows } else { need_rows };
            let message = self.words.floor_message(
                code,
                (self.cols, self.rows),
                (need_cols, need_rows),
                &self.name,
                self.flags.shrink,
                self.hard_min_cols,
            );
            self.write_str(&message);
        } else if size != self.last_refused_size {
            let brand = &self.words.brand;
            self.write_str(&format!("{brand}: now {size} — still too small; waiting\r\n"));
        }
        self.last_refused_size = size;
    }

    fn on_resize(&mut self) {
        if self.phase == Phase::Refused {
            let rows = self.rows;
            self.connect(Some(rows));
            return;
        }
        let bar = self.has_bar();
        if self.bar_shown && !bar {
            self.write_str(&bar_gone(self.rows)); // too short for it now
        }
        self.bar_shown = bar;
        if matches!(self.phase, Phase::Joining | Phase::Live) {
            self.send_control(&Control::Resize { cols: self.cols, rows: self.session_rows(), bar: Some(bar) });
        }
    }

    fn on_socket_lost(&mut self, now: Now) {
        if self.phase == Phase::Lending {
            // It comes back as a terminal not seen before.
            self.lent();
            return;
        }
        if matches!(self.phase, Phase::Done | Phase::Refused | Phase::Lent) {
            return;
        }
        self.schedule_reconnect(false, now);
    }

    fn schedule_reconnect(&mut self, immediate: bool, now: Now) {
        if self.phase == Phase::Done {
            return;
        }
        let Some(delay) = self.reconnect.next(immediate, now.time) else {
            self.finish(1, Leaving::Lost, None, None, now);
            return;
        };
        if self.joined_once {
            // Typed into a connection that did not last.
            self.pending_input.clear();
        }
        self.same_screen = false;
        if self.overlay.take().is_some() {
            // The join redraws everything.
            self.leave_overlay();
        }
        self.phase = Phase::Reconnecting;
        if !self.title_saved {
            self.title_saved = true;
            self.write_str(TITLE_SAVE);
        }
        let title = format!("\x1b]0;{}: reconnecting…\x07", self.words.brand);
        self.write_str(&title);
        self.cancel(Timer::Reconnect);
        // A rejoin pushes the whole visible screen into scrollback (cursorRow = rows) before the snapshot.
        self.reconnect_timer = Some(self.timers.set(now.time, delay, Timer::Reconnect));
    }

    fn check_silence(&mut self, now: Now) {
        let late = now.time.since(self.last_silence_check) > 3 * SILENCE_CHECK_MS;
        self.last_silence_check = now.time;
        if late {
            // This process was the one not running.
            self.last_rx = now.time;
            return;
        }
        if self.connected
            && matches!(self.phase, Phase::Joining | Phase::Live)
            && now.time.since(self.last_rx) > self.silence_ms
        {
            self.drop_link();
            self.schedule_reconnect(false, now);
        }
    }

    // ---- time --------------------------------------------------------------------------------------------------------

    fn cancel(&mut self, which: Timer) {
        let slot = match which {
            Timer::Colors => &mut self.colors_timer,
            Timer::Measure => &mut self.measure_timer,
            Timer::Silence => &mut self.silence_timer,
            Timer::Reconnect => &mut self.reconnect_timer,
            Timer::Redraw => &mut self.redraw_timer,
            Timer::Lend => &mut self.lend_timer,
        };
        if let Some(id) = slot.take() {
            self.timers.cancel(id);
        }
    }

    fn tick(&mut self, now: Now) {
        while let Some((_, which)) = self.timers.pop_due(now.time) {
            match which {
                Timer::Colors => {
                    self.colors_timer = None;
                    self.colors_answered(now);
                }
                Timer::Measure => {
                    self.measure_timer = None;
                    self.finish_measure(None);
                }
                Timer::Silence => {
                    self.silence_timer = Some(self.timers.set(now.time, SILENCE_CHECK_MS, Timer::Silence));
                    self.check_silence(now);
                }
                Timer::Reconnect => {
                    self.reconnect_timer = None;
                    let rows = self.rows;
                    self.connect(Some(rows));
                }
                Timer::Redraw => {
                    self.redraw_timer = None;
                    self.redraw_arrived();
                }
                Timer::Lend => {
                    self.lend_timer = None;
                    if self.phase == Phase::Lending {
                        self.drop_link();
                        self.lent();
                    }
                }
            }
        }
        if self.tokenizer.deadline().is_some_and(|at| at <= now.time.ms()) {
            let mut toks = Vec::new();
            self.tokenizer.on_timer(now.time.ms(), |t| toks.push((t.kind, t.bytes.to_vec())));
            self.on_tokens(toks, now);
        }
    }

    // ---- leaving -----------------------------------------------------------------------------------------------------

    fn restore_modes(&mut self) {
        if self.joined_once {
            self.restore();
        }
    }

    /// The person leaves: a key, SIGHUP, SIGTERM, or the end of input.
    fn detach(&mut self, now: Now) {
        if self.phase == Phase::Done {
            return;
        }
        self.send_control(&Control::Detach { received: Some(self.received), drain: None });
        self.finish(0, Leaving::Detached, None, None, now);
    }

    fn finish(&mut self, code: i32, kind: Leaving, reason: Option<String>, text: Option<String>, now: Now) {
        if self.phase == Phase::Done {
            return;
        }
        if self.handed {
            // The pager stays until it is quit.
            self.deferred.get_or_insert(Finish { code, kind, reason, text });
            return;
        }
        let was_refused = self.phase == Phase::Refused;
        self.phase = Phase::Done;
        if self.overlay.take().is_some() {
            self.leave_overlay();
        }
        self.restore_title();
        for t in [Timer::Reconnect, Timer::Silence, Timer::Lend, Timer::Colors] {
            self.cancel(t);
        }
        self.redraw_arrived();
        self.measure = None;
        self.cancel(Timer::Measure);
        self.colors_buf = None;
        self.drop_link();
        if self.joined_once && !was_refused {
            self.restore_modes();
        } else {
            self.write_str("\r\n");
        }
        let w = wall(now.wall_ms, &self.zone);
        let hhmm = format!("{:02}:{:02}", w.hour, w.minute);
        let line = self.words.detach_line(kind, &self.name, self.others, &hhmm, reason.as_deref());
        self.write_str(&line);
        if let Some(text) = text {
            let text = text.replace("\r\n", "\n").replace('\n', "\r\n");
            self.write_str(&format!("{text}\r\n"));
        }
        let mut last_code = String::new();
        let notices = std::mem::take(&mut self.notices);
        for n in &notices {
            if n.code == last_code {
                continue;
            }
            last_code.clone_from(&n.code);
            let level = if n.level == "warn" { "warning" } else { "note" };
            let line = format!("{}: {level} {}: {}\r\n", self.words.brand, n.code, n.text);
            self.write_str(&line);
        }
        self.effects.push(Effect::Raw(false));
        self.effects.push(Effect::Reading(false));
        self.tokenizer.close(|_| {});
        self.effects.push(Effect::Exit(code));
    }
}

fn seq(bytes: &[u8]) -> String {
    String::from_utf8_lossy(bytes).into_owned()
}
