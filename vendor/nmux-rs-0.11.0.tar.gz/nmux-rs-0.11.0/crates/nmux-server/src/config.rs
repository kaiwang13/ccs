//! What the server needs to know, with its defaults: `config.js`. An embedding program gives its own values in the spec,
//! and otherwise the user's file is read. Each section is read on its own and missing fields keep their defaults, so a
//! section that cannot be read falls back to its defaults and never stops a session from starting.

use std::path::Path;

use serde::Deserialize;
use serde::de::DeserializeOwned;
use serde_json::{Map, Value};

/// The size rules.
#[derive(Clone, Debug, Deserialize, PartialEq, Eq)]
#[serde(default, rename_all = "camelCase")]
pub struct SizeConfig {
    /// Fewer columns than this pauses a client.
    pub floor_cols: u32,
    /// The floor for a client that asked to shrink.
    pub hard_min_cols: u32,
    /// Fewer rows than this pauses a client.
    pub floor_rows: u32,
    /// The widest the pty is made.
    pub max_cols: u32,
    /// The tallest the pty is made.
    pub max_rows: u32,
    /// A new session's columns.
    pub default_cols: u32,
    /// A new session's rows.
    pub default_rows: u32,
    /// How long a shrink waits for more.
    pub shrink_debounce_ms: u64,
    /// The longest a shrink waits.
    pub shrink_max_wait_ms: u64,
    /// How long a grow waits.
    pub grow_debounce_ms: u64,
    /// The least columns a grow takes.
    pub grow_min_cols: u32,
    /// The least rows a grow takes.
    pub grow_min_rows: u32,
    /// How long a join that shrank the pty waits for a program to repaint.
    pub join_repaint_wait_ms: u64,
    /// Unused here; kept so that a configuration that has it reads the same.
    pub grow_reset_check_ms: u64,
}

impl Default for SizeConfig {
    fn default() -> Self {
        Self {
            floor_cols: 2,
            hard_min_cols: 2,
            floor_rows: 1,
            max_cols: 500,
            max_rows: 500,
            default_cols: 120,
            default_rows: 40,
            shrink_debounce_ms: 50,
            shrink_max_wait_ms: 200,
            grow_debounce_ms: 50,
            grow_min_cols: 1,
            grow_min_rows: 1,
            join_repaint_wait_ms: 400,
            grow_reset_check_ms: 300,
        }
    }
}

/// Joins and the emulator.
#[derive(Clone, Debug, Deserialize, PartialEq, Eq)]
#[serde(default, rename_all = "camelCase")]
pub struct SnapshotConfig {
    /// Lines of history the emulator keeps.
    pub scrollback: usize,
    /// The most history a join sends: `"all"`, or a number.
    #[serde(deserialize_with = "join_history")]
    pub join_history: Option<usize>,
    /// How long a join may take to be delivered.
    pub snapshot_timeout_ms: u64,
    /// What a join is sent in.
    pub chunk_bytes: usize,
}

impl Default for SnapshotConfig {
    fn default() -> Self {
        Self { scrollback: 10_000, join_history: None, snapshot_timeout_ms: 30_000, chunk_bytes: 65_536 }
    }
}

fn join_history<'de, D: serde::Deserializer<'de>>(d: D) -> Result<Option<usize>, D::Error> {
    Ok(match Value::deserialize(d)? {
        Value::Number(n) => n.as_u64().and_then(|n| usize::try_from(n).ok()),
        _ => None,
    })
}

/// Clients and their heartbeat.
#[derive(Clone, Debug, Deserialize, PartialEq, Eq)]
#[serde(default, rename_all = "camelCase")]
pub struct ClientsConfig {
    /// How often clients are pinged.
    pub ping_ms: u64,
    /// No pong for this long: the client is stalled and no longer limits the size.
    pub stall_ms: u64,
    /// No pong for this long: the client is let go. Never, when it is not a number.
    #[serde(deserialize_with = "maybe_ms")]
    pub drop_ms: Option<u64>,
    /// Past this much queued for a client, it is skipped ahead rather than queued for.
    pub queue_cap_bytes: usize,
}

impl Default for ClientsConfig {
    fn default() -> Self {
        Self { ping_ms: 5000, stall_ms: 20_000, drop_ms: None, queue_cap_bytes: 1_048_576 }
    }
}

fn maybe_ms<'de, D: serde::Deserializer<'de>>(d: D) -> Result<Option<u64>, D::Error> {
    Ok(Value::deserialize(d)?.as_u64())
}

/// Client input.
#[derive(Clone, Debug, Deserialize, PartialEq, Eq)]
#[serde(default, rename_all = "camelCase")]
pub struct InputConfig {
    /// A lone ESC is sent after this long with nothing after it.
    pub esc_flush_ms: u64,
    /// A paste with no end is closed after this long with nothing more.
    pub paste_idle_close_ms: u64,
}

impl Default for InputConfig {
    fn default() -> Self {
        Self { esc_flush_ms: 40, paste_idle_close_ms: 1500 }
    }
}

/// Stopping a session.
#[derive(Clone, Debug, Deserialize, PartialEq, Eq)]
#[serde(default, rename_all = "camelCase")]
pub struct StopConfig {
    /// How long after hanging up a child is waited for before SIGTERM.
    pub hangup_wait_ms: u64,
    /// How long after SIGTERM before the stop is stuck.
    pub term_wait_ms: u64,
}

impl Default for StopConfig {
    fn default() -> Self {
        Self { hangup_wait_ms: 30_000, term_wait_ms: 60_000 }
    }
}

/// The holder.
#[derive(Clone, Debug, Deserialize, PartialEq, Eq)]
#[serde(default, rename_all = "camelCase")]
pub struct HolderConfig {
    /// What its ring keeps of the output.
    pub ring_bytes: u64,
}

impl Default for HolderConfig {
    fn default() -> Self {
        Self { ring_bytes: 8_388_608 }
    }
}

/// What terminals are told.
#[derive(Clone, Debug, Deserialize, PartialEq, Eq)]
#[serde(default, rename_all = "camelCase")]
pub struct NoticesConfig {
    /// Ring the bell when the session starts asking for a person.
    pub bell_on_attention: bool,
}

impl Default for NoticesConfig {
    fn default() -> Self {
        Self { bell_on_attention: true }
    }
}

/// The program's output.
#[derive(Clone, Debug, Default, Deserialize, PartialEq, Eq)]
#[serde(default, rename_all = "camelCase")]
pub struct StreamConfig {
    /// The program repaints its whole screen, so the emulator is the fixed one.
    pub repaint: bool,
}

/// What is drawn beside the session's own output.
#[derive(Clone, Debug, Deserialize, PartialEq, Eq)]
#[serde(default, rename_all = "camelCase")]
pub struct OverlayConfig {
    /// nmux's bar on the last row of an attached terminal, which its client asks for.
    pub bar: bool,
    /// A line in the scrollback when a day starts.
    pub day_lines: bool,
    /// The time zone they are in, or `TZ`.
    pub time_zone: Option<String>,
}

impl Default for OverlayConfig {
    fn default() -> Self {
        Self { bar: true, day_lines: false, time_zone: None }
    }
}

/// The keys a client takes, as the bar says them.
#[derive(Clone, Debug, Deserialize, PartialEq, Eq)]
#[serde(default)]
pub struct KeysConfig {
    /// The key before each of the others, as `C-\`, or none.
    #[serde(deserialize_with = "leader")]
    pub leader: Option<String>,
    /// Each key after the leader and its action, in the file's order.
    #[serde(deserialize_with = "bindings")]
    pub bindings: Vec<(String, String)>,
    /// Keys that act at once, with no leader.
    #[serde(deserialize_with = "bindings")]
    pub direct: Vec<(String, String)>,
    /// The actions the bar names, each with its word, in the file's order.
    #[serde(deserialize_with = "bindings")]
    pub tips: Vec<(String, String)>,
}

impl Default for KeysConfig {
    fn default() -> Self {
        let owned = |pairs: &[(&str, &str)]| pairs.iter().map(|(k, a)| ((*k).to_owned(), (*a).to_owned())).collect();
        Self {
            leader: Some("C-\\".to_owned()),
            bindings: owned(&[("d", "detach"), ("c", "clients"), ("h", "history"), ("s", "bar"), ("?", "help")]),
            direct: Vec::new(),
            tips: owned(&[("detach", "detach"), ("help", "help")]),
        }
    }
}

/// A leader that is null or empty is none.
fn leader<'de, D: serde::Deserializer<'de>>(d: D) -> Result<Option<String>, D::Error> {
    Ok(Option::<String>::deserialize(d)?.filter(|l| !l.is_empty()))
}

fn bindings<'de, D: serde::Deserializer<'de>>(d: D) -> Result<Vec<(String, String)>, D::Error> {
    let map = Map::<String, Value>::deserialize(d)?;
    Ok(map.into_iter().filter_map(|(k, v)| v.as_str().map(|a| (k, a.to_owned()))).collect())
}

/// See the module.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Config {
    /// See [`SizeConfig`].
    pub size: SizeConfig,
    /// See [`SnapshotConfig`].
    pub snapshot: SnapshotConfig,
    /// See [`ClientsConfig`].
    pub clients: ClientsConfig,
    /// See [`InputConfig`].
    pub input: InputConfig,
    /// See [`StopConfig`].
    pub stop: StopConfig,
    /// See [`HolderConfig`].
    pub holder: HolderConfig,
    /// See [`NoticesConfig`].
    pub notices: NoticesConfig,
    /// See [`StreamConfig`].
    pub stream: StreamConfig,
    /// See [`OverlayConfig`].
    pub overlay: OverlayConfig,
    /// See [`KeysConfig`].
    pub keys: KeysConfig,
}

fn section<T: DeserializeOwned + Default>(o: &Map<String, Value>, name: &str) -> T {
    o.get(name).and_then(|v| T::deserialize(v).ok()).unwrap_or_default()
}

impl Config {
    /// Values over the defaults, a section at a time.
    pub fn from_value(v: &Value) -> Self {
        let Some(o) = v.as_object() else { return Self::default() };
        Self {
            size: section(o, "size"),
            snapshot: section(o, "snapshot"),
            clients: section(o, "clients"),
            input: section(o, "input"),
            stop: section(o, "stop"),
            holder: section(o, "holder"),
            notices: section(o, "notices"),
            stream: section(o, "stream"),
            overlay: section(o, "overlay"),
            keys: section(o, "keys"),
        }
    }

    /// The user's file over the defaults. A missing file is the usual case, and a broken one gives the defaults.
    pub fn load(file: Option<&Path>) -> Self {
        let read = file.and_then(|f| std::fs::read(f).ok());
        read.and_then(|bytes| serde_json::from_slice::<Value>(&bytes).ok())
            .map_or_else(Self::default, |v| Self::from_value(&v))
    }
}
