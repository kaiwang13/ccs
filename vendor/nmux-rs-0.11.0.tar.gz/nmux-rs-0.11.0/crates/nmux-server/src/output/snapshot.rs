//! What a terminal is sent to show the session: a join, a redraw in place, and putting things back after nmux has drawn
//! something of its own. `snapshot.js`.

use std::fmt::Write as _;

use nmux_term::cells::{self, Extras};
use nmux_term::{BufferView, LineBuf};
use nmux_vt::ModeState;
use nmux_vt::kitty;
use nmux_vt::seq::SCHEME_MODE;

use super::emulator::Emulator;
use super::tracker::Tracker;

/// Modes a fixed join restates.
const PRELUDE_MODES: [u32; 9] = [2004, 1004, 2031, 9, 1000, 1002, 1003, 1006, 1016];
/// Every mode a program may set and expect to find still set. Origin mode moves the cursor, so it has a place of its own.
const ALL_MODES: [u32; 16] = [1, 7, 12, 45, 66, 1005, 1015, 2004, 1004, 2031, 9, 1000, 1002, 1003, 1006, 1016];
const ORIGIN_MODE: u32 = 6;
const WRAP_MODE: u32 = 7;
const MOUSE: [u32; 6] = [9, 1000, 1002, 1003, 1006, 1016];
/// A terminal back at its defaults: DECSTR, then the same things by name for one that lacks it.
const DEFAULTS_NOW: &str = "\x1b[!p\x1b[?7h\x1b[?6l\x1b[4l\x1b>\x1b(B";

/// `CSI row ; col H`, 1-based.
fn cup(out: &mut String, row: usize, col: usize) {
    let _ = write!(out, "\x1b[{row};{col}H");
}

/// A line of nmux's own, faint.
fn dim(out: &mut String, text: &str) {
    let _ = write!(out, "\x1b[2m{text}\x1b[0m");
}

/// The modes a program set, as a terminal has to be told them. xterm reports the mouse one way at a time, and turning any
/// of those modes off turns the mouse off, so every mode that is off goes first and only those that are on come after.
/// `every`: say every mode, not only those the program set or reset, for a terminal in no known state.
pub fn mode_bytes(m: &ModeState, modes: &[u32], every: bool) -> String {
    let mut off = String::new();
    let mut on = String::new();
    for &mode in modes {
        let r = m.raw(mode);
        let set = if MOUSE.contains(&mode) { m.state(mode) == 1 } else { r == 1 };
        if set {
            let _ = write!(on, "\x1b[?{mode}h");
        } else if r != 0 || (every && mode != WRAP_MODE) {
            let _ = write!(off, "\x1b[?{mode}l");
        }
    }
    off + &on
}

/// The first history row a join sends: from what the terminal has up to, when it has been here before.
fn first_history_row(b: &BufferView<'_>, scr: usize, limit: Option<usize>, from: usize) -> usize {
    let limit = limit.map_or(0, |n| scr.saturating_sub(n));
    scr.min(cells::first_written_line(b, scr).max(limit).max(from))
}

/// The terminal a join is for.
#[derive(Clone, Debug, Default)]
#[allow(clippy::struct_excessive_bools)] // what is known about the terminal, one flag each
pub struct Client {
    /// Its rows.
    pub rows: usize,
    /// Its columns.
    pub cols: usize,
    /// Where its cursor is, 1-based: what is above it scrolls into its scrollback first.
    pub cursor_row: Option<usize>,
    /// In place: the terminal is in whatever state the output left it, and on the alternate screen or not.
    pub alt: Option<bool>,
    /// Its main screen is whole, so only a program's alternate screen needs drawing.
    pub keep_main: bool,
    /// It still shows the screen it had when the history it holds ends: the rows from `history_from` go over it.
    pub over_screen: bool,
    /// nmux's bar, for a terminal that has it on the row below `rows`. Its scroll region then ends above it.
    pub bar: Option<String>,
    /// The kitty keyboard flags nmux has told it, which a join in place takes off before it changes screens.
    pub keyboard: u8,
}

/// The scroll region of a terminal's `rows`, with nmux's bar below them.
fn bar_region(o: &mut String, rows: usize) {
    let _ = write!(o, "\x1b[1;{rows}r");
}

/// nmux's bar on the row below a terminal's `rows`.
fn put_bar(o: &mut String, rows: usize, bar: &str) {
    cup(o, rows + 1, 1);
    o.push_str(bar);
}

/// What a join is made of.
#[derive(Debug)]
pub struct Join<'a, B> {
    /// The emulator.
    pub emulator: &'a Emulator,
    /// What the program's output says.
    pub tracker: &'a Tracker,
    /// The line above the screen, given how many history lines the join sends.
    pub banner: B,
    /// See [`Client`].
    pub client: Client,
    /// The most history it sends, or all of it.
    pub history_limit: Option<usize>,
    /// The first row it sends: what the terminal has up to, when it has been here before.
    pub history_from: usize,
}

/// Where a fixed emulator's screen is: `Rp`, `Δe`, the first row of the screen, and the first history row to send.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Geometry {
    /// The screen's rows.
    pub screen_rows: usize,
    /// Rows of the emulator above them.
    pub above: usize,
    /// The first row of the screen in the buffer.
    pub scr: usize,
    /// The first history row to send.
    pub h0: usize,
}

/// See [`Geometry`].
pub fn join_geometry(
    emulator: &Emulator,
    tracker: &Tracker,
    history_limit: Option<usize>,
    history_from: usize,
) -> Geometry {
    let b = emulator.normal();
    let screen_rows = tracker.screen_rows as usize;
    let above = emulator.rows().saturating_sub(screen_rows);
    let top = b.len().saturating_sub(emulator.rows());
    let scr = top + above;
    Geometry { screen_rows, above, scr, h0: first_history_row(&b, scr, history_limit, history_from) }
}

/// The bytes of a join, for either kind of emulator.
pub fn join_bytes<B: FnMut(usize) -> Option<String>>(join: Join<'_, B>) -> Vec<u8> {
    if join.emulator.tracking() { tracking_join(join) } else { fixed_join(join) }
}

/// The last parts of a join: the modes, the keyboard flags, the colours and progress the program set, the keypad, the
/// cursor's shape, the title, the pen and the cursor's visibility. A program told of the colour scheme has the terminal asked for its own, which it hears if it is news.
fn ending(o: &mut String, tracker: &Tracker, modes: &[u32], every: bool, keypad: bool, title_always: bool) {
    let m = &tracker.modes;
    o.push_str(&mode_bytes(m, modes, every));
    if m.raw(SCHEME_MODE) == 1 {
        o.push_str("\x1b[?996n");
    }
    o.push_str(&kitty::tell(0, m.keyboard()));
    o.push_str(&tracker.shown.restore());
    if keypad && m.keypad() {
        o.push_str("\x1b=");
    }
    if let Some(style) = m.cursor_style() {
        let _ = write!(o, "\x1b[{style} q");
    }
    if title_always || !tracker.title.is_empty() {
        let _ = write!(o, "\x1b]0;{}\x07", tracker.title);
    }
    o.push_str("\x1b[0m");
    for p in tracker.pen.lists() {
        let _ = write!(o, "\x1b[{p}m");
    }
    o.push_str(if m.raw(25) == 2 { "\x1b[?25l" } else { "\x1b[?25h" });
}

/// The rows of a buffer, each placed with a cursor move after clearing it.
fn place_rows(o: &mut String, b: &BufferView<'_>, from: usize, to: usize, first_row: usize, max_cols: Option<usize>) {
    for (i, row) in cells::serialize_rows(b, from, to, max_cols, Extras::ALL).iter().enumerate() {
        cup(o, first_row + i, 1);
        o.push_str("\x1b[2K");
        o.push_str(row);
    }
}

/// A join for the 240 by 150 emulator: the screen is placed at the bottom of the terminal with a cursor move per row,
/// after the history has scrolled into its scrollback.
fn fixed_join<B: FnMut(usize) -> Option<String>>(mut j: Join<'_, B>) -> Vec<u8> {
    let (emulator, tracker, client) = (j.emulator, j.tracker, j.client);
    let g = join_geometry(emulator, tracker, j.history_limit, j.history_from);
    let b = emulator.normal();
    let rc = client.rows;
    let rp = g.screen_rows;
    // a client shorter than the screen gets its top rows as history; one taller has rows above it
    let skip = rp.saturating_sub(rc);
    let above = rc.saturating_sub(rp);
    let clamp = |r: isize| r.clamp(1, isize::try_from(rc).unwrap_or(isize::MAX)).unsigned_abs();
    let mut o = kitty::tell(client.keyboard, 0);
    if let Some(alt) = client.alt {
        o.push_str("\x1b[?2026l");
        if alt {
            o.push_str("\x1b[?1049l");
        }
    }
    let bar = client.bar.as_deref();
    let rows = if bar.is_some() { rc + 1 } else { rc }; // the terminal's
    o.push_str("\x1b[?25l\x1b[0m\x1b[r");
    cup(&mut o, rows, 1);
    o.push_str(&"\n".repeat(client.cursor_row.unwrap_or(rows)));
    if bar.is_some() {
        bar_region(&mut o, rc);
    }
    cup(&mut o, 1, 1);
    if let Some(line) = (j.banner)(g.scr - g.h0) {
        dim(&mut o, &line);
        o.push_str("\r\n");
    }
    let hist = cells::serialize_rows(&b, g.h0, g.scr + skip, None, Extras::ALL);
    if !hist.is_empty() {
        o.push_str(&hist.join("\r\n"));
        o.push_str("\r\n");
    }
    o.push_str(&"\r\n".repeat(rc.saturating_sub(1 + above)));
    place_rows(&mut o, &b, g.scr + skip, g.scr + rp, above + 1, Some(client.cols));
    if let Some(bar) = bar {
        put_bar(&mut o, rc, bar);
    }
    let dc = signed(rc) - signed(rp);
    // an emulator line, as the client's row
    let to_client_row = |abs_y: usize| clamp(signed(abs_y) - signed(b.base_y()) - signed(g.above) + dc + 1);
    if emulator.term().alternate_active() {
        let alt = emulator.term().alternate();
        let (sx, sy) = emulator.saved_normal().unwrap_or((b.cursor_x(), b.base_y() + b.cursor_y()));
        cup(&mut o, to_client_row(sy), sx + 1);
        o.push_str("\x1b[?1049h"); // which saves this position in the normal screen's slot
        if let Some(bar) = bar {
            bar_region(&mut o, rc);
            put_bar(&mut o, rc, bar);
        }
        // the alternate screen is drawn from its top, and gains history when rows shrink
        place_rows(&mut o, &alt, alt.base_y(), alt.base_y() + rp.min(rc), 1, Some(client.cols));
        if let Some((x, y)) = emulator.saved_alternate() {
            cup(&mut o, clamp(signed(y) - signed(alt.base_y()) + 1), x + 1);
            o.push_str("\x1b7");
        }
        cup(&mut o, clamp(signed(alt.cursor_y()) + 1), alt.cursor_x() + 1);
    } else {
        if let Some((x, y)) = emulator.saved_normal() {
            cup(&mut o, to_client_row(y), x + 1); // the nested ?1049l window
            o.push_str("\x1b7");
        }
        cup(&mut o, to_client_row(b.base_y() + b.cursor_y()), b.cursor_x() + 1);
    }
    ending(&mut o, tracker, &PRELUDE_MODES, false, false, true);
    o.into_bytes()
}

fn signed(n: usize) -> isize {
    isize::try_from(n).unwrap_or(isize::MAX)
}

/// A join for an emulator the pty's size. History and screen go out as one stream, so the terminal wraps long lines
/// itself: they stay single lines in its scrollback and it can reflow them. When the client is another width the rows it
/// shows are placed one by one instead, and only the history reflows.
///
/// - The screen always ends on the client's last row. A client shorter than the screen sees as much of it as fits with
///   the cursor in view: only a viewer can be that short.
/// - In place (`client.alt` known): the terminal is in whatever state the output left it, so it goes back to defaults
///   first, and every mode is then stated rather than only those the session set. `keep_main` says its main screen is
///   whole, so a program's alternate screen is all that needs drawing.
/// - Over its screen (`over_screen`): the terminal still shows the screen it had when the history it holds ends, so the
///   rows from `history_from` are written over it from its top, and what does not fit scrolls into its scrollback.
#[allow(clippy::too_many_lines)] // one join, in the order its bytes go out
fn tracking_join<B: FnMut(usize) -> Option<String>>(mut join: Join<'_, B>) -> Vec<u8> {
    let (emulator, tracker, client) = (join.emulator, join.tracker, join.client);
    let b = emulator.normal();
    let rc = client.rows;
    let rp = emulator.rows();
    let cp = emulator.cols();
    let scr = b.base_y();
    let h0 = first_history_row(&b, scr, join.history_limit, join.history_from);
    let same = client.cols == cp;
    let skip = rp.saturating_sub(rc).min((b.cursor_y() + 1).saturating_sub(rc)); // rows off the top, which become history
    let shown_end = scr + skip + rp.min(rc);
    let line = (join.banner)(scr - h0);
    let in_place = client.alt.is_some();
    let alt = emulator.term().alternate_active();
    let draw_main = !(client.keep_main && alt);
    let over_screen = client.over_screen && same && rc == rp && !alt;
    let bar = client.bar.as_deref();
    // the terminal's: the old screen goes up from its last row, bar and all
    let rows = if bar.is_some() { rc + 1 } else { rc };
    let mut o = kitty::tell(client.keyboard, 0);
    o.push_str("\x1b[?2026l"); // a connection can die in the middle of a synchronized frame
    if in_place {
        if client.alt == Some(true) {
            o.push_str("\x1b[?1049l");
        }
        o.push_str(DEFAULTS_NOW);
    }
    o.push_str("\x1b[?25l\x1b[0m\x1b[r");
    if over_screen {
        cup(&mut o, 1, 1);
        o.push_str("\x1b[J"); // below the cursor only: the scrollback is never touched
    } else if draw_main {
        cup(&mut o, rows, 1);
        o.push_str(&"\n".repeat(client.cursor_row.unwrap_or(rows)));
        cup(&mut o, 1, 1);
    }
    if bar.is_some() {
        bar_region(&mut o, rc);
    }
    if draw_main
        && !over_screen
        && let Some(line) = &line
    {
        dim(&mut o, line);
        o.push_str("\r\n");
    }
    let below = rc.saturating_sub(rp);
    if !draw_main {
        // the terminal's main screen stays exactly as it is
    } else if same {
        let pad = if over_screen { 0 } else { signed(rc) - isize::from(line.is_some()) - signed(shown_end - h0) };
        o.push_str(&"\r\n".repeat(pad.max(0).unsigned_abs()));
        o.push_str(&cells::serialize_flow(&b, h0, shown_end, cp, Extras::ALL));
    } else {
        if scr + skip > h0 {
            o.push_str(&cells::serialize_flow(&b, h0, scr + skip, cp, Extras::ALL));
            o.push_str("\r\n");
        }
        o.push_str(&"\r\n".repeat(rc.saturating_sub(1 + below)));
        place_rows(&mut o, &b, scr + skip, shown_end, below + 1, Some(client.cols));
    }
    if let Some(bar) = bar.filter(|_| draw_main) {
        put_bar(&mut o, rc, bar);
    }
    let clamp = |r: isize| r.clamp(1, signed(rc)).unsigned_abs();
    let to_client_row = |abs_y: usize| clamp(signed(abs_y) - signed(scr + skip) + signed(below) + 1);
    let modes = &tracker.modes;
    let (top, bottom) = emulator.margins();
    let margined = top != 0 || bottom + 1 != rp;
    let shift = if alt { 0 } else { below };
    let origin = modes.raw(ORIGIN_MODE) == 1;
    // a client row, as a cursor move has to say it: origin mode counts from the top margin
    let move_row = |row: usize| if origin && margined { row.saturating_sub(top + shift).max(1) } else { row };
    let place = |o: &mut String, row: usize, col: usize| {
        if margined {
            let bottom = if bar.is_some() { (bottom + 1 + shift).min(rc) } else { bottom + 1 + shift };
            let _ = write!(o, "\x1b[{};{bottom}r", top + 1 + shift);
        }
        if origin {
            let _ = write!(o, "\x1b[?{ORIGIN_MODE}h");
        }
        cup(o, move_row(row), col);
    };
    if alt {
        let a = emulator.term().alternate();
        let (sx, sy) = emulator.saved_normal().unwrap_or((b.cursor_x(), b.base_y() + b.cursor_y()));
        cup(&mut o, to_client_row(sy), sx.min(cp - 1) + 1);
        o.push_str("\x1b[?1049h"); // which saves this position in the normal screen's slot
        if let Some(bar) = bar {
            bar_region(&mut o, rc);
            put_bar(&mut o, rc, bar);
        }
        place_rows(&mut o, &a, a.base_y(), a.base_y() + rp.min(rc), 1, Some(client.cols));
        if let Some((x, y)) = emulator.saved_alternate() {
            cup(&mut o, clamp(signed(y) - signed(a.base_y()) + 1), x + 1);
            o.push_str("\x1b7");
        }
        let row = clamp(signed(a.cursor_y()) + 1);
        place(&mut o, row, a.cursor_x().min(cp - 1) + 1);
        o.push_str(&pending_wrap(&a, a.cursor_x(), a.base_y() + a.cursor_y(), cp, move_row(row)));
    } else {
        if let Some((x, y)) = emulator.saved_normal() {
            cup(&mut o, to_client_row(y), x.min(cp - 1) + 1); // the nested ?1049l window
            o.push_str("\x1b7");
        }
        let row = to_client_row(b.base_y() + b.cursor_y());
        place(&mut o, row, b.cursor_x().min(cp - 1) + 1);
        if same {
            o.push_str(&pending_wrap(&b, b.cursor_x(), b.base_y() + b.cursor_y(), cp, move_row(row)));
        }
    }
    ending(&mut o, tracker, &ALL_MODES, in_place, true, false);
    o.into_bytes()
}

/// A cursor just past the last column means the next character wraps. No cursor move can say that, so the last cell is
/// written again, which puts the terminal in the same state.
fn pending_wrap(b: &BufferView<'_>, x: usize, y: usize, cols: usize, row: usize) -> String {
    let mut line = LineBuf::new();
    if x < cols || !b.read_line(y, &mut line) {
        return String::new();
    }
    let mut cell = line.cell(cols - 1);
    let wide = cell.width() == 0;
    if wide {
        cell = line.cell(cols - 2);
    }
    let mut key = String::new();
    cells::attr_key_with(cell.attr, Extras::ALL, &mut key);
    let mut chars = String::new();
    line.chars(if wide { cols - 2 } else { cols - 1 }, &mut chars);
    if chars.is_empty() {
        chars.push(' ');
    }
    let mut o = String::new();
    cup(&mut o, row, if wide { cols - 1 } else { cols });
    let url = line.string(cell.attr.link);
    if !url.is_empty() {
        cells::link_start(url, &mut o); // written again, the cell would leave its link otherwise
    }
    let _ = write!(o, "\x1b[0{}{key}m{chars}\x1b[0m", if key.is_empty() { "" } else { ";" });
    if !url.is_empty() {
        o.push_str(cells::LINK_END);
    }
    o
}

/// Where the main screen starts in the emulator's buffer, its rows, and the cursor on it, for a terminal exactly the
/// pty's size.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MainScreen {
    /// The first row of the screen in the buffer.
    pub top: usize,
    /// Its rows.
    pub rows: usize,
    /// The cursor's row on it, 0-based.
    pub cursor_row: usize,
    /// The cursor's column, 0-based.
    pub cursor_col: usize,
}

/// See [`MainScreen`].
pub fn main_screen(emulator: &Emulator, tracker: &Tracker) -> MainScreen {
    let b = emulator.normal();
    let rows = tracker.screen_rows as usize;
    let top = if emulator.tracking() { b.base_y() } else { b.len().saturating_sub(rows) };
    MainScreen { top, rows, cursor_row: (b.base_y() + b.cursor_y()).saturating_sub(top), cursor_col: b.cursor_x() }
}

/// What puts the cursor, the pen and the cursor's visibility back as they were, after nmux has drawn something.
pub fn put_back(emulator: &Emulator, tracker: &Tracker) -> String {
    let s = main_screen(emulator, tracker);
    let mut o = String::from("\x1b[0m");
    for p in tracker.pen.lists() {
        let _ = write!(o, "\x1b[{p}m");
    }
    cup(&mut o, s.cursor_row + 1, s.cursor_col + 1);
    if tracker.modes.raw(25) != 2 {
        o.push_str("\x1b[?25h");
    }
    o
}

/// nmux's bar drawn on the row below a session's `rows`, with the scroll region stated again and all that the program had
/// set put back after it: where the cursor is, a wrap pending, the pen, the character set, insert and origin modes, and
/// whether the cursor shows. It is one synchronized frame, unless the program is in the middle of one, which then has the
/// bar in it. `cols` is the pty's.
pub fn draw_bar(emulator: &Emulator, tracker: &Tracker, rows: usize, cols: usize, line: &str) -> String {
    draw_on(emulator, tracker, rows, cols, line, false)
}

/// nmux's bar drawn on the last of a terminal's `rows`, the session's own last row, which it leaves empty: as
/// [`draw_bar`] draws it below them, with the program's scroll region left as it is.
pub fn draw_over(emulator: &Emulator, tracker: &Tracker, rows: usize, cols: usize, line: &str) -> String {
    draw_on(emulator, tracker, rows, cols, line, true)
}

/// What takes nmux's bar off the session's last row: the row as the program has it, drawn where the bar was, so that
/// output from here does to the terminal what it does to the emulator.
pub fn lift_over(emulator: &Emulator, tracker: &Tracker, rows: usize, cols: usize) -> String {
    let line = format!("\x1b[0m\x1b[2K{}", last_row(emulator, tracker, cols));
    draw_on(emulator, tracker, rows, cols, &line, true)
}

/// Whether the session leaves its last row empty, with nothing on it and no colour, so that nmux's bar may go there.
pub fn last_row_empty(emulator: &Emulator, tracker: &Tracker) -> bool {
    last_row(emulator, tracker, emulator.cols()).is_empty()
}

/// The session's last row, on the screen it is on, as SGR runs and text.
fn last_row(emulator: &Emulator, tracker: &Tracker, cols: usize) -> String {
    let term = emulator.term();
    let (b, y) = if term.alternate_active() {
        // the program's screen is the top of it, in an emulator of a fixed size taller than the session
        let b = term.alternate();
        let y = (tracker.screen_rows as usize).min(b.len()).saturating_sub(1);
        (b, y)
    } else {
        let s = main_screen(emulator, tracker);
        (emulator.normal(), (s.top + s.rows).saturating_sub(1))
    };
    cells::serialize_rows(&b, y, y + 1, Some(cols), Extras::ALL).pop().unwrap_or_default()
}

/// `line` drawn on the row below `rows`, or on the last of them (`over`).
fn draw_on(emulator: &Emulator, tracker: &Tracker, rows: usize, cols: usize, line: &str, over: bool) -> String {
    let modes = &tracker.modes;
    let term = emulator.term();
    let alt = term.alternate_active();
    let b = if alt { term.alternate() } else { emulator.normal() };
    let shift = if alt { 0 } else { rows.saturating_sub(tracker.screen_rows as usize) };
    let (cursor_row, cursor_col) = if alt {
        (b.cursor_y(), b.cursor_x())
    } else {
        let s = main_screen(emulator, tracker);
        (s.cursor_row, s.cursor_col)
    };
    let (top, bottom) = emulator.margins();
    let margined = emulator.tracking() && (top != 0 || bottom + 1 != emulator.rows());
    let origin = modes.raw(ORIGIN_MODE) == 1;
    let insert = term.modes().insert;
    let charset = tracker.g0 != b'B' || tracker.shifted;
    let sync = modes.raw(2026) != 1;
    let row = rows.min(cursor_row + 1 + shift);
    let move_row = if origin && margined { row.saturating_sub(top + shift).max(1) } else { row };
    let mut o = String::new();
    if sync {
        o.push_str("\x1b[?2026h");
    }
    o.push_str("\x1b[?25l");
    if over {
        // the program's region is the terminal's
    } else if margined {
        let _ = write!(o, "\x1b[{};{}r", top + 1 + shift, (bottom + 1 + shift).min(rows));
    } else {
        bar_region(&mut o, rows);
    }
    if origin {
        let _ = write!(o, "\x1b[?{ORIGIN_MODE}l");
    }
    if insert {
        o.push_str("\x1b[4l");
    }
    if charset {
        o.push_str("\x1b(B\x0f");
    }
    if over {
        cup(&mut o, rows, 1);
        o.push_str(line);
    } else {
        put_bar(&mut o, rows, line);
    }
    if charset {
        o.push_str("\x1b(");
        o.push(char::from(tracker.g0));
        if tracker.shifted {
            o.push('\x0e');
        }
    }
    if origin {
        let _ = write!(o, "\x1b[?{ORIGIN_MODE}h");
    }
    cup(&mut o, move_row, cursor_col.min(cols.saturating_sub(1)) + 1);
    o.push_str(&pending_wrap(&b, cursor_col, b.base_y() + b.cursor_y(), cols, move_row));
    if insert {
        o.push_str("\x1b[4h");
    }
    o.push_str("\x1b[0m");
    for p in tracker.pen.lists() {
        let _ = write!(o, "\x1b[{p}m");
    }
    if modes.raw(25) != 2 {
        o.push_str("\x1b[?25h");
    }
    if sync {
        o.push_str("\x1b[?2026l");
    }
    o
}

/// The main screen written over where it is, for a terminal that shows it already and is exactly its size. Nothing
/// reaches the terminal's scrollback except `line_above`, which goes in by scrolling once, as a line of its own.
pub fn redraw(emulator: &Emulator, tracker: &Tracker, line_above: Option<&str>) -> Vec<u8> {
    let s = main_screen(emulator, tracker);
    let mut o = String::from("\x1b[?25l\x1b[0m");
    if let Some(line) = line_above {
        cup(&mut o, 1, 1);
        o.push_str("\x1b[2K");
        dim(&mut o, line);
        cup(&mut o, s.rows, 1);
        o.push('\n');
    }
    place_rows(&mut o, &emulator.normal(), s.top, s.top + s.rows, 1, None);
    o.push_str(&put_back(emulator, tracker));
    o.into_bytes()
}
