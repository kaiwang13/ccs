//! The bar at the foot of a terminal that asked for one, `bar.js`, byte for byte: nmux's name, the session's, what it is
//! running and who else is on it, the keys that matter most, and the date and time where the session keeps them. This is
//! what it says and how it looks, for a terminal `cols` wide; drawing it, and keeping the session's output off its row, is the
//! server's.

use nmux_time::{Zone, month_short, wall, zone_label};

/// The bar's colours as SGR parameters: a deep slate bar, a teal tag for nmux, and text in lighter and softer greys. A
/// terminal that has said it shows any colour gets these exactly; any other the nearest of the 256.
#[derive(Debug)]
struct Palette {
    bar: &'static str,
    tag: &'static str,
    tag_text: &'static str,
    edge: &'static str,
    name: &'static str,
    soft: &'static str,
    dot: &'static str,
    key: &'static str,
    date: &'static str,
    time: &'static str,
}

const TRUECOLOR: Palette = Palette {
    bar: "48;2;30;41;59",
    tag: "48;2;20;184;166",
    tag_text: "38;2;15;23;42",
    edge: "38;2;20;184;166",
    name: "38;2;248;250;252",
    soft: "38;2;148;163;184",
    dot: "38;2;100;116;139",
    key: "38;2;94;234;212",
    date: "38;2;203;213;225",
    time: "38;2;248;250;252",
};

const ANSI256: Palette = Palette {
    bar: "48;5;236",
    tag: "48;5;37",
    tag_text: "38;5;234",
    edge: "38;5;37",
    name: "38;5;255",
    soft: "38;5;247",
    dot: "38;5;243",
    key: "38;5;116",
    date: "38;5;252",
    time: "38;5;255",
};

const DOT: &str = " · ";

/// What the bar says, and for whom.
#[derive(Clone, Copy, Debug)]
pub struct BarInfo<'a> {
    /// Who is speaking: `nmux`, or the program that embeds it.
    pub brand: &'a str,
    /// The session's name.
    pub name: &'a str,
    /// What its terminal is running in front of its shell, if anything.
    pub running: Option<&'a str>,
    /// The terminals attached.
    pub clients: usize,
    /// Now, in ms since the epoch.
    pub now: i64,
    /// Where the time is kept.
    pub zone: &'a Zone,
    /// The leader key, as the configuration writes it: `C-\`, or none.
    pub leader: Option<&'a str>,
    /// Each key after the leader and its action, in the configuration's order.
    pub bindings: &'a [(String, String)],
    /// Keys that act at once, with no leader. An action is shown with the leader's key for it, or else with one of these.
    pub direct: &'a [(String, String)],
    /// The actions the bar names, each with its word, in the order shown: those with no key are left out.
    pub tips: &'a [(String, String)],
    /// The terminal shows any colour.
    pub truecolor: bool,
}

/// `C-\` as the bar writes it: `^\`, and `M-g` as `Alt+G`.
pub fn key_label(key: &str) -> String {
    let one = |rest: &str| rest.chars().count() == 1;
    match (key.strip_prefix("C-"), key.strip_prefix("M-")) {
        (Some(rest), _) if one(rest) => format!("^{}", rest.to_uppercase()),
        (_, Some(rest)) if one(rest) => format!("Alt+{}", rest.to_uppercase()),
        _ => key.to_owned(),
    }
}

/// The first of `keys` that does `action`.
fn key_for<'k>(keys: &'k [(String, String)], action: &str) -> Option<&'k str> {
    keys.iter().find(|(_, a)| a == action).map(|(k, _)| k.as_str())
}

/// What may be left out, in the order it goes when the terminal is too narrow for everything: the tips but how to leave, the
/// last of them first, so that how to leave is the last of the tips to go.
#[derive(Clone, Copy, Debug)]
#[allow(clippy::struct_excessive_bools)] // one for each piece the bar can do without
struct Shown {
    more_tips: usize,
    weekday: bool,
    attached: bool,
    tips: bool,
    date: bool,
    running: bool,
    zone: bool,
    time: bool,
}

impl Shown {
    /// Leaves out the next piece, false when there is none left to.
    fn drop_next(&mut self) -> bool {
        if self.more_tips > 0 {
            self.more_tips -= 1;
            return true;
        }
        for piece in [
            &mut self.weekday,
            &mut self.attached,
            &mut self.tips,
            &mut self.date,
            &mut self.running,
            &mut self.zone,
            &mut self.time,
        ] {
            if *piece {
                *piece = false;
                return true;
            }
        }
        false
    }
}

/// Runs of text, each with its style.
type Segments = Vec<(String, String)>;

fn width_of(segments: &Segments) -> i64 {
    // every character here takes one column, and one UTF-16 unit, as the Node code counts them
    segments.iter().map(|(_, text)| i64::try_from(text.chars().count()).unwrap_or(i64::MAX)).sum()
}

/// What the bar shows on a terminal `cols` wide: SGR runs and text, filling the row with the bar's colour. The last column is
/// left for that fill, so writing the bar never leaves a wrap pending.
#[allow(clippy::too_many_lines)] // the layout, as `bar.js` has it
pub fn bar_line(info: &BarInfo<'_>, cols: usize) -> String {
    let p = if info.truecolor { &TRUECOLOR } else { &ANSI256 };
    let sgr = |codes: &[&str]| {
        let mut s = format!("\x1b[0;{}", p.bar);
        for code in codes {
            s.push(';');
            s.push_str(code);
        }
        s.push('m');
        s
    };
    let fill = format!("{}\x1b[K\x1b[0m", sgr(&[]));
    let width = i64::try_from(cols).unwrap_or(i64::MAX) - 1;
    if width < 8 {
        return fill;
    }
    let w = wall(info.now, info.zone);
    let time = format!("{:02}:{:02}", w.hour, w.minute);
    let day = format!("{} {}", w.day, month_short(info.now, info.zone));
    let weekday: String = w.weekday.chars().take(3).collect();
    let zone = zone_label(info.now, info.zone);
    // what is not printable ASCII is a question mark for each UTF-16 unit, as the Node code replaces it
    let running = info.running.map(|r| {
        r.chars()
            .map(|c| if (' '..='~').contains(&c) { c.to_string() } else { "?".repeat(c.len_utf16()) })
            .collect::<String>()
    });
    let tips: Vec<(String, &str, &str)> = info
        .tips
        .iter()
        .filter_map(|(action, word)| {
            let led = info.leader.and_then(|l| key_for(info.bindings, action).map(|k| format!("{} {k}", key_label(l))));
            let key = led.or_else(|| key_for(info.direct, action).map(key_label))?;
            Some((key, word.as_str(), action.as_str()))
        })
        .collect();
    let lasting = tips.iter().position(|(_, _, action)| *action == "detach");
    let brand = format!(" {} ", info.brand);
    let mut show = Shown {
        more_tips: tips.len() - usize::from(lasting.is_some()),
        weekday: true,
        attached: info.clients > 1,
        tips: !tips.is_empty(),
        date: true,
        running: running.is_some(),
        zone: true,
        time: true,
    };
    let seg = |codes: &[&str], text: &str| (sgr(codes), text.to_owned());
    let parts = |show: &Shown, name: &str| -> (Segments, Segments, Segments) {
        let mut left = vec![
            seg(&[p.edge], "▐"),
            seg(&[p.tag, p.tag_text, "1"], &brand),
            seg(&[p.edge], "▌"),
            seg(&[p.name, "1"], &format!(" {name}")),
        ];
        if let Some(running) = running.as_deref().filter(|_| show.running) {
            left.extend([seg(&[p.dot], DOT), seg(&[p.soft], running)]);
        }
        if show.attached {
            left.extend([seg(&[p.dot], DOT), seg(&[p.soft], &format!("{} attached", info.clients))]);
        }
        let mut center = Vec::new();
        if show.tips {
            let mut others = 0;
            let kept = tips.iter().enumerate().filter(|(i, _)| {
                Some(*i) == lasting || {
                    others += 1;
                    others <= show.more_tips
                }
            });
            for (i, (_, (key, word, _))) in kept.enumerate() {
                center.push(seg(&[p.key], &format!("{}{key}", if i > 0 { "  " } else { "" })));
                center.push(seg(&[p.soft], &format!(" {word}")));
            }
        }
        let mut right = Vec::new();
        if show.time {
            if show.date {
                right.push(seg(&[p.date], &if show.weekday { format!("{weekday} {day}") } else { day.clone() }));
                right.push(seg(&[p.dot], DOT));
            }
            right.push(seg(&[p.time, "1"], &time));
            if show.zone {
                right.push(seg(&[p.soft], &format!(" {zone}")));
            }
            right.push(seg(&[], " "));
        }
        (left, center, right)
    };
    let fits = |(left, center, right): &(Segments, Segments, Segments)| {
        let tips = if center.is_empty() { 0 } else { width_of(center) + 4 };
        width_of(left) + width_of(right) + 1 + tips <= width
    };
    let mut name = info.name.to_owned();
    let mut s = parts(&show, &name);
    while !fits(&s) && show.drop_next() {
        s = parts(&show, &name);
    }
    let over = width_of(&s.0) + width_of(&s.2) + 1 - width;
    if over > 0 {
        // a name too long for even this much
        let keep = usize::try_from((i64::try_from(name.len()).unwrap_or(0) - over).max(1)).unwrap_or(1);
        name.truncate(keep.min(name.len()));
        s = parts(&show, &name);
    }
    let (left, center, right) = &s;
    let (lw, cw, rw) = (width_of(left), width_of(center), width_of(right));
    let (mut gap1, mut gap2) = ((width - lw - rw).max(1), 0);
    if cw > 0 {
        let at = ((width - cw) / 2).max(lw + 2).min(width - rw - 2 - cw);
        gap1 = at - lw;
        gap2 = width - rw - at - cw;
    }
    if lw + gap1 + cw + gap2 + rw > width {
        return fill;
    }
    let run = |segments: &Segments| {
        segments.iter().fold(String::new(), |mut out, (style, text)| {
            out.push_str(style);
            out.push_str(text);
            out
        })
    };
    let spaces = |n: i64| " ".repeat(usize::try_from(n).unwrap_or(0));
    format!("{}{}{}{}{}{}{}{fill}", run(left), sgr(&[]), spaces(gap1), run(center), sgr(&[]), spaces(gap2), run(right))
}
