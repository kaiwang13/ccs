//! The program's output, from the holder's bytes to what each client is sent and what the emulator keeps.

mod adapter;
mod bar;
mod emulator;
mod pipeline;
mod snapshot;
mod tracker;

pub use adapter::{ByeExtra, ClientAdapter, ClientFlags, Clipboard, Context, NOTICE_TITLE_MS, Phase, Titles};
pub use bar::{BarInfo, bar_line, key_label};
pub use emulator::{At, Emulator, Keeper, Observer, Pin, Screen, Unwritten, UnwrittenLine};
pub use pipeline::{Chunk, Edit, EditKind, HOLD_MAX_BYTES, HOLD_MAX_MS, Pipeline, Reset, rewrite_row};
pub use snapshot::{
    Client, Geometry, Join, MainScreen, draw_bar, draw_over, join_bytes, join_geometry, last_row_empty, lift_over,
    main_screen, mode_bytes, put_back, redraw,
};
pub use tracker::{Census, Pen, Scheme, Tracker};
