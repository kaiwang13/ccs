//! What a key means to the client itself, before anything reaches the host: `src/client/keytable.js`. Detection lives here so
//! that detaching works even if the server has hung, and every other key belongs to the program.
//!
//! A key is named as `d`, `?`, `C-z`, or `M-g` for Alt+G (`C-M-g` with both). `leader` is the one key this client takes; the key after it is looked up in
//! `bindings`, and the leader twice sends one to the program. `direct` keys act at once, with no leader. A key after the
//! leader with no binding is dropped: it was meant for this client, not for the program.
//!
//! A Mac's terminal sends Option and a letter as the character the Mac's keyboard layout puts there, `©` for G, unless it
//! is told to send Option as Alt. With `mac_option`, such a character is also the Alt key, where one is bound: Alt+G works
//! from a Mac as it comes. Option and E, I, N or U begins an accent, and the Mac sends nothing until the key after it; with
//! a space, the accent alone, so Option+E and then Space is Alt+E.

use nmux_vt::InputKind;
use nmux_vt::keys::{KeyClass, KeyState, classify, decode_input_token};

/// The keys a client takes, as the configuration's `keys` section says.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct KeySpec {
    /// The key that comes before a binding.
    pub leader: Option<String>,
    /// A key after the leader, and the action it is, in the order a help screen lists them.
    pub bindings: Vec<(String, String)>,
    /// Keys that act with no leader.
    pub direct: Vec<(String, String)>,
    /// A character a Mac's Option key types with a letter is also Alt and the letter.
    pub mac_option: bool,
}

/// What Option and each letter from A to Z type on a Mac, in the layout most have (U.S., and ABC beneath Chinese input):
/// with Shift, E, I, N and U type the accents that Option and then Space do.
const MAC_OPTION: &str = "å∫ç∂´ƒ©˙ˆ∆˚¬µ˜øπœ®ß†¨√∑≈¥Ω";

/// The letter Option makes this character of, on a Mac.
fn mac_option_letter(seq: &str) -> Option<char> {
    let mut chars = seq.chars();
    let c = chars.next().filter(|_| chars.next().is_none())?;
    let at = MAC_OPTION.chars().position(|typed| typed == c)?;
    Some(char::from(b'a' + u8::try_from(at).ok()?))
}

/// What a key is to this client.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Action {
    /// The key is the program's.
    Program,
    /// The key is used up here.
    Ignore,
    /// Send the key after all.
    Literal,
    /// An action of the caller's, by name: `detach`, `help`, `history`.
    Named(String),
}

/// The client's keys, and whether the leader came last.
#[derive(Debug)]
pub struct KeyTable {
    spec: KeySpec,
    after_leader: bool,
    state: KeyState,
}

fn lookup<'a>(table: &'a [(String, String)], name: &str) -> Option<&'a str> {
    table.iter().find(|(k, _)| k == name).map(|(_, v)| v.as_str()).filter(|v| !v.is_empty())
}

impl KeyTable {
    /// A table of these keys.
    pub fn new(spec: KeySpec) -> Self {
        Self { spec, after_leader: false, state: KeyState::default() }
    }

    /// The keys it was made with.
    pub fn spec(&self) -> &KeySpec {
        &self.spec
    }

    /// The names a token means, usually one.
    fn names(&mut self, kind: InputKind, seq: &str) -> Vec<String> {
        if !matches!(kind, InputKind::Seq | InputKind::LoneEsc) {
            return Vec::new();
        }
        let mut names: Vec<String> = decode_input_token(seq, &mut self.state)
            .into_iter()
            .map(|ev| {
                let base = ev.name.filter(|n| !n.is_empty() && n != "number").unwrap_or(ev.sequence);
                match (ev.ctrl, ev.meta) {
                    (true, true) => format!("C-M-{base}"),
                    (true, false) => format!("C-{base}"),
                    (false, true) => format!("M-{base}"),
                    (false, false) => base,
                }
            })
            .collect();
        if self.spec.mac_option
            && let Some(letter) = mac_option_letter(seq)
        {
            names.push(format!("M-{letter}"));
        }
        names
    }

    /// What a token means here.
    pub fn action_for(&mut self, kind: InputKind, seq: &str) -> Action {
        let names = self.names(kind, seq);
        if self.after_leader {
            if names.is_empty() {
                // A paste: not meant for this client.
                self.after_leader = false;
                return Action::Program;
            }
            if is_key_up(seq) {
                // The leader's own key-up.
                return Action::Ignore;
            }
            self.after_leader = false;
            if self.spec.leader.as_ref().is_some_and(|l| names.contains(l)) {
                return Action::Literal;
            }
            return names
                .iter()
                .find_map(|n| lookup(&self.spec.bindings, n))
                .map_or(Action::Ignore, |a| Action::Named(a.to_owned()));
        }
        if let Some(a) = names.iter().find_map(|n| lookup(&self.spec.direct, n)) {
            return Action::Named(a.to_owned());
        }
        if self.spec.leader.as_ref().is_some_and(|l| names.contains(l)) {
            self.after_leader = true;
            return Action::Ignore;
        }
        Action::Program
    }

    /// Whether a key asks a client that is only waiting to give up: Ctrl+C or Ctrl+D.
    pub fn is_interrupt(kind: InputKind, seq: &str) -> bool {
        if !matches!(kind, InputKind::Seq | InputKind::LoneEsc) {
            return false;
        }
        decode_input_token(seq, &mut KeyState::default())
            .iter()
            .any(|ev| matches!(classify(ev), KeyClass::C | KeyClass::D))
    }
}

/// `:3` and a final byte: a key-up, in the kitty protocol.
fn is_key_up(seq: &str) -> bool {
    let b = seq.as_bytes();
    b.len() >= 3
        && b[b.len() - 3] == b':'
        && b[b.len() - 2] == b'3'
        && matches!(b[b.len() - 1], b'u' | b'~' | b'A'..=b'Z')
}
