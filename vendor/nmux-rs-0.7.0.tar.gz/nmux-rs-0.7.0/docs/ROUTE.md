# Why nmux-rs is built this way

`nmux` is the Node implementation. It proved the design and owns the conformance suite, and it costs what Node costs: about 115 MB per
session, a 240 MB install, and 16 to 24 MB/s of output. This repository is the same tool with those costs gone. The two are kept level.

Measured on one core of the development host, 2026-11-01, on 30 MB of output at 120x40 with 10,000 lines of history. "Peak" leaves out the
30 MB holding the input.

| | Plain lines | Coloured logs | TUI repaint | History, full |
|---|---|---|---|---|
| @xterm/headless 6 (what nmux uses) | 16 MB/s | 24 MB/s | 23 MB/s | 85 to 127 MB, with V8 |
| alacritty_terminal 0.26 | 68 MB/s | 116 MB/s | 160 MB/s | 30 MB |
| vt100 0.18 | 14 MB/s | 72 MB/s | 97 MB/s | 38 MB |
| A prototype of the design below | 41 MB/s | 114 MB/s | 153 MB/s | 3 MB |
| The vte parser alone | 989 MB/s | 1030 MB/s | 773 MB/s | |

## Language: Rust

Zig was the serious alternative: zmx shows it works, and libghostty-vt is the fastest terminal core there is. But that library is pre-1.0, has no tagged
release and an API that still changes, and a process that may run for months benefits from Rust's guarantees more than from Zig's speed. Go carries a
garbage collector into every session. Rust gives one static binary, no runtime, and no data races in the part of this project with the most state.

## The emulator is written here

This was the choice with the most riding on it. Parsing is not the cost: `vte` runs at a gigabyte a second, and every emulator above loses a factor
of ten or more in its screen model. And nmux needs things no library offers:

- `vt100` does not reflow, so a long line would not survive a resize.
- `alacritty_terminal` is excellent and does not fit. The main screen and the scroll region are private, so a join cannot be built while a program is on
  the alternate screen. Nothing says how many rows have scrolled, which is what a pin, a bookmark and the spool are built on. Its cells are 24 bytes.
- wezterm's terminal is not published as a crate, and libghostty-vt is ruled out above.

So `nmux-term` is a model made for this job: 8-byte cells on the screen, and history packed as it leaves it, which is what takes a full history from 30 MB to 3.
Rows carry numbers, so pins need no bookkeeping. It behaves as xterm does, because that is what the conformance suite compares with, and `alacritty_terminal`
stays on as a test oracle: a second opinion on the same bytes, fuzzed.

## One parser

The Node host lexes every byte twice, once to find what clients must treat specially and once inside xterm. Here `nmux-vt` tokenizes once, keeps each token's
raw bytes and offset, and the same tokens drive both.

## A sans-IO core on a small reactor

Session logic is plain state machines: events go in, and effects come out. Nothing in `nmux-server` touches a socket or a clock, so everything that took a fake clock in
Node is deterministic here by construction, and there are no `await` points for state to change across. `nmux-io` is the reactor underneath, on `mio`, shared by all
three processes. There is no async runtime: this is a handful of file descriptors per process, and tokio would bring more than it saved, particularly to the holder.

## Compatible on purpose

The wire protocol, the spec and state files and the runtime layout are the same, so a Rust server adopts a running Node holder and the other way round, and moving from one to
the other costs no session. The binary is called `nmux` and takes the same arguments.

## Naming

`nmux-rs`, as with `sudo-rs`, `ntpd-rs` and `tmux-rs`: the name of the repository says what it is a rewrite of, and the command keeps the tool's own name.
