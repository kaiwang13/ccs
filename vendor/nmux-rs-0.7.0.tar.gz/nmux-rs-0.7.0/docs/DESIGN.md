# How nmux-rs is put together

Read `docs/ROUTE.md` for why. The Node implementation in `../nmux` is the reference for behaviour: where this says nothing, do what it does.

## What may not differ

Everything a running process or another implementation can observe. A holder outlives every other process, so a Rust server has to adopt a Node holder and the reverse.

- **Frames:** `u32be length | u8 type | payload`, the types and limits in `src/wire/framing.js` and `proto.js`.
- **Every message:** HELLO, WELCOME, STATE, EVENT, REQ and RES, and all the holder's, field for field, including the frozen names in `src/wire/holder-wire.js`. New fields are additive, as there.
- **Files:** `session.json`, `state.json`, `holder-<gen>.json`, `holder.json`, the spool, and the runtime layout in `src/wire/layout.js`. A session's files are read by both.
- **Environment:** `NMUX_*`, `SHELL`, `SSH_AUTH_SOCK`, and the config file.
- **The command:** arguments, output, exit codes, words. Text a person reads comes from the same table.
- **`shell/`:** the same files as `../nmux/shell`, byte for byte. A test holds this.

## Crates

Each may use only those above it. `tools/` and tests may use anything.

| Crate | Holds | From `../nmux` |
|---|---|---|
| `nmux-vt` | The one parser: output tokens, input tokens, keys, modes, marks. No dependencies | `src/vt` |
| `nmux-time` | Times as a person reads and writes them, in a time zone, as `Intl` shows them. Only `jiff` | `src/base/time.js` |
| `nmux-wire` | Frames, messages, holder wire, layout | `src/wire` |
| `nmux-platform` | Everything that differs between Linux and macOS, behind one surface | `src/platform`, `native/` |
| `nmux-io` | The reactor: readiness, timers, signals, buffered connections | |
| `nmux-term` | The emulator, and rows as text | `@xterm/headless`, `src/server/output/cells.js` |
| `nmux-history` | The kept history: its files, writing them, and reading them back | `src/wire/history.js`, `src/server/output/spool.js`, `src/client/history.js` |
| `nmux-holder` | The process that owns the pty | `src/holder` |
| `nmux-server` | A session's server | `src/server` |
| `nmux-client` | The attach client, a pager on a history, control connections to a server, and the configuration file as a client reads it | `src/client`, `src/wire/ctlclient.js`, `src/sdk/client.js` |
| `nmux` | The binary: the command, and `__server` and `__holder`, which are how it runs as those processes | `src/cli`, `bin/` |

All of it is one binary, so a holder started by one release keeps running from the pages it has, and an upgrade is replacing a file.

## Principles

- **A sans-IO core.** `nmux-server` and `nmux-holder` hold their logic in types with no sockets, no clocks and no threads: `on_event(&mut self, event, now)`, which queues effects. Time is a value passed in. A thin
  run loop in each connects that to `nmux-io`. What took a fake clock and `await` in Node is an ordinary test here, and a long flow, such as a join, is an explicit state, not a suspended function.
- **One thread per process, and one for the disk.** No locks, no `Rc<RefCell<>>`, no async runtime. The kept history is written on a
  thread of its own (`nmux-history`), because a home on NFS can hang and a session must never wait for it: the server only queues.
- **One parse.** Output is tokenized once, and tokens drive both the clients' edits and the emulator, synchronously, so where a token fell is known without waiting for anything.
- **No allocation per byte, per line or per frame on the output path.** Reuse buffers. Copy only what is kept.
- **The holder stays small.** It is the process with the most to lose: no emulator, and nothing that could grow.
- **Platform code is in one place.** `#[cfg(target_os)]` appears only in `nmux-platform`, behind questions rather than OS names. Both Linux and macOS are targets. `cargo check --target x86_64-apple-darwin` must pass for it.
- **`unsafe` only in `nmux-platform`,** and only where a safe API does not exist, with a comment saying why it is sound.
- **Never force-kill anything.** SIGTERM is the strongest signal this project sends.

## How it is judged

- `cargo fmt --check`, `cargo clippy --all-targets -- -D warnings` and `cargo test` pass.
- Unit tests in `../nmux/test/unit` move here with the code they test, translated, not dropped.
- `../nmux/test/conformance` is the judge of the whole: `tools/conformance.sh` runs it against this binary. It only knows a host through `lib/host.js`.
- The emulator is held to xterm by differential tests: the same bytes through `@xterm/headless` and through `nmux-term`, with the same rows, attributes, cursor and modes afterwards.
- Performance is measured, not assumed: `cargo bench`-style numbers go in the commit that changes them.

## Style

Code reads like the Node code it came from where it can: the same names, and comments that say why. Plain words, full sentences, few of them. Types and small functions instead of comments where they can carry the meaning. No `unwrap` on anything that can
happen at run time. `panic = "abort"` in release, so a panic in a server is a crash the holder recovers from, and a panic in a holder loses a session: the holder must not have any.
