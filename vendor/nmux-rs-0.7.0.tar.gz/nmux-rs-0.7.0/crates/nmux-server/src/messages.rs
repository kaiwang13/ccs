//! Everything the server says to a person, in one table: `messages.js`. An embedding program replaces entries in its spec
//! to speak in its own name. A spec is a file, so an entry is text with `{name}`-style holes rather than a function;
//! `{amount}` is a byte count as a person reads it, and `null` says nothing where saying nothing is allowed.

use serde_json::{Map, Value};

/// A byte count as a person reads it.
pub fn amount(bytes: u64) -> String {
    #[allow(clippy::cast_precision_loss)] // a count of bytes rounded for reading
    let round = |n: u64, unit: u64| ((n as f64) / (unit as f64)).round();
    if bytes >= 1_048_576 {
        format!("{} MB", round(bytes, 1_048_576))
    } else if bytes >= 1024 {
        format!("{} KB", round(bytes, 1024))
    } else {
        format!("{bytes} bytes")
    }
}

/// A duration as a person reads it.
pub fn span(ms: u64) -> String {
    let s = ms / 1000;
    if s < 60 {
        return format!("{s}s");
    }
    let m = s / 60;
    if m < 60 {
        return format!("{m}m");
    }
    let h = m / 60;
    if h < 48 { format!("{h}h") } else { format!("{}d", h / 24) }
}

/// A count with the thousands apart, as `toLocaleString('en-US')` writes it.
fn grouped(n: u64) -> String {
    let digits = n.to_string();
    let mut out = String::new();
    for (i, c) in digits.chars().enumerate() {
        if i > 0 && (digits.len() - i) % 3 == 0 {
            out.push(',');
        }
        out.push(c);
    }
    out
}

/// A command that finished while a terminal was away.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Finished {
    /// What it was.
    pub command: Option<String>,
    /// Its exit code.
    pub exit: Option<u64>,
    /// How long it took.
    pub duration_ms: Option<u64>,
}

/// What happened while a terminal was away, in a line, or `None` if nothing did. Commands are what a shell typed back, and
/// this goes to a terminal, so they may not carry anything that would drive it.
pub fn away_text(finished: &[Finished], running: Option<Option<&str>>, lines: u64) -> Option<String> {
    let named = |c: Option<&str>| {
        c.filter(|c| !c.is_empty()).map_or_else(
            || "a command".to_owned(),
            |c| c.chars().map(|ch| if is_control(ch) { ' ' } else { ch }).take(40).collect(),
        )
    };
    let exit = |e: Option<u64>| e.map_or_else(|| "exit unknown".to_owned(), |e| format!("exit {e}"));
    let mut parts = Vec::new();
    if let [last] = finished {
        let after = last.duration_ms.map_or(String::new(), |d| format!(" after {}", span(d)));
        parts.push(format!("{} finished: {}{after}", named(last.command.as_deref()), exit(last.exit)));
    } else if let Some(last) = finished.last() {
        parts.push(format!("{} commands finished, the last with {}", finished.len(), exit(last.exit)));
    }
    if let Some(running) = running {
        parts.push(format!("{} still running", named(running)));
    }
    if lines > 0 {
        parts.push(format!("{} new line{}", grouped(lines), if lines == 1 { "" } else { "s" }));
    }
    (!parts.is_empty()).then(|| parts.join(" · "))
}

/// C0, DEL and C1: what may not reach a terminal from a line of text.
pub fn is_control(c: char) -> bool {
    matches!(c, '\u{0}'..='\u{1f}' | '\u{7f}'..='\u{9f}')
}

/// What the table says for an entry.
enum Entry {
    /// Nothing: the default stands.
    Default,
    /// Null: nothing is said.
    Nothing,
    /// This.
    Text(String),
}

/// See the module.
#[derive(Clone, Debug, Default)]
pub struct Messages {
    table: Map<String, Value>,
}

impl Messages {
    /// The defaults, with the entries of a spec's table over them.
    pub fn from_table(table: Option<&Value>) -> Self {
        Self { table: table.and_then(Value::as_object).cloned().unwrap_or_default() }
    }

    /// An entry of the table with its holes filled.
    fn entry(&self, key: &str, args: &[(&str, &str)], bytes: Option<u64>) -> Entry {
        let template = match self.table.get(key) {
            Some(Value::Null) => return Entry::Nothing,
            Some(Value::String(s)) => s.as_str(),
            Some(Value::Object(o)) => o.get("text").and_then(Value::as_str).unwrap_or(""),
            _ => return Entry::Default,
        };
        Entry::Text(fill(template, args, bytes))
    }

    fn text(&self, key: &str, args: &[(&str, &str)], default: impl FnOnce() -> String) -> String {
        match self.entry(key, args, None) {
            Entry::Text(s) => s,
            Entry::Nothing => String::new(),
            Entry::Default => default(),
        }
    }

    /// What a notice in a title starts with.
    pub fn brand(&self) -> String {
        self.text("brand", &[], || "nmux".into())
    }

    /// What a title starts with while the session asks for a person.
    pub fn attention_title(&self) -> String {
        self.text("attentionTitle", &[], || "[needs you] ".into())
    }

    /// The session is stopping.
    pub fn stopping(&self, name: &str) -> String {
        self.text("stopping", &[("name", name)], || format!("stopping '{name}'"))
    }

    /// The child would not exit.
    pub fn stop_stuck(&self, pid: &str) -> String {
        self.text("stopStuck", &[("pid", pid)], || format!("child pid {pid} did not exit; inspect it manually"))
    }

    /// The child outlived its holder.
    pub fn orphan_alive(&self, pid: &str) -> String {
        self.text("orphanAlive", &[("pid", pid)], || format!("child pid {pid} outlived its holder; sending SIGTERM"))
    }

    /// The child exited and the session stays: the notice's code and text.
    pub fn child_exited(&self, name: &str, how: &str) -> (String, String) {
        let code = self
            .table
            .get("childExited")
            .and_then(|v| v.get("code"))
            .and_then(Value::as_str)
            .unwrap_or("CHILD_EXITED")
            .to_owned();
        (code, self.text("childExited", &[("name", name), ("how", how)], || format!("the child exited ({how})")))
    }

    /// A new child could not be started.
    pub fn respawn_failed(&self, name: &str) -> String {
        self.text("respawnFailed", &[("name", name)], || "could not restart the child".into())
    }

    /// The session stopped.
    pub fn session_stopped(&self, name: &str) -> String {
        self.text("sessionStopped", &[("name", name)], || format!("session '{name}' stopped"))
    }

    /// The host is going down.
    pub fn host_shutdown(&self) -> String {
        self.text("hostShutdown", &[], || "the host is shutting down".into())
    }

    /// This server is going and another takes over.
    pub fn restarting(&self) -> String {
        self.text("restarting", &[], || "the server is restarting; reconnecting".into())
    }

    /// A terminal left, and the session goes on.
    pub fn client_exit(&self, name: &str) -> String {
        self.text("clientExit", &[("name", name)], || format!("the session '{name}' keeps running"))
    }

    /// Who sent a terminal away, when nobody said.
    pub fn default_kicked_by(&self) -> String {
        self.text("defaultKickedBy", &[], || "kick".into())
    }

    /// A terminal was sent away.
    pub fn kicked(&self, who: &str, name: &str) -> String {
        self.text("kicked", &[("who", who), ("name", name)], || format!("{who} — the session '{name}' keeps running"))
    }

    /// A client spoke another protocol.
    pub fn proto_mismatch(&self, theirs: &str, ours: u32, name: &str) -> String {
        let ours = ours.to_string();
        self.text("protoMismatch", &[("theirs", theirs), ("ours", &ours), ("name", name)], || {
            format!("protocol {theirs} is not supported (this session speaks {ours})")
        })
    }

    /// The session is blocked.
    pub fn blocked(&self, name: &str, code: Option<&str>) -> String {
        let code = code.unwrap_or("null");
        self.text("blocked", &[("name", name), ("code", code)], || format!("session '{name}' is blocked ({code})"))
    }

    /// A terminal too narrow.
    pub fn below_floor(&self, name: &str, cols: u32, rows: u32, floor: u32, hard_min: u32) -> String {
        let (c, r, f, h) = (cols.to_string(), rows.to_string(), floor.to_string(), hard_min.to_string());
        let args = [
            ("name", name),
            ("cols", c.as_str()),
            ("rows", r.as_str()),
            ("floor", f.as_str()),
            ("hardMin", h.as_str()),
        ];
        self.text("belowFloor", &args, || {
            format!(
                "this terminal is {cols}x{rows} — below the {floor}-column floor for shared sessions (minimum with shrink: {hard_min})"
            )
        })
    }

    /// Input was dropped because the child is not reading.
    pub fn input_dropped(&self) -> String {
        self.text("inputDropped", &[], || "input dropped — the child is not reading".into())
    }

    /// An ESC held for the child was let go.
    pub fn esc_hold_expired(&self) -> String {
        self.text("escHoldExpired", &[], || "Esc was not read by the child in time; later keys were sent anyway".into())
    }

    /// A guarded key pressed again too soon.
    pub fn held_key(&self, cls: &str, name: &str) -> String {
        self.text("heldKey", &[("cls", cls), ("name", name)], || {
            format!("repeated Ctrl+{cls} ignored — use 'nmux stop {name}' to end the session")
        })
    }

    /// The line above a join's screen, or none.
    pub fn join_banner(&self, name: &str, lines: u64) -> Option<String> {
        let n = lines.to_string();
        match self.entry("joinBanner", &[("name", name), ("lines", &n)], None) {
            Entry::Text(s) => Some(s),
            Entry::Nothing | Entry::Default => None,
        }
    }

    /// The line above the screen of a terminal that came back.
    pub fn away(&self, name: &str, what: &str) -> String {
        self.text("away", &[("name", name), ("what", what)], || format!("── nmux · {name} · {what} ──"))
    }

    /// Output a terminal did not keep up with.
    pub fn skipped_output(&self, bytes: u64, name: &str) -> String {
        let b = bytes.to_string();
        match self.entry("skippedOutput", &[("bytes", &b), ("name", name)], Some(bytes)) {
            Entry::Text(s) => s,
            Entry::Nothing => String::new(),
            Entry::Default => {
                format!("── nmux · skipped {} of output · nmux capture {name} --lines 100000 ──", amount(bytes))
            }
        }
    }

    /// Output lost for everyone.
    pub fn lost_output(&self, bytes: u64) -> String {
        let b = bytes.to_string();
        match self.entry("lostOutput", &[("bytes", &b)], Some(bytes)) {
            Entry::Text(s) => s,
            Entry::Nothing => String::new(),
            Entry::Default => format!("── nmux · lost {} of output ──", amount(bytes)),
        }
    }
}

/// `{name}` holes filled from `args`, `{amount}` from `bytes`; a hole nothing fills stays as it is.
fn fill(template: &str, args: &[(&str, &str)], bytes: Option<u64>) -> String {
    let mut out = String::with_capacity(template.len());
    let mut rest = template;
    while let Some(open) = rest.find('{') {
        out.push_str(&rest[..open]);
        let after = &rest[open + 1..];
        let word = after
            .find('}')
            .map(|close| &after[..close])
            .filter(|w| !w.is_empty() && w.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_'));
        let Some(word) = word else {
            out.push('{');
            rest = after;
            continue;
        };
        let value = if word == "amount" {
            Some(amount(bytes.unwrap_or(0)))
        } else {
            args.iter().find(|(k, _)| *k == word).map(|(_, v)| (*v).to_owned())
        };
        if let Some(v) = value {
            out.push_str(&v);
        } else {
            out.push('{');
            out.push_str(word);
            out.push('}');
        }
        rest = &after[word.len() + 1..];
    }
    out.push_str(rest);
    out
}
