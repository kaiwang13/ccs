//! The output pipeline, `pipeline.js`: it lexes the program's bytes once, marks every token a client must treat
//! specially, and finds full repaints: `CSI H (CSI 2K CSI 1B)×N CSI H` on the main screen. After one, everything is drawn
//! relative to home, so a client taller than the pty shows the whole repaint lower down by rewriting the two homes and any
//! absolute row (see the adapter).
//!
//! A program that is not repainting like that runs without looking for repaints: nothing is held back, and every resize
//! becomes an edit at the offset it took effect, so that the emulator follows the pty's size exactly.
//!
//! What took timers in Node is a deadline here: [`Pipeline::deadline`] says when [`Pipeline::on_time`] has something to
//! let go of.

use nmux_io::Time;
use nmux_vt::kitty;
use nmux_vt::marks::{Mark, parse_mark};
use nmux_vt::seq::{
    self, QueryKind, RowForm, ScrollbackHostile, absolute_row, dec_private, is_bare_home, is_cursor_down_1, is_decsc,
    is_erase_line_2, osc_number, scroll_region,
};
use nmux_vt::{Csi, Kind, Lexer, Token};

use super::tracker::{Applied, Tracker};

/// A repaint held back longer than this is not one.
pub const HOLD_MAX_BYTES: usize = 4096;
/// How long a repaint, or a sequence cut off by the end of a read, is waited for.
pub const HOLD_MAX_MS: u64 = 100;
const ALT_MODES: [u32; 3] = [47, 1047, 1049];

/// What a client or the emulator must do about a token.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum EditKind {
    /// A query: the holder answers it, and no client sees it.
    Drop(QueryKind),
    /// Absolute row positioning, drawn for a screen of `render_rows`.
    Row {
        /// How it was written.
        form: RowForm,
        /// 1-based.
        row: u32,
        /// 1-based, `None` for VPA.
        col: Option<u32>,
        /// The rows of the screen it was drawn for.
        render_rows: u32,
    },
    /// The program went to the alternate screen.
    AltEnter {
        /// With 1049, which saves the cursor of the screen it leaves.
        saves_cursor: bool,
    },
    /// The program left the alternate screen.
    AltExit,
    /// OSC 0 or 2.
    Title(String),
    /// OSC 52.
    Clipboard,
    /// DECSC.
    Decsc,
    /// The pty took this size here. It has no bytes.
    Resize {
        /// Columns.
        cols: u32,
        /// Rows.
        rows: u32,
    },
    /// DECSTBM, for a screen of `render_rows`.
    Margins {
        /// 1-based.
        top: u32,
        /// 1-based, `None` for the last row.
        bottom: Option<u32>,
        /// The rows of the screen.
        render_rows: u32,
    },
    /// A mark from the session's shell, and what a terminal is sent instead.
    Mark {
        /// What it said.
        mark: Mark,
        /// The standard OSC 133, empty for none.
        standard: Vec<u8>,
    },
    /// The screen was wiped: ED2 or ED3.
    Erase,
    /// A scroll region set where [`EditKind::Margins`] is not made (on the other screen, or by a program that repaints), or
    /// every setting reset (RIS, DECSTR), which `reset` says: only a terminal with nmux's bar at its foot does anything about it.
    Region {
        /// 1-based.
        top: u32,
        /// 1-based, `None` for the last row.
        bottom: Option<u32>,
        /// RIS or DECSTR.
        reset: bool,
    },
    /// The program's kitty keyboard flags are these from here, on the screen it is on: where it changed them, which no
    /// terminal is sent, after it changed screens, and before RIS. A terminal is told them as nmux tells it, never as the
    /// program did.
    Keyboard(u8),
}

/// An edit and where its bytes are in the chunk.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Edit {
    /// What it is.
    pub kind: EditKind,
    /// Where its bytes start in [`Chunk::bytes`].
    pub start: usize,
    /// Where they end.
    pub end: usize,
}

/// A full repaint, found.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Reset {
    /// The rows it cleared.
    pub n: u32,
    /// The rows it was drawn for.
    pub render_rows: u32,
    /// Where it started.
    pub offset: u64,
}

/// A stretch of the program's output with what is special in it: `AnnotatedChunk`.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Chunk {
    /// The stream offset of the first byte.
    pub start_offset: u64,
    /// The stream offset just past the last.
    pub end_offset: u64,
    /// The bytes.
    pub bytes: Vec<u8>,
    /// What is special in them, in order.
    pub edits: Vec<Edit>,
    /// It ends with nothing half sent: no sequence, no repaint held.
    pub ground_after: bool,
    /// Something in it may have written over a terminal's last row, which a bar there has to be drawn again after.
    pub wipes: bool,
    /// Full repaints that ended in it.
    pub resets: Vec<Reset>,
    /// Its text, with a line feed for each CR and LF, for what looks for words in the output: empty unless the pipeline
    /// keeps it ([`Pipeline::keep_text`]).
    pub text: String,
}

impl Chunk {
    /// The bytes of an edit.
    pub fn raw(&self, e: &Edit) -> &[u8] {
        &self.bytes[e.start..e.end]
    }

    /// The part of the chunk from a stream offset on, which is at a token's edge, so that no edit is cut in two.
    #[must_use]
    pub fn after(&self, offset: u64) -> Self {
        let cut = usize::try_from(offset.saturating_sub(self.start_offset)).unwrap_or(usize::MAX).min(self.bytes.len());
        let edits = self
            .edits
            .iter()
            .filter(|e| e.start >= cut)
            .map(|e| Edit { kind: e.kind.clone(), start: e.start - cut, end: e.end - cut })
            .collect();
        Self {
            start_offset: offset,
            end_offset: self.end_offset,
            bytes: self.bytes[cut..].to_vec(),
            edits,
            ground_after: self.ground_after,
            wipes: self.wipes,
            resets: Vec::new(),
            text: self.text.clone(),
        }
    }
}

/// The sequence that puts the cursor on `row` the way `form` did, with its column: `rewriteRow`.
pub fn rewrite_row(form: RowForm, col: Option<u32>, row: u32) -> Vec<u8> {
    match (form, col) {
        (RowForm::Home, _) => format!("\x1b[{row};1H"),
        (RowForm::Cup, None) => format!("\x1b[{row}H"),
        (RowForm::Cup, Some(col)) => format!("\x1b[{row};{col}H"),
        (RowForm::Hvp, col) => format!("\x1b[{row};{}f", col.unwrap_or(1)),
        (RowForm::Vpa, _) => format!("\x1b[{row}d"),
    }
    .into_bytes()
}

/// A token of a repaint being held: all CSI, so nothing but where it is and what it says is needed.
#[derive(Debug)]
struct Held {
    start: u64,
    raw: Vec<u8>,
}

#[derive(Debug)]
struct Hold {
    home: Held,
    toks: Vec<Held>,
    pairs: u32,
    /// The next token that would carry the repaint on is `CSI 2K`, not `CSI 1B`.
    expect_erase: bool,
    bytes: usize,
}

/// Tokens ready to go out, with their bytes already together.
#[derive(Debug, Default)]
struct Ready {
    start: Option<u64>,
    end: u64,
    bytes: Vec<u8>,
    edits: Vec<Edit>,
    text: String,
    last_partial: bool,
    wipes: bool,
}

/// See the module.
#[derive(Debug)]
#[allow(clippy::struct_excessive_bools)] // what it is asked to do, and whether the lexer holds anything
pub struct Pipeline {
    detect_resets: bool,
    mark_token: Option<String>,
    notes_erase: bool,
    keeps_text: bool,
    start_offset: u64,
    lexer: Option<Lexer>,
    /// The next offset the lexer expects, once it has had any.
    next_offset: Option<u64>,
    lexer_ground: bool,
    ready: Ready,
    hold: Option<Hold>,
    hold_due: Option<Time>,
    partial_due: Option<Time>,
    resets: Vec<Reset>,
}

impl Pipeline {
    /// A pipeline for a stream that starts at `start_offset`. `detect_resets` for a program that repaints; `mark_token` for
    /// the marks of a shell started to give them; `notes_erase` when something needs to know that the screen was wiped.
    pub fn new(detect_resets: bool, start_offset: u64, mark_token: Option<String>, notes_erase: bool) -> Self {
        Self {
            detect_resets,
            mark_token,
            notes_erase,
            keeps_text: false,
            start_offset,
            lexer: None,
            next_offset: None,
            lexer_ground: true,
            ready: Ready::default(),
            hold: None,
            hold_due: None,
            partial_due: None,
            resets: Vec::new(),
        }
    }

    /// Chunks carry their text, for something that looks for words in the output. Gathering it costs more than the rest of
    /// the pipeline does, so only a session that looks has it.
    #[must_use]
    pub fn keep_text(mut self) -> Self {
        self.keeps_text = true;
        self
    }

    /// Nothing is held: no repaint, no half sequence, nothing not yet handed out.
    pub fn quiescent(&self) -> bool {
        self.hold.is_none() && self.lexer_ground && self.ready.start.is_none()
    }

    /// When [`Pipeline::on_time`] has something to let go of.
    pub fn deadline(&self) -> Option<Time> {
        match (self.hold_due, self.partial_due) {
            (Some(a), Some(b)) => Some(a.min(b)),
            (a, b) => a.or(b),
        }
    }

    /// The program's bytes from `offset` on.
    pub fn process(&mut self, tracker: &mut Tracker, offset: u64, bytes: &[u8], now: Time) -> Vec<Chunk> {
        self.partial_due = None;
        let mut out = Vec::new();
        let next = *self.next_offset.get_or_insert(offset);
        let mut lexer = self.lexer.take().unwrap_or_else(|| Lexer::new(offset));
        let (mut offset, mut bytes) = (offset, bytes);
        if offset < next {
            // sent again: what was lexed already is skipped
            let skip = usize::try_from(next - offset).unwrap_or(usize::MAX);
            if skip >= bytes.len() {
                self.lexer = Some(lexer);
                return out;
            }
            bytes = &bytes[skip..];
            offset = next;
        }
        if offset > next {
            // a gap: nothing can carry on across it
            lexer.flush_partial(|t| self.token(tracker, &t, now));
            self.lexer_ground = true;
            self.resolve_hold(tracker, false, None);
            out.extend(self.emit());
            lexer = Lexer::new(offset);
        }
        let end = offset + bytes.len() as u64;
        self.next_offset = Some(end);
        let ground = lexer.feed(bytes, |t| self.token(tracker, &t, now));
        self.lexer = Some(lexer);
        self.lexer_ground = ground;
        self.settle_at(tracker, end);
        out.extend(self.emit());
        if !ground {
            self.partial_due = Some(now.after(HOLD_MAX_MS));
        }
        out
    }

    /// A resize the stream has already reached, with no token after it to carry it.
    pub fn settle(&mut self, tracker: &mut Tracker) -> Option<Chunk> {
        self.settle_at(tracker, self.next_offset.unwrap_or(self.start_offset));
        self.emit()
    }

    /// Lets go of everything held: a repaint, as not one, and a half sequence.
    pub fn flush(&mut self, tracker: &mut Tracker, now: Time) -> Option<Chunk> {
        self.partial_due = None;
        if let Some(mut lexer) = self.lexer.take() {
            lexer.flush_partial(|t| self.token(tracker, &t, now));
            self.lexer = Some(lexer);
        }
        self.lexer_ground = true;
        self.resolve_hold(tracker, false, None);
        self.emit()
    }

    /// What is due at `now`: a half sequence waited for long enough, or a repaint that never finished.
    pub fn on_time(&mut self, tracker: &mut Tracker, now: Time) -> Vec<Chunk> {
        let mut out = Vec::new();
        if self.partial_due.is_some_and(|due| due <= now) {
            self.partial_due = None;
            if let Some(mut lexer) = self.lexer.take() {
                lexer.flush_partial(|t| self.token(tracker, &t, now));
                self.lexer = Some(lexer);
                self.lexer_ground = true;
                out.extend(self.emit());
            }
        }
        if self.hold_due.is_some_and(|due| due <= now) {
            self.resolve_hold(tracker, false, None);
            out.extend(self.emit());
        }
        out
    }

    fn settle_at(&mut self, tracker: &mut Tracker, offset: u64) {
        if self.detect_resets {
            return; // a repaint waits for the first token past the resize
        }
        let applied = tracker.advance_to(offset);
        self.resized(&applied, offset);
    }

    fn resized(&mut self, applied: &[Applied], offset: u64) {
        for r in applied {
            self.push(offset, b"", Some(EditKind::Resize { cols: r.cols, rows: r.rows }), false);
        }
    }

    fn token(&mut self, tracker: &mut Tracker, t: &Token<'_>, now: Time) {
        let applied = tracker.advance_to(t.start);
        if !self.detect_resets {
            self.resized(&applied, t.start);
        }
        if let Some(h) = &mut self.hold {
            let held = || Held { start: t.start, raw: t.raw.to_vec() };
            if h.expect_erase && is_erase_line_2(t) {
                h.toks.push(held());
                h.expect_erase = false;
                h.bytes += t.raw.len();
                self.check_hold_size(tracker);
                return;
            }
            if !h.expect_erase && is_cursor_down_1(t) {
                h.toks.push(held());
                h.expect_erase = true;
                h.pairs += 1;
                h.bytes += t.raw.len();
                self.check_hold_size(tracker);
                return;
            }
            if h.expect_erase && h.pairs > 0 && is_bare_home(t) {
                self.resolve_hold(tracker, true, Some(t));
                return;
            }
            self.resolve_hold(tracker, false, None);
        }
        self.annotate(tracker, t, now);
    }

    fn check_hold_size(&mut self, tracker: &mut Tracker) {
        if self.hold.as_ref().is_some_and(|h| h.bytes > HOLD_MAX_BYTES) {
            self.resolve_hold(tracker, false, None);
        }
    }

    fn resolve_hold(&mut self, tracker: &mut Tracker, is_reset: bool, closing: Option<&Token<'_>>) {
        let Some(h) = self.hold.take() else { return };
        self.hold_due = None;
        let render_rows = if is_reset { tracker.reset_rows(h.pairs) } else { tracker.pty_rows };
        if !is_reset {
            tracker.census.bare_home += 1;
        }
        let home = || EditKind::Row { form: RowForm::Home, row: 1, col: Some(1), render_rows };
        self.push(h.home.start, &h.home.raw, Some(home()), false);
        for t in &h.toks {
            self.push(t.start, &t.raw, None, false);
        }
        if let (true, Some(closing)) = (is_reset, closing) {
            self.push(closing.start, closing.raw, Some(home()), false);
            self.resets.push(Reset { n: h.pairs, render_rows, offset: h.home.start });
            tracker.last_reset_offset = Some(h.home.start);
            tracker.screen_rows = render_rows;
        }
    }

    #[allow(clippy::too_many_lines)] // one decision per kind of token, in the order Node makes them
    fn annotate(&mut self, tracker: &mut Tracker, t: &Token<'_>, now: Time) {
        match t.kind {
            Kind::C0(b @ (0x0e | 0x0f)) => tracker.shifted = b == 0x0e,
            Kind::Esc { intermediates: b"(", final_byte } => tracker.g0 = final_byte,
            _ if is_full_reset(t) => {
                tracker.g0 = b'B';
                tracker.shifted = false;
                tracker.scheme.forget();
            }
            _ => {}
        }
        if wipes_bottom(t) {
            self.ready.wipes = true;
        }
        if matches!(t.kind, Kind::Text { .. } | Kind::C0(_)) {
            self.push_token(t, None); // most of any output, and nothing below is about it
            return;
        }
        if let Some(query) = seq::query_kind(t) {
            self.push_token(t, Some(EditKind::Drop(query)));
            return;
        }
        if seq::is_scheme_query(t) {
            tracker.scheme.ask(); // the terminals answer it, as input
            self.push_token(t, None);
            return;
        }
        if kitty::op(t).is_some() {
            tracker.modes.apply(t);
            self.push_token(t, Some(EditKind::Keyboard(tracker.modes.keyboard())));
            return;
        }
        if let Some(dp) = dec_private(t) {
            if dp.modes().any(|m| m == seq::SCHEME_MODE) {
                tracker.scheme.forget();
            }
            let alt_modes = dp.modes().any(|m| ALT_MODES.contains(&m));
            if !tracker.alt && dp.set && dp.modes().any(|m| m == 47 || m == 1047) {
                tracker.census.alt47 += 1;
            }
            tracker.modes.apply(t);
            if !alt_modes {
                self.push_token(t, None);
                return;
            }
            tracker.alt = dp.set;
            self.ready.wipes = true;
            let kind = if dp.set {
                EditKind::AltEnter { saves_cursor: dp.modes().any(|m| m == 1049) }
            } else {
                EditKind::AltExit
            };
            self.push_token(t, Some(kind));
            let keyboard = tracker.modes.keyboard();
            if keyboard != 0 {
                self.push(t.end(), b"", Some(EditKind::Keyboard(keyboard)), false); // the flags of the screen it is on now
            }
            return;
        }
        if tracker.modes.keyboard() != 0 && matches!(t.kind, Kind::Esc { intermediates: b"", final_byte: b'c' }) {
            self.push(t.start, b"", Some(EditKind::Keyboard(0)), false); // RIS takes them off every stack
        }
        tracker.modes.apply(t); // RIS, DECSCUSR
        if let Kind::Csi(Csi { prefix: None, intermediates: b"", final_byte: b'm', params, .. }) = t.kind {
            // the lexer only ever puts bytes from 0x30 to 0x3f here
            tracker.note_pen(std::str::from_utf8(params.as_bytes()).unwrap_or(""));
            self.push_token(t, None);
            return;
        }
        if matches!(t.kind, Kind::Esc { intermediates: b"", final_byte: b'c' }) {
            tracker.pen.clear();
        }
        if !tracker.alt {
            let ar = absolute_row(t);
            if ar.is_some_and(|ar| ar.form == RowForm::Home) && self.detect_resets {
                // it may start a repaint: what follows is held
                self.hold = Some(Hold {
                    home: Held { start: t.start, raw: t.raw.to_vec() },
                    toks: Vec::new(),
                    pairs: 0,
                    expect_erase: true,
                    bytes: t.raw.len(),
                });
                self.hold_due = Some(now.after(HOLD_MAX_MS));
                return;
            }
            if let Some(ar) = ar {
                tracker.census.absolute += 1;
                let relative = !self.detect_resets && tracker.modes.raw(6) == 1; // DECOM counts from the margins
                let edit = (!relative).then_some(EditKind::Row {
                    form: ar.form,
                    row: ar.row,
                    col: ar.col,
                    render_rows: tracker.pty_rows,
                });
                self.push_token(t, edit);
                return;
            }
            if let Some(region) = scroll_region(t).filter(|_| !self.detect_resets) {
                tracker.census.decstbm += 1;
                let kind = EditKind::Margins { top: region.top, bottom: region.bottom, render_rows: tracker.pty_rows };
                self.push_token(t, Some(kind));
                return;
            }
            let hostile = seq::is_scrollback_hostile(t);
            match hostile {
                Some(ScrollbackHostile::Ed2) => tracker.census.ed2 += 1,
                Some(ScrollbackHostile::Ed3) => tracker.census.ed3 += 1,
                Some(ScrollbackHostile::Ris) => tracker.census.ris += 1,
                Some(ScrollbackHostile::Decstbm) => tracker.census.decstbm += 1,
                Some(ScrollbackHostile::Su) => tracker.census.su += 1,
                Some(ScrollbackHostile::Sd) => tracker.census.sd += 1,
                _ => {}
            }
            if self.notes_erase && matches!(hostile, Some(ScrollbackHostile::Ed2 | ScrollbackHostile::Ed3)) {
                self.push_token(t, Some(EditKind::Erase));
                return;
            }
        }
        if let Some(region) = scroll_region(t) {
            self.push_token(t, Some(EditKind::Region { top: region.top, bottom: region.bottom, reset: false }));
            return;
        }
        if is_full_reset(t) {
            self.push_token(t, Some(EditKind::Region { top: 1, bottom: None, reset: true }));
            return;
        }
        if is_decsc(t) {
            self.push_token(t, Some(EditKind::Decsc));
            return;
        }
        match (osc_number(t), t.kind) {
            (Some(0 | 2), Kind::Osc(data)) => {
                let text = data
                    .iter()
                    .position(|&b| b == b';')
                    .map_or(String::new(), |i| String::from_utf8_lossy(&data[i + 1..]).into_owned());
                tracker.title.clone_from(&text);
                self.push_token(t, Some(EditKind::Title(text)));
                return;
            }
            (Some(52), _) => {
                self.push_token(t, Some(EditKind::Clipboard));
                return;
            }
            (Some(133), Kind::Osc(data)) => {
                if let Some(found) = self.mark_token.as_deref().and_then(|token| parse_mark(data, token)) {
                    self.push_token(t, Some(EditKind::Mark { mark: found.mark, standard: found.standard }));
                    return;
                }
            }
            _ => {}
        }
        self.push_token(t, None);
    }

    fn push_token(&mut self, t: &Token<'_>, edit: Option<EditKind>) {
        let partial = matches!(t.kind, Kind::Partial);
        self.push(t.start, t.raw, edit, partial);
        if !self.keeps_text {
            return;
        }
        match t.kind {
            Kind::Text { .. } => self.ready.text.push_str(&String::from_utf8_lossy(t.raw)),
            Kind::C0(b'\n' | b'\r') => self.ready.text.push('\n'),
            _ => {}
        }
    }

    fn push(&mut self, start: u64, raw: &[u8], edit: Option<EditKind>, partial: bool) {
        let r = &mut self.ready;
        let base = *r.start.get_or_insert(start);
        let at = usize::try_from(start - base).unwrap_or(usize::MAX);
        // Tokens that are ready always follow each other, so where one starts is where the bytes end.
        debug_assert_eq!(at, r.bytes.len());
        if let Some(kind) = edit {
            r.edits.push(Edit { kind, start: r.bytes.len(), end: r.bytes.len() + raw.len() });
        }
        r.bytes.extend_from_slice(raw);
        r.end = start + raw.len() as u64;
        r.last_partial = partial;
    }

    fn emit(&mut self) -> Option<Chunk> {
        let ready = std::mem::take(&mut self.ready);
        let start_offset = ready.start?;
        Some(Chunk {
            start_offset,
            end_offset: ready.end,
            bytes: ready.bytes,
            edits: ready.edits,
            ground_after: self.lexer_ground && self.hold.is_none() && !ready.last_partial,
            wipes: ready.wipes,
            resets: std::mem::take(&mut self.resets),
            text: ready.text,
        })
    }
}

/// RIS, or DECSTR: every setting back to its default, the scroll region included.
fn is_full_reset(t: &Token<'_>) -> bool {
    matches!(t.kind, Kind::Esc { intermediates: b"", final_byte: b'c' })
        || matches!(t.kind, Kind::Csi(Csi { prefix: None, intermediates: b"!", final_byte: b'p', .. }))
}

/// Whether `t` may write over a terminal's last row, wherever the cursor is: an erase of what is below it or of
/// everything, a full reset, or the screen filled with the alignment pattern. The other screen coming or going is said
/// where it is found.
fn wipes_bottom(t: &Token<'_>) -> bool {
    if is_full_reset(t) || matches!(t.kind, Kind::Esc { intermediates: b"#", final_byte: b'8' }) {
        return true;
    }
    matches!(t.kind, Kind::Csi(Csi { prefix: None | Some(b'?'), intermediates: b"", final_byte: b'J', params, .. })
        if matches!(params.as_bytes(), b"" | b"0" | b"2"))
}
