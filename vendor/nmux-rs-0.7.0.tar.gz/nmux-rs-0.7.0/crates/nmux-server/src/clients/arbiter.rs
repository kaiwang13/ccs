//! The size arbiter, `arbiter.js`: the pty takes the smallest size of the clients that count, within the floors and the
//! largest. A shrink waits a moment for more, never longer than its most; a grow waits longer, for each dimension on its
//! own, and only for a change worth making. A change back cancels what was waiting, and one resize carries both
//! dimensions. With no client that counts, nothing changes.

use nmux_io::Time;
use nmux_wire::Size;

use crate::config::SizeConfig;
use crate::output::Phase;

/// What the arbiter needs to know of a client.
#[derive(Clone, Copy, Debug)]
#[allow(clippy::struct_excessive_bools)] // what decides whether it counts
pub struct Seat {
    /// Its columns.
    pub cols: u32,
    /// Its rows.
    pub rows: u32,
    /// Where it is.
    pub phase: Phase,
    /// It stopped answering pings.
    pub stalled: bool,
    /// It stopped answering for long.
    pub unresponsive: bool,
    /// It may go below the usual floor.
    pub shrink: bool,
    /// It only watches.
    pub view: bool,
}

impl Seat {
    /// Live or joining, answering, and not only watching: the clients that limit the size.
    fn counts(&self) -> bool {
        matches!(self.phase, Phase::Live | Phase::Joining) && !self.stalled && !self.unresponsive && !self.view
    }
}

#[derive(Clone, Copy, Debug, Default)]
struct Grow {
    due: Option<Time>,
    target: Option<u32>,
    matured: bool,
}

/// See the module.
#[derive(Debug)]
pub struct Arbiter {
    size: SizeConfig,
    shrink_due: Option<Time>,
    shrink_first_at: Option<Time>,
    /// Columns, then rows.
    grow: [Grow; 2],
    disposed: bool,
}

impl Arbiter {
    /// An arbiter with these rules.
    pub fn new(size: SizeConfig) -> Self {
        Self { size, shrink_due: None, shrink_first_at: None, grow: [Grow::default(); 2], disposed: false }
    }

    /// The size the clients that count want, or `None` when none does.
    pub fn desired(&self, seats: &[Seat]) -> Option<Size> {
        let live: Vec<&Seat> = seats.iter().filter(|s| s.counts()).collect();
        let narrowest = live.iter().map(|s| s.cols).min()?;
        let shortest = live.iter().map(|s| s.rows).min()?;
        let floor = if live.iter().any(|s| s.shrink) { self.size.hard_min_cols } else { self.size.floor_cols };
        Some(Size {
            cols: narrowest.clamp(floor, self.size.max_cols.max(floor)),
            rows: shortest.clamp(self.size.floor_rows, self.size.max_rows.max(self.size.floor_rows)),
        })
    }

    /// When [`Arbiter::on_time`] has something to do.
    pub fn deadline(&self) -> Option<Time> {
        [self.shrink_due, self.grow[0].due, self.grow[1].due].into_iter().flatten().min()
    }

    /// Looks again after a join, a leave, a resize, a stall or its end, a pause, or a size applied.
    pub fn on_change(&mut self, now: Time, seats: &[Seat], pty: Size) {
        if self.disposed {
            return;
        }
        let Some(d) = self.desired(seats).filter(|d| *d != pty) else {
            self.cancel_all();
            return;
        };
        if d.cols < pty.cols || d.rows < pty.rows {
            let first = *self.shrink_first_at.get_or_insert(now);
            let wait =
                self.size.shrink_debounce_ms.min((first.ms() + self.size.shrink_max_wait_ms).saturating_sub(now.ms()));
            self.shrink_due = Some(now.after(wait));
        } else {
            self.cancel_shrink();
        }
        let s = &self.size;
        let (wide, tall) = (d.cols >= pty.cols + s.grow_min_cols, d.rows >= pty.rows + s.grow_min_rows);
        self.schedule_grow(0, wide, d.cols, now);
        self.schedule_grow(1, tall, d.rows, now);
    }

    fn schedule_grow(&mut self, dim: usize, wanted: bool, target: u32, now: Time) {
        if !wanted {
            self.cancel_grow(dim);
            return;
        }
        if self.grow[dim].due.is_some() && self.grow[dim].target == Some(target) {
            return;
        }
        self.cancel_grow(dim);
        self.grow[dim] =
            Grow { due: Some(now.after(self.size.grow_debounce_ms)), target: Some(target), matured: false };
    }

    /// What is due at `now`: the size to give the pty, if it changes.
    pub fn on_time(&mut self, now: Time, seats: &[Seat], pty: Size) -> Option<Size> {
        let shrink = self.shrink_due.is_some_and(|due| due <= now);
        let grown: Vec<usize> = (0..2).filter(|&d| self.grow[d].due.is_some_and(|due| due <= now)).collect();
        if !shrink && grown.is_empty() {
            return None;
        }
        if shrink {
            self.shrink_due = None;
            self.shrink_first_at = None;
        }
        // a grow due at this same moment has matured too: both dimensions then share one resize
        for d in grown {
            self.grow[d] = Grow { due: None, target: None, matured: true };
        }
        self.fire(seats, pty)
    }

    fn fire(&mut self, seats: &[Seat], pty: Size) -> Option<Size> {
        if self.disposed {
            return None;
        }
        let matured = [self.grow[0].matured, self.grow[1].matured];
        self.grow[0].matured = false;
        self.grow[1].matured = false;
        let d = self.desired(seats)?;
        let s = &self.size;
        // a shrinking dimension follows what is wanted now; a growing one only once its own wait is over
        let cols =
            if d.cols < pty.cols || (matured[0] && d.cols >= pty.cols + s.grow_min_cols) { d.cols } else { pty.cols };
        let rows =
            if d.rows < pty.rows || (matured[1] && d.rows >= pty.rows + s.grow_min_rows) { d.rows } else { pty.rows };
        if cols == pty.cols && rows == pty.rows {
            return None;
        }
        if cols < pty.cols || rows < pty.rows {
            self.cancel_shrink();
        }
        Some(Size { cols, rows })
    }

    fn cancel_shrink(&mut self) {
        self.shrink_due = None;
        self.shrink_first_at = None;
    }

    fn cancel_grow(&mut self, dim: usize) {
        self.grow[dim] = Grow::default();
    }

    fn cancel_all(&mut self) {
        self.cancel_shrink();
        self.cancel_grow(0);
        self.cancel_grow(1);
    }

    /// Nothing more is done.
    pub fn dispose(&mut self) {
        self.cancel_all();
        self.disposed = true;
    }
}
