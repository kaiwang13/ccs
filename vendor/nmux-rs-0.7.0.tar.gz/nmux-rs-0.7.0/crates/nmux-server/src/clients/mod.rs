//! The attached clients: who is here, what reaches them, and the size they share.

pub mod arbiter;
