//! A session's spec, `session.json`: everything its server needs, so that the holder can start the same server again with
//! nothing but the file. Written by the command or an embedding program, as `src/sdk/host.js` writes it.

use std::collections::BTreeMap;

use nmux_wire::{Colors, Size};
use serde::Deserialize;
use serde_json::{Map, Value};

/// The program the session runs.
#[derive(Clone, Debug, Default, Deserialize, PartialEq, Eq)]
#[serde(default)]
pub struct Child {
    /// Its command line.
    pub argv: Vec<String>,
    /// Its whole environment.
    pub env: BTreeMap<String, String>,
    /// Where it starts.
    pub cwd: String,
}

/// The kept history.
#[derive(Clone, Debug, Default, Deserialize, PartialEq, Eq)]
#[serde(default, rename_all = "camelCase")]
pub struct SpoolSpec {
    /// The most it keeps, when it is not kept whole.
    pub max_bytes: u64,
    /// Kept whole, in a directory that outlives the session.
    pub keep: bool,
    /// Where, if not in the session's directory.
    pub dir: Option<String>,
}

/// A shell started to say where its prompts and commands are.
#[derive(Clone, Debug, Default, Deserialize, PartialEq, Eq)]
#[serde(default)]
pub struct ShellSpec {
    /// What its marks carry, so that output that only looks like one is not taken for one.
    pub token: String,
}

/// A key guard a managed session declares.
#[derive(Clone, Debug, Default, Deserialize, PartialEq, Eq)]
#[serde(default, rename_all = "camelCase")]
pub struct GuardSpec {
    /// The key classes guarded: `C`, `D`.
    pub keys: Vec<String>,
    /// How long after the program's answer another press is let through.
    pub margin_ms: u64,
    /// The notice's code when a press is held.
    pub code: Option<String>,
}

/// The command that starts the controller of a managed session, when none is connected.
#[derive(Clone, Debug, Default, Deserialize, PartialEq, Eq)]
#[serde(default)]
pub struct CommandSpec {
    /// Its command line.
    pub argv: Vec<String>,
    /// Added to the server's environment.
    pub env: BTreeMap<String, String>,
}

/// What a managed session's controller declares, because it has to happen on every keystroke and cannot wait for it.
#[derive(Clone, Debug, Default, Deserialize, PartialEq)]
#[serde(default, rename_all = "camelCase")]
pub struct Managed {
    /// What STATE and STATUS start with.
    pub attrs: Map<String, Value>,
    /// What WELCOME adds.
    pub welcome: Map<String, Value>,
    /// The session outlives its child.
    pub stays: bool,
    /// The key classes that detach a terminal.
    pub detach_keys: Vec<String>,
    /// `false`: focus reports never reach the program.
    pub forward_focus: Option<bool>,
    /// Key guards.
    pub guards: Vec<GuardSpec>,
    /// Patterns whose appearance in the output is an event.
    #[serde(rename = "match")]
    pub patterns: Vec<String>,
    /// How long a stop waits for the controller.
    pub stop_grace_ms: Option<u64>,
    /// How often the controller is pinged.
    pub ping_ms: Option<u64>,
    /// How long a controller may be silent.
    pub silent_ms: Option<u64>,
    /// What starts the controller.
    pub command: Option<CommandSpec>,
}

/// The server's own timers, shortened by tests: `DEFAULT_TIMERS`.
#[derive(Clone, Debug, Deserialize, PartialEq, Eq)]
#[serde(default, rename_all = "camelCase")]
#[allow(clippy::struct_field_names)] // the Node names
pub struct Timers {
    /// How long the holder is waited for.
    pub holder_connect_ms: u64,
    /// How often it is pinged.
    pub holder_ping_ms: u64,
    /// How long it may be silent before terminals are told.
    pub holder_unresponsive_ms: u64,
    /// How long a child that outlived its holder is waited for.
    pub orphan_wait_ms: u64,
    /// How long changes to the record wait to be written together.
    pub state_debounce_ms: u64,
    /// How many times a join waits for a frame to end.
    pub quiesce_tries: u32,
    /// How long each of those waits.
    pub sync_frame_wait_ms: u64,
}

impl Default for Timers {
    fn default() -> Self {
        Self {
            holder_connect_ms: 10_000,
            holder_ping_ms: 5000,
            holder_unresponsive_ms: 15_000,
            orphan_wait_ms: 60_000,
            state_debounce_ms: 2000,
            quiesce_tries: 5,
            sync_frame_wait_ms: 200,
        }
    }
}

/// See the module.
#[derive(Clone, Debug, Default, Deserialize, PartialEq)]
#[serde(default, rename_all = "camelCase")]
pub struct Spec {
    /// The session's id.
    pub id: String,
    /// Its name.
    pub name: String,
    /// The runtime directory.
    pub runtime_dir: String,
    /// Where its record is written, if anywhere.
    pub state_file: Option<String>,
    /// What it runs.
    pub child: Child,
    /// The pty's first size.
    pub pty: Size,
    /// `TERM`.
    pub term: Option<String>,
    /// The variable that names the session in its own processes, to refuse attaching from inside it.
    pub nest_env: Option<String>,
    /// The configuration, in place of the user's file.
    pub config: Option<Value>,
    /// The user's configuration file.
    pub config_file: Option<String>,
    /// The session's own words.
    pub messages: Option<Value>,
    /// What a controller declares.
    pub managed: Option<Managed>,
    /// The colours of the terminal it was started from.
    pub term_colors: Option<Colors>,
    /// More environment for the holder.
    pub holder_env: BTreeMap<String, String>,
    /// A shell that gives marks.
    pub shell: Option<ShellSpec>,
    /// The link the session's programs know the ssh agent by.
    pub agent: Option<String>,
    /// The kept history.
    pub spool: Option<SpoolSpec>,
    /// When it was created.
    pub created_at: Option<String>,
    /// The server's timers.
    pub timers: Option<Value>,
    /// The holder's timers.
    pub holder_timers: Option<Value>,
}

impl Spec {
    /// Reads a spec.
    pub fn parse(text: &[u8]) -> Result<Self, String> {
        serde_json::from_slice(text).map_err(|e| format!("session spec: {e}"))
    }

    /// The server's timers, with what the spec shortens.
    pub fn timers(&self) -> Timers {
        self.timers.as_ref().and_then(|t| Timers::deserialize(t).ok()).unwrap_or_default()
    }
}
