//! The session's lifecycle as a pure function, `machine.js`: [`reduce`] gives the next state and what the session must
//! do, in order. Nothing here touches a clock, a socket or a process.

use serde::Serialize;

/// Where a session is in its life. A controller may add phases of its own, which are names too.
#[derive(Clone, Debug, PartialEq, Eq, Hash, Serialize)]
#[serde(transparent)]
pub struct Lifecycle(pub String);

impl Lifecycle {
    /// The holder is being started.
    pub fn starting() -> Self {
        Self::named("STARTING")
    }

    /// A lifecycle by name.
    pub fn named(name: &str) -> Self {
        Self(name.to_owned())
    }

    /// Its name.
    pub fn as_str(&self) -> &str {
        &self.0
    }

    /// Whether it is this one.
    pub fn is(&self, name: &str) -> bool {
        self.0 == name
    }
}

/// How the child last ended.
#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub struct LastExit {
    /// Its exit code.
    pub code: Option<i64>,
    /// The signal that ended it.
    pub signal: Option<String>,
    /// When, as an ISO date.
    pub at: String,
    /// `stopped`, `host-shutdown`, `restart`, `client-exit`, `terminated`, `exited` or `unexpected`.
    pub cause: String,
}

/// See the module.
#[derive(Clone, Debug, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)] // the Node state, flag for flag
pub struct State {
    /// Where the session is.
    pub lifecycle: Lifecycle,
    /// Why it is blocked, when it is.
    pub blocked_code: Option<String>,
    /// The child is gone, or its exit is being dealt with.
    pub exited: bool,
    /// A stop was asked for.
    pub stop_requested: bool,
    /// A restart was asked for.
    pub restart_requested: bool,
    /// How the child last ended.
    pub last_exit: Option<LastExit>,
    /// Exits a controller claimed for one client.
    pub attributed: u64,
}

impl State {
    /// A new session, or one taken over from a server before.
    pub fn new(recover: bool) -> Self {
        Self {
            lifecycle: Lifecycle::named(if recover { "RECOVERING" } else { "STARTING" }),
            blocked_code: None,
            exited: false,
            stop_requested: false,
            restart_requested: false,
            last_exit: None,
            attributed: 0,
        }
    }

    fn enter(mut self, lifecycle: &str) -> Self {
        if !self.lifecycle.is(lifecycle) {
            if lifecycle != "BLOCKED" {
                self.blocked_code = None;
            }
            self.lifecycle = Lifecycle::named(lifecycle);
        }
        self
    }
}

/// What a session must do.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Effect {
    /// Tell the holder it may go.
    Release,
    /// The session has stopped.
    Stopped,
    /// Start a new child, after the controller's delay.
    RespawnLater,
    /// This client's exit it was: let it go.
    ClientExit(String),
    /// Tell everyone how the child ended.
    ExitNotice(String),
}

/// How the child ended, and what the controller makes of it.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Exit {
    /// Its exit code.
    pub code: Option<i64>,
    /// The signal that ended it.
    pub signal: Option<String>,
    /// When.
    pub at: String,
    /// The host is going down.
    pub shutting_down: bool,
    /// The client whose exit the controller says it was.
    pub claimed_by: Option<String>,
    /// The session outlives its child.
    pub stays: bool,
    /// Nobody is told: the controller says how it went.
    pub quiet: bool,
}

/// What happened.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Event {
    /// A holder was adopted.
    Adopted,
    /// A new server has read back what the holder had.
    Replayed,
    /// A controller's phase, from any of `from` when given.
    Phase {
        /// The phase.
        to: String,
        /// Only from these.
        from: Option<Vec<String>>,
    },
    /// Blocked, with why.
    Blocked(String),
    /// The child's exit is being dealt with.
    ExitSeen,
    /// The child exited.
    Exit(Exit),
    /// The child outlived its holder.
    Orphaned,
    /// A new child is starting.
    Respawning,
    /// It could not be started.
    RespawnFailed,
    /// A stop was asked for.
    StopRequested,
    /// A restart was asked for.
    RestartRequested,
    /// The stop has begun.
    Stopping,
    /// The child would not go.
    StopStuck,
    /// The session has stopped.
    Stopped,
}

/// What an exit means. A stop asked for and a host going down end the session, and a restart asked for starts a new child;
/// an exit a controller claims for one client restarts the child for everyone else. Any other exit ends the session, as
/// logging out ends an ssh connection, unless the controller keeps it at EXITED.
fn on_exit(s: State, e: Exit) -> (State, Vec<Effect>) {
    let Exit { code, signal, at, .. } = e.clone();
    let last = |cause: &str| Some(LastExit { code, signal: signal.clone(), at: at.clone(), cause: cause.to_owned() });
    let ended = |s: State, cause: &str| (State { last_exit: last(cause), ..s }, vec![Effect::Release, Effect::Stopped]);
    if s.stop_requested {
        return ended(s, "stopped");
    }
    if e.shutting_down {
        return ended(s, "host-shutdown");
    }
    if s.restart_requested {
        let next = State { restart_requested: false, last_exit: last("restart"), ..s }.enter("EXITED");
        return (next, vec![Effect::Release, Effect::RespawnLater]);
    }
    if let Some(client) = e.claimed_by {
        let attributed = s.attributed + 1;
        let next = State { last_exit: last("client-exit"), attributed, ..s }.enter("EXITED");
        return (next, vec![Effect::ClientExit(client), Effect::Release, Effect::RespawnLater]);
    }
    let terminated = signal.as_deref() == Some("SIGTERM");
    if !e.stays {
        return ended(s, if terminated { "terminated" } else { "exited" });
    }
    let next = State { last_exit: last(if terminated { "terminated" } else { "unexpected" }), ..s }.enter("EXITED");
    let how = code.map(|c| c.to_string()).or(signal).unwrap_or_else(|| "unknown".to_owned());
    (next, if e.quiet { vec![Effect::Release] } else { vec![Effect::Release, Effect::ExitNotice(how)] })
}

/// See the module.
pub fn reduce(s: State, e: Event) -> (State, Vec<Effect>) {
    let next = match e {
        Event::Adopted => State { exited: false, ..s },
        Event::Replayed if s.lifecycle.is("RECOVERING") => s.enter("STARTING"),
        Event::Replayed => s,
        Event::Phase { to, from } => {
            if from.is_none_or(|f| f.iter().any(|l| s.lifecycle.is(l))) {
                s.enter(&to)
            } else {
                s
            }
        }
        Event::Blocked(code) => State { blocked_code: Some(code), ..s }.enter("BLOCKED"),
        Event::ExitSeen => State { exited: true, ..s },
        Event::Exit(exit) => return on_exit(s, exit),
        Event::Orphaned => State { exited: true, blocked_code: Some("ORPHAN_ALIVE".to_owned()), ..s }.enter("BLOCKED"),
        Event::Respawning => s.enter("STARTING"),
        Event::RespawnFailed => s.enter("EXITED"),
        Event::StopRequested => State { stop_requested: true, ..s },
        Event::RestartRequested => State { restart_requested: true, ..s },
        Event::Stopping => s.enter("STOPPING"),
        Event::StopStuck => s.enter("STOP_STUCK"),
        Event::Stopped => s.enter("STOPPED"),
    };
    (next, Vec::new())
}
