//! The session: its lifecycle, its holder, its shell, and what a controller adds to it.

pub mod controller;
pub mod machine;
pub mod shell;
