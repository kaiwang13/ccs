//! What the shell in a session has said about itself, from its marks: whether it is at a prompt, what it is running, and
//! what it ran. `shell.js`. Rows are the emulator's, pinned, so the output of a command can be read back for as long as
//! the emulator keeps it. A record says only what the marks said: a server rebuilt from the holder's ring reads the same
//! marks with no clock to go with them, so those times are none, and a command whose marks left the ring is not known.
//!
//! What took timers in Node is deadlines here; what it emitted is [`ShellEvent`]s the session takes; asking for the line
//! to be cleared is [`ShellTracker::cancel_line`], which the session does.

use nmux_io::Time;
use nmux_vt::marks::{Mark, MarkKind};
use serde_json::{Value, json};

use crate::output::{At, Emulator, Observer, Pin, Screen};

/// Every record holds two pins, which cost something on each resize.
const MAX_RECORDS: usize = 128;
/// A line longer than this is not one anybody reads whole in a listing.
const MAX_COMMAND: usize = 4096;
/// A prompt can be drawn again at any moment. One still there after this means the line was not taken.
const REFUSED_AFTER_MS: u64 = 300;
/// How long a finished run waits for its prompt.
const PROMPT_BACK_MS: u64 = 3000;

/// A command the shell ran.
#[derive(Clone, Debug)]
pub struct Command {
    /// Its number in this session.
    pub seq: u64,
    /// What it was, as the shell said or as it was typed.
    pub command: Option<String>,
    /// Where it ran.
    pub cwd: Option<String>,
    /// When it started, in ms since the epoch, if seen live.
    pub started_at: Option<i64>,
    /// When it finished.
    pub finished_at: Option<i64>,
    /// How it exited.
    pub exit: Option<u64>,
    /// The `RUN` it was, if it was one.
    pub run: Option<u64>,
    /// Its start was before what was read back.
    pub partial: bool,
    /// The line was entered and nothing ran.
    pub never_ran: bool,
    /// Its first row.
    pub start: Pin,
    /// The row it ended on.
    pub end: Option<Pin>,
    /// How far into its last line it ended, in UTF-16 units, 0 at a line's start.
    pub end_chars: u64,
    /// The history's number for its first row, once that is there.
    pub spool_start: Option<u64>,
    /// The history's number for its last row.
    pub spool_end: Option<u64>,
}

/// Something typed that has not been seen to start yet.
#[derive(Clone, Debug)]
struct Awaited {
    id: u64,
    text: String,
    row: u64,
    /// What ran instead.
    passed_by: Option<u64>,
}

/// What the shell's state means to the session.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ShellState {
    /// Nothing known.
    Unknown,
    /// At its prompt.
    Prompt,
    /// Running something.
    Running,
}

impl ShellState {
    fn as_str(self) -> &'static str {
        match self {
            Self::Unknown => "unknown",
            Self::Prompt => "prompt",
            Self::Running => "running",
        }
    }
}

/// What the session hears from the shell.
#[derive(Clone, Debug, PartialEq)]
pub enum ShellEvent {
    /// Back at its prompt.
    Prompt,
    /// A command's start, end, or refusal: the fields of a `command` event.
    Command(Value),
}

/// Why nothing can be typed at the prompt now.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NotReady {
    /// The shell says it cannot say.
    NoIntegration,
    /// It is running something, or something typed has not started.
    Busy,
    /// It is not at its prompt.
    NotAtPrompt,
    /// Something is typed at the prompt.
    Typed,
}

impl NotReady {
    /// As a reply says it.
    pub fn as_str(self) -> &'static str {
        match self {
            Self::NoIntegration => "NO_INTEGRATION",
            Self::Busy => "BUSY",
            Self::NotAtPrompt => "NOT_AT_PROMPT",
            Self::Typed => "TYPED",
        }
    }
}

/// Whether what a shell says it ran is what was typed. History can join lines and space them differently, so only what
/// is left of them is compared, and of several lines bash may only name the first.
pub fn same_command(said: &str, typed: &str) -> bool {
    let words = |s: &str| s.replace("\\\n", "").chars().filter(|c| !c.is_whitespace() && *c != ';').collect::<String>();
    if typed.contains('\n') { words(typed).starts_with(&words(said)) } else { words(said) == words(typed) }
}

/// See the module.
#[derive(Debug)]
#[allow(clippy::struct_excessive_bools)] // what the marks said, a flag each
pub struct ShellTracker {
    state: ShellState,
    cwd: Option<String>,
    /// What it ran, oldest first.
    pub records: Vec<Command>,
    current: Option<usize>,
    seq: u64,
    /// The prompt as drawn: the line up to where typing goes, and what the shell put to the right of that.
    prompt_end: Option<(String, String)>,
    prefilled: bool,
    /// The line editor is in vi mode, so plain keys may be commands to it.
    pub vi_mode: bool,
    awaited: Option<Awaited>,
    /// A run that ended, unless more of it comes before the prompt, and when that is given up on.
    closing: Option<(usize, Time)>,
    /// When a line typed for a run is taken to have been refused, and which.
    refusal: Option<(Time, u64)>,
    /// The shell said it cannot do this.
    pub absent: bool,
    midway: bool,
    /// The line at the prompt is to be cleared with Ctrl+C.
    pub cancel_line: bool,
    /// What happened, for the session to take.
    pub events: Vec<ShellEvent>,
    /// The time now, in ms since the epoch, and on the monotonic clock: set before each feed.
    pub now: (i64, Time),
    /// Marks up to this offset are being read back from the holder's ring, not seen as they happen.
    pub replay_until: u64,
}

impl Default for ShellTracker {
    fn default() -> Self {
        Self::new()
    }
}

impl ShellTracker {
    /// A shell nothing is known of.
    pub fn new() -> Self {
        Self {
            state: ShellState::Unknown,
            cwd: None,
            records: Vec::new(),
            current: None,
            seq: 0,
            prompt_end: None,
            prefilled: false,
            vi_mode: false,
            awaited: None,
            closing: None,
            refusal: None,
            absent: false,
            midway: false,
            cancel_line: false,
            events: Vec::new(),
            now: (0, Time::ZERO),
            replay_until: 0,
        }
    }

    /// The marks being read back do not start at the beginning.
    pub fn joined_midway(&mut self) {
        self.midway = true;
    }

    /// The command running now, if any.
    pub fn current(&self) -> Option<&Command> {
        self.current.map(|i| &self.records[i])
    }

    /// Its sequence number counter.
    pub fn seq(&self) -> u64 {
        self.seq
    }

    /// A mark of the shell's, where it fell; `live`: seen as it happened, not read back from the holder's ring.
    pub fn mark(&mut self, emulator: &mut dyn Screen, mark: &Mark, at: At, live: bool) {
        let now = live.then_some(self.now.0);
        match mark.kind {
            MarkKind::B => {
                self.midway = false;
                let arrived = self.state != ShellState::Prompt;
                self.finish(emulator, None, at, now, live);
                if mark.typed && self.closing.is_some_and(|(i, _)| self.records[i].never_ran) {
                    self.put_back();
                }
                self.closed();
                self.state = ShellState::Prompt;
                let right = if arrived { emulator.right_of_cursor() } else { String::new() };
                self.prompt_end = Some((emulator.line_before_cursor(), right));
                self.prefilled = mark.typed;
                if live && let Some(awaited) = &self.awaited {
                    if self.refusal.is_none_or(|(_, id)| id != awaited.id) {
                        self.refusal = Some((self.now.1.after(REFUSED_AFTER_MS), awaited.id));
                    }
                } else if arrived && live {
                    self.events.push(ShellEvent::Prompt);
                }
            }
            MarkKind::C => {
                // several commands in one pasted text are still one line entered
                self.midway = false;
                if self.closing.is_some() {
                    self.reopen(emulator);
                }
                if self.current.is_none() {
                    self.start(emulator, mark.command.clone(), at.row, now, live);
                }
            }
            MarkKind::D => {
                self.absent = false;
                self.vi_mode = mark.vi;
                if mark.cwd.is_some() {
                    self.cwd.clone_from(&mark.cwd);
                }
                if self.midway && self.current.is_none() {
                    // how it ended, and as much of it as is left
                    let row = emulator.trimmed();
                    self.start(emulator, None, row, None, live);
                }
                self.midway = false;
                let mut exit = mark.exit;
                if self.current.is_none()
                    && let Some(awaited) = self.awaited.clone().filter(|a| a.passed_by.is_none())
                {
                    // the prompt is back with no command started: the line would not parse, or held nothing to run.
                    // If nothing was printed either it was the latter, and `$?` is still what it was.
                    if at.row <= awaited.row {
                        exit = Some(0);
                    }
                    self.start(emulator, Some(awaited.text), awaited.row, now, live);
                    if let Some(i) = self.current {
                        self.records[i].never_ran = true;
                    }
                }
                if self.current.is_some() {
                    self.finish(emulator, exit, at, now, live);
                }
                if self.state == ShellState::Prompt {
                    self.state = ShellState::Unknown;
                }
            }
            MarkKind::N => {
                self.absent = true;
                match self.awaited.clone() {
                    // it is running, with nothing left to say how it ends
                    Some(a) => self.start(emulator, Some(a.text), a.row, now, live),
                    None => self.finish(emulator, None, at, now, live),
                }
            }
            MarkKind::A => {} // its end is what matters
        }
    }

    /// When [`ShellTracker::on_time`] has something to do.
    pub fn deadline(&self) -> Option<Time> {
        [self.closing.map(|c| c.1), self.refusal.map(|r| r.0)].into_iter().flatten().min()
    }

    /// What is due: a run's prompt waited for long enough, or a line typed for a run that the shell did not take.
    pub fn on_time(&mut self, now: Time) {
        if self.closing.is_some_and(|(_, due)| due <= now) {
            self.closed();
        }
        if let Some((due, id)) = self.refusal
            && due <= now
        {
            self.refusal = None;
            self.refused(id);
        }
    }

    /// Some shells keep a line they will not run in the editor, and draw the prompt again with no mark to say so. That
    /// line was typed by nmux, and would be in the way of everything after it; at the prompt, Ctrl+C only clears it. If
    /// something else ran and nothing more came, that was this line in the shell's own words, which there is no being
    /// sure of, so whoever asked is told that too.
    fn refused(&mut self, id: u64) {
        if self.awaited.as_ref().is_none_or(|a| a.id != id) {
            return;
        }
        let Some(awaited) = self.awaited.take() else { return };
        match awaited.passed_by.and_then(|seq| self.records.iter().position(|r| r.seq == seq)) {
            Some(i) if self.records[i].end.is_some() => {
                self.records[i].run = Some(awaited.id);
                let mut fields = self.describe(&self.records[i]);
                fields["phase"] = json!("end");
                fields["unsure"] = json!(true);
                self.events.push(ShellEvent::Command(fields));
            }
            _ => {
                self.cancel_line = true;
                self.events
                    .push(ShellEvent::Command(json!({ "phase": "refused", "run": awaited.id, "error": "SYNTAX" })));
            }
        }
    }

    /// The shell gave the line back to be looked at, as zsh does with `hist_verify`, so it did not run, and is in the way.
    fn put_back(&mut self) {
        let Some((i, _)) = self.closing.take() else { return };
        self.prefilled = false;
        self.cancel_line = true;
        let run = self.records[i].run;
        self.events.push(ShellEvent::Command(json!({ "phase": "refused", "run": run, "error": "SYNTAX" })));
    }

    fn start(&mut self, emulator: &mut dyn Screen, command: Option<String>, row: u64, now: Option<i64>, live: bool) {
        // A person's line can get in ahead of one typed for a run. A shell cannot always say what it ran, and then that
        // is taken on trust.
        let mine = self
            .awaited
            .clone()
            .filter(|a| command.as_deref().is_none_or(|c| c.is_empty() || same_command(c, &a.text)));
        if mine.is_some() {
            self.awaited = None;
        }
        self.seq += 1;
        let command = match &mine {
            Some(a) => Some(a.text.clone()),
            None => command.filter(|c| !c.is_empty()).map(|c| c.chars().take(MAX_COMMAND).collect()),
        };
        let rec = Command {
            seq: self.seq,
            command,
            cwd: self.cwd.clone(),
            started_at: now,
            finished_at: None,
            exit: None,
            run: mine.as_ref().map(|a| a.id),
            partial: self.midway,
            never_ran: false,
            start: emulator.pin(row),
            end: None,
            end_chars: 0,
            spool_start: None,
            spool_end: None,
        };
        if let (Some(awaited), None) = (self.awaited.as_mut(), &mine) {
            awaited.passed_by = Some(rec.seq);
        }
        self.records.push(rec);
        self.current = Some(self.records.len() - 1);
        self.state = ShellState::Running;
        if self.records.len() > MAX_RECORDS {
            let gone = self.records.remove(0);
            self.forget(emulator, &gone);
            self.current = self.current.map(|i| i - 1);
            self.closing = self.closing.and_then(|(i, due)| i.checked_sub(1).map(|i| (i, due)));
        }
        if live && let Some(i) = self.current {
            let mut fields = self.describe(&self.records[i]);
            fields["phase"] = json!("start");
            self.events.push(ShellEvent::Command(fields));
        }
    }

    fn finish(&mut self, emulator: &mut dyn Screen, exit: Option<u64>, at: At, now: Option<i64>, live: bool) {
        let Some(i) = self.current.take() else { return };
        if emulator.pin_row(self.records[i].start).is_some_and(|start| at.row < start) {
            // it went back over what it had printed
            let top = emulator.screen_top(0);
            emulator.set_pin(self.records[i].start, Some(top));
        }
        let end = emulator.pin(at.row);
        let end_chars = if at.col > 0 { emulator.line_up_to(at) } else { 0 };
        let rec = &mut self.records[i];
        rec.end = Some(end);
        rec.end_chars = end_chars;
        rec.exit = exit;
        rec.finished_at = now;
        self.state = ShellState::Unknown;
        if !live {
            return;
        }
        if rec.run.is_none() {
            let mut fields = self.describe(&self.records[i]);
            fields["phase"] = json!("end");
            self.events.push(ShellEvent::Command(fields));
        } else {
            self.closing = Some((i, self.now.1.after(PROMPT_BACK_MS)));
        }
    }

    /// A run ends when the prompt is back: before bash 5.1 its hooks run between the lines of what was pasted, so a
    /// command ending is not enough.
    fn closed(&mut self) {
        let Some((i, _)) = self.closing.take() else { return };
        let mut fields = self.describe(&self.records[i]);
        fields["phase"] = json!("end");
        self.events.push(ShellEvent::Command(fields));
    }

    /// There is more to a run that seemed to have ended.
    fn reopen(&mut self, emulator: &mut dyn Screen) {
        let Some((i, _)) = self.closing.take() else { return };
        let rec = &mut self.records[i];
        if let Some(end) = rec.end.take() {
            emulator.unpin(end);
        }
        rec.end_chars = 0;
        rec.exit = None;
        rec.finished_at = None;
        self.current = Some(i);
        self.state = ShellState::Running;
    }

    fn forget(&self, emulator: &mut dyn Screen, rec: &Command) {
        let _ = self;
        emulator.unpin(rec.start);
        if let Some(end) = rec.end {
            emulator.unpin(end);
        }
    }

    /// Why nothing can be typed at the prompt now, or `None`.
    pub fn not_ready(&self, emulator: &dyn Screen) -> Option<NotReady> {
        if self.absent {
            return Some(NotReady::NoIntegration);
        }
        if self.state == ShellState::Running || self.awaited.is_some() {
            return Some(NotReady::Busy);
        }
        let Some((left, right)) = &self.prompt_end else { return Some(NotReady::NotAtPrompt) };
        if self.state != ShellState::Prompt || emulator.on_alternate() {
            return Some(NotReady::NotAtPrompt);
        }
        let clear = !self.prefilled && emulator.line_before_cursor() == *left && !emulator.text_at_cursor(Some(right));
        if clear { None } else { Some(NotReady::Typed) }
    }

    /// Something is about to be typed at the prompt.
    pub fn expect(&mut self, emulator: &dyn Screen, id: u64, text: &str) {
        self.awaited = Some(Awaited { id, text: text.to_owned(), row: emulator.cursor_row() + 1, passed_by: None });
    }

    /// Whoever typed this has stopped waiting, and it never started, so the shell waits for the rest of it, which would be
    /// in the way of everything after it.
    pub fn abandon(&mut self, id: u64) {
        if self.awaited.as_ref().is_none_or(|a| a.id != id) || self.state != ShellState::Prompt {
            return;
        }
        self.awaited = None;
        self.cancel_line = true;
    }

    /// The shell was replaced: what it said is no longer true, and a run waiting for it will not get an answer.
    pub fn reset(&mut self, emulator: &mut dyn Screen) {
        self.closed();
        let mut running: Vec<u64> = Vec::new();
        if let Some(a) = &self.awaited {
            running.push(a.id);
        }
        if let Some(run) = self.current().and_then(|c| c.run) {
            running.push(run);
        }
        for rec in std::mem::take(&mut self.records) {
            self.forget(emulator, &rec);
        }
        self.current = None;
        self.state = ShellState::Unknown;
        self.prompt_end = None;
        self.awaited = None;
        self.refusal = None;
        self.absent = false;
        for run in running {
            self.events.push(ShellEvent::Command(json!({ "phase": "refused", "run": run, "error": "RESTARTED" })));
        }
    }

    /// A record as events and listings say it.
    pub fn describe(&self, rec: &Command) -> Value {
        let duration = rec.started_at.zip(rec.finished_at).map(|(s, f)| f - s);
        json!({
            "seq": rec.seq, "command": rec.command, "cwd": rec.cwd, "startedAt": rec.started_at, "finishedAt": rec.finished_at,
            "exit": rec.exit, "run": rec.run, "durationMs": duration,
        })
    }

    /// The last command that finished.
    pub fn last_finished(&self) -> Option<&Command> {
        self.records.iter().rev().find(|r| r.end.is_some())
    }

    /// A command by its number.
    pub fn find(&self, seq: u64) -> Option<&Command> {
        self.records.iter().find(|r| r.seq == seq)
    }

    /// What a command printed, as far as the emulator still has it, and whether all of it was there. `from`: start here,
    /// when what came before is known from elsewhere.
    pub fn output(&self, emulator: &dyn Screen, rec: &Command, ansi: bool, from: Option<u64>) -> (String, bool) {
        let unfinished = rec.end.is_some() && rec.end_chars > 0;
        let end_row = rec.end.and_then(|e| emulator.pin_row(e));
        let to = match end_row {
            None if rec.end.is_none() => emulator.cursor_row() + 1,
            Some(row) if unfinished => emulator.line_end(row),
            Some(row) => row,
            None => 0,
        };
        // a start nothing can place any more has gone, and so has some of the output
        let start = from.or_else(|| emulator.pin_row(rec.start));
        let (lines, complete) = emulator.text(start.unwrap_or(0), to, ansi, unfinished.then_some(rec.end_chars));
        let text = if lines.is_empty() { String::new() } else { lines.join("\n") + "\n" };
        (text, complete && start.is_some() && !rec.partial)
    }

    /// What STATUS says of the shell.
    pub fn status(&self) -> Value {
        json!({
            "state": self.state.as_str(), "cwd": self.cwd,
            "current": self.current().map(|c| self.describe(c)), "last": self.last_finished().map(|c| self.describe(c)),
        })
    }
}

impl Observer for ShellTracker {
    fn on_mark(&mut self, emulator: &mut Emulator, mark: &Mark, at: At, offset: u64) {
        let live = offset > self.replay_until;
        self.mark(emulator, mark, at, live);
    }

    fn on_erased(&mut self, emulator: &mut Emulator, top: u64) {
        self.erased(emulator, top);
    }

    fn on_spooled(&mut self, emulator: &Emulator, from: u64, to: u64, line: u64) {
        self.spooled(emulator, from, to, line);
    }
}

impl ShellTracker {
    /// The screen was wiped, so what a command is printing starts again from there.
    pub fn erased(&mut self, emulator: &mut dyn Screen, top: u64) {
        let Some(i) = self.current else { return };
        emulator.set_pin(self.records[i].start, Some(top));
        self.records[i].spool_start = None;
    }

    /// Rows went to the history, which numbers them its own way: this is when to note where a command landed in it, since
    /// rows in memory can be renumbered by a reflow and these cannot.
    pub fn spooled(&mut self, emulator: &dyn Screen, from: u64, to: u64, line: u64) {
        let inside = |row: Option<u64>| row.filter(|r| (from..to).contains(r));
        for rec in &mut self.records {
            if rec.spool_start.is_none()
                && let Some(row) = inside(emulator.pin_row(rec.start))
            {
                rec.spool_start = Some(line + row - from);
            }
            if rec.spool_end.is_none()
                && let Some(row) = inside(rec.end.and_then(|e| emulator.pin_row(e)))
            {
                rec.spool_end = Some(line + row - from);
            }
        }
    }
}
