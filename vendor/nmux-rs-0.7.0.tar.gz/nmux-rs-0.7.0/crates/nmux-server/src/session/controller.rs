//! What a program may add to a session that runs something it understands: `controller.js` and `remote.js`. A plain
//! session has none of it: it is running as soon as the holder answers, and nothing is gated, held back or claimed. A
//! managed session is understood by a controller in another process, reached over the control socket. What has to happen
//! on the keystroke path cannot wait for that, so it is declared in the spec and done here: which keys detach, which are
//! guarded, whether the session outlives its child. Everything else the controller is told as events, and it answers with
//! requests. Without a controller the session runs on and stays attachable; only what the controller adds stops.

use std::collections::BTreeMap;

use nmux_io::Time;
use nmux_vt::InputToken;
use nmux_vt::keys::KeyClass;
use serde_json::{Map, Value, json};

use crate::input::guard::KeyGuard;
use crate::input::lastline::LastLine;
use crate::input::router::{GateEffect, Policy, Writer};
use crate::spec::Managed;

/// How long a stop waits for a controller that does not answer.
pub const DEFAULT_STOP_GRACE_MS: u64 = 15_000;
/// How long a stop waits for a controller to turn up, when one is expected.
pub const ARRIVAL_WAIT_MS: u64 = 1500;

/// A gate a controller set.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Gate {
    /// What it does to input.
    pub effect: GateEffect,
    /// A client that may type through gates passes it.
    pub passable: bool,
    /// It turns a control client's INPUT away.
    pub blocking: bool,
    /// Lower first.
    pub rank: i64,
}

fn class_of(name: &str) -> Option<KeyClass> {
    Some(match name {
        "Z" => KeyClass::Z,
        "Q" => KeyClass::Q,
        "C" => KeyClass::C,
        "D" => KeyClass::D,
        _ => return None,
    })
}

/// What a managed session keeps.
#[derive(Debug)]
pub struct Remote {
    /// What it declared.
    pub managed: Managed,
    /// What STATE and STATUS carry beside the host's own fields.
    pub attrs: Map<String, Value>,
    gates: BTreeMap<String, Gate>,
    detach_keys: Vec<KeyClass>,
    /// The last line a client typed, for the exit event.
    pub last_line: LastLine,
    guard: Option<KeyGuard>,
    patterns: Vec<regex::Regex>,
    /// A controller is connected and listening, on this connection.
    pub connection: Option<u64>,
    /// What runs next, as the controller said.
    pub next_argv: Option<Vec<String>>,
    last_alt: bool,
    tty: Option<Value>,
    /// The controller has written down that the session has gone.
    pub recorded: bool,
    /// The exit the session is standing on, told to whoever arrives until a new program runs.
    pub standing_exit: Option<Value>,
}

/// See the module.
#[derive(Debug, Default)]
pub struct Controller {
    /// What a managed session keeps; `None` for a plain session.
    pub remote: Option<Remote>,
    /// Events for subscribers, in order.
    pub said: Vec<Value>,
    /// A guarded key was held for this client.
    pub held: Vec<String>,
}

impl Controller {
    /// A plain session's, or a managed one's.
    pub fn new(managed: Option<Managed>) -> Self {
        let remote = managed.map(|managed| {
            let keys: Vec<KeyClass> =
                managed.guards.iter().flat_map(|g| g.keys.iter().filter_map(|k| class_of(k))).collect();
            let guard = managed.guards.first().map(|g| KeyGuard::new(g.margin_ms, &keys));
            Remote {
                attrs: managed.attrs.clone(),
                gates: BTreeMap::new(),
                detach_keys: managed.detach_keys.iter().filter_map(|k| class_of(k)).collect(),
                last_line: LastLine::default(),
                guard,
                patterns: managed.patterns.iter().filter_map(|p| regex::Regex::new(p).ok()).collect(),
                connection: None,
                next_argv: None,
                last_alt: false,
                tty: None,
                recorded: false,
                standing_exit: None,
                managed,
            }
        });
        Self { remote, said: Vec::new(), held: Vec::new() }
    }

    /// Whether a controller manages the session.
    pub fn managed(&self) -> bool {
        self.remote.is_some()
    }

    /// Whether a controller is connected.
    pub fn connected(&self) -> bool {
        self.remote.as_ref().is_some_and(|r| r.connection.is_some())
    }

    fn say(&mut self, event: &str, fields: Value) {
        if self.remote.is_none() {
            return;
        }
        let mut e = Map::new();
        e.insert("event".into(), json!(event));
        if let Value::Object(f) = fields {
            e.extend(f);
        }
        self.said.push(Value::Object(e));
    }

    // ---- facts ------------------------------------------------------------------------------------------------------

    /// A holder connected.
    pub fn on_holder(&mut self, generation: u64, child: &Value, pty: &Value) {
        if let Some(g) = self.remote.as_mut().and_then(|r| r.guard.as_mut()) {
            g.reset();
        }
        self.say("holder", json!({ "gen": generation, "child": child, "pty": pty }));
    }

    /// Attached and streaming. A plain session is running now.
    pub fn on_attached(&mut self) -> bool {
        self.say("attached", json!({}));
        self.remote.is_none()
    }

    /// A server that took over has read back what the holder had. A plain session is running now.
    pub fn on_replayed(&mut self) -> bool {
        self.say("replayed", json!({}));
        self.remote.is_none()
    }

    /// Output came: its text, and whether the program is on the alternate screen.
    pub fn on_chunk(&mut self, text: &str, alt: bool, now: Time) {
        let Some(r) = self.remote.as_mut() else { return };
        if let Some(g) = r.guard.as_mut() {
            g.on_data(now);
        }
        let mut said = Vec::new();
        if alt != r.last_alt {
            r.last_alt = alt;
            said.push(("alt", json!({ "alt": alt })));
        }
        if !text.is_empty() {
            for re in &r.patterns {
                if re.is_match(text) {
                    said.push(("match", json!({ "pattern": re.as_str() })));
                }
            }
        }
        for (event, fields) in said {
            self.say(event, fields);
        }
    }

    /// The program read a watched write.
    pub fn on_consumed(&mut self, watch: u32) {
        if let Some(g) = self.remote.as_mut().and_then(|r| r.guard.as_mut()) {
            g.on_consumed(watch);
        }
    }

    /// The pty's local modes changed.
    pub fn on_lflag(&mut self, lflag: Value, alt: bool) {
        let Some(r) = self.remote.as_mut() else { return };
        r.tty = Some(lflag);
        let tty = self.tty_event(alt);
        self.say("tty", tty);
    }

    /// The tty as the `tty` event says it.
    pub fn tty_event(&self, alt: bool) -> Value {
        match self.remote.as_ref().and_then(|r| r.tty.clone()) {
            Some(Value::Object(mut t)) => {
                t.insert("alt".into(), json!(alt));
                Value::Object(t)
            }
            _ => Value::Null,
        }
    }

    /// The child's exit has been dealt with: the controller is told, with the last line a client typed.
    pub fn on_exited(&mut self, code: Option<i64>, signal: Option<&str>, at: &str, written_total: u64) {
        let Some(r) = self.remote.as_mut() else { return };
        let last_line = r.last_line.take(written_total).map(|l| json!({ "client": l.client, "text": l.text }));
        let exit = json!({ "event": "exit", "code": code, "signal": signal, "at": at, "lastLine": last_line });
        r.standing_exit = Some(exit.clone());
        self.said.push(exit);
    }

    /// A new child is taking over.
    pub fn on_respawned(&mut self) {
        if let Some(r) = self.remote.as_mut() {
            r.next_argv = None;
            r.standing_exit = None;
        }
        self.say("respawned", json!({}));
    }

    /// The stop gives the controller first go.
    pub fn on_stopping(&mut self) {
        self.say("stopping", json!({}));
    }

    // ---- questions --------------------------------------------------------------------------------------------------

    /// Whether something looks for words in the output, so that chunks must carry their text.
    pub fn looks_for_words(&self) -> bool {
        self.remote.as_ref().is_some_and(|r| !r.patterns.is_empty())
    }

    /// Whether the session outlives its child.
    pub fn stays_after_exit(&self) -> bool {
        self.remote.as_ref().is_some_and(|r| r.managed.stays)
    }

    /// Whether a kept session tells its clients how its child exited. A controller says that itself.
    pub fn announces_exit(&self) -> bool {
        self.remote.is_none()
    }

    /// What runs when the child is started again.
    pub fn respawn_argv(&self, spec_argv: &[String]) -> Vec<String> {
        self.remote.as_ref().and_then(|r| r.next_argv.clone()).unwrap_or_else(|| spec_argv.to_vec())
    }

    /// The gates, most important first.
    pub fn gates(&self) -> Vec<String> {
        let Some(r) = &self.remote else { return Vec::new() };
        let mut gates: Vec<(&String, &Gate)> = r.gates.iter().collect();
        gates.sort_by_key(|(_, g)| g.rank);
        gates.into_iter().map(|(name, _)| name.clone()).collect()
    }

    /// The gates that turn a control client's INPUT away.
    pub fn blocking_gates(&self) -> Vec<String> {
        let Some(r) = &self.remote else { return Vec::new() };
        self.gates().into_iter().filter(|g| r.gates.get(g).is_some_and(|g| g.blocking)).collect()
    }

    /// Whether focus reports may reach the program at all.
    pub fn forwards_focus(&self) -> bool {
        self.remote.as_ref().is_none_or(|r| r.managed.forward_focus != Some(false))
    }

    // ---- answers ----------------------------------------------------------------------------------------------------

    /// Sets a gate, or with no effect removes it.
    pub fn set_gate(&mut self, name: &str, effect: Option<GateEffect>, passable: bool, blocking: bool, rank: i64) {
        let Some(r) = self.remote.as_mut() else { return };
        match effect {
            None => {
                r.gates.remove(name);
            }
            Some(effect) => {
                r.gates.insert(name.to_owned(), Gate { effect, passable, blocking, rank });
            }
        }
    }

    /// Adds to what STATE and STATUS carry.
    pub fn set_attrs(&mut self, attrs: &Map<String, Value>) {
        if let Some(r) = self.remote.as_mut() {
            r.attrs.extend(attrs.clone());
        }
    }

    /// STATUS: the controller's fields, the host's over them, and whether a controller is connected.
    pub fn status(&self, host: Map<String, Value>) -> Map<String, Value> {
        let Some(r) = &self.remote else { return host };
        let mut out = r.attrs.clone();
        out.extend(host);
        out.insert("controller".into(), json!(r.connection.is_some()));
        out
    }

    /// What STATE carries beside the host's own fields.
    pub fn state_fields(&self) -> Map<String, Value> {
        self.remote.as_ref().map(|r| r.attrs.clone()).unwrap_or_default()
    }

    /// What WELCOME carries beside the host's own fields.
    pub fn welcome_fields(&self) -> Map<String, Value> {
        self.remote.as_ref().map(|r| r.managed.welcome.clone()).unwrap_or_default()
    }

    /// The record as written to disk, which the controller is told of.
    pub fn persisted(&mut self, mut doc: Map<String, Value>) -> Map<String, Value> {
        let Some(r) = &self.remote else { return doc };
        doc.insert("attrs".into(), Value::Object(r.attrs.clone()));
        let record = Value::Object(doc.clone());
        self.say("record", json!({ "doc": record }));
        doc
    }
}

impl Policy for Controller {
    fn detach_keys(&self) -> &[KeyClass] {
        self.remote.as_ref().map_or(&[], |r| &r.detach_keys)
    }

    fn gate_effect(&self, gate: &str, allow_gated: bool) -> GateEffect {
        match self.remote.as_ref().and_then(|r| r.gates.get(gate)) {
            None => GateEffect::Drop,
            Some(g) if g.passable && allow_gated => GateEffect::Open,
            Some(g) => g.effect,
        }
    }

    fn guards_key(&self, class: KeyClass) -> bool {
        self.remote.as_ref().and_then(|r| r.guard.as_ref()).is_some_and(|g| g.covers(class))
    }

    fn offer_signal_key(&mut self, class: KeyClass, now: Time, writer: &mut dyn Writer) -> bool {
        let Some(g) = self.remote.as_mut().and_then(|r| r.guard.as_mut()) else { return true };
        g.offer(class, now, |bytes| writer.write(bytes, false, true)).is_some()
    }

    fn on_paste(&mut self) {
        if let Some(r) = self.remote.as_mut() {
            r.last_line.on_paste();
        }
    }

    fn on_forwarded(&mut self, client: &str, tok: &InputToken<'_>, total: u64) {
        if let Some(r) = self.remote.as_mut() {
            r.last_line.on_forwarded(client, tok, total);
        }
    }
}
