//! Stopping, `stop-runner.js`, and how a server ends, `main.js`. A stop gates input, gives a controller its first go,
//! hangs up, sends SIGTERM, and is stuck after that: nothing stronger is ever sent. Once the session has stopped, the
//! joins under way are given a moment, every client is told, the controller writes down that the session has gone, and the
//! history is finished before the lock is let go. SIGTERM to the server leaves the session running under the next one.

use nmux_holder::Level;
use nmux_io::TimerId;
use nmux_wire::Control;
use serde_json::json;

use super::{Due, Effect, Server};
use crate::output::ByeExtra;
use crate::session::controller::{ARRIVAL_WAIT_MS, DEFAULT_STOP_GRACE_MS};
use crate::session::machine::Event as MachineEvent;

/// How long a program being watched from the start waits for its first terminal.
pub const FIRST_CLIENT_WAIT_MS: u64 = 5000;
/// How long the joins under way are given once the session has stopped.
const LAST_JOIN_WAIT_MS: u64 = 1000;
const JOIN_POLL_MS: u64 = 10;
/// How long the controller is given to write down that the session has gone.
const LAST_RECORD_WAIT_MS: u64 = 2000;
/// A last moment for the goodbyes to be written.
const LAST_WORD_MS: u64 = 100;
/// How long a server that is going waits for its history to reach the disk. A disk that has hung must not keep it.
const SPOOL_CLOSE_MS: u64 = 2000;
/// How long a server leaving for the next one waits after its goodbyes.
const LEAVING_MS: u64 = 50;

/// Where a stop is.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Stage {
    /// The holder is on its way: it must not be left without a server.
    WaitStarted,
    /// A controller is expected and has not come yet.
    Arrival,
    /// The controller has its first go.
    Controller,
    /// The pty was hung up.
    Hangup,
    /// SIGTERM was sent.
    Term,
}

/// The stop under way, or over.
#[derive(Debug, Default)]
pub struct Stopping {
    stage: Option<Stage>,
    timer: Option<TimerId>,
    asked: bool,
    done: bool,
}

impl Stopping {
    /// The stop that was asked for has done all it can.
    pub fn over(&self) -> bool {
        self.asked && self.done
    }
}

/// Where a server's end is.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Step {
    /// Joins under way are given a moment, until then.
    Joins(nmux_io::Time),
    /// The controller writes down that the session has gone.
    Record,
    /// The goodbyes are written.
    LastWord,
    /// The server leaves its session to the next one, after its goodbyes.
    Leaving,
    /// The history is finished.
    History(bool),
}

/// A server ending.
#[derive(Debug)]
pub struct Ending {
    step: Step,
    timer: Option<TimerId>,
}

impl Server {
    /// Stops the session. A second ask joins the first.
    pub(super) fn stop(&mut self) {
        if self.stop.asked {
            return;
        }
        self.stop.asked = true;
        self.dispatch(MachineEvent::StopRequested);
        if self.starting {
            self.stop.stage = Some(Stage::WaitStarted);
            return;
        }
        self.stop_begins();
    }

    fn stop_begins(&mut self) {
        if self.holder.is_none() || self.machine.exited {
            self.mark_stopped();
            return;
        }
        self.dispatch(MachineEvent::Stopping);
        let text = self.messages.stopping(&self.name());
        self.notify("info", "STOPPING", &text);
        let Some(r) = self.controller.remote.as_ref() else {
            self.hang_up();
            return;
        };
        if r.connection.is_none() && r.managed.command.is_some() {
            // a session this new may not have met its controller yet
            self.stop_wait(Stage::Arrival, ARRIVAL_WAIT_MS);
            return;
        }
        self.controller_first();
    }

    fn controller_first(&mut self) {
        let Some(r) = self.controller.remote.as_ref() else { return self.hang_up() };
        if r.connection.is_none() {
            return self.hang_up();
        }
        let grace = r.managed.stop_grace_ms.unwrap_or(DEFAULT_STOP_GRACE_MS);
        self.controller.on_stopping();
        self.stop_wait(Stage::Controller, grace);
    }

    fn stop_wait(&mut self, stage: Stage, ms: u64) {
        let mut old = self.stop.timer.take();
        self.cancel(&mut old);
        self.stop.stage = Some(stage);
        self.stop.timer = Some(self.set_timer(ms, Due::Stop));
    }

    fn hang_up(&mut self) {
        if !self.machine.exited
            && let Some(h) = self.holder.as_mut()
        {
            let _ = h.out.control(&Control::CloseMaster); // EIO and SIGHUP
        }
        self.stop_wait(Stage::Hangup, self.config.stop.hangup_wait_ms);
    }

    pub(super) fn stop_due(&mut self) {
        self.stop.timer = None;
        match self.stop.stage {
            Some(Stage::Arrival | Stage::Controller) => {
                if self.stop.stage == Some(Stage::Arrival) && self.controller.connected() {
                    return self.controller_first();
                }
                self.hang_up();
            }
            Some(Stage::Hangup) => {
                if !self.machine.exited {
                    self.signal_child("SIGTERM");
                }
                self.stop_wait(Stage::Term, self.config.stop.term_wait_ms);
            }
            Some(Stage::Term) => {
                self.stop.stage = None;
                self.stop.done = true;
                self.dispatch(MachineEvent::StopStuck);
                let pid = self.hello.as_ref().map_or_else(|| "?".to_owned(), |h| h.child.pid.to_string());
                let text = self.messages.stop_stuck(&pid);
                self.notify("warn", "STOP_STUCK", &text);
                self.requests_hear_stopped();
            }
            Some(Stage::WaitStarted) | None => {}
        }
    }

    /// The controller arrived while a stop waited for it.
    pub(super) fn controller_arrived(&mut self) {
        if self.stop.stage == Some(Stage::Arrival) {
            self.controller_first();
        }
    }

    /// `STOP_PROCEED`: the controller has had its go.
    pub(super) fn stop_proceed(&mut self) {
        if self.stop.stage == Some(Stage::Controller) {
            self.hang_up();
        }
    }

    /// The session has stopped.
    pub(super) fn mark_stopped(&mut self) {
        self.started = true;
        if self.stop.stage == Some(Stage::WaitStarted) {
            self.stop.stage = None;
        }
        self.dispatch(MachineEvent::Stopped);
        let mut t = self.stop.timer.take();
        self.cancel(&mut t);
        self.stop.stage = None;
        self.stop.done = true;
        self.on_started();
        self.requests_hear_stopped();
        self.publish(&json!({ "event": "stopped", "lastExit": self.machine.last_exit }));
        if self.ending.is_none() {
            let until = self.now.time.after(LAST_JOIN_WAIT_MS);
            self.ending_step(Step::Joins(until), 0);
        }
    }

    /// A start that a stop waited for is over.
    pub(super) fn stop_hears_started(&mut self) {
        if self.stop.stage == Some(Stage::WaitStarted) {
            self.stop.stage = None;
            self.stop_begins();
        }
    }

    fn ending_step(&mut self, step: Step, ms: u64) {
        let mut old = self.ending.take().and_then(|e| e.timer);
        self.cancel(&mut old);
        let timer = self.set_timer(ms, Due::Ending);
        self.ending = Some(Ending { step, timer: Some(timer) });
    }

    pub(super) fn ending_due(&mut self) {
        let Some(e) = self.ending.as_mut() else { return };
        e.timer = None;
        match e.step {
            Step::Joins(until) => {
                if !self.joins_done() && self.now.time < until {
                    return self.ending_step(Step::Joins(until), JOIN_POLL_MS);
                }
                self.last_byes();
                let r = self.controller.remote.as_ref();
                if r.is_some_and(|r| r.connection.is_some() && !r.recorded) {
                    self.ending_step(Step::Record, LAST_RECORD_WAIT_MS);
                } else {
                    self.ending_step(Step::LastWord, LAST_WORD_MS);
                }
            }
            Step::Record => self.ending_step(Step::LastWord, LAST_WORD_MS),
            Step::LastWord => self.end(false),
            Step::Leaving => {
                self.detach_holder();
                self.end(true);
            }
            Step::History(leaving) => self.finish(leaving),
        }
    }

    /// `RECORDED`: the controller has written down that the session has gone.
    pub(super) fn ending_hears_recorded(&mut self) {
        if self.ending.as_ref().is_some_and(|e| e.step == Step::Record) {
            self.ending_step(Step::LastWord, LAST_WORD_MS);
        }
    }

    /// Every client is told the session has gone, and how.
    fn last_byes(&mut self) {
        let e = self.machine.last_exit.clone();
        if e.as_ref().is_some_and(|e| e.cause == "host-shutdown") {
            let text = self.messages.host_shutdown();
            self.bye_going("HOST_SHUTDOWN", &text);
        } else if self.machine.stop_requested || e.is_none() {
            let text = self.messages.session_stopped(&self.name());
            self.bye_going("SESSION_ENDING", &text);
        } else {
            let ended = e.map(|e| e.signal.map_or_else(|| json!(e.code), |s| json!(s)));
            self.bye_all("SESSION_ENDING", false, "", &ByeExtra { ended, ..ByeExtra::default() });
        }
    }

    /// SIGTERM: this server goes and the session goes on. Terminals that are up to date are told how far they had got.
    pub(super) fn terminate(&mut self) {
        if self.ending.is_some() {
            return;
        }
        self.restarting();
        self.ending_step(Step::Leaving, LEAVING_MS);
    }

    /// Lets go of everything; the lock goes last, since until then no server may open the history this one finishes.
    /// `leaving`: the session goes on under the next server.
    pub(super) fn end(&mut self, leaving: bool) {
        if self.ending.as_ref().is_some_and(|e| matches!(e.step, Step::History(_))) {
            return;
        }
        self.arbiter.dispose();
        self.ambient_stop();
        let conns: Vec<_> =
            self.clients.keys().chain(self.controls.keys()).chain(self.greeting.keys()).copied().collect();
        for conn in conns {
            self.effects.push(Effect::Close { conn, now: false });
        }
        self.dispose_session();
        match self.spool.as_mut() {
            Some(spool) => {
                spool.close();
                self.ending_step(Step::History(leaving), SPOOL_CLOSE_MS);
            }
            None => self.finish(leaving),
        }
    }

    /// The history answered that it is closed.
    pub(super) fn history_closed(&mut self) {
        if let Some(Step::History(leaving)) = self.ending.as_ref().map(|e| e.step) {
            self.finish(leaving);
        }
    }

    fn finish(&mut self, leaving: bool) {
        if let Some(e) = self.ending.take()
            && let Some(t) = e.timer
        {
            self.timers.cancel(t);
        }
        if let Some(spool) = self.spool.as_mut() {
            spool.give_up();
        }
        let lifecycle = self.machine.lifecycle.as_str().to_owned();
        self.log(Level::Info, "sessiond.exit", &[("lifecycle", json!(lifecycle)), ("leaving", json!(leaving))]);
        self.ending = Some(Ending { step: Step::History(leaving), timer: None });
        self.effects.push(Effect::Exit { leaving });
    }
}
