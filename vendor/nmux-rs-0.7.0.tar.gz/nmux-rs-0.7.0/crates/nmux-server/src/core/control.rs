//! ctl.sock, `control.js`: HELLO is answered with WELCOME or REFUSE; an attach client joins through the hub; a control
//! connection gets STATE pushes and REQ answered with RES, and never counts in arbitration. Anything unknown is answered
//! UNSUPPORTED.
//!
//! - Read: `STATUS` `PEEK` `SCREEN` `CAPTURE` `SINCE` `UNWRITTEN` `CLIENTS` `COMMANDS` `LAST`. Those with text send it as
//!   OUTPUT frames before the RES.
//! - Act: `INPUT` `SEND` `RUN` `WRITE` `SIGNAL` `STOP` `RESTART` `RESPAWN` `RENAME` `KICK` `NOTICE`.
//! - Extend: `SUBSCRIBE`, and on a managed session `PHASE` `GATE` `SET_ATTR` `STOP_PROCEED` `RECORDED`.

use std::collections::BTreeSet;
use std::fmt::Write as _;

use nmux_history::write::{Answer, Ticket};
use nmux_holder::Level;
use nmux_io::{OutBuf, Time, TimerId};
use nmux_term::cells::cut_line;
use nmux_wire::{CTL_PROTO, Control, Frame, FrameType, Hello, PingPolicy, Policy as SizePolicy, Res, Size, Welcome};
use serde_json::{Map, Value, json};

use super::session::joined;
use super::{ConnId, Due, Effect, Server};
use crate::input::router::GateEffect;
use crate::messages::is_control;
use crate::output::ByeExtra;

const HELLO_TIMEOUT_MS: u64 = 5000;
/// What a text reply is sent in.
const REPLY_PIECE: usize = 262_144;
/// What a subscriber gets unless it asks for less.
const ALL_EVENTS: [&str; 15] = [
    "lifecycle",
    "notice",
    "stopped",
    "holder",
    "attached",
    "replayed",
    "tty",
    "alt",
    "match",
    "exit",
    "respawned",
    "stopping",
    "record",
    "prompt",
    "command",
];
/// Past this many unread bytes a subscriber is not reading, and is let go rather than queued for.
const MAX_EVENT_BACKLOG: usize = 1_048_576;
const CONTROLLER_PING_MS: u64 = 3000;
const CONTROLLER_SILENT_MS: u64 = 15_000;
/// How long a session waits before starting its controller, and the longest it waits between tries.
pub const CONTROLLER_WAIT_MS: u64 = 1000;
const CONTROLLER_MAX_WAIT_MS: u64 = 60_000;
/// The host's own moments: a controller's word comes from another process and may be out of date.
const NOT_A_CONTROLLERS_TO_CHANGE: [&str; 5] = ["RECOVERING", "EXITED", "STOPPING", "STOPPED", "STOP_STUCK"];
const MAX_INPUT_TEXT: usize = 16_384;
const MAX_RUN_TEXT: usize = 48_000;
/// A prompt drawn again says nothing, so a queue also looks for itself.
const QUEUE_LOOK_MS: u64 = 1000;
/// How long a read of what is not written yet waits for the disk.
const UNWRITTEN_WAIT_MS: u64 = 2000;
const PASTE_START: &[u8] = b"\x1b[200~";
const PASTE_END: &[u8] = b"\x1b[201~";

/// A connection that said HELLO as `control`.
#[derive(Debug)]
pub struct ControlConn {
    /// Its id, `k5` and on.
    pub id: String,
    label: String,
    pid: u32,
    /// What is queued for it.
    pub out: OutBuf,
    /// Bytes ever queued, and where the last text reply ended among them.
    queued: u64,
    reply_end: u64,
    /// It has typed, through the router.
    typing: bool,
    /// The events it subscribed to.
    want: Option<BTreeSet<String>>,
    /// It is the session's controller, pinged.
    controller: Option<ControllerBeat>,
    /// The `RUN` it typed last.
    typed: Option<u64>,
}

#[derive(Debug)]
struct ControllerBeat {
    last_pong: Time,
    due: Time,
    seq: u64,
    start: Option<String>,
    timer: TimerId,
}

impl ControlConn {
    fn send(&mut self, m: &Control) {
        let before = self.out.len();
        let _ = self.out.control(m);
        self.queued += (self.out.len() - before) as u64;
    }

    fn text(&mut self, bytes: &[u8]) {
        for piece in bytes.chunks(REPLY_PIECE) {
            let before = self.out.len();
            let _ = self.out.frame(FrameType::Output, piece);
            self.queued += (self.out.len() - before) as u64;
        }
        self.reply_end = self.queued;
    }

    /// What waits to be sent beyond the text it asked for: the size of that says nothing about how it reads events.
    fn backlog(&self) -> usize {
        let written = self.queued - self.out.len() as u64;
        let reply_left = usize::try_from(self.reply_end.saturating_sub(written)).unwrap_or(usize::MAX);
        self.out.len().saturating_sub(reply_left)
    }
}

/// A RUN waiting its turn for the prompt.
#[derive(Debug)]
pub struct QueuedRun {
    conn: ConnId,
    id: u64,
    text: String,
}

/// A request waiting for something.
#[derive(Debug)]
pub enum Waiting {
    /// For the session to have started and read back what the holder had: it is asked again then.
    Settled { conn: ConnId, id: Value, op: String, args: Value },
    /// For the history's last lines, with the lines still in the emulator.
    Capture { conn: ConnId, id: Value, lines: Option<usize>, held: Vec<String>, ticket: Ticket },
    /// For a command's output from the history.
    Last { conn: ConnId, id: Value, seq: u64, ansi: bool, ticket: Ticket },
    /// For the history to have what it was given, at most a while.
    Unwritten { conn: ConnId, id: Value, ansi: bool, ticket: Ticket, timer: TimerId },
    /// For the stop to be over.
    Stop { conn: ConnId, id: Value },
}

/// The answer to a request: what RES says.
type Reply = Result<Value, String>;

#[allow(clippy::unnecessary_wraps)] // what an arm of a request returns
fn ok(v: Value) -> Option<Reply> {
    Some(Ok(v))
}

#[allow(clippy::unnecessary_wraps)] // what an arm of a request returns
fn err(code: &str) -> Option<Reply> {
    Some(Err(code.to_owned()))
}

fn arg<'a>(args: &'a Value, k: &str) -> Option<&'a Value> {
    args.get(k)
}

fn safe_int(v: Option<&Value>) -> Option<u64> {
    v.and_then(Value::as_u64).filter(|n| *n < (1 << 53))
}

/// A name, printed on terminals: no escape sequences, and not so long a STATE no longer fits.
fn good_name(name: &str) -> bool {
    let units: usize = name.chars().map(char::len_utf16).sum();
    (1..=64).contains(&units) && !name.chars().any(is_control)
}

/// The bytes an INPUT request stands for, or `None` when its arguments are wrong. Text is a bracketed paste with CR
/// after it, so that newlines in it do not submit it early; it may carry no control byte but TAB and LF, so that it cannot
/// smuggle a key or end the paste itself. A key is one of a few, never one that suspends, detaches or interrupts.
fn input_bytes(args: &Value) -> Option<Vec<u8>> {
    match (args.get("text").and_then(Value::as_str), args.get("key").and_then(Value::as_str)) {
        (Some(_), Some(_)) | (None, None) => None,
        (None, Some(key)) => match key {
            "esc" => Some(b"\x1b".to_vec()),
            "enter" => Some(b"\r".to_vec()),
            k if k.len() == 1 && matches!(k.as_bytes()[0], b'1'..=b'9') => Some(k.as_bytes().to_vec()),
            _ => None,
        },
        (Some(text), None) => {
            if text.is_empty() || text.len() > MAX_INPUT_TEXT || text.chars().any(not_text) {
                return None;
            }
            Some([PASTE_START, text.as_bytes(), PASTE_END, b"\r"].concat())
        }
    }
}

/// What is a key and not text: C0 but TAB and LF, and DEL.
fn not_text(c: char) -> bool {
    matches!(c, '\u{0}'..='\u{8}' | '\u{b}'..='\u{1f}' | '\u{7f}')
}

impl Server {
    // ---- connections ------------------------------------------------------------------------------------------------

    pub(super) fn accepted(&mut self, conn: ConnId) {
        let timer = self.set_timer(HELLO_TIMEOUT_MS, Due::HelloTimeout(conn));
        self.greeting.insert(conn, (OutBuf::new(), timer));
    }

    pub(super) fn hello_timeout(&mut self, conn: ConnId) {
        if self.greeting.remove(&conn).is_some() {
            self.effects.push(Effect::Close { conn, now: true });
        }
    }

    pub(super) fn frame(&mut self, conn: ConnId, frame: &Frame<'_>) {
        if self.clients.contains_key(&conn) {
            self.client_frame(conn, frame);
        } else if self.controls.contains_key(&conn) {
            if let Frame::Control(m) = frame {
                self.control_message(conn, m);
            }
        } else if let Some((_, timer)) = self.greeting.get(&conn) {
            let timer = *timer;
            self.timers.cancel(timer);
            match frame {
                Frame::Control(Control::Hello(h)) => self.hello(conn, h),
                _ => self.refuse(conn, "PROTO", "expected HELLO", None),
            }
        }
    }

    pub(super) fn closed(&mut self, conn: ConnId) {
        if self.clients.contains_key(&conn) {
            self.client_gone(conn);
        } else if let Some(c) = self.controls.remove(&conn) {
            self.control_gone(conn, c);
        } else if let Some((_, timer)) = self.greeting.remove(&conn) {
            self.timers.cancel(timer);
        }
        self.closing.remove(&conn);
    }

    fn refuse(&mut self, conn: ConnId, code: &str, text: &str, need: Option<Size>) {
        let Some((mut out, _)) = self.greeting.remove(&conn) else { return };
        let _ = out.control(&Control::Refuse { code: code.to_owned(), need, text: text.to_owned() });
        self.closing.insert(conn, out);
        self.effects.push(Effect::Close { conn, now: false });
    }

    /// WELCOME for a client, saying whether its bar is drawn when it asked for one.
    fn welcome(&self, client_id: &str, bar: bool) -> Control {
        let size = &self.config.size;
        Control::Welcome(Welcome {
            proto: CTL_PROTO,
            id: self.spec.id.clone(),
            extra: self.controller.welcome_fields(),
            name: Some(self.name()),
            client_id: client_id.to_owned(),
            pty: self.pty,
            lifecycle: self.machine.lifecycle.as_str().to_owned(),
            policy: SizePolicy {
                floor_cols: size.floor_cols,
                floor_rows: size.floor_rows,
                hard_min_cols: size.hard_min_cols,
            },
            ping: PingPolicy { interval_ms: self.config.clients.ping_ms, timeout_ms: self.config.clients.stall_ms },
            bar: bar.then_some(true),
        })
    }

    fn hello(&mut self, conn: ConnId, h: &Hello) {
        let name = self.name();
        if h.proto != CTL_PROTO {
            let text = self.messages.proto_mismatch(&h.proto.to_string(), CTL_PROTO, &name);
            self.refuse(conn, "PROTO", &text, None);
            return;
        }
        match h.role.as_str() {
            "control" => return self.control_hello(conn, h),
            "attach" => {}
            other => return self.refuse(conn, "PROTO", &format!("unknown role {other}"), None),
        }
        let lc = &self.machine.lifecycle;
        if lc.is("STOPPING") || lc.is("STOPPED") || lc.is("STOP_STUCK") {
            return self.refuse(conn, "STOPPING", &format!("session '{name}' is stopping"), None);
        }
        if lc.is("BLOCKED") {
            let text = self.messages.blocked(&name, self.machine.blocked_code.as_deref());
            return self.refuse(conn, "BLOCKED", &text, None);
        }
        // A client running inside this session is refused. That needs its environment, which macOS does not show, so
        // there the guard cannot fire; walking the process tree instead would refuse genuine clients.
        if let Some(var) = self.spec.nest_env.as_deref()
            && h.pid > 0
            && self.probe.environ(h.pid, var).as_deref() == Some(self.spec.id.as_str())
        {
            return self.refuse(conn, "NESTED", "refusing to attach a session from inside itself", None);
        }
        let size = &self.config.size;
        let floor = if h.flags.shrink() { size.hard_min_cols } else { size.floor_cols };
        let need = Some(Size { cols: floor, rows: size.floor_rows });
        if h.cols < floor {
            let text = self.messages.below_floor(&name, h.cols, h.rows, floor, size.hard_min_cols);
            return self.refuse(conn, "BELOW_FLOOR", &text, need);
        }
        if h.rows < size.floor_rows {
            let text = format!(
                "this terminal is {}x{} — below the {}-row floor for shared sessions",
                h.cols, h.rows, size.floor_rows
            );
            return self.refuse(conn, "TOO_SHORT", &text, need);
        }
        let id = self.next_client_id();
        let Some((mut out, _)) = self.greeting.remove(&conn) else { return };
        let _ = out.control(&self.welcome(&id, h.flags.bar()));
        self.add_client(conn, h.clone(), &id, out);
    }

    fn control_hello(&mut self, conn: ConnId, h: &Hello) {
        let id = format!("k{}", &self.next_client_id()[1..]);
        let Some((out, _)) = self.greeting.remove(&conn) else { return };
        let label = if h.label.is_empty() { "control".to_owned() } else { h.label.clone() };
        let mut c = ControlConn {
            id: id.clone(),
            label,
            pid: h.pid,
            out,
            queued: 0,
            reply_end: 0,
            typing: false,
            want: None,
            controller: None,
            typed: None,
        };
        c.send(&self.welcome(&id, false));
        c.send(&self.state_message());
        self.controls.insert(conn, c);
    }

    fn control_gone(&mut self, conn: ConnId, c: ControlConn) {
        self.run_queue.retain(|r| r.conn != conn);
        if let (Some(typed), Some(shell)) = (c.typed, self.shell.as_mut()) {
            shell.abandon(typed);
        }
        if let Some(beat) = c.controller {
            self.timers.cancel(beat.timer);
        }
        self.disconnect_controller(conn);
        if c.typing {
            self.router_remove(&c.id);
        }
        let waiting: Vec<u64> = self.requests.iter().filter(|(_, w)| w.conn() == conn).map(|(k, _)| *k).collect();
        for n in waiting {
            self.requests.remove(&n);
        }
    }

    fn control_message(&mut self, conn: ConnId, m: &Control) {
        let Some(c) = self.controls.get_mut(&conn) else { return };
        match m {
            Control::Ping { seq } => c.send(&Control::Pong { seq: *seq }),
            Control::Pong { .. } => {
                if let Some(beat) = c.controller.as_mut() {
                    beat.last_pong = self.now.time;
                }
            }
            Control::Req { id, op, args } => {
                let args = if args.is_object() { args.clone() } else { json!({}) };
                if let Some(reply) = self.request(conn, id, op, &args) {
                    self.reply(conn, id, reply);
                }
            }
            _ => {}
        }
    }

    fn reply(&mut self, conn: ConnId, id: &Value, reply: Reply) {
        let Some(c) = self.controls.get_mut(&conn) else { return };
        let res = match reply {
            Ok(data) => Res { id: id.clone(), ok: true, data: Some(data), error: None, extra: Map::new() },
            Err(e) => Res { id: id.clone(), ok: false, data: None, error: Some(e), extra: Map::new() },
        };
        c.send(&Control::Res(res));
    }

    /// Text as OUTPUT frames, far more than a JSON reply may carry, and the reply's data with its length.
    fn text_reply(&mut self, conn: ConnId, text: &str, mut more: Map<String, Value>) -> Option<Reply> {
        if let Some(c) = self.controls.get_mut(&conn) {
            c.text(text.as_bytes());
        }
        more.insert("bytes".into(), json!(text.len()));
        ok(Value::Object(more))
    }

    /// Whether the session has started and read back what the holder had, so that what it says is what is true now.
    fn settled(&self) -> bool {
        self.started && !self.machine.lifecycle.is("RECOVERING")
    }

    fn wait(&mut self, w: Waiting) -> Option<Reply> {
        self.request_seq += 1;
        self.requests.insert(self.request_seq, w);
        None
    }

    fn wait_settled(&mut self, conn: ConnId, id: &Value, op: &str, args: &Value) -> Option<Reply> {
        self.wait(Waiting::Settled { conn, id: id.clone(), op: op.to_owned(), args: args.clone() })
    }

    // ---- requests ---------------------------------------------------------------------------------------------------

    /// A request, answered now, or later when what it waits for has come: `None` then.
    #[allow(clippy::too_many_lines)] // one arm for each operation, as Node has them
    fn request(&mut self, conn: ConnId, id: &Value, op: &str, a: &Value) -> Option<Reply> {
        match op {
            "STATUS" => {
                let mut data = Map::new();
                data.insert("id".into(), json!(self.spec.id));
                data.extend(self.status());
                data.insert("clients".into(), serde_json::to_value(self.client_info()).unwrap_or_default());
                ok(Value::Object(data))
            }
            "PEEK" => {
                let n = arg(a, "lines")
                    .and_then(Value::as_u64)
                    .filter(|n| *n >= 1)
                    .map_or(6, |n| usize::try_from(n.min(50)).unwrap_or(50));
                let screen = self.screen_text();
                let lines: Vec<&str> = screen.split('\n').filter(|l| !l.trim().is_empty()).collect();
                ok(json!({ "lines": lines[lines.len().saturating_sub(n)..] }))
            }
            "CAPTURE" => {
                let lines =
                    safe_int(arg(a, "lines")).filter(|n| *n > 0).map(|n| usize::try_from(n).unwrap_or(usize::MAX));
                let ansi = arg(a, "ansi").and_then(Value::as_bool).unwrap_or(false);
                self.capture(conn, id, lines, ansi)
            }
            "SINCE" => {
                let (text, top, cursor) = self.emulator.since(safe_int(arg(a, "row")));
                let mut more = Map::new();
                more.insert("top".into(), json!(top));
                more.insert("cursor".into(), json!(cursor));
                self.text_reply(conn, &text, more)
            }
            "UNWRITTEN" => {
                let ansi = arg(a, "ansi") == Some(&Value::Bool(true));
                match self.spool.as_mut() {
                    Some(spool) => {
                        let ticket = spool.idle();
                        self.request_seq += 1;
                        let n = self.request_seq;
                        let timer = self.set_timer(UNWRITTEN_WAIT_MS, Due::Request(n));
                        self.requests.insert(n, Waiting::Unwritten { conn, id: id.clone(), ansi, ticket, timer });
                        None
                    }
                    None => self.unwritten_reply(conn, ansi),
                }
            }
            "SCREEN" => {
                let text = self.screen_text();
                self.text_reply(conn, &text, Map::new())
            }
            "COMMANDS" => {
                if self.shell.is_none() {
                    return err("NO_INTEGRATION");
                }
                if !self.settled() {
                    return self.wait_settled(conn, id, op, a);
                }
                let shell = self.shell.as_ref()?;
                if shell.absent {
                    return err("NO_INTEGRATION");
                }
                let mut data = shell.status().as_object().cloned().unwrap_or_default();
                data.insert("commands".into(), Value::Array(shell.records.iter().map(|r| shell.describe(r)).collect()));
                ok(Value::Object(data))
            }
            "LAST" => self.last(conn, id, a),
            "RUN" => self.run(conn, id, a),
            "STOP" => {
                self.stop();
                if self.stop.over() {
                    return ok(json!({ "lifecycle": self.machine.lifecycle }));
                }
                self.wait(Waiting::Stop { conn, id: id.clone() })
            }
            "RESTART" => {
                if self.controller.managed() {
                    return err("UNSUPPORTED"); // a controller says what to run, with RESPAWN
                }
                self.restart();
                ok(json!({}))
            }
            "RENAME" => {
                let Some(name) = arg(a, "name").and_then(Value::as_str).filter(|n| good_name(n)) else {
                    return err("BAD_ARGS");
                };
                self.rename(name);
                self.save_state(true);
                self.broadcast_state();
                ok(json!({ "name": name }))
            }
            "SEND" => {
                let Some(text) = arg(a, "text").and_then(Value::as_str).filter(|t| !t.is_empty()) else {
                    return err("BAD_ARGS");
                };
                let paste = text.contains('\n') && self.tracker.modes.raw(2004) == 1;
                let body = if paste { text.replace("\x1b[201~", "") } else { text.to_owned() }; // it may not end its own paste
                let enter = arg(a, "enter").is_some_and(|v| v.as_bool().unwrap_or(!v.is_null()));
                let mut bytes = Vec::new();
                if paste {
                    bytes.extend_from_slice(PASTE_START);
                }
                bytes.extend_from_slice(body.as_bytes());
                if paste {
                    bytes.extend_from_slice(PASTE_END);
                }
                if enter {
                    bytes.push(b'\r');
                }
                Some(self.type_bytes(conn, &bytes, "send"))
            }
            "WRITE" => {
                // past the gates: for a controller that knows what it is doing, as a stop's own last word is
                let Some(text) = arg(a, "text").and_then(Value::as_str).filter(|t| !t.is_empty()) else {
                    return err("BAD_ARGS");
                };
                let watch_id = self.write(text.as_bytes(), false, false);
                ok(json!({ "watchId": watch_id }))
            }
            "SIGNAL" => match arg(a, "sig").and_then(Value::as_str) {
                Some(sig @ ("SIGCONT" | "SIGTERM")) => {
                    self.signal_child(sig);
                    ok(json!({}))
                }
                _ => err("BAD_ARGS"),
            },
            "RESPAWN" => {
                let argv: Option<Vec<String>> = arg(a, "argv")
                    .and_then(Value::as_array)
                    .filter(|v| !v.is_empty())
                    .and_then(|v| v.iter().map(|x| x.as_str().map(str::to_owned)).collect());
                let Some(argv) = argv else { return err("BAD_ARGS") };
                if let Some(r) = self.controller.remote.as_mut() {
                    r.next_argv = Some(argv.clone());
                }
                if self.machine.exited {
                    self.respawn_with(argv);
                } else {
                    self.restart();
                }
                ok(json!({}))
            }
            "NOTICE" => {
                let level = arg(a, "level").and_then(Value::as_str).filter(|l| matches!(*l, "info" | "warn"));
                let (Some(level), Some(code), Some(text)) =
                    (level, arg(a, "code").and_then(Value::as_str), arg(a, "text").and_then(Value::as_str))
                else {
                    return err("BAD_ARGS");
                };
                self.notify(level, code, text);
                ok(json!({}))
            }
            "SUBSCRIBE" => self.subscribe(conn, a),
            "PHASE" | "GATE" | "SET_ATTR" | "STOP_PROCEED" | "RECORDED" => self.manage(op, a),
            "INPUT" => match input_bytes(a) {
                Some(bytes) => {
                    let kind = if a.get("text").is_some_and(Value::is_string) { "text" } else { "key" };
                    Some(self.type_bytes(conn, &bytes, kind))
                }
                None => err("BAD_ARGS"),
            },
            "CLIENTS" => ok(json!({ "clients": self.listing() })),
            "KICK" => self.kick_request(a),
            _ => err("UNSUPPORTED"),
        }
    }

    /// History and screen as text, with everything printed so far. The history answers for all it has been given, and the
    /// emulator only for what it has not: the two cannot be told apart row by row once a reflow has renumbered one.
    fn capture(&mut self, conn: ConnId, id: &Value, lines: Option<usize>, ansi: bool) -> Option<Reply> {
        let Some(spool) = self.spool.as_mut().filter(|s| !s.failed()) else {
            let text = joined(&self.emulator.capture_lines(lines, ansi, false));
            return self.text_reply(conn, &text, Map::new());
        };
        let held = self.emulator.capture_lines(lines, ansi, true);
        let short = lines.map(|n| n.saturating_sub(held.len()));
        if short == Some(0) {
            let all: Vec<String> = held[held.len().saturating_sub(lines.unwrap_or(0))..].to_vec();
            return self.text_reply(conn, &joined(&all), Map::new());
        }
        let ticket = spool.last_lines(short.map(|n| n + 1), ansi);
        self.wait(Waiting::Capture { conn, id: id.clone(), lines, held, ticket })
    }

    fn capture_answered(
        &mut self,
        conn: ConnId,
        id: &Value,
        lines: Option<usize>,
        mut held: Vec<String>,
        early: Vec<String>,
    ) {
        let mut early = early;
        if !early.is_empty() && !held.is_empty() && self.emulator.unspooled_continues() {
            let last = early.pop().unwrap_or_default();
            held[0] = last + &held[0];
        }
        early.extend(held);
        let all = match lines {
            Some(n) => early[early.len().saturating_sub(n)..].to_vec(),
            None => early,
        };
        let reply = self.text_reply(conn, &joined(&all), Map::new());
        if let Some(r) = reply {
            self.reply(conn, id, r);
        }
    }

    fn unwritten_reply(&mut self, conn: ConnId, ansi: bool) -> Option<Reply> {
        let keeper = self.spool.as_ref().map(|s| s as &dyn crate::output::Keeper);
        let u = self.emulator.unwritten(ansi, keeper);
        let mut text = String::new();
        for l in &u.lines {
            let _ = writeln!(text, "{}\t{}\t{}", l.rows, l.at, l.text);
        }
        let mut more = Map::new();
        more.insert("first".into(), json!(u.first));
        more.insert("count".into(), json!(u.lines.len()));
        self.text_reply(conn, &text, more)
    }

    /// The output of a command: the last to finish, or the one asked for.
    fn last(&mut self, conn: ConnId, id: &Value, a: &Value) -> Option<Reply> {
        if self.shell.is_none() {
            return err("NO_INTEGRATION");
        }
        if !self.settled() {
            return self.wait_settled(conn, id, "LAST", a);
        }
        let shell = self.shell.as_ref()?;
        if shell.absent {
            return err("NO_INTEGRATION");
        }
        let rec = match safe_int(arg(a, "seq")) {
            Some(seq) => shell.find(seq),
            None => shell.last_finished(),
        };
        let Some(rec) = rec.cloned() else { return err("NONE") };
        let ansi = arg(a, "ansi").and_then(Value::as_bool).unwrap_or(false);
        let from_history = self.spool.as_ref().is_some_and(|s| !s.failed()) && rec.spool_start.is_some();
        if from_history && let (Some(spool), Some(start)) = (self.spool.as_mut(), rec.spool_start) {
            let to = rec.spool_end.map_or(spool.lines(), |end| end + u64::from(rec.end_chars > 0));
            let ticket = spool.range(start, to, ansi);
            return self.wait(Waiting::Last { conn, id: id.clone(), seq: rec.seq, ansi, ticket });
        }
        let (text, complete) = shell.output(&self.emulator, &rec, ansi, None);
        self.last_reply(conn, &rec, &text, complete)
    }

    fn last_reply(
        &mut self,
        conn: ConnId,
        rec: &crate::session::shell::Command,
        text: &str,
        complete: bool,
    ) -> Option<Reply> {
        let shell = self.shell.as_ref()?;
        let mut more = shell.describe(rec).as_object().cloned().unwrap_or_default();
        more.insert("complete".into(), json!(complete));
        self.text_reply(conn, text, more)
    }

    fn last_answered(&mut self, conn: ConnId, id: &Value, seq: u64, ansi: bool, early: Option<Vec<String>>) {
        let Some(rec) = self.shell.as_ref().and_then(|s| s.find(seq)).cloned() else {
            self.reply(conn, id, Err("NONE".into()));
            return;
        };
        let Some(shell) = self.shell.as_ref() else { return };
        let (text, complete) = match early {
            None => shell.output(&self.emulator, &rec, ansi, None),
            Some(mut early) => {
                if rec.spool_end.is_some()
                    && rec.end_chars > 0
                    && let Some(last) = early.last_mut()
                {
                    *last = cut_line(last, rec.end_chars);
                }
                if rec.spool_end.is_some() {
                    (joined(&early), true)
                } else {
                    let from = self.emulator.unspooled_row();
                    let (rest, _) = shell.output(&self.emulator, &rec, ansi, from);
                    (joined(&early) + &rest, true)
                }
            }
        };
        if let Some(reply) = self.last_reply(conn, &rec, &text, complete) {
            self.reply(conn, id, reply);
        }
    }

    /// What the history answered.
    pub(super) fn history_answers(&mut self) {
        let Some(spool) = self.spool.as_mut() else { return };
        let done = spool.take_done();
        for d in done {
            let Some(n) = self.requests.iter().find(|(_, w)| w.ticket() == Some(d.ticket)).map(|(k, _)| *k) else {
                if matches!(d.answer, Answer::Closed) {
                    self.history_closed();
                }
                continue;
            };
            let Some(w) = self.requests.remove(&n) else { continue };
            match (w, d.answer) {
                (Waiting::Capture { conn, id, lines, held, .. }, Answer::LastLines(early)) => {
                    self.capture_answered(conn, &id, lines, held, early.unwrap_or_default());
                }
                (Waiting::Last { conn, id, seq, ansi, .. }, Answer::Range(early)) => {
                    self.last_answered(conn, &id, seq, ansi, early.ok().flatten());
                }
                (Waiting::Unwritten { conn, id, ansi, timer, .. }, _) => {
                    self.timers.cancel(timer);
                    if let Some(r) = self.unwritten_reply(conn, ansi) {
                        self.reply(conn, &id, r);
                    }
                }
                _ => {}
            }
        }
    }

    /// A request waited for the disk long enough.
    pub(super) fn request_due(&mut self, n: u64) {
        if let Some(Waiting::Unwritten { conn, id, ansi, .. }) = self.requests.remove(&n)
            && let Some(r) = self.unwritten_reply(conn, ansi)
        {
            self.reply(conn, &id, r);
        }
    }

    /// The session has settled: requests that waited for that are asked again.
    pub(super) fn requests_hear_settled(&mut self) {
        if !self.settled() {
            return;
        }
        let waiting: Vec<u64> =
            self.requests.iter().filter(|(_, w)| matches!(w, Waiting::Settled { .. })).map(|(k, _)| *k).collect();
        for n in waiting {
            if let Some(Waiting::Settled { conn, id, op, args }) = self.requests.remove(&n)
                && let Some(reply) = self.request(conn, &id, &op, &args)
            {
                self.reply(conn, &id, reply);
            }
        }
    }

    /// The stop is over: requests that waited for it are answered.
    pub(super) fn requests_hear_stopped(&mut self) {
        let waiting: Vec<u64> =
            self.requests.iter().filter(|(_, w)| matches!(w, Waiting::Stop { .. })).map(|(k, _)| *k).collect();
        let lifecycle = json!(self.machine.lifecycle);
        for n in waiting {
            if let Some(Waiting::Stop { conn, id }) = self.requests.remove(&n) {
                self.reply(conn, &id, Ok(json!({ "lifecycle": lifecycle })));
            }
        }
    }

    // ---- typing -----------------------------------------------------------------------------------------------------

    /// Input from a control connection, through the same router and gates as a terminal's keys. The gates are looked at
    /// here first only so that the caller learns why nothing was typed.
    fn type_bytes(&mut self, conn: ConnId, bytes: &[u8], kind: &str) -> Reply {
        let gates = self.gates();
        if let Some(g) = self.blocking_gates().into_iter().find(|g| gates.contains(g)) {
            return Err(g);
        }
        let Some(c) = self.controls.get_mut(&conn) else { return Err("EXITED".into()) };
        let (id, label) = (c.id.clone(), c.label.clone());
        if !c.typing {
            c.typing = true;
            self.router.add_client(&id, false);
        }
        self.route_input(&id, bytes);
        self.log(
            Level::Info,
            "control.input",
            &[("client", json!(id)), ("label", json!(label)), ("kind", json!(kind)), ("bytes", json!(bytes.len()))],
        );
        Ok(json!({}))
    }

    /// RUN: a line typed at the shell's prompt, the only place known to be safe to type at. The check and the typing happen
    /// with nothing between them. With `queue` it waits its turn for the prompt, for as long as the caller stays.
    fn run(&mut self, conn: ConnId, id: &Value, a: &Value) -> Option<Reply> {
        if self.shell.is_none() {
            return err("NO_INTEGRATION");
        }
        let text = arg(a, "text").and_then(Value::as_str).unwrap_or("");
        if text.trim().is_empty() || text.len() > MAX_RUN_TEXT || text.chars().any(not_text) {
            return err("BAD_ARGS");
        }
        if !self.settled() {
            return self.wait_settled(conn, id, "RUN", a);
        }
        self.runs += 1;
        let run = self.runs;
        let why = self.shell.as_ref().and_then(|s| s.not_ready(&self.emulator));
        let Some(why) = why else {
            return Some(self.start_run(conn, run, text).map(|()| json!({ "run": run })));
        };
        if !arg(a, "queue").and_then(Value::as_bool).unwrap_or(false) || why.as_str() == "NO_INTEGRATION" {
            return err(why.as_str());
        }
        self.run_queue.push_back(QueuedRun { conn, id: run, text: text.to_owned() });
        self.look_at_queue();
        ok(json!({ "run": run, "queued": true }))
    }

    fn start_run(&mut self, conn: ConnId, run: u64, text: &str) -> Result<(), String> {
        let paste = self.tracker.modes.raw(2004) == 1;
        let vi = self.shell.as_ref().is_some_and(|s| s.vi_mode);
        if !paste && (text.contains('\n') || text.contains('\t') || vi) {
            // each line would run alone, TAB would complete, and in vi mode the keys are commands
            return Err("NO_PASTE".into());
        }
        let bytes = if paste {
            [PASTE_START, text.as_bytes(), PASTE_END, b"\r"].concat()
        } else {
            [text.as_bytes(), b"\r"].concat()
        };
        self.type_bytes(conn, &bytes, "run")?;
        if let Some(shell) = self.shell.as_mut() {
            shell.expect(&self.emulator, run, text);
        }
        if let Some(c) = self.controls.get_mut(&conn) {
            c.typed = Some(run);
        }
        Ok(())
    }

    fn look_at_queue(&mut self) {
        if self.run_queue_timer.is_none() && !self.run_queue.is_empty() {
            self.run_queue_timer = Some(self.set_timer(QUEUE_LOOK_MS, Due::RunQueue));
        }
    }

    pub(super) fn run_queue_due(&mut self) {
        self.run_queue_timer = None;
        self.next_run();
        self.look_at_queue();
    }

    /// The next queued RUN, if the shell is at its prompt.
    pub(super) fn next_run(&mut self) {
        if self.run_queue.is_empty() || self.shell.as_ref().is_none_or(|s| s.not_ready(&self.emulator).is_some()) {
            return;
        }
        let Some(q) = self.run_queue.pop_front() else { return };
        if let Err(error) = self.start_run(q.conn, q.id, &q.text) {
            let e = json!({ "event": "command", "phase": "refused", "run": q.id, "error": error });
            self.event_to(q.conn, &e);
        }
    }

    fn rename(&mut self, name: &str) {
        name.clone_into(&mut self.current_name);
        if let Some(spool) = self.spool.as_mut() {
            spool.describe(&nmux_history::write::Meta {
                id: self.spec.id.clone(),
                name: Some(name.to_owned()),
                created_at: self.spec.created_at.clone(),
                cwd: Some(self.spec.child.cwd.clone()),
                argv: self.spec.child.argv.clone(),
            });
        }
    }

    fn kick_request(&mut self, a: &Value) -> Option<Reply> {
        let ids = |v: Option<&Value>| -> Option<Vec<String>> {
            let v = v?.as_array()?;
            if v.len() > 256 {
                return None;
            }
            v.iter().map(|x| x.as_str().filter(|s| s.chars().count() <= 32).map(str::to_owned)).collect()
        };
        let (has_clients, has_except) = (a.get("clients").is_some(), a.get("allExcept").is_some());
        let clients = ids(a.get("clients"));
        let except = ids(a.get("allExcept"));
        if has_clients == has_except
            || (has_clients && clients.as_ref().is_none_or(Vec::is_empty))
            || (has_except && except.is_none())
        {
            return err("BAD_ARGS");
        }
        // printed on the kicked terminal: it may not carry escape sequences
        let by: String =
            a.get("by").and_then(Value::as_str).unwrap_or("").chars().filter(|c| !is_control(*c)).take(64).collect();
        if a.get("because").and_then(Value::as_str) == Some("CLIENT_EXIT") {
            return ok(self.leave(clients.as_deref().unwrap_or(&[])));
        }
        ok(self.kick(clients.as_deref(), except.as_deref(), &by))
    }

    // ---- events -----------------------------------------------------------------------------------------------------

    /// An event, to every subscriber that wants it. One not reading is let go rather than queued for.
    pub(super) fn publish(&mut self, e: &Value) {
        let Some(name) = e.get("event").and_then(Value::as_str) else { return };
        let conns: Vec<ConnId> = self
            .controls
            .iter()
            .filter(|(_, c)| c.want.as_ref().is_some_and(|w| w.contains(name)))
            .map(|(k, _)| *k)
            .collect();
        for conn in conns {
            self.event_to(conn, e);
        }
    }

    fn event_to(&mut self, conn: ConnId, e: &Value) {
        let Some(c) = self.controls.get_mut(&conn) else { return };
        if c.backlog() > MAX_EVENT_BACKLOG {
            let id = c.id.clone();
            self.log(Level::Warn, "subscriber.not_reading", &[("client", json!(id))]);
            self.effects.push(Effect::Close { conn, now: true });
            return;
        }
        let mut fields = e.as_object().cloned().unwrap_or_default();
        let event = fields.remove("event").and_then(|v| v.as_str().map(str::to_owned)).unwrap_or_default();
        c.send(&Control::Event(nmux_wire::Event { event, fields }));
    }

    /// SUBSCRIBE: EVENT pushes until the connection closes. The reply says where things stand, so nothing earlier needs
    /// replaying. `controller` claims the session: its controller is connected.
    fn subscribe(&mut self, conn: ConnId, a: &Value) -> Option<Reply> {
        let wants_controller = a.get("controller").is_some_and(|v| v.as_bool().unwrap_or(!v.is_null()));
        if wants_controller && !self.controller.managed() {
            return err("UNSUPPORTED");
        }
        let want: BTreeSet<String> = match a.get("events").and_then(Value::as_array) {
            Some(events) => events.iter().filter_map(Value::as_str).map(str::to_owned).collect(),
            None => ALL_EVENTS.iter().map(|e| (*e).to_owned()).collect(),
        };
        self.disconnect_controller(conn);
        if let Some(c) = self.controls.get_mut(&conn) {
            c.want = Some(want);
        }
        if wants_controller {
            self.watch_controller(conn);
        }
        let m = &self.machine;
        if self.controller.managed() {
            let h = self.hello.as_ref();
            let r = self.controller.remote.as_ref()?;
            return ok(json!({
                "holder": h.map(|h| json!({ "gen": h.generation, "child": { "pid": h.child.pid, "procStart": h.child.proc_start },
                    "pty": { "cols": h.pty.cols, "rows": h.pty.rows } })),
                "tty": self.controller.tty_event(self.tracker.alt), "lifecycle": m.lifecycle, "blockedCode": m.blocked_code,
                "exited": m.exited, "lastExit": m.last_exit, "exit": r.standing_exit, "gates": self.controller.gates(),
                "launchedAtMs": self.launched_at_ms, "name": self.name(),
            }));
        }
        ok(json!({ "lifecycle": m.lifecycle, "name": self.name(), "lastExit": m.last_exit }))
    }

    /// A controller that is connected and not answering is no controller: a hung process looks just like a working one,
    /// and something else needs to know so that it can be replaced. It is given a chance to end cleanly and is let go.
    fn watch_controller(&mut self, conn: ConnId) {
        let ping = self.controller.remote.as_ref().and_then(|r| r.managed.ping_ms).unwrap_or(CONTROLLER_PING_MS);
        let Some(c) = self.controls.get(&conn) else { return };
        let start = (c.pid > 0).then(|| self.probe.proc_start(c.pid)).flatten();
        let timer = self.set_timer(ping, Due::ControllerPing(conn));
        let now = self.now.time;
        if let Some(c) = self.controls.get_mut(&conn) {
            c.controller = Some(ControllerBeat { last_pong: now, due: now.after(ping), seq: 0, start, timer });
        }
        if let Some(r) = self.controller.remote.as_mut() {
            r.connection = Some(conn.0);
        }
        self.controller_arrived();
    }

    fn disconnect_controller(&mut self, conn: ConnId) {
        if let Some(r) = self.controller.remote.as_mut()
            && r.connection == Some(conn.0)
        {
            r.connection = None;
        }
        if let Some(beat) = self.controls.get_mut(&conn).and_then(|c| c.controller.take()) {
            self.timers.cancel(beat.timer);
        }
    }

    pub(super) fn controller_beat(&mut self, conn: ConnId) {
        let remote = self.controller.remote.as_ref();
        let ping = remote.and_then(|r| r.managed.ping_ms).unwrap_or(CONTROLLER_PING_MS);
        let silent = remote.and_then(|r| r.managed.silent_ms).unwrap_or(CONTROLLER_SILENT_MS);
        let now = self.now.time;
        let Some(c) = self.controls.get_mut(&conn) else { return };
        let Some(beat) = c.controller.as_mut() else { return };
        // time this process lost is not the controller's silence
        beat.last_pong = beat.last_pong.after(now.since(beat.due));
        if now.since(beat.last_pong) > silent {
            let (id, pid, start) = (c.id.clone(), c.pid, beat.start.clone());
            c.controller = None;
            self.log(Level::Warn, "controller.silent", &[("client", json!(id)), ("pid", json!(pid))]);
            self.disconnect_controller(conn);
            if let Some(start) = start {
                for sig in ["SIGCONT", "SIGTERM"] {
                    self.effects.push(Effect::Signal { pid, start: Some(start.clone()), sig });
                }
            }
            self.effects.push(Effect::Close { conn, now: true });
            return;
        }
        beat.seq += 1;
        beat.due = now.after(ping);
        let seq = beat.seq;
        c.send(&Control::Ping { seq });
        let timer = self.set_timer(ping, Due::ControllerPing(conn));
        if let Some(beat) = self.controls.get_mut(&conn).and_then(|c| c.controller.as_mut()) {
            beat.timer = timer;
        }
    }

    /// Keeps a managed session's controller alive with nothing else having to: if none is connected, it is started. It is
    /// one process for many sessions, so one that runs already finds this session and connects; a second one exits.
    pub(super) fn watch_controller_start(&mut self) {
        if self.controller.remote.as_ref().and_then(|r| r.managed.command.as_ref()).is_some() {
            self.set_timer(CONTROLLER_WAIT_MS, Due::ControllerWatch);
        }
    }

    pub(super) fn controller_watch(&mut self) {
        if self.ending.is_some() {
            return;
        }
        let Some(command) = self.controller.remote.as_ref().and_then(|r| r.managed.command.clone()) else { return };
        if self.controller.connected() {
            self.controller_watch_ms = CONTROLLER_WAIT_MS;
        } else {
            self.effects.push(Effect::Spawn { argv: command.argv, env: command.env });
            self.controller_watch_ms = (self.controller_watch_ms * 2).min(CONTROLLER_MAX_WAIT_MS);
        }
        self.set_timer(self.controller_watch_ms, Due::ControllerWatch);
    }

    /// What a controller may ask of a managed session.
    fn manage(&mut self, op: &str, a: &Value) -> Option<Reply> {
        if !self.controller.managed() {
            return err("UNSUPPORTED");
        }
        match op {
            "PHASE" => {
                if NOT_A_CONTROLLERS_TO_CHANGE.iter().any(|l| self.machine.lifecycle.is(l)) {
                    return err("NOT_NOW");
                }
                if let Some(code) = a.get("code").filter(|c| !c.is_null() && c.as_str() != Some("")) {
                    let code = code.as_str().map_or_else(|| code.to_string(), str::to_owned);
                    self.dispatch(crate::session::machine::Event::Blocked(code));
                    return ok(json!({ "lifecycle": self.machine.lifecycle }));
                }
                let Some(to) = a.get("to").and_then(Value::as_str).filter(|t| !t.is_empty()) else {
                    return err("BAD_ARGS");
                };
                let from: Option<Vec<String>> = a
                    .get("from")
                    .and_then(Value::as_array)
                    .map(|f| f.iter().filter_map(|x| x.as_str().map(str::to_owned)).collect());
                self.dispatch(crate::session::machine::Event::Phase { to: to.to_owned(), from });
                ok(json!({ "lifecycle": self.machine.lifecycle }))
            }
            "GATE" => {
                let Some(name) = a.get("name").and_then(Value::as_str).filter(|n| !n.is_empty()) else {
                    return err("BAD_ARGS");
                };
                let effect = match a.get("effect") {
                    Some(Value::Null) => None,
                    Some(Value::String(e)) if e == "filter" => Some(GateEffect::Filter),
                    _ => Some(GateEffect::Drop),
                };
                let flag = |k: &str| a.get(k).and_then(Value::as_bool).unwrap_or(false);
                let rank = a.get("rank").and_then(Value::as_i64).unwrap_or(0);
                self.controller.set_gate(name, effect, flag("passable"), flag("blocking"), rank);
                ok(json!({ "gate": self.gate_name() }))
            }
            "SET_ATTR" => {
                let Some(attrs) = a.get("attrs").and_then(Value::as_object) else { return err("BAD_ARGS") };
                self.controller.set_attrs(attrs);
                self.save_state(false);
                match a.get("attention").and_then(Value::as_bool) {
                    Some(attention) => self.publish_attention(attention),
                    None => self.broadcast_state(),
                }
                ok(json!({}))
            }
            "RECORDED" => {
                if let Some(r) = self.controller.remote.as_mut() {
                    r.recorded = true;
                }
                self.ending_hears_recorded();
                ok(json!({}))
            }
            _ => {
                self.stop_proceed();
                ok(json!({}))
            }
        }
    }

    /// Bye to every client that the session is going: used when a server ends with clients still here.
    pub(super) fn bye_going(&mut self, reason: &str, text: &str) {
        self.bye_all(reason, false, text, &ByeExtra::default());
    }
}

impl Waiting {
    fn conn(&self) -> ConnId {
        match self {
            Self::Settled { conn, .. }
            | Self::Capture { conn, .. }
            | Self::Last { conn, .. }
            | Self::Unwritten { conn, .. }
            | Self::Stop { conn, .. } => *conn,
        }
    }

    fn ticket(&self) -> Option<Ticket> {
        match self {
            Self::Capture { ticket, .. } | Self::Last { ticket, .. } | Self::Unwritten { ticket, .. } => Some(*ticket),
            Self::Settled { .. } | Self::Stop { .. } => None,
        }
    }
}
