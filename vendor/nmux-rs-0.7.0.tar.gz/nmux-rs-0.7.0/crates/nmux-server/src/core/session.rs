//! The session, `session.js`: the holder and its child, the output path from the holder's bytes to the emulator and the
//! clients, the lifecycle, and the record on disk.

use nmux_history::write::Spool;
use nmux_holder::Level;
use nmux_holder::valid_color;
use nmux_io::{OutBuf, Time};
use nmux_wire::{
    Colors, Control, ErrorMessage, Exit as WireExit, Frame, HHello, HOLDER_PROTO, Size, Write, decode_data,
};
use serde_json::{Map, Value, json};

use super::{Bookmark, Due, Effect, Server};
use crate::input::router::Writer;
use crate::messages::{Finished, away_text};
use crate::output::{Chunk, Edit, EditKind, Keeper, Pipeline, Tracker};
use crate::session::machine::{Effect as MachineEffect, Event as MachineEvent, Exit, reduce};

/// How much of what it has just read back a new server keeps, and for how long, for the terminals on their way back.
const TAIL_BYTES: usize = 1_048_576;
/// See [`TAIL_BYTES`].
pub const TAIL_KEEP_MS: u64 = 15_000;
/// How often pty.sock is tried while a holder starts.
const CONNECT_RETRY_MS: u64 = 50;
/// How often the old holder's lock is looked at before a new child starts, and how many times.
const LOCK_POLL_MS: u64 = 50;
const LOCK_POLLS: u32 = 100;
/// How often a child that outlived its holder is looked for.
const ORPHAN_POLL_MS: u64 = 500;
/// DECSTR, then what it leaves alone.
const CLEAN_MODES: &str = "\x1b[!p\x1b[?1000l\x1b[?1002l\x1b[?1003l\x1b[?1006l\x1b[?1004l\x1b[?2004l";

/// The connection to the holder: what is queued for it, and its greeting once it came.
#[derive(Debug)]
pub struct HolderLink {
    /// What is queued for pty.sock.
    pub out: OutBuf,
    hello: Option<HHello>,
    watch_seq: u32,
    /// The colours it was told last.
    colors: Option<Colors>,
}

impl HolderLink {
    fn new() -> Self {
        Self { out: OutBuf::new(), hello: None, watch_seq: 0, colors: None }
    }

    fn flow(&self) -> bool {
        self.hello.as_ref().is_some_and(HHello::flow)
    }

    fn takes_colors(&self) -> bool {
        self.hello.as_ref().is_some_and(HHello::colors)
    }

    fn send(&mut self, m: &Control) {
        let _ = self.out.control(m);
    }
}

/// Why pty.sock is being tried.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Purpose {
    /// The session starts; `replay`: from the holder's ring, after another server.
    Start {
        /// See above.
        replay: bool,
    },
    /// A new child, after the last one.
    Respawn,
}

/// pty.sock being tried, until a deadline.
#[derive(Debug)]
pub struct Connecting {
    purpose: Purpose,
    deadline: Time,
    last_error: String,
}

/// A new child on its way: the old holder's lock is waited for first.
#[derive(Debug)]
pub struct Respawning {
    argv: Vec<String>,
    polls: u32,
}

/// A child that outlived its holder, watched until a deadline.
#[derive(Debug)]
pub struct Orphaned {
    pid: u32,
    start: Option<String>,
    deadline: Time,
}

/// Lines with a line feed after each.
pub fn joined(lines: &[String]) -> String {
    let mut out = String::new();
    for l in lines {
        out.push_str(l);
        out.push('\n');
    }
    out
}

/// Whether a terminal's old rows are still what is at those numbers. Whole lines, because a reflow changes rows and not
/// what they say. The last may have grown: it is where the cursor was, and what is typed there now is new.
fn same_as_shown(shown: &[String], now: Option<Vec<String>>) -> bool {
    let Some(now) = now.filter(|n| n.len() == shown.len()) else { return false };
    let last = shown.len().saturating_sub(1);
    shown
        .iter()
        .zip(&now)
        .enumerate()
        .all(|(i, (was, is))| if i == last { is.starts_with(was.as_str()) } else { is == was })
}

impl Keeper for Spool {
    fn append(&mut self, rows: Vec<String>, wrapped: Vec<bool>, offset: u64, times: Vec<i64>) -> u64 {
        Spool::append(self, rows, wrapped, offset, Some(times))
    }

    fn already_has(&self, offset: u64) -> bool {
        Spool::already_has(self, offset)
    }

    fn through(&self) -> Option<u64> {
        Spool::through(self)
    }

    fn lines(&self) -> u64 {
        Spool::lines(self)
    }

    fn failed(&self) -> bool {
        Spool::failed(self)
    }
}

/// Writes go to the holder, counted: the router and the key guard write through this.
pub(super) struct HolderWriter<'a> {
    pub holder: Option<&'a mut HolderLink>,
    pub total: &'a mut u64,
    pub closed: bool,
}

impl Writer for HolderWriter<'_> {
    fn write(&mut self, bytes: &[u8], lone_esc: bool, watch: bool) -> u32 {
        let Some(h) = self.holder.as_deref_mut().filter(|_| !self.closed) else { return 0 };
        let watch_id = if watch {
            h.watch_seq += 1;
            h.watch_seq
        } else {
            0
        };
        let _ = h.out.write(&Write { watch_id, lone_esc, bytes });
        *self.total += bytes.len() as u64;
        watch_id
    }

    fn total(&self) -> u64 {
        *self.total
    }
}

impl Server {
    // ---- starting ---------------------------------------------------------------------------------------------------

    /// ctl.sock listens: a program being watched from the start waits for the first terminal, and otherwise the session
    /// starts.
    pub(super) fn begin(&mut self) {
        self.watch_controller_start();
        self.ambient_start();
        if self.wait_for_client && !self.recover && self.clients.is_empty() {
            self.set_timer(super::stop::FIRST_CLIENT_WAIT_MS, Due::FirstClient);
            return;
        }
        self.start();
    }

    pub(super) fn first_client_due(&mut self) {
        if !self.starting && !self.started && !self.machine.lifecycle.is("STOPPED") {
            self.start();
        }
    }

    /// The first terminal arrived while the program waited for it.
    pub(super) fn client_arrived(&mut self) {
        if self.wait_for_client && !self.starting && !self.started && self.hello.is_none() {
            self.start();
        }
    }

    /// A new session starts its holder; a recovering one adopts the one running.
    fn start(&mut self) {
        if self.starting {
            return;
        }
        self.starting = true;
        if !self.recover {
            self.generation = 1;
            self.launched_at_ms = Some(self.now.wall_ms);
            let argv = self.spec.child.argv.clone();
            self.spawn_holder(&argv, self.spec.pty);
        }
        self.connect_holder(Purpose::Start { replay: self.recover });
    }

    /// Writes a holder's spec and starts it.
    fn spawn_holder(&mut self, argv: &[String], size: Size) {
        let Ok(file) = self.layout.holder_spec(&self.spec.id, self.generation) else { return };
        let mut argv_cmd: Vec<String> = self.restart_argv.iter().filter(|a| *a != "--recover").cloned().collect();
        argv_cmd.push("--recover".to_owned());
        let mut spec = json!({
            "schema": "nmux.holderspec/1", "id": self.spec.id, "argv": argv, "env": self.spec.child.env,
            "cwd": self.spec.child.cwd, "cols": size.cols, "rows": size.rows, "ringBytes": self.config.holder.ring_bytes,
            "sessiondCmd": argv_cmd, "gen": self.generation, "runtimeDir": self.spec.runtime_dir,
            "termColors": self.spec.term_colors, "term": self.spec.term,
        });
        if let (Some(timers), Some(o)) = (&self.spec.holder_timers, spec.as_object_mut()) {
            o.insert("timers".into(), timers.clone());
        }
        self.effects.push(Effect::SpawnHolder { file, spec, env: self.holder_env.clone() });
        self.log(Level::Info, "holder.spawn", &[("gen", json!(self.generation))]);
    }

    fn connect_holder(&mut self, purpose: Purpose) {
        let deadline = self.now.time.after(self.timer_cfg.holder_connect_ms);
        self.connect = Some(Connecting { purpose, deadline, last_error: String::new() });
        self.effects.push(Effect::ConnectHolder);
    }

    pub(super) fn connect_retry(&mut self) {
        if self.connect.is_some() {
            self.effects.push(Effect::ConnectHolder);
        }
    }

    pub(super) fn holder_connected(&mut self) {
        self.holder = Some(HolderLink::new());
    }

    /// pty.sock could not be reached, or refused this server: again, until the deadline.
    pub(super) fn holder_unreachable(&mut self, why: &str) {
        self.holder = None;
        let Some(c) = self.connect.as_mut() else { return };
        why.clone_into(&mut c.last_error);
        if self.now.time.after(CONNECT_RETRY_MS) <= c.deadline {
            self.set_timer(CONNECT_RETRY_MS, Due::ConnectRetry);
            return;
        }
        let Some(c) = self.connect.take() else { return };
        let error = format!("holder not reachable: {}", c.last_error);
        match c.purpose {
            Purpose::Start { .. } => self.start_failed(&error),
            Purpose::Respawn => self.respawn_failed(&error),
        }
    }

    fn start_failed(&mut self, error: &str) {
        self.starting = false;
        self.started = true;
        self.start_failed = true;
        self.log(Level::Error, "start.failed", &[("error", json!(error))]);
        self.end(false);
    }

    // ---- the holder -------------------------------------------------------------------------------------------------

    pub(super) fn holder_frame(&mut self, frame: &Frame<'_>) {
        let Some(h) = self.holder.as_mut() else { return };
        if h.hello.is_none() {
            match frame {
                Frame::Control(Control::HHello(hello)) if hello.proto == HOLDER_PROTO => {
                    h.hello = Some(hello.clone());
                    let hello = hello.clone();
                    self.hello_arrived(&hello);
                }
                Frame::Control(Control::HHello(_)) => self.refused_by_holder("holder protocol mismatch"),
                Frame::Control(Control::Err(e)) => self.refused_by_holder(&format!("holder refused: {}", e.code)),
                _ => {}
            }
            return;
        }
        match frame {
            Frame::Data(payload) => {
                if let Ok(d) = decode_data(payload)
                    && let Some(mut p) = self.pipeline.take()
                {
                    let chunks = p.process(&mut self.tracker, d.offset, d.bytes, self.now.time);
                    self.pipeline = Some(p);
                    self.chunks(chunks);
                }
            }
            Frame::Control(m) => self.holder_control(m),
            _ => {}
        }
    }

    fn refused_by_holder(&mut self, why: &str) {
        self.effects.push(Effect::CloseHolder);
        self.holder_unreachable(why);
    }

    fn hello_arrived(&mut self, hello: &HHello) {
        let Some(c) = self.connect.take() else { return };
        match c.purpose {
            Purpose::Start { replay } => {
                self.adopt(hello, replay);
                self.starting = false;
                self.started = true;
                self.on_started();
            }
            Purpose::Respawn => {
                self.controller.on_respawned();
                self.attention = false; // a new child has asked for nothing yet
                self.dispatch(MachineEvent::Respawning);
                if let Some(shell) = self.shell.as_mut() {
                    shell.reset(&mut self.emulator);
                }
                if !self.repaint {
                    self.clean_slate();
                } else if let Some(gone) = self.keyboard_gone() {
                    self.chunks(vec![Chunk { edits: vec![gone], ground_after: true, ..Chunk::default() }]);
                }
                self.adopt(hello, false);
            }
        }
    }

    fn holder_control(&mut self, m: &Control) {
        match m {
            Control::Gap { from, to } => {
                let bytes = to.saturating_sub(*from);
                self.lost_bytes += bytes;
                self.log(Level::Warn, "holder.gap", &[("from", json!(from)), ("to", json!(to))]);
                for c in self.clients.values_mut() {
                    c.adapter.skip(bytes, true);
                }
            }
            Control::Consumed { watch_id } => self.controller.on_consumed(*watch_id),
            Control::Lflag(l) => {
                self.fg = l.fg;
                let value = json!({ "icanon": l.icanon, "isig": l.isig, "echo": l.echo, "fgIsChild": l.fg_is_child, "fg": l.fg });
                self.controller.on_lflag(value, self.tracker.alt);
            }
            Control::QueryFwd { id, kind, offset } => {
                self.pending_cpr.push((*id, kind == "DECXCPR", *offset));
                self.answer_cpr();
            }
            Control::Resized(r) => {
                self.tracker.note_resize(r.cols, r.rows, r.offset);
                if let Some(mut p) = self.pipeline.take() {
                    let chunk = p.settle(&mut self.tracker);
                    self.pipeline = Some(p);
                    self.chunks(chunk.into_iter().collect());
                }
                self.pty = Size { cols: r.cols, rows: r.rows };
                self.on_pty();
                self.save_state(false);
            }
            Control::Err(ErrorMessage { code, .. }) => {
                self.log(Level::Warn, "holder.err", &[("code", json!(code))]);
                if code == "WRITE_OVERFLOW" {
                    self.router.on_write_overflow(self.now.time);
                }
                if code == "ESC_HOLD_EXPIRED" {
                    self.router.on_esc_hold_expired();
                }
            }
            Control::Ping { seq } => {
                if let Some(h) = self.holder.as_mut() {
                    h.send(&Control::Pong { seq: *seq });
                }
            }
            Control::Pong { .. } => {
                self.last_pong_at = self.now.time;
                self.unresponsive_notified = false;
            }
            Control::Exit(e) => self.on_exit(e, None),
            _ => {}
        }
    }

    /// pty.sock closed without EXIT: the child's pid is watched until it is gone, and no second child is started beside it.
    pub(super) fn holder_closed(&mut self) {
        let adopted = self.holder.as_ref().is_some_and(|h| h.hello.is_some());
        self.holder = None;
        if !adopted {
            if self.connect.is_some() {
                self.holder_unreachable("holder closed before hello");
            }
            return;
        }
        if self.machine.exited || self.detaching {
            return;
        }
        self.log(Level::Warn, "holder.lost", &[]);
        let child = self.hello.as_ref().map(|h| (h.child.pid, h.child.proc_start.clone()));
        match child {
            Some((pid, start)) if self.probe.alive(pid, start.as_deref()) => {
                let deadline = self.now.time.after(self.timer_cfg.orphan_wait_ms);
                self.orphan = Some(Orphaned { pid, start, deadline });
                self.set_timer(ORPHAN_POLL_MS, Due::Orphan);
            }
            _ => self.lost_exit(),
        }
    }

    pub(super) fn orphan_due(&mut self) {
        let Some(o) = self.orphan.take() else { return };
        if !self.probe.alive(o.pid, o.start.as_deref()) {
            self.lost_exit();
            return;
        }
        if self.now.time < o.deadline {
            self.orphan = Some(o);
            self.set_timer(ORPHAN_POLL_MS, Due::Orphan);
            return;
        }
        self.dispatch(MachineEvent::Orphaned);
        let text = self.messages.orphan_alive(&o.pid.to_string());
        self.notify("warn", "ORPHAN_ALIVE", &text);
        self.effects.push(Effect::Signal { pid: o.pid, start: o.start, sig: "SIGTERM" });
    }

    fn lost_exit(&mut self) {
        let e = WireExit { detected_by: "holder-lost".into(), ..WireExit::default() };
        self.on_exit(&e, Some("holder-lost"));
    }

    /// Adopts a holder: a new server rebuilds the emulator from what the ring holds, with the holder's resize log; a new
    /// child after a restart starts a new stream in the same emulator.
    fn adopt(&mut self, h: &HHello, replay: bool) {
        self.hello = Some(h.clone());
        self.generation = h.generation;
        self.dispatch(MachineEvent::Adopted);
        self.last_pong_at = self.now.time;
        self.unresponsive_notified = false;
        let mut from = 0;
        if self.emulator_ready {
            self.tracker.rebase(h.pty.cols, h.pty.rows);
            if let Some(s) = self.spool.as_mut() {
                s.new_stream(h.generation);
            }
            if !self.repaint {
                // a resize can be lost in the child's last moments
                self.emulator.resize_to(h.pty.cols as usize, h.pty.rows as usize);
            }
        } else {
            if let Some(s) = self.spool.as_mut() {
                if replay {
                    s.resume(h.generation); // what a server before this one wrote is not written twice
                }
                s.stream(h.generation);
            }
            let first = h.resize_log.first().map_or(h.pty, |r| Size { cols: r.cols, rows: r.rows });
            if replay && h.ring.start > 0 && self.repaint {
                // a wrapped ring is not read back
                self.tracker = Tracker::new(h.pty.cols, h.pty.rows);
                self.emulator.init(h.pty.rows as usize, None);
                from = h.ring.end;
                self.history_truncated_before = Some(h.ring.end);
                self.log(
                    Level::Warn,
                    "recover.ring_wrapped",
                    &[("start", json!(h.ring.start)), ("end", json!(h.ring.end))],
                );
            } else {
                from = if replay { h.ring.start } else { 0 };
                let size = h
                    .resize_log
                    .iter()
                    .rev()
                    .find(|r| r.offset <= from)
                    .map_or(first, |r| Size { cols: r.cols, rows: r.rows });
                self.tracker = Tracker::new(size.cols, size.rows);
                for r in h.resize_log.iter().filter(|r| r.offset > from) {
                    self.tracker.note_resize(r.cols, r.rows, r.offset);
                }
                self.emulator.init(size.rows as usize, Some(size.cols as usize));
                if from > 0 {
                    self.history_truncated_before = Some(from);
                    self.log(
                        Level::Warn,
                        "recover.ring_wrapped",
                        &[("start", json!(h.ring.start)), ("end", json!(h.ring.end))],
                    );
                    if let Some(shell) = self.shell.as_mut() {
                        shell.joined_midway();
                    }
                }
            }
            self.emulator_ready = true;
        }
        self.pty = h.pty;
        let notes_erase = self.mark_token.is_some() || self.spool.is_some();
        let pipeline = Pipeline::new(self.repaint, from, self.mark_token.clone(), notes_erase);
        self.pipeline = Some(if self.controller.looks_for_words() { pipeline.keep_text() } else { pipeline });
        self.last_chunk = None;
        let child = json!({ "pid": h.child.pid, "procStart": h.child.proc_start });
        let pty = json!({ "cols": h.pty.cols, "rows": h.pty.rows });
        self.controller.on_holder(h.generation, &child, &pty);
        self.replay_until = if replay { h.ring.end } else { 0 };
        if let Some(shell) = self.shell.as_mut() {
            shell.replay_until = self.replay_until;
        }
        if self.replay_until <= from {
            self.dispatch(MachineEvent::Replayed);
        }
        if let Some(link) = self.holder.as_mut() {
            let flow = link.flow();
            link.send(&Control::Attach { from_offset: from, pid: self.pid, flow });
        }
        self.tell_holder_colors();
        if self.controller.on_attached() {
            self.set_phase("RUNNING", Some(&["STARTING"]));
        }
        self.cancel_holder_ping();
        self.holder_ping = Some(self.set_timer(self.timer_cfg.holder_ping_ms, Due::HolderPing));
        self.save_state(true);
    }

    // ---- the output path ------------------------------------------------------------------------------------------

    /// Chunks of output: into the emulator, the tail kept for terminals coming back, the controller, and every client.
    pub(super) fn chunks(&mut self, chunks: Vec<Chunk>) {
        if chunks.is_empty() {
            return;
        }
        self.last_output_at = self.now.time;
        for chunk in chunks {
            self.feed(&chunk);
            self.last_chunk = Some((chunk.end_offset, chunk.ground_after));
            self.controller.on_chunk(&chunk.text, self.tracker.alt, self.now.time);
            self.render_all(&chunk);
            for r in &chunk.resets {
                self.on_reset(r.offset);
            }
            if self.machine.lifecycle.is("RECOVERING") && chunk.end_offset >= self.replay_until {
                self.dispatch(MachineEvent::Replayed);
                if self.controller.on_replayed() {
                    self.set_phase("RUNNING", Some(&["STARTING"]));
                }
            }
            self.keep_tail(chunk);
        }
        self.answer_cpr();
        let parsed = self.emulator.processed_offset();
        if let Some(h) = self.holder.as_mut().filter(|h| h.flow()) {
            h.send(&Control::Ack { offset: parsed });
        }
    }

    /// One chunk into the emulator, with the history and the shell hearing of what is in it as it happens.
    fn feed(&mut self, chunk: &Chunk) {
        let keeper = self.spool.as_mut().map(|s| s as &mut dyn Keeper);
        match self.shell.as_mut() {
            Some(shell) => {
                shell.now = (self.now.wall_ms, self.now.time);
                self.emulator.feed(chunk, self.now.wall_ms, keeper, shell);
                if shell.cancel_line {
                    shell.cancel_line = false;
                    self.write(b"\x03", false, false);
                }
            }
            None => self.emulator.feed(chunk, self.now.wall_ms, keeper, &mut ()),
        }
    }

    fn keep_tail(&mut self, chunk: Chunk) {
        let Some(until) = self.tail_kept_until else { return };
        if self.now.time > until {
            self.tail_kept_until = None;
            self.tail.clear();
            self.tail_bytes = 0;
            return;
        }
        self.tail_bytes += chunk.bytes.len();
        self.tail.push_back(chunk);
        while self.tail_bytes > TAIL_BYTES {
            let Some(old) = self.tail.pop_front() else { break };
            self.tail_bytes -= old.bytes.len();
        }
    }

    pub(super) fn pipeline_due(&mut self) {
        self.component_timers[0] = None;
        if let Some(mut p) = self.pipeline.take() {
            let chunks = p.on_time(&mut self.tracker, self.now.time);
            self.pipeline = Some(p);
            self.chunks(chunks);
        }
    }

    /// How far a terminal that is here as this server goes has got, or `None` if that cannot be said: offsets mean nothing
    /// in the middle of a sequence, or to a program that repaints.
    pub(super) fn resume_point(&self) -> Option<(u64, u64)> {
        let (end, ground) = self.last_chunk?;
        let quiescent = self.pipeline.as_ref().is_some_and(Pipeline::quiescent);
        (!self.repaint && ground && quiescent).then_some((self.generation, end))
    }

    /// What a terminal coming back from the last server has not seen, or `None` if that cannot be helped.
    pub(super) fn output_since(&self, from: Option<&Value>, cols: u32, rows: u32) -> Option<Vec<Chunk>> {
        let from = from?;
        let n = |k: &str| from.get(k).and_then(Value::as_u64);
        let offset = n("offset").filter(|o| *o < (1 << 53))?;
        if n("gen")? != self.generation || n("cols")? != u64::from(cols) || n("rows")? != u64::from(rows) {
            return None;
        }
        let (end, _) = self.last_chunk?;
        let first = self.tail.front()?;
        if end < offset || first.start_offset > offset {
            return None;
        }
        let missed = self.tail.iter().filter(|c| c.end_offset > offset);
        Some(missed.map(|c| if c.start_offset >= offset { c.clone() } else { c.after(offset) }).collect())
    }

    /// A query only the server can answer arrives before the output it is in: answered once the emulator has got there.
    fn answer_cpr(&mut self) {
        if self.pending_cpr.is_empty() || self.holder.is_none() {
            return;
        }
        let end = self.last_chunk.map_or(0, |c| c.0);
        let (ready, waiting): (Vec<_>, Vec<_>) = self.pending_cpr.drain(..).partition(|q| q.2 <= end);
        self.pending_cpr = waiting;
        let rows = self.tracker.screen_rows as usize;
        for (id, decx, offset) in ready {
            let bytes = self.emulator.cpr(rows, decx, Some(offset));
            if let Some(h) = self.holder.as_mut() {
                h.send(&Control::QueryReply { id, bytes });
            }
        }
    }

    // ---- acting on the child --------------------------------------------------------------------------------------

    /// Writes to the program; with `watch`, the id the holder says it was read with.
    pub(super) fn write(&mut self, bytes: &[u8], lone_esc: bool, watch: bool) -> u32 {
        let closed = self.machine.exited;
        HolderWriter { holder: self.holder.as_mut(), total: &mut self.writes_total, closed }
            .write(bytes, lone_esc, watch)
    }

    /// `SIGCONT` or `SIGTERM` for the child.
    pub(super) fn signal_child(&mut self, sig: &str) {
        if let Some(h) = self.holder.as_mut() {
            h.send(&Control::Signal { sig: sig.to_owned() });
        }
    }

    /// The size the arbiter chose.
    pub(super) fn resize_pty(&mut self, size: Size) {
        if self.machine.exited {
            return;
        }
        if let Some(h) = self.holder.as_mut() {
            h.send(&Control::Resize { cols: size.cols, rows: size.rows, bar: None });
            self.pty = size;
        }
    }

    /// The pty's screen as text.
    pub(super) fn screen_text(&self) -> String {
        self.emulator.screen_text(self.tracker.screen_rows as usize)
    }

    /// Lets go of the holder without touching the child: the holder starts the next server.
    pub(super) fn detach_holder(&mut self) {
        self.detaching = true;
        self.dispose_session();
        self.effects.push(Effect::CloseHolder);
    }

    // ---- exits -----------------------------------------------------------------------------------------------------

    fn on_exit(&mut self, e: &WireExit, detected_by: Option<&str>) {
        if self.machine.exited {
            return;
        }
        self.dispatch(MachineEvent::ExitSeen);
        if let Some(mut p) = self.pipeline.take() {
            let chunk = p.flush(&mut self.tracker, self.now.time);
            self.pipeline = Some(p);
            self.chunks(chunk.into_iter().collect());
        }
        if let Some(spool) = self.spool.as_mut() {
            // nothing will scroll it out now
            let end = self.last_chunk.map_or(0, |c| c.0);
            match self.shell.as_mut() {
                Some(shell) => self.emulator.spool_rest(end, spool, shell),
                None => self.emulator.spool_rest(end, spool, &mut ()),
            }
        }
        self.cancel_holder_ping();
        self.pending_cpr.clear();
        let detected = detected_by.unwrap_or(&e.detected_by);
        let at = if e.at.is_empty() { Self::iso(self.now.wall_ms) } else { e.at.clone() };
        self.log(
            Level::Info,
            "child.exit",
            &[
                ("code", json!(e.code)),
                ("signal", json!(e.signal)),
                ("shuttingDown", json!(e.shutting_down)),
                ("detectedBy", if detected.is_empty() { Value::Null } else { json!(detected) }),
            ],
        );
        self.dispatch(MachineEvent::Exit(Exit {
            code: e.code,
            signal: e.signal.clone(),
            at: at.clone(),
            shutting_down: e.shutting_down,
            claimed_by: None,
            stays: self.controller.stays_after_exit(),
            quiet: !self.controller.announces_exit(),
        }));
        self.controller.on_exited(e.code, e.signal.as_deref(), &at, self.writes_total);
    }

    pub(super) fn respawn_due(&mut self) {
        let Some(mut r) = self.respawn.take() else { return };
        if self.machine.stop_requested || self.disposed {
            return;
        }
        let lock = self.layout.holder_lock(&self.spec.id).ok();
        if r.polls < LOCK_POLLS && lock.is_some_and(|l| self.probe.locked(&l)) {
            // the old holder, and so the old child, is not gone yet
            r.polls += 1;
            self.respawn = Some(r);
            self.set_timer(LOCK_POLL_MS, Due::Respawn);
            return;
        }
        self.generation += 1;
        self.launched_at_ms = Some(self.now.wall_ms);
        self.spawn_holder(&r.argv, self.pty);
        self.connect_holder(super::session::Purpose::Respawn);
    }

    fn respawn_failed(&mut self, error: &str) {
        self.log(Level::Error, "restart.failed", &[("error", json!(error))]);
        self.dispatch(MachineEvent::RespawnFailed);
        let text = self.messages.respawn_failed(&self.current_name.clone());
        self.notify("warn", "RESTART_FAILED", &text);
    }

    /// Starts `argv` in a new holder, the old one gone first. Clients stay attached.
    pub(super) fn respawn_with(&mut self, argv: Vec<String>) {
        if self.machine.stop_requested || self.disposed {
            return;
        }
        self.respawn = Some(Respawning { argv, polls: 0 });
        self.respawn_due();
    }

    /// A new program starts on a line of its own, with nothing the last one left set. Everyone sees this, so the emulator
    /// does too.
    fn clean_slate(&mut self) {
        let leave_alt: &[u8] = if self.tracker.alt { b"\x1b[?1049l" } else { b"" };
        let mut bytes = leave_alt.to_vec();
        bytes.extend_from_slice(CLEAN_MODES.as_bytes());
        if self.emulator.normal().cursor_x() > 0 {
            bytes.extend_from_slice(b"\r\n");
        }
        let mut edits: Vec<Edit> = self.keyboard_gone().into_iter().collect();
        if !leave_alt.is_empty() {
            edits.push(Edit { kind: EditKind::AltExit, start: 0, end: leave_alt.len() });
        }
        let wipes = !leave_alt.is_empty();
        let chunk = Chunk { bytes, edits, ground_after: true, wipes, ..Chunk::default() };
        self.chunks(vec![chunk]);
    }

    /// The last program's kitty keyboard flags, which a terminal that was told them is told are gone.
    fn keyboard_gone(&self) -> Option<Edit> {
        (self.tracker.modes.keyboard() != 0).then_some(Edit { kind: EditKind::Keyboard(0), start: 0, end: 0 })
    }

    /// A new child running the same command; clients stay attached.
    pub(super) fn restart(&mut self) {
        if self.holder.is_none() || self.machine.exited || self.machine.stop_requested {
            return;
        }
        if let Some(shell) = self.shell.as_mut() {
            shell.reset(&mut self.emulator); // nothing that shell says from here on is about the session
        }
        self.dispatch(MachineEvent::RestartRequested);
        if let Some(h) = self.holder.as_mut() {
            h.send(&Control::CloseMaster); // EIO and SIGHUP
        }
        let mut old = self.restart_term.take();
        self.cancel(&mut old);
        self.restart_term = Some(self.set_timer(self.config.stop.hangup_wait_ms, Due::RestartTerm));
    }

    pub(super) fn restart_term_due(&mut self) {
        self.restart_term = None;
        if self.holder.is_some() && !self.machine.exited && self.machine.restart_requested {
            self.signal_child("SIGTERM");
        }
    }

    // ---- the holder's health ---------------------------------------------------------------------------------------

    fn cancel_holder_ping(&mut self) {
        let mut t = self.holder_ping.take();
        self.cancel(&mut t);
    }

    pub(super) fn ping_holder(&mut self) {
        self.holder_ping = None;
        if self.holder.is_none() || self.machine.exited || self.disposed {
            return;
        }
        let seq = self.now.time.ms();
        if let Some(h) = self.holder.as_mut() {
            h.send(&Control::Ping { seq });
        }
        if self.now.time.since(self.last_pong_at) > self.timer_cfg.holder_unresponsive_ms && !self.unresponsive_notified
        {
            self.unresponsive_notified = true;
            self.log(Level::Warn, "holder.unresponsive", &[]);
            self.notify("warn", "HOLDER_UNRESPONSIVE", "the PTY holder is not answering; output may be delayed");
        }
        self.holder_ping = Some(self.set_timer(self.timer_cfg.holder_ping_ms, Due::HolderPing));
    }

    // ---- the lifecycle ---------------------------------------------------------------------------------------------

    /// The one place a lifecycle changes.
    pub(super) fn dispatch(&mut self, event: MachineEvent) {
        let from = self.machine.lifecycle.clone();
        let (state, effects) = reduce(self.machine.clone(), event);
        self.machine = state;
        if self.machine.lifecycle != from {
            let to = self.machine.lifecycle.as_str().to_owned();
            self.log(Level::Info, "lifecycle", &[("from", json!(from.as_str())), ("to", json!(to))]);
            self.lifecycle_since = self.now.wall_ms;
            self.on_lifecycle(&to);
            self.save_state(true);
        }
        for effect in effects {
            match effect {
                MachineEffect::Release => {
                    if let Some(h) = self.holder.as_mut() {
                        h.send(&Control::Release);
                    }
                }
                MachineEffect::Stopped => self.mark_stopped(),
                MachineEffect::ClientExit(client) => self.client_exit(&client),
                MachineEffect::RespawnLater => {
                    let argv = self.controller.respawn_argv(&self.spec.child.argv);
                    self.respawn = Some(Respawning { argv, polls: 0 });
                    self.set_timer(0, Due::Respawn);
                }
                MachineEffect::ExitNotice(how) => {
                    let (code, text) = self.messages.child_exited(&self.current_name.clone(), &how);
                    self.notify("warn", &code, &text);
                }
            }
        }
    }

    /// Moves to a controller's phase, from any of `from` when given.
    pub(super) fn set_phase(&mut self, to: &str, from: Option<&[&str]>) {
        let from = from.map(|f| f.iter().map(|s| (*s).to_owned()).collect());
        self.dispatch(MachineEvent::Phase { to: to.to_owned(), from });
    }

    /// Every gate that applies, most important first.
    pub(super) fn gates(&self) -> Vec<String> {
        let lc = &self.machine.lifecycle;
        let mut g = Vec::new();
        if ["STOPPING", "STOPPED", "STOP_STUCK"].iter().any(|s| lc.is(s)) {
            g.push("STOPPING".to_owned());
        }
        if lc.is("EXITED") || lc.is("RECOVERING") || self.holder.is_none() || self.machine.exited {
            g.push("EXITED".to_owned());
        }
        g.extend(self.controller.gates());
        g
    }

    pub(super) fn gate_name(&self) -> String {
        self.gates().into_iter().next().unwrap_or_else(|| "OPEN".to_owned())
    }

    pub(super) fn blocking_gates(&self) -> Vec<String> {
        let mut g = vec!["STOPPING".to_owned(), "EXITED".to_owned()];
        g.extend(self.controller.blocking_gates());
        g
    }

    /// The session's name now.
    pub(super) fn name(&self) -> String {
        self.current_name.clone()
    }

    // ---- what terminals that come back are given ---------------------------------------------------------------

    /// How far a terminal that leaves now has got. It has everything down to the cursor, but those rows can still change
    /// while it is away, so they are kept to compare with when it comes back. A program that repaints draws its screen
    /// again, so there it only has what is above.
    pub(super) fn bookmark(&mut self) -> Bookmark {
        let top = self.emulator.screen_top(self.tracker.screen_rows as usize);
        let cursor = if self.repaint { top } else { self.emulator.cursor_row() };
        let seq = self.shell.as_ref().map_or(0, |s| s.current().map_or(s.seq(), |c| c.seq.saturating_sub(1)));
        let shown =
            if self.repaint { Vec::new() } else { self.emulator.lines_between(top, cursor + 1).unwrap_or_default() };
        Bookmark { top: self.emulator.pin(top), cursor: self.emulator.pin(cursor), shown, seq }
    }

    /// The first row a terminal that came back needs. Rows above the screen it left cannot have changed. Those on it can,
    /// so unless they still say the same, it gets them again.
    pub(super) fn row_after(&self, b: &Bookmark) -> Option<u64> {
        let top = self.emulator.pin_row(b.top);
        if self.repaint {
            return top;
        }
        let (Some(top_row), Some(cursor)) = (top, self.emulator.pin_row(b.cursor)) else { return top };
        if same_as_shown(&b.shown, self.emulator.lines_between(top_row, cursor + 1)) { Some(cursor) } else { top }
    }

    /// What happened while a terminal was away, in a line.
    pub(super) fn away_since(&self, b: &Bookmark, lines: u64) -> Option<String> {
        let shell = self.shell.as_ref();
        let finished: Vec<Finished> = shell.map_or_else(Vec::new, |s| {
            s.records
                .iter()
                .filter(|r| r.seq > b.seq && r.end.is_some())
                .map(|r| Finished {
                    command: r.command.clone(),
                    exit: r.exit,
                    duration_ms: r.started_at.zip(r.finished_at).map(|(a, z)| u64::try_from(z - a).unwrap_or(0)),
                })
                .collect()
        });
        let running = shell.and_then(|s| s.current()).map(|c| c.command.as_deref());
        away_text(&finished, running, lines)
    }

    // ---- the record ------------------------------------------------------------------------------------------------

    /// The session as STATUS reports it.
    pub(super) fn status(&self) -> Map<String, Value> {
        let m = &self.machine;
        let host = json!({
            "name": self.name(), "lifecycle": m.lifecycle, "blockedCode": m.blocked_code, "gate": self.gate_name(),
            "gates": self.gates(), "child": { "pid": self.hello.as_ref().map(|h| h.child.pid) },
            "pty": { "cols": self.pty.cols, "rows": self.pty.rows }, "alt": self.tracker.alt, "lastExit": m.last_exit,
            "restarts": { "attributed": m.attributed }, "census": self.tracker.census,
            "historyTruncatedBefore": self.history_truncated_before, "lostBytes": self.lost_bytes,
            "parsedBytes": self.emulator.processed_offset(), "idleMs": self.now.time.since(self.last_output_at),
            "foregroundPid": self.fg, "shell": self.shell.as_ref().map(crate::session::shell::ShellTracker::status),
        });
        let Value::Object(host) = host else { return Map::new() };
        self.controller.status(host)
    }

    /// The record on disk, merged into whatever the file has.
    fn record(&mut self) -> Map<String, Value> {
        let (boot, hostname, machine) = self.probe.host();
        let h = self.hello.as_ref();
        let doc = json!({
            "schema": "nmux.state/1", "id": self.spec.id, "bootId": boot, "host": { "hostname": hostname, "machineId": machine },
            "writer": { "pid": self.pid, "procStart": self.probe.proc_start(self.pid) },
            "lifecycle": self.machine.lifecycle, "lifecycleSince": Self::iso(self.lifecycle_since),
            "blockedCode": self.machine.blocked_code, "gate": self.gate_name(),
            "holder": h.map(|h| json!({ "pid": h.pid, "procStart": h.proc_start, "gen": h.generation, "proto": h.proto })),
            "child": h.map(|h| json!({ "pid": h.child.pid, "procStart": h.child.proc_start })),
            "launchedAtMs": self.launched_at_ms, "pty": { "cols": self.pty.cols, "rows": self.pty.rows },
            "clients": self.client_info(), "restarts": { "attributed": self.machine.attributed, "lastExit": self.machine.last_exit },
            "census": self.tracker.census, "historyTruncatedBefore": self.history_truncated_before,
            "updatedAt": Self::iso(self.now.wall_ms),
        });
        let Value::Object(doc) = doc else { return Map::new() };
        self.controller.persisted(doc)
    }

    /// Writes the record: at once, or after the changes that come together have come.
    pub(super) fn save_state(&mut self, immediate: bool) {
        if self.spec.state_file.is_none() || self.disposed {
            return;
        }
        if !immediate {
            if self.state_timer.is_none() {
                self.state_timer = Some(self.set_timer(self.timer_cfg.state_debounce_ms, Due::StateSave));
            }
            return;
        }
        let mut t = self.state_timer.take();
        self.cancel(&mut t);
        let record = self.record();
        self.effects.push(Effect::WriteState(record));
    }

    /// Lets go of the session's timers and writes its record a last time.
    pub(super) fn dispose_session(&mut self) {
        if self.disposed {
            return;
        }
        self.save_state(true);
        self.disposed = true;
        let mut t = self.state_timer.take();
        self.cancel(&mut t);
    }

    // ---- the agent link ----------------------------------------------------------------------------------------

    /// A terminal with an ssh agent arrived: the link points at its agent.
    pub(super) fn agent_arrived(&mut self, id: &str, target: Option<&str>) {
        let Some(link) = self.spec.agent.clone() else { return };
        let Some(target) = target.filter(|t| t.starts_with('/') && t.len() <= 1024 && *t != link) else { return };
        self.agent_lenders.push((id.to_owned(), target.to_owned()));
        self.effects.push(Effect::PointAgent(target.to_owned()));
    }

    /// A terminal attached with its default colours. A program that asks for them (OSC 10 and 11) is answered with these
    /// from now on, as a program started in that terminal would be, and so is one started by a new holder. What a terminal
    /// did not say is kept from before. Only colours in the one form the holder writes into a pty count.
    pub(super) fn colors_arrived(&mut self, colors: Option<&Colors>) {
        let valid = |v: &Option<String>| v.clone().filter(|v| valid_color(v));
        let Some((fg, bg)) =
            colors.map(|c| (valid(&c.fg), valid(&c.bg))).filter(|(fg, bg)| fg.is_some() || bg.is_some())
        else {
            return;
        };
        let mut now = self.attached_colors.clone().or_else(|| self.spec.term_colors.clone()).unwrap_or_default();
        now.fg = fg.or(now.fg);
        now.bg = bg.or(now.bg);
        self.spec.term_colors = Some(now.clone());
        self.attached_colors = Some(now);
        self.tell_holder_colors();
    }

    /// The holder is told the colours of the terminals that attached, if it takes them and has not been told these. A
    /// holder this server only adopted keeps what it has until a terminal attaches.
    fn tell_holder_colors(&mut self) {
        let Some(colors) = self.attached_colors.as_ref() else { return };
        if let Some(h) = self.holder.as_mut().filter(|h| h.takes_colors() && h.colors.as_ref() != Some(colors)) {
            h.send(&Control::Colors(colors.clone()));
            h.colors = Some(colors.clone());
        }
    }

    /// A terminal left: the one before it takes over, if it was the newest.
    pub(super) fn agent_left(&mut self, id: &str) {
        if self.spec.agent.is_none() {
            return;
        }
        let newest = self.agent_lenders.last().map(|l| l.0.clone());
        self.agent_lenders.retain(|l| l.0 != id);
        if newest.as_deref() == Some(id)
            && let Some((_, target)) = self.agent_lenders.last()
        {
            self.effects.push(Effect::PointAgent(target.clone()));
        }
    }
}
