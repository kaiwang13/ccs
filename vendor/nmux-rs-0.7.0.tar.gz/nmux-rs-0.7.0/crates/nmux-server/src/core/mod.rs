//! A session's server as one state machine, `main.js`, `session.js`, `hub.js`, `join.js` and `control.js` of the Node
//! code: [`Server::on_event`] takes what happened and the time, and leaves what the run loop is to do in
//! [`Server::effects`]. It owns what is queued for every connection, which the run loop writes out.
//!
//! What was a promise in Node is a state here: a join waiting for the pty to shrink, a stop waiting for the child, a
//! request waiting for the disk. Each is moved on when what it waits for happens, or when its time is up.

mod ambient;
mod control;
mod hub;
mod join;
mod session;
mod stop;

use std::collections::{BTreeMap, VecDeque};
use std::path::PathBuf;

use nmux_history::write::Spool;
use nmux_holder::{Level, Log};
use nmux_io::{Now, OutBuf, Time, TimerId, Timers};
use nmux_wire::{Colors, Frame, HHello, Layout, Size};
use serde_json::{Map, Value};

use crate::clients::arbiter::Arbiter;
use crate::config::Config;
use crate::input::router::Router;
use crate::messages::Messages;
use crate::output::{Chunk, Emulator, Pin, Pipeline, Titles, Tracker};
use crate::session::controller::Controller;
use crate::session::machine::State;
use crate::session::shell::ShellTracker;
use crate::spec::{Spec, Timers as SpecTimers};

pub use control::ControlConn;
pub use hub::Client;

/// A connection on ctl.sock, as the run loop numbers them.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct ConnId(pub u64);

/// What happened, for [`Server::on_event`].
#[derive(Debug)]
pub enum Event<'a> {
    /// The lock is taken and ctl.sock listens: the session starts.
    Started,
    /// A connection came on ctl.sock.
    Accepted(ConnId),
    /// A frame came on one.
    Frame(ConnId, Frame<'a>),
    /// One closed.
    Closed(ConnId),
    /// Everything queued on one has been written.
    Drained(ConnId),
    /// The connection to pty.sock is made.
    HolderConnected,
    /// It could not be made.
    HolderUnreachable(String),
    /// A frame came from the holder.
    HolderFrame(Frame<'a>),
    /// The holder's connection closed.
    HolderClosed,
    /// The kept history has answers.
    History,
    /// SIGTERM: the server goes, and the session goes on under the next one.
    Term,
    /// Time passed: what is due is done.
    Tick,
}

/// What the run loop is asked to do, in order.
#[derive(Clone, Debug, PartialEq)]
pub enum Effect {
    /// Connect to the holder's pty.sock.
    ConnectHolder,
    /// End the connection to the holder once what is queued is written.
    CloseHolder,
    /// End a connection once what is queued is written, or at once.
    Close {
        /// Which.
        conn: ConnId,
        /// Without writing what is queued.
        now: bool,
    },
    /// Write a holder's spec to `file` and start a holder with it, with `env` added to the environment.
    SpawnHolder {
        /// Where the spec goes.
        file: PathBuf,
        /// The spec.
        spec: Value,
        /// More environment.
        env: BTreeMap<String, String>,
    },
    /// Start a program, detached: a managed session's controller.
    Spawn {
        /// Its command line.
        argv: Vec<String>,
        /// More environment.
        env: BTreeMap<String, String>,
    },
    /// Send a signal, if the process is still the one that started at `start`.
    Signal {
        /// Its pid.
        pid: u32,
        /// When it started; `None` sends it whatever it is.
        start: Option<String>,
        /// `SIGCONT` or `SIGTERM`.
        sig: &'static str,
    },
    /// Merge this into the session's record and write it.
    WriteState(Map<String, Value>),
    /// Point the session's agent link at this.
    PointAgent(String),
    /// The server is done. `leaving`: the session goes on under the next server.
    Exit {
        /// See above.
        leaving: bool,
    },
}

/// Questions about the system that are answered at once, so that the core can ask them and stay testable.
pub trait Probe: std::fmt::Debug {
    /// Whether a process is still the one that started at `start`.
    fn alive(&self, pid: u32, start: Option<&str>) -> bool;
    /// When a process started.
    fn proc_start(&self, pid: u32) -> Option<String>;
    /// Whether a lock file is held.
    fn locked(&self, path: &std::path::Path) -> bool;
    /// One variable of a process's environment, where it can be read.
    fn environ(&self, pid: u32, key: &str) -> Option<String>;
    /// What the record says about the machine: the boot id, the host name, the machine id.
    fn host(&self) -> (Option<String>, String, Option<String>);
}

/// What a timer is for.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Due {
    /// The pipeline has something to let go of.
    Pipeline,
    /// The input router.
    Router,
    /// The size arbiter.
    Arbiter,
    /// The shell tracker.
    Shell,
    /// Try pty.sock again.
    ConnectRetry,
    /// Ping the holder.
    HolderPing,
    /// Write the record.
    StateSave,
    /// Ping a client.
    ClientPing(ConnId),
    /// A notice has been in a client's title long enough.
    NoticeEnd(ConnId),
    /// A connection did not say hello in time.
    HelloTimeout(ConnId),
    /// A join or redraw waited long enough for something.
    Join(ConnId),
    /// A join's snapshot took too long.
    SnapshotTimeout(ConnId),
    /// A step of the stop.
    Stop,
    /// A restart's hang-up was not enough.
    RestartTerm,
    /// Start the next child.
    Respawn,
    /// Look whether a child that outlived its holder is gone.
    Orphan,
    /// Look whether a bar or a day line should be drawn.
    Ambient,
    /// Draw the bars output may have written over.
    Bar,
    /// Look whether a managed session's controller is there.
    ControllerWatch,
    /// Ping a managed session's controller.
    ControllerPing(ConnId),
    /// Look whether a queued RUN can go.
    RunQueue,
    /// The first terminal did not come.
    FirstClient,
    /// A step of what happens once the session has stopped.
    Ending,
    /// A request waiting for the disk has waited long enough.
    Request(u64),
}

/// Where a terminal that left had got: the screen's top row, the cursor's, what it showed, and the last command it saw.
#[derive(Clone, Debug)]
pub struct Bookmark {
    top: Pin,
    cursor: Pin,
    shown: Vec<String>,
    seq: u64,
}

/// See the module.
#[derive(Debug)]
#[allow(clippy::struct_excessive_bools)] // the session's flags, as Node keeps them
pub struct Server {
    // ---- what it was started with ----
    spec: Spec,
    config: Config,
    messages: Messages,
    titles: Titles,
    timer_cfg: SpecTimers,
    layout: Layout,
    pid: u32,
    recover: bool,
    wait_for_client: bool,
    probe: Box<dyn Probe>,
    /// The command a holder restarts this server with.
    restart_argv: Vec<String>,
    holder_env: BTreeMap<String, String>,
    // ---- the session ----
    machine: State,
    lifecycle_since: i64,
    holder: Option<session::HolderLink>,
    hello: Option<HHello>,
    connect: Option<session::Connecting>,
    generation: u64,
    repaint: bool,
    emulator: Emulator,
    emulator_ready: bool,
    tracker: Tracker,
    pipeline: Option<Pipeline>,
    last_chunk: Option<(u64, bool)>,
    tail: VecDeque<Chunk>,
    tail_bytes: usize,
    tail_kept_until: Option<Time>,
    pty: Size,
    writes_total: u64,
    launched_at_ms: Option<i64>,
    current_name: String,
    attention: bool,
    history_truncated_before: Option<u64>,
    replay_until: u64,
    detaching: bool,
    lost_bytes: u64,
    fg: Option<i64>,
    last_output_at: Time,
    pending_cpr: Vec<(u32, bool, u64)>,
    last_pong_at: Time,
    unresponsive_notified: bool,
    disposed: bool,
    starting: bool,
    started: bool,
    start_failed: bool,
    shell: Option<ShellTracker>,
    mark_token: Option<String>,
    spool: Option<Spool>,
    controller: Controller,
    agent_lenders: Vec<(String, String)>,
    /// The colours of the terminals that attached, the last one's over those before: see `colors_arrived`.
    attached_colors: Option<Colors>,
    stop: stop::Stopping,
    respawn: Option<session::Respawning>,
    orphan: Option<session::Orphaned>,
    restart_term: Option<TimerId>,
    ending: Option<stop::Ending>,
    // ---- clients ----
    clients: BTreeMap<ConnId, Client>,
    controls: BTreeMap<ConnId, ControlConn>,
    greeting: BTreeMap<ConnId, (OutBuf, TimerId)>,
    /// What is still to be written to connections being closed.
    closing: BTreeMap<ConnId, OutBuf>,
    client_seq: u64,
    departures: VecDeque<(String, Bookmark)>,
    router: Router,
    arbiter: Arbiter,
    ambient: ambient::Ambient,
    // ---- control ----
    runs: u64,
    run_queue: VecDeque<control::QueuedRun>,
    run_queue_timer: Option<TimerId>,
    requests: BTreeMap<u64, control::Waiting>,
    request_seq: u64,
    controller_watch_ms: u64,
    // ---- the process ----
    timers: Timers<Due>,
    component_timers: [Option<(TimerId, Time)>; 4],
    state_timer: Option<TimerId>,
    holder_ping: Option<TimerId>,
    /// What the run loop is to do, in order.
    pub effects: Vec<Effect>,
    /// What is to be logged, in order.
    pub logs: Vec<Log>,
    now: Now,
}

/// How a server is made.
#[derive(Debug)]
pub struct Options {
    /// The session's spec.
    pub spec: Spec,
    /// Adopt the holder that is running, rather than start one.
    pub recover: bool,
    /// A terminal is about to attach: the program starts when it arrives.
    pub wait_for_client: bool,
    /// The record a server before this one left.
    pub initial_state: Option<Value>,
    /// This process's pid.
    pub pid: u32,
    /// The command a holder starts this server again with, without `--recover`.
    pub server_argv: Vec<String>,
    /// See [`Probe`].
    pub probe: Box<dyn Probe>,
    /// The kept history, already open.
    pub spool: Option<Spool>,
    /// The configuration.
    pub config: Config,
    /// The time it starts.
    pub now: Now,
}

impl Server {
    /// A server for a session; nothing happens until [`Event::Started`].
    #[allow(clippy::too_many_lines)] // every field of the session, once
    pub fn new(o: Options) -> Self {
        let spec = o.spec;
        let config = o.config;
        let messages = Messages::from_table(spec.messages.as_ref());
        let titles = Titles {
            brand: messages.brand(),
            attention: messages.attention_title(),
            bell_on_attention: config.notices.bell_on_attention,
        };
        let repaint = config.stream.repaint;
        let pty = spec.pty;
        let scrollback = config.snapshot.scrollback;
        let emulator = if repaint {
            Emulator::new(None, scrollback)
        } else {
            Emulator::new(Some((pty.cols as usize, pty.rows as usize)), scrollback)
        };
        let mark_token = spec.shell.as_ref().filter(|_| !repaint).map(|s| s.token.clone());
        let launched_at_ms = o.initial_state.as_ref().and_then(|s| s.get("launchedAtMs")).and_then(Value::as_i64);
        let layout = Layout::new(&spec.runtime_dir);
        let timer_cfg = spec.timers();
        let mut server = Self {
            controller: Controller::new(spec.managed.clone()),
            shell: mark_token.as_ref().map(|_| ShellTracker::new()),
            current_name: spec.name.clone(),
            holder_env: spec.holder_env.clone(),
            router: Router::new(config.input.clone()),
            arbiter: Arbiter::new(config.size.clone()),
            ambient: ambient::Ambient::new(&config.overlay),
            spec,
            messages,
            titles,
            timer_cfg,
            layout,
            pid: o.pid,
            recover: o.recover,
            wait_for_client: o.wait_for_client,
            probe: o.probe,
            restart_argv: o.server_argv,
            machine: State::new(o.recover),
            lifecycle_since: o.now.wall_ms,
            holder: None,
            hello: None,
            connect: None,
            generation: 0,
            repaint,
            emulator,
            emulator_ready: false,
            tracker: Tracker::new(pty.cols, pty.rows),
            pipeline: None,
            last_chunk: None,
            tail: VecDeque::new(),
            tail_bytes: 0,
            tail_kept_until: (o.recover && !repaint).then(|| o.now.time.after(session::TAIL_KEEP_MS)),
            pty,
            writes_total: 0,
            launched_at_ms,
            attention: false,
            history_truncated_before: None,
            replay_until: 0,
            detaching: false,
            lost_bytes: 0,
            fg: None,
            last_output_at: o.now.time,
            pending_cpr: Vec::new(),
            last_pong_at: o.now.time,
            unresponsive_notified: false,
            disposed: false,
            starting: false,
            started: false,
            start_failed: false,
            mark_token,
            spool: o.spool,
            agent_lenders: Vec::new(),
            attached_colors: None,
            stop: stop::Stopping::default(),
            respawn: None,
            orphan: None,
            restart_term: None,
            ending: None,
            clients: BTreeMap::new(),
            controls: BTreeMap::new(),
            greeting: BTreeMap::new(),
            closing: BTreeMap::new(),
            client_seq: 0,
            departures: VecDeque::new(),
            runs: 0,
            run_queue: VecDeque::new(),
            run_queue_timer: None,
            requests: BTreeMap::new(),
            request_seq: 0,
            controller_watch_ms: control::CONTROLLER_WAIT_MS,
            timers: Timers::new(),
            component_timers: [None; 4],
            state_timer: None,
            holder_ping: None,
            effects: Vec::new(),
            logs: Vec::new(),
            now: o.now,
            config,
        };
        if server.spool.is_some() {
            server.emulator.keep_rows();
        }
        server
    }

    /// The session's id.
    pub fn id(&self) -> &str {
        &self.spec.id
    }

    /// Whether the session started, or would have had nothing gone wrong starting it.
    pub fn started_ok(&self) -> bool {
        !self.start_failed
    }

    /// How the child last ended, as the record says it.
    pub fn last_exit(&self) -> Option<Value> {
        serde_json::to_value(&self.machine.last_exit).ok()
    }

    /// When the next timer is due.
    pub fn next_due(&mut self) -> Option<Time> {
        self.timers.next_due()
    }

    /// What is queued for a connection, client or control, or one that has not said hello.
    pub fn out(&mut self, conn: ConnId) -> Option<&mut OutBuf> {
        if let Some(c) = self.clients.get_mut(&conn) {
            return Some(&mut c.adapter.out);
        }
        if let Some(c) = self.controls.get_mut(&conn) {
            return Some(&mut c.out);
        }
        if let Some((out, _)) = self.greeting.get_mut(&conn) {
            return Some(out);
        }
        self.closing.get_mut(&conn)
    }

    /// The connections with something queued.
    pub fn writable(&self) -> Vec<ConnId> {
        let clients = self.clients.iter().filter(|(_, c)| !c.adapter.out.is_empty()).map(|(k, _)| *k);
        let controls = self.controls.iter().filter(|(_, c)| !c.out.is_empty()).map(|(k, _)| *k);
        let greeting = self.greeting.iter().filter(|(_, (o, _))| !o.is_empty()).map(|(k, _)| *k);
        let closing = self.closing.iter().filter(|(_, o)| !o.is_empty()).map(|(k, _)| *k);
        clients.chain(controls).chain(greeting).chain(closing).collect()
    }

    /// What is queued for the holder.
    pub fn holder_out(&mut self) -> Option<&mut OutBuf> {
        self.holder.as_mut().map(|h| &mut h.out)
    }

    /// Takes in what happened at `now`.
    pub fn on_event(&mut self, event: Event<'_>, now: Now) {
        self.now = now;
        match event {
            Event::Started => self.begin(),
            Event::Accepted(conn) => self.accepted(conn),
            Event::Frame(conn, frame) => self.frame(conn, &frame),
            Event::Closed(conn) => self.closed(conn),
            Event::Drained(conn) => self.drained(conn),
            Event::HolderConnected => self.holder_connected(),
            Event::HolderUnreachable(why) => self.holder_unreachable(&why),
            Event::HolderFrame(frame) => self.holder_frame(&frame),
            Event::HolderClosed => self.holder_closed(),
            Event::History => self.history_answers(),
            Event::Term => self.terminate(),
            Event::Tick => self.tick(),
        }
        self.settle();
    }

    fn tick(&mut self) {
        while let Some((_, due)) = self.timers.pop_due(self.now.time) {
            self.fire(due);
        }
    }

    fn fire(&mut self, due: Due) {
        match due {
            Due::Pipeline => self.pipeline_due(),
            Due::Router => self.router_due(),
            Due::Arbiter => self.arbiter_due(),
            Due::Shell => self.shell_due(),
            Due::ConnectRetry => self.connect_retry(),
            Due::HolderPing => self.ping_holder(),
            Due::StateSave => {
                self.state_timer = None;
                self.save_state(true);
            }
            Due::ClientPing(conn) => self.heartbeat(conn),
            Due::NoticeEnd(conn) => self.notice_end(conn),
            Due::HelloTimeout(conn) => self.hello_timeout(conn),
            Due::Join(conn) => self.advance_join(conn),
            Due::SnapshotTimeout(conn) => self.snapshot_timeout(conn),
            Due::Stop => self.stop_due(),
            Due::RestartTerm => self.restart_term_due(),
            Due::Respawn => self.respawn_due(),
            Due::Orphan => self.orphan_due(),
            Due::Ambient => self.ambient_tick(),
            Due::Bar => self.bar_due(),
            Due::ControllerWatch => self.controller_watch(),
            Due::ControllerPing(conn) => self.controller_beat(conn),
            Due::RunQueue => self.run_queue_due(),
            Due::FirstClient => self.first_client_due(),
            Due::Ending => self.ending_due(),
            Due::Request(n) => self.request_due(n),
        }
    }

    /// After every event: what a component left for the session is taken, and every component's next deadline armed.
    fn settle(&mut self) {
        for _ in 0..8 {
            if !self.take_component_work() {
                break;
            }
        }
        let deadlines = [
            self.pipeline.as_ref().and_then(Pipeline::deadline),
            self.router.deadline(),
            self.arbiter.deadline(),
            self.shell.as_ref().and_then(ShellTracker::deadline),
        ];
        let keys = [Due::Pipeline, Due::Router, Due::Arbiter, Due::Shell];
        for (i, (due, key)) in deadlines.into_iter().zip(keys).enumerate() {
            let slot = &mut self.component_timers[i];
            if slot.map(|(_, at)| at) == due {
                continue;
            }
            if let Some((id, _)) = slot.take() {
                self.timers.cancel(id);
            }
            if let Some(at) = due {
                *slot = Some((self.timers.set_at(at, key), at));
            }
        }
    }

    /// Takes what the router, the shell, the controller and the clients left to be done. True when there was any.
    fn take_component_work(&mut self) -> bool {
        let mut any = self.take_router_events();
        any |= self.take_shell_events();
        any |= self.take_controller_events();
        any |= self.take_client_work();
        any
    }

    /// A timer `ms` from now.
    fn set_timer(&mut self, ms: u64, due: Due) -> TimerId {
        self.timers.set(self.now.time, ms, due)
    }

    fn cancel(&mut self, timer: &mut Option<TimerId>) {
        if let Some(id) = timer.take() {
            self.timers.cancel(id);
        }
    }

    fn log(&mut self, level: Level, ev: &'static str, fields: &[(&str, Value)]) {
        let mut log = Log::new(level, ev);
        for (k, v) in fields {
            log = log.with(k, v.clone());
        }
        self.logs.push(log);
    }

    /// An ISO 8601 time, as Node's `toISOString` writes it.
    fn iso(ms: i64) -> String {
        nmux_platform::iso_utc(ms)
    }
}
