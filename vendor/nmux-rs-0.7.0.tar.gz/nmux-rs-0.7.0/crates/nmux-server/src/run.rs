//! The server's run loop, `run.js` and the process half of `main.js`: everything [`Server`] does not do itself. It takes the
//! session's lock, opens the history, listens on ctl.sock, and then waits on the reactor, hands the core what happened and
//! does what it asks: the sockets, the holder's connection, starting holders and controllers, signals, the record on disk,
//! and the log. `nmux __server --spec FILE [--recover] [--wait-for-client]`: the holder starts exactly this command again
//! when the server dies, which is why everything it needs is in the spec file.

use std::collections::BTreeMap;
use std::error::Error;
use std::ffi::OsString;
use std::fs::{self, DirBuilder, OpenOptions};
use std::io::Write as _;
use std::os::unix::fs::{DirBuilderExt, OpenOptionsExt};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::{Duration, Instant};

use nmux_history::write::{self, Meta, Spool};
use nmux_holder::{Level as LogLevel, Log, Logger};
use nmux_io::{Conn, Listener, Reactor, ReadEnd, Token, UnixStream, Waker};
use nmux_platform::{
    OOM_SCORE_ADJ_PATH, ProcState, Signal, boot_id, hostname, is_locked, is_same_process, iso_utc, kill, machine_id,
    proc_start, proc_state, read_environ, reap, spawn_detached_with, try_lock,
};
use nmux_wire::Layout;
use serde_json::{Map, Value};

use crate::config::Config;
use crate::core::{ConnId, Effect, Event, Options, Probe, Server};
use crate::spec::Spec;

const LISTENER: Token = Token(0);
const HOLDER: Token = Token(1);
const WAKER: Token = Token(2);
const FIRST_CONN: usize = 3;
/// How long a server taking over waits for the one before it to let go: that one finishes its history first.
const TAKEOVER_WAIT_MS: u64 = 15_000;
const LOCK_POLL_MS: u64 = 25;
/// Nothing in /tmp is safe from an age-based cleaner unless it keeps looking used.
const TOUCH_MS: u64 = 3_600_000;
/// How long a server that is done keeps writing what it queued.
const LAST_FLUSH_MS: u64 = 100;

/// `nmux __server …`: runs a session's server and returns its exit code.
pub fn main(args: &[OsString]) -> i32 {
    let spec = args.iter().position(|a| a == "--spec").and_then(|i| args.get(i + 1)).filter(|a| !a.is_empty());
    let Some(spec) = spec else {
        eprintln!("usage: nmux __server --spec <session.json> [--recover] [--wait-for-client]");
        return 2;
    };
    let recover = args.iter().any(|a| a == "--recover");
    let wait = args.iter().any(|a| a == "--wait-for-client");
    let path = match std::path::absolute(spec) {
        Ok(p) => p,
        Err(e) => {
            eprintln!("nmux server: {e}");
            return 1;
        }
    };
    match run(&path, recover, wait) {
        Ok(code) => code,
        Err(e) => {
            eprintln!("nmux server: {e}");
            1
        }
    }
}

/// The system, as the core asks about it.
#[derive(Debug)]
struct System;

impl Probe for System {
    fn alive(&self, pid: u32, start: Option<&str>) -> bool {
        let Ok(pid) = i32::try_from(pid) else { return false };
        match start {
            Some(start) => is_same_process(pid, start),
            None => proc_state(pid) == ProcState::Alive,
        }
    }

    fn proc_start(&self, pid: u32) -> Option<String> {
        proc_start(i32::try_from(pid).ok()?)
    }

    fn locked(&self, path: &Path) -> bool {
        is_locked(path).unwrap_or(false)
    }

    fn environ(&self, pid: u32, key: &str) -> Option<String> {
        read_environ(i32::try_from(pid).ok()?)?.remove(key)
    }

    fn host(&self) -> (Option<String>, String, Option<String>) {
        (boot_id().ok(), hostname(), machine_id().ok())
    }
}

/// The session's lock, waited for when this server takes over from one still finishing.
fn take_lock(path: &Path, wait_ms: u64) -> std::io::Result<Option<nmux_platform::Lock>> {
    let deadline = Instant::now() + Duration::from_millis(wait_ms);
    loop {
        if let Some(lock) = try_lock(path)? {
            return Ok(Some(lock));
        }
        if Instant::now() >= deadline {
            return Ok(None);
        }
        std::thread::sleep(Duration::from_millis(LOCK_POLL_MS));
    }
}

/// A JSON file written in one step: a file of its own beside it, written, synced, and renamed over it.
fn write_atomic(file: &Path, value: &Value) -> std::io::Result<()> {
    let mut data = serde_json::to_vec_pretty(value).map_err(std::io::Error::other)?;
    data.push(b'\n');
    let tmp = file.with_extension(format!("tmp.{}.{}", hostname(), std::process::id()));
    let written = (|| {
        let mut f = OpenOptions::new().write(true).create_new(true).mode(0o600).open(&tmp)?;
        f.write_all(&data)?;
        f.sync_all()?;
        fs::rename(&tmp, file)
    })();
    if written.is_err() {
        let _ = fs::remove_file(&tmp);
    }
    written
}

fn read_json(file: &Path) -> Option<Value> {
    serde_json::from_slice(&fs::read(file).ok()?).ok()
}

fn touch_all(dir: &Path) {
    let Ok(entries) = fs::read_dir(dir) else { return };
    let now = std::time::SystemTime::now();
    for e in entries.flatten() {
        if let Ok(f) = fs::File::open(e.path()) {
            let _ = f.set_modified(now);
        }
    }
}

/// Points the link a session's programs know the ssh agent by at `target`, in one step: anything connecting at that moment
/// finds one agent or the other, and nothing is left beside the link.
pub fn point_agent(link: &Path, target: &str) -> std::io::Result<()> {
    let tmp = PathBuf::from(format!("{}.new", link.display()));
    let _ = fs::remove_file(&tmp);
    let done = std::os::unix::fs::symlink(target, &tmp).and_then(|()| fs::rename(&tmp, link));
    if done.is_err() {
        let _ = fs::remove_file(&tmp);
    }
    done
}

/// An exit nobody needs to look at leaves nothing behind.
fn nothing_to_keep(last_exit: Option<&Value>) -> bool {
    let Some(e) = last_exit.filter(|e| !e.is_null()) else { return true };
    let cause = e.get("cause").and_then(Value::as_str);
    cause == Some("stopped") || (cause == Some("exited") && e.get("code").and_then(Value::as_i64) == Some(0))
}

fn run(spec_path: &Path, recover: bool, wait_for_client: bool) -> Result<i32, Box<dyn Error>> {
    let spec = Spec::parse(&fs::read(spec_path)?)?;
    let session_dir = spec_path.parent().map(Path::to_path_buf).unwrap_or_default();
    let config = match &spec.config {
        Some(c) => Config::from_value(c),
        None => Config::load(spec.config_file.as_deref().map(Path::new)),
    };
    let layout = Layout::new(&spec.runtime_dir);
    DirBuilder::new().recursive(true).mode(0o700).create(layout.session_dir(&spec.id)?)?;
    let log_path = layout.log_file(&spec.id, "sessiond")?;
    let log = Logger::new(log_path.clone(), "sessiond", &spec.id);
    let wait = if recover { TAKEOVER_WAIT_MS } else { 0 };
    let Some(lock) = take_lock(&layout.sessiond_lock(&spec.id)?, wait)? else {
        return Err(format!("a sessiond already runs for {}", spec.id).into());
    };
    // biases the OOM killer away from this process where there is one
    if let Some(path) = OOM_SCORE_ADJ_PATH {
        let _ = fs::write(path, "300");
    }
    let mut reactor = Reactor::new()?;
    // a hangup must never end a session; SIGTERM leaves it to the next server
    reactor.catch_signals(&[Signal::Term, Signal::Hup, Signal::Chld])?;
    let waker = Arc::new(Waker::new(reactor.registry(), WAKER)?);
    let spool = open_spool(&spec, &layout, &log_path, &waker, reactor.now().wall_ms);
    let initial_state = spec.state_file.as_deref().and_then(|f| read_json(Path::new(f)));
    let exe = std::env::current_exe()?.to_string_lossy().into_owned();
    let mut server_argv: Vec<String> = vec![exe.clone()];
    server_argv.extend(std::env::args().skip(1));
    let managed = spec.managed.is_some();
    let ctl_sock = layout.ctl_sock(&spec.id)?;
    let state_file = spec.state_file.clone().map(PathBuf::from);
    let agent_link = spec.agent.clone().map(PathBuf::from);
    let id = spec.id.clone();
    let now = reactor.now();
    let server = Server::new(Options {
        spec,
        recover,
        wait_for_client,
        initial_state,
        pid: std::process::id(),
        server_argv,
        probe: Box::new(System),
        spool,
        config,
        now,
    });
    let mut listener = Listener::bind(&ctl_sock, 0o600)?;
    listener.register(reactor.registry(), LISTENER)?;
    let mut shell = Shell {
        reactor,
        listener: Some(listener),
        conns: BTreeMap::new(),
        holder: None,
        holder_ending: false,
        next_conn: FIRST_CONN as u64,
        log,
        pty_sock: layout.pty_sock(&id)?,
        ctl_sock,
        holder_bin: std::env::var("NMUX_HOLDER_BIN").ok().filter(|b| !b.is_empty()).unwrap_or(exe),
        state_file,
        agent_link,
        exit: None,
        last_touch: Instant::now(),
        session_dir: session_dir.clone(),
    };
    let leaving = shell.run(server);
    drop(lock);
    let Some((leaving, last_exit)) = leaving else { return Ok(1) };
    if !leaving && !managed && nothing_to_keep(last_exit.as_ref()) {
        // what stays is for whoever manages it to say
        let _ = fs::remove_dir_all(&session_dir);
        if let Some(dir) = log_path.parent() {
            let _ = fs::remove_dir_all(dir);
        }
    }
    Ok(0)
}

/// The kept history, open, writing on its own thread and waking the reactor when it has answers.
fn open_spool(spec: &Spec, layout: &Layout, log_path: &Path, waker: &Arc<Waker>, now_ms: i64) -> Option<Spool> {
    let s = spec.spool.as_ref()?;
    let dir = s.dir.clone().map_or_else(|| layout.session_dir(&spec.id).unwrap_or_default(), PathBuf::from);
    let meta = Meta {
        id: spec.id.clone(),
        name: Some(spec.name.clone()),
        created_at: Some(spec.created_at.clone().unwrap_or_else(|| iso_utc(now_ms))),
        cwd: Some(spec.child.cwd.clone()),
        argv: spec.child.argv.clone(),
    };
    let options =
        write::Options { dir, max_bytes: s.max_bytes, keep: s.keep, meta: Some(meta), wall_now: write::system_clock() };
    let mut spool_log = Logger::new(log_path.to_path_buf(), "sessiond", &spec.id);
    let logger = move |level: write::Level, code: &'static str, fields: &[(&'static str, Value)]| {
        let level = if level == write::Level::Warn { LogLevel::Warn } else { LogLevel::Info };
        let mut record = Log::new(level, code);
        for (k, v) in fields {
            record = record.with(k, v.clone());
        }
        spool_log.write(&record, &iso_utc(now()));
    };
    let waker = Arc::clone(waker);
    Some(Spool::new(
        options,
        Box::new(logger),
        Box::new(move || {
            let _ = waker.wake();
        }),
    ))
}

fn now() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |d| i64::try_from(d.as_millis()).unwrap_or(0))
}

/// A connection on ctl.sock.
#[derive(Debug)]
struct Link {
    conn: Conn,
    /// End it once what is queued is written.
    ending: bool,
    /// Something was queued and not yet all written.
    pending: bool,
}

/// The run loop's state: everything with a descriptor in it.
#[derive(Debug)]
struct Shell {
    reactor: Reactor,
    listener: Option<Listener>,
    conns: BTreeMap<ConnId, Link>,
    holder: Option<Conn>,
    holder_ending: bool,
    next_conn: u64,
    log: Logger,
    pty_sock: PathBuf,
    ctl_sock: PathBuf,
    holder_bin: String,
    state_file: Option<PathBuf>,
    agent_link: Option<PathBuf>,
    /// The server is done: whether it leaves the session to the next one.
    exit: Option<bool>,
    last_touch: Instant,
    session_dir: PathBuf,
}

impl Shell {
    /// Runs until the server is done: whether it left the session to the next, and how the child last ended. `None` when
    /// the server could not start.
    fn run(&mut self, mut server: Server) -> Option<(bool, Option<Value>)> {
        let now = self.reactor.now();
        server.on_event(Event::Started, now);
        loop {
            self.settle(&mut server);
            if let Some(leaving) = self.exit {
                self.last_flush(&mut server);
                return server.started_ok().then(|| (leaving, server.last_exit()));
            }
            if self.last_touch.elapsed() >= Duration::from_millis(TOUCH_MS) {
                self.last_touch = Instant::now();
                touch_all(&self.session_dir);
            }
            // a connection read to its limit has more: the reactor only says so once
            let more =
                self.conns.values().any(|l| l.conn.wants_read()) || self.holder.as_ref().is_some_and(Conn::wants_read);
            let due = if more { Some(self.reactor.now().time) } else { server.next_due() };
            if self.reactor.wait(due).is_err() {
                return Some((true, None));
            }
            for sig in self.reactor.take_signals() {
                match sig {
                    Signal::Term => server.on_event(Event::Term, self.reactor.now()),
                    Signal::Chld => while reap().is_some() {},
                    _ => {}
                }
            }
            let ready: Vec<_> = self.reactor.ready().to_vec();
            for r in ready {
                match r.token {
                    LISTENER => self.accept(&mut server),
                    HOLDER => {
                        if let Some(h) = self.holder.as_mut() {
                            h.on_ready(&r);
                        }
                    }
                    WAKER => server.on_event(Event::History, self.reactor.now()),
                    Token(t) => {
                        if let Some(link) = self.conns.get_mut(&ConnId(t as u64)) {
                            link.conn.on_ready(&r);
                        }
                    }
                }
            }
            self.read_holder(&mut server);
            let readable: Vec<ConnId> =
                self.conns.iter().filter(|(_, l)| l.conn.wants_read()).map(|(k, _)| *k).collect();
            for conn in readable {
                self.read_conn(&mut server, conn);
            }
            server.on_event(Event::Tick, self.reactor.now());
        }
    }

    /// Does what the server asked, writes what it queued, and lets it know what that changed, until it asks nothing more.
    fn settle(&mut self, server: &mut Server) {
        for _ in 0..16 {
            let effects = std::mem::take(&mut server.effects);
            let logs = std::mem::take(&mut server.logs);
            let stamp = iso_utc(self.reactor.now().wall_ms);
            for l in &logs {
                self.log.write(l, &stamp);
            }
            let any = !effects.is_empty();
            for e in effects {
                self.apply(server, e);
            }
            let drained = self.flush(server);
            for conn in &drained {
                server.on_event(Event::Drained(*conn), self.reactor.now());
            }
            if !any && drained.is_empty() && server.effects.is_empty() {
                return;
            }
        }
    }

    fn apply(&mut self, server: &mut Server, effect: Effect) {
        let now = self.reactor.now();
        match effect {
            Effect::ConnectHolder => {
                if let Some(mut old) = self.holder.take() {
                    let _ = old.deregister(self.reactor.registry());
                }
                self.holder_ending = false;
                match UnixStream::connect(&self.pty_sock) {
                    Ok(stream) => {
                        let mut conn = Conn::new(stream);
                        match conn.register(self.reactor.registry(), HOLDER) {
                            Ok(()) => {
                                self.holder = Some(conn);
                                server.on_event(Event::HolderConnected, now);
                            }
                            Err(e) => server.on_event(Event::HolderUnreachable(e.to_string()), now),
                        }
                    }
                    Err(e) => server.on_event(Event::HolderUnreachable(e.to_string()), now),
                }
            }
            Effect::CloseHolder => self.holder_ending = true,
            Effect::Close { conn, now: at_once } => {
                if at_once {
                    self.drop_conn(server, conn);
                } else if let Some(link) = self.conns.get_mut(&conn) {
                    link.ending = true;
                }
            }
            Effect::SpawnHolder { file, spec, env } => {
                if let Err(e) = write_atomic(&file, &spec) {
                    self.log_now(LogLevel::Error, "holder.spawn_failed", &e.to_string());
                    return;
                }
                let argv = vec![
                    self.holder_bin.clone(),
                    "__holder".into(),
                    "--spec".into(),
                    file.to_string_lossy().into_owned(),
                ];
                let env: Vec<(String, String)> = env.into_iter().collect();
                if let Err(e) = spawn_detached_with(&argv, Path::new("/"), &env) {
                    self.log_now(LogLevel::Error, "holder.spawn_failed", &e.to_string());
                }
            }
            Effect::Spawn { argv, env } => {
                let env: Vec<(String, String)> = env.into_iter().collect();
                if let Err(e) = spawn_detached_with(&argv, Path::new("/"), &env) {
                    self.log_now(LogLevel::Warn, "controller.spawn_failed", &e.to_string());
                }
            }
            Effect::Signal { pid, start, sig } => {
                let Ok(pid) = i32::try_from(pid) else { return };
                if start.as_deref().is_some_and(|s| !is_same_process(pid, s)) {
                    return;
                }
                if let Some(sig) = Signal::from_name(sig) {
                    let _ = kill(pid, sig);
                }
            }
            Effect::WriteState(record) => {
                let Some(file) = &self.state_file else { return };
                // merged into the file, so that what others wrote there stays
                let mut merged: Map<String, Value> =
                    read_json(file).and_then(|v| v.as_object().cloned()).unwrap_or_default();
                merged.extend(record);
                if let Err(e) = write_atomic(file, &Value::Object(merged)) {
                    self.log_now(LogLevel::Warn, "state.write_failed", &e.to_string());
                }
            }
            Effect::PointAgent(target) => {
                let Some(link) = &self.agent_link else { return };
                if let Err(e) = point_agent(link, &target) {
                    self.log_now(LogLevel::Warn, "agent.link_failed", &e.to_string());
                }
            }
            Effect::Exit { leaving } => {
                if let Some(mut l) = self.listener.take() {
                    let _ = l.deregister(self.reactor.registry());
                }
                let _ = fs::remove_file(&self.ctl_sock);
                self.exit = Some(leaving);
            }
        }
    }

    fn log_now(&mut self, level: LogLevel, ev: &'static str, error: &str) {
        let record = Log::new(level, ev).with("error", error);
        self.log.write(&record, &iso_utc(self.reactor.now().wall_ms));
    }

    /// Writes what the server queued, and ends what is to be ended once it is written. The connections that were left
    /// with nothing queued.
    fn flush(&mut self, server: &mut Server) -> Vec<ConnId> {
        let mut drained = Vec::new();
        if let (Some(h), Some(out)) = (self.holder.as_mut(), server.holder_out()) {
            let _ = h.flush(out);
            if self.holder_ending && out.is_empty() {
                let _ = h.shutdown_write();
            }
        }
        let conns: Vec<ConnId> = self.conns.keys().copied().collect();
        for conn in conns {
            let Some(link) = self.conns.get_mut(&conn) else { continue };
            let Some(out) = server.out(conn) else {
                if link.ending {
                    self.drop_conn(server, conn);
                }
                continue;
            };
            let had = !out.is_empty();
            let failed = link.conn.flush(out).is_err();
            let empty = out.is_empty();
            if failed {
                self.drop_conn(server, conn);
                continue;
            }
            if had && empty {
                link.pending = false;
                drained.push(conn);
            } else if !empty {
                link.pending = true;
            }
            if link.ending && empty {
                let _ = link.conn.shutdown_write();
                self.drop_conn(server, conn);
            }
        }
        drained
    }

    /// What is queued when the server is done goes out as far as the sockets take it, for a moment.
    fn last_flush(&mut self, server: &mut Server) {
        let deadline = Instant::now() + Duration::from_millis(LAST_FLUSH_MS);
        while Instant::now() < deadline {
            self.flush(server);
            let holder_left = server.holder_out().is_some_and(|o| !o.is_empty()) && self.holder.is_some();
            if self.conns.is_empty() && !holder_left {
                break;
            }
            let _ = self.reactor.wait(Some(self.reactor.now().time.after(10)));
            let ready: Vec<_> = self.reactor.ready().to_vec();
            for r in ready {
                if let Some(link) = self.conns.get_mut(&ConnId(r.token.0 as u64)) {
                    link.conn.on_ready(&r);
                }
                if r.token == HOLDER
                    && let Some(h) = self.holder.as_mut()
                {
                    h.on_ready(&r);
                }
            }
            let ending: Vec<ConnId> = self.conns.keys().copied().collect();
            for conn in ending {
                if let Some(link) = self.conns.get_mut(&conn) {
                    link.ending = true;
                }
            }
        }
        if let Some(h) = self.holder.as_ref() {
            let _ = h.shutdown_write();
        }
    }

    fn drop_conn(&mut self, server: &mut Server, conn: ConnId) {
        if let Some(mut link) = self.conns.remove(&conn) {
            let _ = link.conn.deregister(self.reactor.registry());
            server.on_event(Event::Closed(conn), self.reactor.now());
        }
    }

    fn accept(&mut self, server: &mut Server) {
        loop {
            let Some(listener) = self.listener.as_ref() else { return };
            let Ok(Some(stream)) = listener.accept() else { return };
            let conn = ConnId(self.next_conn);
            self.next_conn += 1;
            let mut c = Conn::new(stream);
            if c.register(self.reactor.registry(), Token(usize::try_from(conn.0).unwrap_or(usize::MAX))).is_err() {
                continue;
            }
            self.conns.insert(conn, Link { conn: c, ending: false, pending: false });
            server.on_event(Event::Accepted(conn), self.reactor.now());
            self.read_conn(server, conn);
        }
    }

    fn read_conn(&mut self, server: &mut Server, conn: ConnId) {
        let Some(link) = self.conns.get_mut(&conn) else { return };
        let now = self.reactor.now();
        let end = link.conn.read(|frame| server.on_event(Event::Frame(conn, frame), now));
        match end {
            ReadEnd::Open => {}
            ReadEnd::Closed | ReadEnd::Failed(_) => self.drop_conn(server, conn),
        }
    }

    fn read_holder(&mut self, server: &mut Server) {
        let Some(h) = self.holder.as_mut() else { return };
        let now = self.reactor.now();
        let end = h.read(|frame| server.on_event(Event::HolderFrame(frame), now));
        match end {
            ReadEnd::Open => {}
            ReadEnd::Closed | ReadEnd::Failed(_) => {
                if let Some(mut h) = self.holder.take() {
                    let _ = h.deregister(self.reactor.registry());
                }
                server.on_event(Event::HolderClosed, self.reactor.now());
            }
        }
    }
}
