//! The last line one client typed and submitted, so that an exit can say what came just before it: `lastline.js`. It reads
//! the bytes of each token forwarded: a printable character adds to the line, DEL or BS takes one away, CR or LF submits,
//! and anything else, another control byte, a sequence, a lone ESC or a paste, spoils the line. Two clients typing into one
//! line spoil it too. What it reports is an unbroken typed run with nothing else written after it.

use nmux_vt::{InputKind, InputToken};

#[derive(Clone, Debug, Default)]
struct Draft {
    client: Option<String>,
    text: String,
}

#[derive(Clone, Debug)]
struct Submitted {
    client: String,
    text: String,
    at_total: u64,
}

/// The line, and who typed it.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Line {
    /// The client.
    pub client: String,
    /// What it typed.
    pub text: String,
}

/// See the module.
#[derive(Clone, Debug, Default)]
pub struct LastLine {
    draft: Draft,
    submitted: Option<Submitted>,
}

impl LastLine {
    /// Every token forwarded to the program for a client, with the session's byte total after it.
    pub fn on_forwarded(&mut self, client: &str, tok: &InputToken<'_>, written_total: u64) {
        if self.submitted.as_ref().is_some_and(|s| s.at_total != written_total) {
            self.submitted = None; // something was written after it
        }
        if tok.kind != InputKind::Seq || self.draft.client.as_deref().is_some_and(|c| c != client) {
            self.clear();
            return;
        }
        let b = tok.bytes;
        if matches!(b, [b'\r' | b'\n']) {
            if self.draft.client.as_deref() == Some(client) {
                let text = std::mem::take(&mut self.draft.text);
                self.submitted = Some(Submitted { client: client.to_owned(), text, at_total: written_total });
            }
            self.clear();
            return;
        }
        if matches!(b, [0x7f | 0x08]) {
            self.draft.client.get_or_insert_with(|| client.to_owned());
            self.draft.text.pop();
            return;
        }
        let seq = tok.seq();
        let mut chars = seq.chars();
        if let (Some(c), None) = (chars.next(), chars.next())
            && !matches!(c, '\u{0}'..='\u{1f}' | '\u{7f}')
            && b[0] != 0x1b
        {
            self.draft.client.get_or_insert_with(|| client.to_owned());
            self.draft.text.push(c);
            return;
        }
        self.clear(); // arrows, history, any control
    }

    /// A paste was forwarded: pasted text is not a typed line.
    pub fn on_paste(&mut self) {
        self.clear();
    }

    /// The line submitted last, if nothing else has been written since.
    pub fn take(&mut self, written_total: u64) -> Option<Line> {
        let line = self.submitted.take();
        self.clear();
        line.filter(|l| l.at_total == written_total).map(|l| Line { client: l.client, text: l.text })
    }

    fn clear(&mut self) {
        self.draft = Draft::default();
    }
}
