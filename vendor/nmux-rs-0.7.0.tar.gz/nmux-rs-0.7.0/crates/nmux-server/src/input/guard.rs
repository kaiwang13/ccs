//! A key that must not take effect twice by accident, `guard.js`. A press of a guarded class is forwarded only when the one
//! before it was read by the program, followed by its output, and at least the margin ago after that output. No spacing of
//! presses is trusted: a program that has stopped never reads, so every press after is swallowed and the client told.

use nmux_io::Time;
use nmux_vt::keys::KeyClass;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum State {
    Idle,
    AwaitConsume(u32),
    AwaitOutput,
}

/// One class's state, shared by all clients.
#[derive(Clone, Copy, Debug)]
struct Guarded {
    class: KeyClass,
    state: State,
    ready_at: Option<Time>,
}

/// See the module.
#[derive(Clone, Debug)]
pub struct KeyGuard {
    margin_ms: u64,
    guards: Vec<Guarded>,
}

impl KeyGuard {
    /// Guards these classes, with this margin after the program's output.
    pub fn new(margin_ms: u64, keys: &[KeyClass]) -> Self {
        Self {
            margin_ms,
            guards: keys.iter().map(|&class| Guarded { class, state: State::Idle, ready_at: None }).collect(),
        }
    }

    /// Whether this class is guarded.
    pub fn covers(&self, class: KeyClass) -> bool {
        self.guards.iter().any(|g| g.class == class)
    }

    /// A press of `class`. With `write` it is forwarded, which gives the id of the watched write; `None` when it is held.
    pub fn offer(&mut self, class: KeyClass, now: Time, write: impl FnOnce(&[u8]) -> u32) -> Option<u32> {
        let g = self.guards.iter_mut().find(|g| g.class == class)?;
        if g.state != State::Idle || g.ready_at.is_some_and(|at| now < at) {
            return None;
        }
        let watch = write(if class == KeyClass::C { b"\x03" } else { b"\x04" });
        g.state = State::AwaitConsume(watch);
        Some(watch)
    }

    /// The program read a watched write.
    pub fn on_consumed(&mut self, watch: u32) {
        for g in &mut self.guards {
            if g.state == State::AwaitConsume(watch) {
                g.state = State::AwaitOutput;
            }
        }
    }

    /// Output came. Output after the press was read proves the program dealt with it.
    pub fn on_data(&mut self, now: Time) {
        for g in &mut self.guards {
            if g.state == State::AwaitOutput {
                g.state = State::Idle;
                g.ready_at = Some(now.after(self.margin_ms));
            }
        }
    }

    /// A new holder: the watches waited for were the old one's.
    pub fn reset(&mut self) {
        for g in &mut self.guards {
            g.state = State::Idle;
            g.ready_at = None;
        }
    }
}
