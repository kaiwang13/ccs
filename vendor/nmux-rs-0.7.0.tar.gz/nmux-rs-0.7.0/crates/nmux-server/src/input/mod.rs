//! Client input: what each client types, on its way to the program.

pub mod guard;
pub mod lastline;
pub mod router;
