//! A session's server, ported from `src/server` of the Node code: it owns the connection to the holder, turns the
//! program's output into what each client is sent, keeps the emulator that joins, captures and the history are made from,
//! and answers the control socket.
//!
//! The logic has no I/O, as the holder's has none: types that take what happened and the time, and queue what is to be
//! done. A thin run loop connects them to the sockets and the clock on `nmux-io`.

pub mod clients;
pub mod config;
pub mod core;
pub mod input;
pub mod messages;
pub mod output;
pub mod run;
pub mod session;
pub mod spec;
