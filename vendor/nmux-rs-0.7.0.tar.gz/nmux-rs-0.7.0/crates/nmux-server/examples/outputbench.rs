//! What each stage of the server's output path costs, on a file of output: `cargo run --release -p nmux-server --example
//! outputbench FILE`. The file is read in the 64 KiB pieces a holder sends, through the pipeline, the emulator of a 120 by 40
//! pty with 10,000 lines of history, and one client's view.

use std::time::Instant;

use nmux_io::Time;
use nmux_server::output::{ClientAdapter, ClientFlags, Context, Emulator, Pipeline, Titles, Tracker};

#[allow(clippy::cast_precision_loss)] // a rate needs no more precision than a double has
fn main() {
    let Some(path) = std::env::args().nth(1) else {
        eprintln!("usage: outputbench FILE");
        std::process::exit(2);
    };
    let Ok(bytes) = std::fs::read(&path) else {
        eprintln!("outputbench: cannot read {path}");
        std::process::exit(1);
    };
    let mb = bytes.len() as f64 / 1_048_576.0;
    let titles = Titles { brand: "nmux".into(), attention: String::new(), bell_on_attention: false };
    let only = std::env::var("STAGE").ok();
    for stage in ["pipeline", "pipeline + emulator", "pipeline + emulator + client"] {
        if only.as_deref().is_some_and(|o| o != stage) {
            continue;
        }
        // the best of five: the slower runs measure the machine
        let best = (0..5).map(|_| run(&bytes, stage, &titles)).fold(f64::MAX, f64::min);
        println!("{stage:<30} {:>7.1} MB/s", mb / best);
    }
}

/// One pass of the file through `stage`, in seconds.
fn run(bytes: &[u8], stage: &str, titles: &Titles) -> f64 {
    {
        let mut tracker = Tracker::new(120, 40);
        let mut pipeline = Pipeline::new(false, 0, None, false);
        let mut emulator = Emulator::new(Some((120, 40)), 10_000);
        emulator.init(40, Some(120));
        let mut client = ClientAdapter::new(120, 40, ClientFlags::default());
        client.go_live();
        let start = Instant::now();
        let mut offset = 0u64;
        for piece in bytes.chunks(65_536) {
            let chunks = pipeline.process(&mut tracker, offset, piece, Time::ZERO);
            offset += piece.len() as u64;
            for c in &chunks {
                if stage != "pipeline" {
                    emulator.feed(c, 1, None, &mut ());
                }
                if stage.ends_with("client") {
                    let cx = Context { titles, tracker: &tracker, queue_cap: usize::MAX };
                    client.render(c, &cx);
                    let n = client.out.len();
                    client.out.consume(n);
                }
            }
        }
        start.elapsed().as_secs_f64()
    }
}
