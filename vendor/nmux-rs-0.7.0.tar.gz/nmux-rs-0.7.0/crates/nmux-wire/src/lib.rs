//! The wire protocol of nmux, as the Node code speaks it: frames, control messages, the payloads of the binary frames,
//! the holder's frozen field names, and where a session's files live. Sans-IO: nothing here reads or writes a socket.
//!
//! Encoding appends to the caller's buffer and decoding reads from the caller's buffer, with no allocation per frame for the
//! binary types. A control message is a [`Control`].
//!
//! ```
//! use nmux_wire::{Control, Frame, FrameDecoder, encode_control};
//!
//! let mut out = Vec::new();
//! encode_control(&mut out, &Control::Ping { seq: 7 })?;
//! assert_eq!(&out[5..], br#"{"t":"PING","seq":7}"#);
//! let (frame, _) = FrameDecoder::new().decode(&out)?.expect("a whole frame");
//! assert_eq!(frame, Frame::Control(Control::Ping { seq: 7 }));
//! # Ok::<(), nmux_wire::ProtocolError>(())
//! ```

mod framing;
mod holder_wire;
mod layout;
mod messages;
mod proto;

pub use framing::{
    ErrorCode, Frame, FrameDecoder, FrameType, MAX_FRAME, MAX_JSON, ProtocolError, encode_control, encode_frame,
};
pub use holder_wire::{ChildInfo, HHello, Lflag, Ring, name_of_state};
pub use layout::{Layout, LayoutError, segment};
pub use messages::{
    Bye, ClientInfo, Colors, Control, ErrorMessage, Event, Exit, Extra, Flags, Hello, PingPolicy, Policy, Res, Resized,
    Resume, Size, State, Welcome,
};
pub use proto::{CTL_PROTO, Data, HOLDER_PROTO, Write, decode_data, decode_write, encode_data, encode_write};
