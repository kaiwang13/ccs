//! Where one session's sockets, locks and logs live under a runtime directory. The holder, the server and every client
//! derive these paths here, so they always agree.

use std::fmt;
use std::path::{Path, PathBuf};

/// A path that cannot be made: a segment that would climb out of its directory or hide in it, or a generation no peer
/// could read back. A `TypeError` in the Node code, with the same message.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct LayoutError {
    message: String,
}

impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.message)
    }
}

impl std::error::Error for LayoutError {}

/// `value`, if it is a safe path segment: a letter or digit, then up to 63 letters, digits, `.`, `_` or `-`. `kind` names
/// it in the error, as `session id` does.
pub fn segment<'v>(kind: &str, value: &'v str) -> Result<&'v str, LayoutError> {
    let mut bytes = value.bytes();
    let first = bytes.next().is_some_and(|b| b.is_ascii_alphanumeric());
    let rest = bytes.all(|b| b.is_ascii_alphanumeric() || matches!(b, b'.' | b'_' | b'-'));
    if first && rest && value.len() <= 64 {
        Ok(value)
    } else {
        let quoted = serde_json::to_string(value).unwrap_or_default();
        Err(LayoutError { message: format!("invalid {kind}: {quoted}") })
    }
}

/// The largest generation a JavaScript number holds exactly: a Node peer reads the same files.
const MAX_SAFE_INTEGER: u64 = (1 << 53) - 1;

/// The paths of every session under one runtime directory.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    runtime_dir: PathBuf,
    log_dir: PathBuf,
}

impl Layout {
    /// The layout under `runtime_dir`, which is absolute.
    pub fn new(runtime_dir: impl Into<PathBuf>) -> Self {
        let runtime_dir = runtime_dir.into();
        let log_dir = runtime_dir.join("log");
        Self { runtime_dir, log_dir }
    }

    /// The runtime directory.
    pub fn runtime_dir(&self) -> &Path {
        &self.runtime_dir
    }

    /// Where every session's logs go.
    pub fn log_dir(&self) -> &Path {
        &self.log_dir
    }

    /// `s/<id>`: one session's directory.
    pub fn session_dir(&self, id: &str) -> Result<PathBuf, LayoutError> {
        Ok(self.runtime_dir.join("s").join(segment("session id", id)?))
    }

    fn in_session(&self, id: &str, name: &str) -> Result<PathBuf, LayoutError> {
        Ok(self.session_dir(id)?.join(name))
    }

    /// The server's socket, for clients.
    pub fn ctl_sock(&self, id: &str) -> Result<PathBuf, LayoutError> {
        self.in_session(id, "ctl.sock")
    }

    /// The holder's socket, for the server.
    pub fn pty_sock(&self, id: &str) -> Result<PathBuf, LayoutError> {
        self.in_session(id, "pty.sock")
    }

    /// Held by the one holder of the session.
    pub fn holder_lock(&self, id: &str) -> Result<PathBuf, LayoutError> {
        self.in_session(id, "holder.lock")
    }

    /// Held by the one server of the session.
    pub fn sessiond_lock(&self, id: &str) -> Result<PathBuf, LayoutError> {
        self.in_session(id, "sessiond.lock")
    }

    /// What one generation of holder was started with.
    pub fn holder_spec(&self, id: &str, generation: u64) -> Result<PathBuf, LayoutError> {
        if generation > MAX_SAFE_INTEGER {
            return Err(LayoutError { message: format!("invalid holder gen: {generation}") });
        }
        self.in_session(id, &format!("holder-{generation}.json"))
    }

    /// What the running holder says about itself.
    pub fn holder_json(&self, id: &str) -> Result<PathBuf, LayoutError> {
        self.in_session(id, "holder.json")
    }

    /// The link to an attached client's agent socket.
    pub fn agent_link(&self, id: &str) -> Result<PathBuf, LayoutError> {
        self.in_session(id, "agent.sock")
    }

    /// `log/<id>/<component>.log`.
    pub fn log_file(&self, id: &str, component: &str) -> Result<PathBuf, LayoutError> {
        let dir = self.log_dir.join(segment("session id", id)?);
        Ok(dir.join(format!("{}.log", segment("component", component)?)))
    }
}
