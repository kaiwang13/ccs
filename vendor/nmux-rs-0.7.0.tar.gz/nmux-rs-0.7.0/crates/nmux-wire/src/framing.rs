//! Wire framing shared by ctl.sock, between a client and the server, and pty.sock, between the server and the holder:
//! `u32be length | u8 type | payload`, where the length covers type and payload. A frame is at most [`MAX_FRAME`] bytes of
//! type and payload, and a control payload at most [`MAX_JSON`] bytes of UTF-8.
//!
//! There is no I/O here. Frames are encoded onto the end of the caller's buffer and decoded from the start of it, and only a
//! control frame allocates, for its JSON.

use std::fmt;

use crate::messages::Control;

/// The largest frame, type and payload.
pub const MAX_FRAME: usize = 1_048_576;
/// The largest control payload.
pub const MAX_JSON: usize = 65_536;
/// Length and type.
const HEAD: usize = 5;

/// What a frame carries.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum FrameType {
    /// A JSON message with a `t` field.
    Control = 0x01,
    /// A client's keyboard bytes.
    Input = 0x02,
    /// Bytes for a client's terminal.
    Output = 0x03,
    /// The holder's output: see [`crate::decode_data`].
    Data = 0x10,
    /// Bytes for the pty: see [`crate::decode_write`].
    Write = 0x11,
}

impl FrameType {
    /// DATA and WRITE start with a fixed head (see `proto.rs`): the type's name and the head's length. A frame too short for
    /// it is the peer's mistake, and is refused when its header is read.
    fn head(self) -> Option<(&'static str, usize)> {
        match self {
            Self::Data => Some(("DATA", 8)),
            Self::Write => Some(("WRITE", 5)),
            Self::Control | Self::Input | Self::Output => None,
        }
    }

    /// The type with this number, if there is one.
    pub fn from_u8(byte: u8) -> Option<Self> {
        match byte {
            0x01 => Some(Self::Control),
            0x02 => Some(Self::Input),
            0x03 => Some(Self::Output),
            0x10 => Some(Self::Data),
            0x11 => Some(Self::Write),
            _ => None,
        }
    }
}

/// Which error a [`ProtocolError`] is, as `err.code` in the Node code.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ErrorCode {
    /// `PROTO`: an unknown type, a zero length, a DATA or WRITE frame too short for its head, or a decoder that already
    /// failed.
    Proto,
    /// `FRAME_TOO_LARGE`
    FrameTooLarge,
    /// `JSON_TOO_LARGE`
    JsonTooLarge,
    /// `BAD_JSON`: not JSON, or not an object.
    BadJson,
    /// A DATA or WRITE payload, or a value for one, out of range: a `RangeError` in the Node code.
    Range,
}

impl ErrorCode {
    /// The code as the Node code spells it.
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Proto => "PROTO",
            Self::FrameTooLarge => "FRAME_TOO_LARGE",
            Self::JsonTooLarge => "JSON_TOO_LARGE",
            Self::BadJson => "BAD_JSON",
            Self::Range => "RangeError",
        }
    }
}

/// A frame that cannot be sent or received. A connection whose decoder returned one must be dropped.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ProtocolError {
    /// Which error.
    pub code: ErrorCode,
    /// The words of the Node code's message.
    pub message: String,
}

impl ProtocolError {
    pub(crate) fn new(code: ErrorCode, message: impl Into<String>) -> Self {
        Self { code, message: message.into() }
    }
}

impl fmt::Display for ProtocolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.message)
    }
}

impl std::error::Error for ProtocolError {}

/// One decoded frame. Binary payloads borrow the caller's buffer.
#[derive(Clone, Debug, PartialEq)]
#[allow(clippy::large_enum_variant)] // a frame is handled where it is decoded, and is never stored
pub enum Frame<'b> {
    /// A control message.
    Control(Control),
    /// A client's keyboard bytes.
    Input(&'b [u8]),
    /// Bytes for a client's terminal.
    Output(&'b [u8]),
    /// A DATA payload, for [`crate::decode_data`].
    Data(&'b [u8]),
    /// A WRITE payload, for [`crate::decode_write`].
    Write(&'b [u8]),
}

/// Appends a frame of this type to `out`.
pub fn encode_frame(out: &mut Vec<u8>, frame_type: FrameType, payload: &[u8]) -> Result<(), ProtocolError> {
    encode_parts(out, frame_type, &[payload])
}

/// Appends a frame whose payload is these parts one after another, so that a header and the bytes it describes need not
/// be copied together first.
pub(crate) fn encode_parts(out: &mut Vec<u8>, frame_type: FrameType, parts: &[&[u8]]) -> Result<(), ProtocolError> {
    let length = 1 + parts.iter().map(|p| p.len()).sum::<usize>();
    let head = frame_head(frame_type, length)?;
    out.reserve(HEAD + length - 1);
    out.extend_from_slice(&head);
    for part in parts {
        out.extend_from_slice(part);
    }
    Ok(())
}

fn frame_head(frame_type: FrameType, length: usize) -> Result<[u8; HEAD], ProtocolError> {
    let too_large =
        || ProtocolError::new(ErrorCode::FrameTooLarge, format!("frame of {length} bytes exceeds {MAX_FRAME}"));
    let length = u32::try_from(length).ok().filter(|&n| n as usize <= MAX_FRAME).ok_or_else(too_large)?;
    let [a, b, c, d] = length.to_be_bytes();
    Ok([a, b, c, d, frame_type as u8])
}

/// Appends a control frame to `out`. Nothing is appended if it fails.
pub fn encode_control(out: &mut Vec<u8>, message: &Control) -> Result<(), ProtocolError> {
    let at = out.len();
    out.extend_from_slice(&[0; HEAD]);
    let written = serde_json::to_writer(&mut *out, message);
    let length = out.len() - at - HEAD;
    let checked = match written {
        Err(e) => Err(ProtocolError::new(ErrorCode::Proto, e.to_string())),
        Ok(()) if length > MAX_JSON => {
            Err(ProtocolError::new(ErrorCode::JsonTooLarge, format!("JSON frame of {length} bytes exceeds {MAX_JSON}")))
        }
        Ok(()) => frame_head(FrameType::Control, length + 1),
    };
    match checked {
        Ok(head) => {
            out[at..at + HEAD].copy_from_slice(&head);
            Ok(())
        }
        Err(e) => {
            out.truncate(at);
            Err(e)
        }
    }
}

/// Decodes frames from the start of a buffer the caller keeps: it reads into the buffer, decodes what is complete, and
/// drops the bytes each frame took. A decoder that failed stays failed, as the connection must be dropped.
///
/// ```
/// use nmux_wire::{Frame, FrameDecoder, FrameType, encode_frame};
///
/// let mut buf = Vec::new();
/// encode_frame(&mut buf, FrameType::Output, b"hi")?;
/// let mut decoder = FrameDecoder::new();
/// let mut used = 0;
/// while let Some((frame, len)) = decoder.decode(&buf[used..])? {
///     assert_eq!(frame, Frame::Output(b"hi"));
///     used += len;
/// }
/// buf.drain(..used);
/// # Ok::<(), nmux_wire::ProtocolError>(())
/// ```
#[derive(Debug, Default)]
pub struct FrameDecoder {
    failed: bool,
}

impl FrameDecoder {
    /// A decoder at the start of a connection.
    pub fn new() -> Self {
        Self::default()
    }

    /// The frame at the start of `buf`, and the number of bytes it took, or `None` until all of it has arrived. The header
    /// is checked as soon as it is there, so an oversize frame fails before its body is waited for.
    pub fn decode<'b>(&mut self, buf: &'b [u8]) -> Result<Option<(Frame<'b>, usize)>, ProtocolError> {
        if self.failed {
            return Err(ProtocolError::new(ErrorCode::Proto, "decoder already failed"));
        }
        let decoded = decode_frame(buf);
        self.failed = decoded.is_err();
        decoded
    }
}

fn decode_frame(buf: &[u8]) -> Result<Option<(Frame<'_>, usize)>, ProtocolError> {
    let Some((&[a, b, c, d, type_byte], body)) = buf.split_first_chunk::<HEAD>() else { return Ok(None) };
    let length = u32::from_be_bytes([a, b, c, d]) as usize;
    if length < 1 {
        return Err(ProtocolError::new(ErrorCode::Proto, "zero-length frame"));
    }
    if length > MAX_FRAME {
        return Err(ProtocolError::new(
            ErrorCode::FrameTooLarge,
            format!("frame of {length} bytes exceeds {MAX_FRAME}"),
        ));
    }
    let Some(frame_type) = FrameType::from_u8(type_byte) else {
        return Err(ProtocolError::new(ErrorCode::Proto, format!("unknown frame type 0x{type_byte:x}")));
    };
    if frame_type == FrameType::Control && length - 1 > MAX_JSON {
        let message = format!("JSON frame of {} bytes exceeds {MAX_JSON}", length - 1);
        return Err(ProtocolError::new(ErrorCode::JsonTooLarge, message));
    }
    if let Some((name, head)) = frame_type.head() {
        if length - 1 < head {
            return Err(ProtocolError::new(ErrorCode::Proto, format!("{name} payload shorter than {head} bytes")));
        }
    }
    let Some(payload) = body.get(..length - 1) else { return Ok(None) };
    let frame = match frame_type {
        FrameType::Control => Frame::Control(Control::parse(payload)?),
        FrameType::Input => Frame::Input(payload),
        FrameType::Output => Frame::Output(payload),
        FrameType::Data => Frame::Data(payload),
        FrameType::Write => Frame::Write(payload),
    };
    Ok(Some((frame, HEAD - 1 + length)))
}
