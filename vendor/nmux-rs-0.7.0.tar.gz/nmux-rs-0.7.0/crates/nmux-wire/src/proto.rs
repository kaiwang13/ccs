//! Protocol versions, and the payloads of the binary frames between the server and the holder.

use crate::framing::{ErrorCode, FrameType, ProtocolError, encode_parts};

/// The version of the protocol on ctl.sock.
pub const CTL_PROTO: u32 = 1;
/// The version of the protocol on pty.sock.
pub const HOLDER_PROTO: u32 = 1;

/// A stream offset must stay exact as a JavaScript number, because a Node peer holds it in one.
const MAX_SAFE_INTEGER: u64 = (1 << 53) - 1;

/// A DATA payload: the holder's output from an absolute stream offset.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Data<'a> {
    /// Absolute stream offset of the first byte.
    pub offset: u64,
    /// The bytes.
    pub bytes: &'a [u8],
}

/// Appends a DATA frame: `u64be offset | bytes`.
pub fn encode_data(out: &mut Vec<u8>, offset: u64, bytes: &[u8]) -> Result<(), ProtocolError> {
    if offset > MAX_SAFE_INTEGER {
        return Err(ProtocolError::new(ErrorCode::Range, format!("bad DATA offset {offset}")));
    }
    encode_parts(out, FrameType::Data, &[&offset.to_be_bytes(), bytes])
}

/// Reads a DATA payload.
pub fn decode_data(payload: &[u8]) -> Result<Data<'_>, ProtocolError> {
    let Some((head, bytes)) = payload.split_first_chunk::<8>() else {
        return Err(ProtocolError::new(ErrorCode::Range, "DATA payload shorter than 8 bytes"));
    };
    let offset = u64::from_be_bytes(*head);
    if offset > MAX_SAFE_INTEGER {
        return Err(ProtocolError::new(ErrorCode::Range, "DATA offset beyond 2^53"));
    }
    Ok(Data { offset, bytes })
}

/// A WRITE payload: bytes for the pty.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Write<'a> {
    /// The holder says CONSUMED with this id once the bytes are written, and 0 asks for nothing.
    pub watch_id: u32,
    /// The bytes are a lone ESC, which the holder keeps apart from what follows.
    pub lone_esc: bool,
    /// The bytes.
    pub bytes: &'a [u8],
}

/// Appends a WRITE frame: `u32be watchId | u8 flags | bytes`, where bit 0 of the flags is `lone_esc`.
pub fn encode_write(out: &mut Vec<u8>, write: &Write<'_>) -> Result<(), ProtocolError> {
    let mut head = [0; 5];
    head[..4].copy_from_slice(&write.watch_id.to_be_bytes());
    head[4] = u8::from(write.lone_esc);
    encode_parts(out, FrameType::Write, &[&head, write.bytes])
}

/// Reads a WRITE payload. Only bit 0 of the flags counts.
pub fn decode_write(payload: &[u8]) -> Result<Write<'_>, ProtocolError> {
    let Some((&[a, b, c, d, flags], bytes)) = payload.split_first_chunk::<5>() else {
        return Err(ProtocolError::new(ErrorCode::Range, "WRITE payload shorter than 5 bytes"));
    };
    Ok(Write { watch_id: u32::from_be_bytes([a, b, c, d]), lone_esc: flags & 1 == 1, bytes })
}
