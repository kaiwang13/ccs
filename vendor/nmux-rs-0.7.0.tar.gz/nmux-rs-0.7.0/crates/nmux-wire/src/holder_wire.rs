//! The field names on the wire that predate this project. Holders outlive every other process, so a server must keep
//! adopting the ones already running: these names stay as they are until a protocol version negotiates them away, and this
//! is the only file that spells them. Everything else sees `child`.

use serde::{Deserialize, Serialize};

use crate::messages::{Exit, Extra, Resized, Size, State};

/// The holder's greeting.
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct HHello {
    /// [`crate::HOLDER_PROTO`] for this version.
    pub proto: u32,
    /// The holder's release.
    pub holder_version: String,
    /// Which holder of the session this is.
    #[serde(rename = "gen")]
    pub generation: u64,
    /// The holder's pid.
    pub pid: u32,
    /// When the holder started, as the platform tells it apart from a pid reused later.
    pub proc_start: Option<String>,
    /// The pty's size.
    pub pty: Size,
    /// What the ring holds.
    pub ring: Ring,
    /// The spawn size and the last resizes.
    pub resize_log: Vec<Resized>,
    /// The child's exit, if it has exited.
    #[serde(with = "exited")]
    pub exited: Option<Exit>,
    /// The pty's device.
    pub pts_name: String,
    /// What the holder can do beyond the base protocol. One from an older release does not say.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub caps: Option<Vec<String>>,
    /// Fields this side does not name.
    #[serde(flatten)]
    pub extra: Extra,
    /// The child the holder runs.
    #[serde(rename = "claude")]
    pub child: ChildInfo,
}

impl HHello {
    fn can(&self, cap: &str) -> bool {
        self.caps.as_ref().is_some_and(|caps| caps.iter().any(|c| c == cap))
    }

    /// The holder takes acknowledgements. One from an older release does not, and drains regardless.
    pub fn flow(&self) -> bool {
        self.can("flow")
    }

    /// The holder takes [`crate::Control::Colors`]. One from an older release does not, and answers with the colours it
    /// was started with.
    pub fn colors(&self) -> bool {
        self.can("colors")
    }
}

/// The child as the holder's greeting names it.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ChildInfo {
    /// Its pid.
    pub pid: u32,
    /// When it started.
    pub proc_start: Option<String>,
}

/// The stream offsets the holder's ring holds.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default)]
pub struct Ring {
    /// The oldest offset it still has.
    pub start: u64,
    /// Just past the newest.
    pub end: u64,
}

/// The pty's local modes and its foreground process group.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default)]
#[allow(clippy::struct_excessive_bools)] // one for each mode, as termios has them
pub struct Lflag {
    /// Canonical mode: the line discipline edits lines.
    pub icanon: bool,
    /// Control characters raise signals.
    pub isig: bool,
    /// Input is echoed.
    pub echo: bool,
    /// The child leads the foreground process group, so nothing it started has the terminal.
    #[serde(rename = "fgIsClaude")]
    pub fg_is_child: bool,
    /// The foreground process group.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub fg: Option<i64>,
}

/// The session's current name from a STATE message. A server that predates the `name` field carries it under the child's
/// status instead.
pub fn name_of_state(state: &State) -> Option<&str> {
    let older = || state.extra.get("claude")?.get("name")?.as_str();
    state.name.as_deref().filter(|n| !n.is_empty()).or_else(|| older().filter(|n| !n.is_empty()))
}

/// `exited` is the EXIT message itself, `t` and all.
mod exited {
    use serde::{Deserialize, Deserializer, Serialize, Serializer};

    use crate::messages::Exit;

    #[derive(Serialize, Deserialize)]
    #[serde(tag = "t")]
    enum Tagged<E> {
        #[serde(rename = "EXIT")]
        Exit(E),
    }

    #[allow(clippy::ref_option)] // serde's signature
    pub fn serialize<S: Serializer>(exit: &Option<Exit>, serializer: S) -> Result<S::Ok, S::Error> {
        exit.as_ref().map(Tagged::Exit).serialize(serializer)
    }

    pub fn deserialize<'de, D: Deserializer<'de>>(deserializer: D) -> Result<Option<Exit>, D::Error> {
        Ok(Option::<Tagged<Exit>>::deserialize(deserializer)?.map(|Tagged::Exit(exit)| exit))
    }
}
