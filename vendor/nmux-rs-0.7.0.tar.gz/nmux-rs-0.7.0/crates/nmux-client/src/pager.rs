//! A history in a pager: the half of `src/client/history.js` that runs one. What a running session has not written yet is
//! asked of it first, then the lines go to `NMUX_PAGER`, or `less -R`, or straight out as plain text when that is not a
//! terminal.

use std::io::{self, Write};
use std::path::Path;
use std::process::{Command, Stdio};

use nmux_history::read::{Kept, Paged, Pages, Target, Unwritten, lines_of, pager_args, plain_page, target_line};
use nmux_platform::{Shield, Signal};
use nmux_time::Zone;
use serde_json::{Value, json};

use crate::ctl::control_request;

/// A session reading back a long history can take a while, and answering is all it is asked to do.
pub const READ_BACK_WAIT_MS: u64 = 120_000;
const PAGER: &str = "less -R";
const BATCH: usize = 65_536;

/// What a running session has not yet written to its history, numbered on from what it has. Nothing, if it is not running or
/// does not answer within `wait_ms`.
pub fn unwritten_of(sock: &Path, ansi: bool, wait_ms: u64, now: i64) -> Option<Unwritten> {
    let r = control_request(sock, "UNWRITTEN", json!({ "ansi": ansi }), wait_ms, "history").ok()?;
    if !r.ok {
        return None;
    }
    let number = |key: &str| r.data.get(key).and_then(Value::as_f64).filter(|n| n.is_finite() && *n >= 0.0);
    #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)] // a row and a count, whole and not negative
    let (first, count) = (number("first").unwrap_or(0.0) as u64, number("count").unwrap_or(0.0) as usize);
    Some(Unwritten::parse(&r.output, first, count, ansi, now))
}

/// Where the lines go: the terminal, or not one.
#[derive(Clone, Debug)]
pub struct Output {
    /// Standard output is a terminal.
    pub tty: bool,
    /// `NMUX_PAGER`.
    pub pager: Option<String>,
}

/// What to show, and where to open it.
#[derive(Clone, Debug)]
pub struct View<'a> {
    /// The history.
    pub kept: &'a Kept,
    /// A running session's socket, so that what it has not written is shown too.
    pub sock: Option<&'a Path>,
    /// Where times are shown.
    pub zone: &'a Zone,
    /// Opens at a time or a row; at the end without either.
    pub target: Target,
    /// Opens at its first match, which the pager finds.
    pub grep: Option<String>,
    /// Each line starts with its time.
    pub times: bool,
    /// How long a running session has to say what it has not written.
    pub wait_ms: u64,
}

/// A history in a pager, opened at a time, a row, or the first match. Each day starts with a line saying which, in the zone,
/// so that a search for a date finds it. `take` is asked just before the pager starts, by a terminal lending itself: false
/// means it has gone, and nothing is shown. The pager's exit code.
pub fn view(v: &View<'_>, out: &Output, now: i64, take: Option<&mut dyn FnMut() -> bool>) -> io::Result<i32> {
    let live = v.sock.and_then(|sock| unwritten_of(sock, true, v.wait_ms, now));
    let render = || {
        let first = live.as_ref().map(|l| l.first);
        let written = lines_of(&v.kept.dir, true)
            .take_while(move |l| !matches!((l, first), (Ok(written), Some(first)) if written.row >= first));
        let unwritten = live.iter().flat_map(|l| l.lines.iter().cloned()).map(Ok);
        let mut pages = Pages::new(v.zone, &v.kept.name, v.times);
        written.chain(unwritten).map(move |l| l.map(|l| pages.page(l)))
    };
    let target = target_line(render(), v.target)?;
    page(render(), &pager_args(v.grep.as_deref(), target), out, take)
}

/// Lines into a pager, or straight out as plain text when that is not a terminal. The pager is in this process's group, so
/// ^C at it reaches this process too, which waits for it rather than leave it drawing over the shell; and the pager is waited
/// for whatever happens to the lines on their way to it: an error reading them comes back once it has gone.
pub fn page(
    lines: impl Iterator<Item = io::Result<Paged>>,
    args: &[String],
    out: &Output,
    take: Option<&mut dyn FnMut() -> bool>,
) -> io::Result<i32> {
    if !out.tty {
        return plain(lines, &mut io::stdout().lock());
    }
    if let Some(take) = take {
        if !take() {
            return Ok(0);
        }
    }
    let _shield = Shield::raise(&[Signal::Int, Signal::Quit])?;
    let pager = out.pager.as_deref().filter(|p| !p.is_empty()).unwrap_or(PAGER);
    let spawned =
        Command::new("sh").arg("-c").arg(format!("{pager} \"$@\"")).arg("sh").args(args).stdin(Stdio::piped()).spawn();
    let Ok(mut child) = spawned else { return Ok(127) };
    let mut failed = None;
    if let Some(mut stdin) = child.stdin.take() {
        for p in lines {
            match p {
                // Quitting before the end is how a pager is used.
                Ok(p) => {
                    if stdin.write_all(p.head.as_bytes()).and_then(|()| stdin.write_all(p.body.as_bytes())).is_err() {
                        break;
                    }
                }
                Err(e) => {
                    failed = Some(e);
                    break;
                }
            }
        }
    }
    let status = child.wait()?;
    match failed {
        Some(e) => Err(e),
        None => Ok(status.code().unwrap_or(0)),
    }
}

/// Into a pipe, which may close before the end, as `head` does.
fn plain(lines: impl Iterator<Item = io::Result<Paged>>, out: &mut impl Write) -> io::Result<i32> {
    let mut batch = String::new();
    for p in lines {
        batch.push_str(&plain_page(&p?));
        if batch.len() > BATCH {
            if out.write_all(batch.as_bytes()).and_then(|()| out.flush()).is_err() {
                return Ok(0);
            }
            batch.clear();
        }
    }
    let _ = out.write_all(batch.as_bytes()).and_then(|()| out.flush());
    Ok(0)
}
