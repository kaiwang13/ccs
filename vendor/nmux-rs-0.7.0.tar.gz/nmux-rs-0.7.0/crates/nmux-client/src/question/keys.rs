//! The keys in what a terminal sends, as readline reads them: `emitKeypressEvents` and `emitKeys` in Node's
//! `lib/internal/readline/`. Bytes are UTF-8, a character that is cut in two waits for the rest of it, and a key is each
//! character, or ESC with what follows it read as far as `emitKeys` reads, whatever that turns out to be.

const ESC: char = '\x1b';

/// A key, as far as a question tells keys apart.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum Name {
    /// CR.
    Return,
    /// LF.
    Enter,
    /// BS or DEL.
    Backspace,
    /// A letter, in lower case, or a digit; or with `ctrl`, the letter of a control character.
    Char(char),
    Left,
    Right,
    Home,
    End,
    Delete,
    /// Any other: Tab, Space and Escape, the arrows up and down, and the keys and characters that have no name.
    Other,
}

/// A key and its modifiers.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct Key {
    pub name: Name,
    pub ctrl: bool,
    pub meta: bool,
    pub shift: bool,
    /// The character it types, unless it came after ESC.
    pub text: Option<char>,
}

/// What is left of what was read until the rest of it comes.
#[derive(Debug, Default)]
pub(super) struct Keys {
    /// The start of a character.
    partial: Vec<u8>,
    /// The characters of a key.
    pending: Vec<char>,
}

impl Keys {
    /// The characters `bytes` ends, after the start of one read before. What is not UTF-8 is U+FFFD.
    pub fn decode(&mut self, bytes: &[u8]) -> String {
        self.partial.extend_from_slice(bytes);
        let len = self.partial.len();
        // where the last character starts, if it has not all come
        let whole = (len.saturating_sub(3)..len)
            .rev()
            .find(|&i| self.partial[i] >= 0xc0)
            .filter(|&i| std::str::from_utf8(&self.partial[i..]).is_err_and(|e| e.error_len().is_none()))
            .unwrap_or(len);
        let text = String::from_utf8_lossy(&self.partial[..whole]).into_owned();
        self.partial.drain(..whole);
        text
    }

    /// The key `c` ends, if it ends one that is a key.
    pub fn push(&mut self, c: char) -> Option<Key> {
        self.pending.push(c);
        self.take(false)
    }

    /// The key a pause ends, after ESC: Escape.
    pub fn pause(&mut self) -> Option<Key> {
        self.take(true)
    }

    fn take(&mut self, paused: bool) -> Option<Key> {
        let key = parse(&self.pending, paused).ok()?;
        self.pending.clear();
        key
    }
}

/// More is needed to know the key.
struct More;

/// The characters of a key so far. A pause reads as one empty character, as the escape timeout gives `emitKeys` one.
struct Reader<'a> {
    chars: &'a [char],
    at: usize,
    paused: bool,
}

impl Reader<'_> {
    fn next(&mut self) -> Result<Option<char>, More> {
        if let Some(&c) = self.chars.get(self.at) {
            self.at += 1;
            Ok(Some(c))
        } else if std::mem::take(&mut self.paused) {
            Ok(None)
        } else {
            Err(More)
        }
    }
}

/// `chars` as `emitKeys` reads them: a key, or nothing that is one, once they are enough.
fn parse(chars: &[char], paused: bool) -> Result<Option<Key>, More> {
    let mut r = Reader { chars, at: 0, paused };
    let mut ch = r.next()?;
    let mut escaped = false;
    if ch == Some(ESC) {
        escaped = true;
        ch = r.next()?;
        if ch == Some(ESC) {
            ch = r.next()?;
        }
    }
    let mut key = Key { name: Name::Other, ctrl: false, meta: false, shift: false, text: None };
    if escaped && matches!(ch, Some('O' | '[')) {
        let (code, modifier) = sequence(&mut r, ch == Some('O'))?;
        // xterm's modifier less one: 1 Shift, 2 Alt, 4 Ctrl, 8 Meta
        key.ctrl = modifier & 0b100 != 0;
        key.meta = modifier & 0b1010 != 0;
        key.shift = modifier & 0b1 != 0;
        let (name, shift, ctrl) = named(&code);
        key.name = name;
        key.shift |= shift;
        key.ctrl |= ctrl;
    } else {
        match ch {
            Some('\r') => key.name = Name::Return,
            Some('\n') => key.name = Name::Enter,
            Some('\x08' | '\x7f') => key.name = Name::Backspace,
            Some('\t' | ESC | ' ') => {}
            Some(c) if !escaped && c <= '\x1a' => {
                key.name = Name::Char(char::from(b'`' + u8::try_from(c).unwrap_or(0)));
                key.ctrl = true;
            }
            Some(c) if c.is_ascii_alphanumeric() => {
                key.name = Name::Char(c.to_ascii_lowercase());
                key.shift = c.is_ascii_uppercase();
            }
            _ => {}
        }
        key.meta = escaped;
    }
    if r.at == 0 {
        // the pause with nothing before it
        return Ok(None);
    }
    key.text = if escaped { None } else { ch };
    Ok(Some(key))
}

/// After ESC O or ESC [: the code `emitKeys` names the key by, and its modifiers, as xterm numbers them less one.
fn sequence(r: &mut Reader<'_>, o: bool) -> Result<(String, i32), More> {
    let digit = |c: Option<char>| c.filter(char::is_ascii_digit);
    let mut code = String::from(if o { 'O' } else { '[' });
    let mut modifier = 0;
    let mut ch = r.next()?;
    if o {
        if let Some(d) = digit(ch) {
            modifier = less_one(d);
            ch = r.next()?;
        }
        code.extend(ch);
        return Ok((code, modifier));
    }
    if ch == Some('[') {
        code.push('[');
        ch = r.next()?;
    }
    let start = r.at - 1;
    // up to three digits, then a modifier
    for _ in 0..3 {
        if digit(ch).is_none() {
            break;
        }
        ch = r.next()?;
    }
    if ch == Some(';') {
        ch = r.next()?;
        if digit(ch).is_some() {
            r.next()?;
        }
    }
    let cmd = &r.chars[start..r.at];
    match csi(cmd) {
        Some((part, m)) => {
            code.push_str(&part);
            modifier = m.unwrap_or(modifier);
        }
        None => code.extend(cmd),
    }
    Ok((code, modifier))
}

/// What `emitKeys`'s two patterns make of what follows ESC [: `\d\d?(;\d)?[~^$]` or `\d{3}~`, and `((\d;)?\d)?[A-Za-z]`. The
/// part of the code it gives, and the modifier, where it gives one.
fn csi(cmd: &[char]) -> Option<(String, Option<i32>)> {
    let digits = cmd.iter().take_while(|c| c.is_ascii_digit()).count();
    let (number, rest) = cmd.split_at(digits);
    let number: String = number.iter().collect();
    match (digits, rest) {
        (3, ['~']) => Some((number + "~", None)),
        (1 | 2, [t @ ('~' | '^' | '$')]) => Some((format!("{number}{t}"), Some(0))),
        (1 | 2, [';', m, t @ ('~' | '^' | '$')]) if m.is_ascii_digit() => {
            Some((format!("{number}{t}"), Some(less_one(*m))))
        }
        (0, [l]) if l.is_ascii_alphabetic() => Some((l.to_string(), Some(0))),
        (1, [l]) if l.is_ascii_alphabetic() => Some((l.to_string(), Some(less_one(cmd[0])))),
        (1, [';', m, l]) if m.is_ascii_digit() && l.is_ascii_alphabetic() => Some((l.to_string(), Some(less_one(*m)))),
        _ => None,
    }
}

/// A digit less one, as `emitKeys` makes a modifier of it: `0` is -1, every modifier at once.
fn less_one(digit: char) -> i32 {
    i32::from(u8::try_from(digit).unwrap_or(b'1')) - i32::from(b'1')
}

/// The key a code names, with the shift and ctrl its name says beyond the modifiers.
fn named(code: &str) -> (Name, bool, bool) {
    match code {
        "[C" | "OC" => (Name::Right, false, false),
        "[c" => (Name::Right, true, false),
        "Oc" => (Name::Right, false, true),
        "[D" | "OD" => (Name::Left, false, false),
        "[d" => (Name::Left, true, false),
        "Od" => (Name::Left, false, true),
        "[H" | "OH" | "[1~" | "[7~" => (Name::Home, false, false),
        "[7$" => (Name::Home, true, false),
        "[7^" => (Name::Home, false, true),
        "[F" | "OF" | "[4~" | "[8~" => (Name::End, false, false),
        "[8$" => (Name::End, true, false),
        "[8^" => (Name::End, false, true),
        "[3~" => (Name::Delete, false, false),
        "[3$" => (Name::Delete, true, false),
        "[3^" => (Name::Delete, false, true),
        _ => (Name::Other, false, false),
    }
}
