//! A question at a terminal, as the Node command asks one with `readline`'s `rl.question` when its output is a terminal:
//! `pick` in `src/cli/main.js`. The answer is edited as readline edits a line (`lib/internal/readline/interface.js` in Node
//! 24), with Emacs's keys, a ring of what was cut, undo and redo, and is drawn with the same bytes, its quirks included. There
//! is no history and no completion, as the picker has neither, and the question is over at its first line, where the picker
//! closes readline. The prompt is one line of plain text.
//!
//! [`Question`] is the logic, with no I/O; [`crate::run::ask`] gives it the terminal.

mod keys;

use std::fmt::Write as _;
use std::time::{Duration, Instant};

use nmux_term::wcwidth;

use keys::{Key, Keys, Name};

/// How long ESC waits for what follows it before it is the Escape key: readline's `ESCAPE_CODE_TIMEOUT`.
pub const ESCAPE_TIMEOUT: Duration = Duration::from_millis(500);
/// How far apart readline puts tab stops.
const TAB: usize = 8;
/// How many edits can be undone.
const UNDO_DEPTH: usize = 2048;
/// How much of what was cut is kept.
const KILL_RING: usize = 32;

/// Where a question is after what was read.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Step {
    /// Still asking.
    Asking,
    /// The line given, at Return or Enter.
    Answered(String),
    /// Given up: ^C, or ^D on an empty line.
    GaveUp,
    /// ^Z: the terminal's own modes are to be put back and this process stopped, and when it goes on, raw mode again and
    /// [`Question::redraw`].
    Stop,
}

/// A line being asked for.
#[derive(Debug)]
pub struct Question {
    prompt: Vec<char>,
    line: Vec<char>,
    cursor: usize,
    /// The rows the cursor is below the prompt's.
    below: usize,
    /// The terminal's width, or `usize::MAX` where it has not said.
    columns: usize,
    /// Whether TERM is `dumb`, where nothing is edited.
    dumb: bool,
    keys: Keys,
    /// Whether the key is the last of what was read: readline's `isCompletionEnabled`. A character typed before the last
    /// is written where the cursor is, without drawing again what is after it.
    last: bool,
    /// When ESC, read last, is the Escape key.
    escape_at: Option<Instant>,
    /// What was cut, the latest first: readline's kill ring.
    cut: Vec<Vec<char>>,
    /// Which of it a yank takes.
    yank_at: usize,
    /// Whether the last key yanked, so that Meta-Y can take what was cut before it instead.
    yanking: bool,
    /// The line and the cursor before each edit, and before each undoing.
    undo: Vec<(Vec<char>, usize)>,
    redo: Vec<(Vec<char>, usize)>,
}

impl Question {
    /// A question, not yet asked.
    pub fn new(prompt: &str) -> Self {
        Self {
            prompt: prompt.chars().collect(),
            line: Vec::new(),
            cursor: 0,
            below: 0,
            columns: usize::MAX,
            dumb: false,
            keys: Keys::default(),
            last: false,
            escape_at: None,
            cut: Vec::new(),
            yank_at: 0,
            yanking: false,
            undo: Vec::new(),
            redo: Vec::new(),
        }
    }

    /// Asks it at a terminal `columns` wide, 0 where it has not said. One whose TERM is `dumb` gets the prompt alone, and
    /// the line is not edited, as readline has it there.
    pub fn ask(&mut self, columns: u16, dumb: bool, out: &mut String) {
        self.set_columns(columns);
        self.dumb = dumb;
        if dumb {
            out.extend(&self.prompt);
        } else {
            self.cursor = 0;
            self.refresh(out);
        }
    }

    /// What the terminal sent, read at `now`. Once the question is answered or given up, it is over.
    pub fn read(&mut self, bytes: &[u8], now: Instant, columns: u16, out: &mut String) -> Step {
        self.set_columns(columns);
        let text = self.keys.decode(bytes);
        if text.is_empty() {
            return Step::Asking;
        }
        self.escape_at = None;
        // a stop waits for the rest of what was read, as the keys go on in Node once it is continued
        let mut stopped = false;
        let mut chars = text.chars().peekable();
        while let Some(c) = chars.next() {
            self.last = chars.peek().is_none();
            match self.keys.push(c).and_then(|key| self.key(key, out)) {
                Some(Step::Stop) => stopped = true,
                Some(ended) => return ended,
                None => {}
            }
            if self.last && c == '\x1b' {
                self.escape_at = Some(now + ESCAPE_TIMEOUT);
            }
        }
        if stopped { Step::Stop } else { Step::Asking }
    }

    /// When an ESC read last is the Escape key, if one was.
    pub fn escape_deadline(&self) -> Option<Instant> {
        self.escape_at
    }

    /// It is `now`, and nothing has been read since: an ESC read last whose time has come is the Escape key.
    pub fn wait(&mut self, now: Instant, out: &mut String) {
        if self.escape_at.is_some_and(|at| now >= at) {
            self.escape_at = None;
            if let Some(key) = self.keys.pause() {
                // Escape does nothing but end a yank
                let step = self.key(key, out);
                debug_assert_eq!(step, None);
            }
        }
    }

    /// Draws it again, on a terminal `columns` wide now: after its size changed, or a stop.
    pub fn redraw(&mut self, columns: u16, out: &mut String) {
        self.set_columns(columns);
        self.refresh(out);
    }

    fn set_columns(&mut self, columns: u16) {
        self.columns = if columns == 0 { usize::MAX } else { usize::from(columns) };
    }

    /// What a key does: readline's `_ttyWrite`. A step where it ends the question, or stops this process.
    fn key(&mut self, key: Key, out: &mut String) -> Option<Step> {
        if self.dumb {
            return self.dumb_key(key, out);
        }
        if !(key.meta && key.name == Name::Char('y')) {
            self.yanking = false;
        }
        match key.text {
            Some('\x1f') => self.undo(out),
            Some('\x1e') => self.redo(out),
            _ if key.ctrl && key.shift => match key.name {
                Name::Backspace => self.cut_left(out),
                Name::Delete => self.cut_right(out),
                _ => {}
            },
            _ if key.ctrl => match key.name {
                Name::Char('c') => return Some(Step::GaveUp),
                Name::Char('d') if self.line.is_empty() => return Some(Step::GaveUp),
                Name::Char('d') => self.delete_right(out),
                Name::Char('h') => self.delete_left(out),
                Name::Char('u') => self.cut_left(out),
                Name::Char('k') => self.cut_right(out),
                Name::Char('a') => self.move_to(0, out),
                Name::Char('e') => self.move_to(self.line.len(), out),
                Name::Char('b') => self.move_to(self.cursor.saturating_sub(1), out),
                Name::Char('f') => self.move_to(self.cursor + 1, out),
                Name::Char('l') => {
                    out.push_str("\x1b[1;1H\x1b[0J");
                    self.refresh(out);
                }
                Name::Char('y') => self.yank(out),
                Name::Char('z') => return Some(Step::Stop),
                Name::Char('w') | Name::Backspace => self.delete_word_left(out),
                Name::Delete => self.delete_word_right(out),
                Name::Left => self.word_left(out),
                Name::Right => self.word_right(out),
                // ^N and ^P go through a history, which a question asked once has none of
                _ => {}
            },
            _ if key.meta => match key.name {
                Name::Char('b') => self.word_left(out),
                Name::Char('f') => self.word_right(out),
                Name::Char('d') | Name::Delete => self.delete_word_right(out),
                Name::Backspace => self.delete_word_left(out),
                Name::Char('y') => self.yank_pop(out),
                _ => {}
            },
            _ => match key.name {
                Name::Return | Name::Enter => return Some(self.answer(out)),
                Name::Backspace => self.delete_left(out),
                Name::Delete => self.delete_right(out),
                Name::Left => self.move_to(self.cursor.saturating_sub(1), out),
                Name::Right => self.move_to(self.cursor + 1, out),
                Name::Home => self.move_to(0, out),
                Name::End => self.move_to(self.line.len(), out),
                _ => {
                    if let Some(c) = key.text {
                        self.insert(&[c], out);
                    }
                }
            },
        }
        None
    }

    /// What a key does where TERM is `dumb`: readline's `_ttyWriteDumb`. ^C and ^D give up, Return and Enter answer, and
    /// any other key that types a character adds it, a control character included.
    fn dumb_key(&mut self, key: Key, out: &mut String) -> Option<Step> {
        match key.name {
            Name::Char('c' | 'd') if key.ctrl => Some(Step::GaveUp),
            Name::Return | Name::Enter => Some(self.answer(out)),
            _ => {
                if let Some(c) = key.text {
                    self.line.push(c);
                    self.cursor += 1;
                    out.push(c);
                }
                None
            }
        }
    }

    /// The line as it is, as the answer, and the cursor to the line after it.
    fn answer(&mut self, out: &mut String) -> Step {
        self.move_to(self.line.len(), out);
        out.push_str("\r\n");
        Step::Answered(self.line.iter().collect())
    }

    /// The column and the row below the prompt's that the first `upto` characters of the line end at: readline's
    /// `_getDisplayPos`, with the terminal's own widths.
    fn position(&self, upto: usize) -> (usize, usize) {
        let columns = self.columns;
        let (mut offset, mut rows) = (0usize, 0usize);
        for &c in self.prompt.iter().chain(&self.line[..upto]) {
            match c {
                '\n' => {
                    rows += offset.div_ceil(columns).max(1);
                    offset = 0;
                }
                '\t' => offset += TAB - offset % TAB,
                _ => match wcwidth(u32::from(c)) {
                    2 => {
                        // a wide character that would be cut by the edge goes to the next row
                        if (offset + 1) % columns == 0 {
                            offset += 1;
                        }
                        offset += 2;
                    }
                    w => offset += w as usize,
                },
            }
        }
        (offset % columns, rows + offset / columns)
    }

    /// The prompt and the line drawn again, from where the prompt starts: readline's `_refreshLine`.
    fn refresh(&mut self, out: &mut String) {
        let (end_column, end_row) = self.position(self.line.len());
        let (column, row) = self.position(self.cursor);
        if self.below > 0 {
            let _ = write!(out, "\x1b[{}A", self.below);
        }
        out.push_str("\x1b[1G\x1b[0J");
        out.extend(&self.prompt);
        out.extend(&self.line);
        if end_column == 0 {
            // a line that ends at the edge, which the terminal moves on from only when something is written
            out.push(' ');
        }
        let _ = write!(out, "\x1b[{}G", column + 1);
        if end_row > row {
            let _ = write!(out, "\x1b[{}A", end_row - row);
        }
        self.below = row;
    }

    /// The cursor to `to`, or as near as the line lets it.
    fn move_to(&mut self, to: usize, out: &mut String) {
        let (from_column, from_row) = self.position(self.cursor);
        self.cursor = to.min(self.line.len());
        let (column, row) = self.position(self.cursor);
        if row != from_row {
            self.refresh(out);
        } else if column > from_column {
            let _ = write!(out, "\x1b[{}C", column - from_column);
        } else if column < from_column {
            let _ = write!(out, "\x1b[{}D", from_column - column);
        }
    }

    /// Keeps the line as it is, to come back to.
    fn remember(&mut self) {
        self.undo.push((self.line.clone(), self.cursor));
        if self.undo.len() > UNDO_DEPTH {
            self.undo.remove(0);
        }
    }

    fn insert(&mut self, text: &[char], out: &mut String) {
        self.remember();
        let at = self.cursor;
        if !self.last {
            self.line.splice(at..at, text.iter().copied());
            self.cursor += text.len();
            out.extend(text);
        } else if at < self.line.len() {
            self.line.splice(at..at, text.iter().copied());
            self.cursor += text.len();
            self.refresh(out);
        } else {
            let (_, from_row) = self.position(at);
            self.line.extend_from_slice(text);
            self.cursor += text.len();
            if self.position(self.cursor).1 > from_row {
                self.refresh(out);
            } else {
                out.extend(text);
            }
        }
    }

    fn delete_left(&mut self, out: &mut String) {
        if self.cursor > 0 {
            self.remember();
            self.cursor -= 1;
            self.line.remove(self.cursor);
            self.refresh(out);
        }
    }

    fn delete_right(&mut self, out: &mut String) {
        if self.cursor < self.line.len() {
            self.remember();
            self.line.remove(self.cursor);
            self.refresh(out);
        }
    }

    fn word_left(&mut self, out: &mut String) {
        if self.cursor > 0 {
            let n = word_back(&self.line[..self.cursor]);
            self.move_to(self.cursor - n, out);
        }
    }

    fn word_right(&mut self, out: &mut String) {
        if self.cursor < self.line.len() {
            let n = word_on(&self.line[self.cursor..], false);
            self.move_to(self.cursor + n, out);
        }
    }

    fn delete_word_left(&mut self, out: &mut String) {
        if self.cursor > 0 {
            self.remember();
            let n = word_back(&self.line[..self.cursor]);
            self.line.drain(self.cursor - n..self.cursor);
            self.cursor -= n;
            self.refresh(out);
        }
    }

    fn delete_word_right(&mut self, out: &mut String) {
        if self.cursor < self.line.len() {
            self.remember();
            let n = word_on(&self.line[self.cursor..], true);
            self.line.drain(self.cursor..self.cursor + n);
            self.refresh(out);
        }
    }

    /// Cuts the line before the cursor, into the ring.
    fn cut_left(&mut self, out: &mut String) {
        self.remember();
        let cut: Vec<char> = self.line.drain(..self.cursor).collect();
        self.cursor = 0;
        self.keep(cut);
        self.refresh(out);
    }

    /// Cuts the line from the cursor on, into the ring.
    fn cut_right(&mut self, out: &mut String) {
        self.remember();
        let cut = self.line.split_off(self.cursor);
        self.keep(cut);
        self.refresh(out);
    }

    fn keep(&mut self, cut: Vec<char>) {
        if cut.is_empty() || self.cut.first() == Some(&cut) {
            return;
        }
        self.cut.insert(0, cut);
        self.yank_at = 0;
        self.cut.truncate(KILL_RING);
    }

    fn yank(&mut self, out: &mut String) {
        if let Some(text) = self.cut.get(self.yank_at).cloned() {
            self.yanking = true;
            self.insert(&text, out);
        }
    }

    /// What was yanked last replaced with what was cut before it.
    fn yank_pop(&mut self, out: &mut String) {
        if !self.yanking || self.cut.len() < 2 {
            return;
        }
        let before = self.cut[self.yank_at].len();
        self.yank_at = (self.yank_at + 1) % self.cut.len();
        let text = &self.cut[self.yank_at];
        let start = self.cursor - before;
        self.line.splice(start..self.cursor, text.iter().copied());
        self.cursor = start + text.len();
        self.refresh(out);
    }

    fn undo(&mut self, out: &mut String) {
        if let Some((line, cursor)) = self.undo.pop() {
            self.redo.push((std::mem::replace(&mut self.line, line), std::mem::replace(&mut self.cursor, cursor)));
            self.refresh(out);
        }
    }

    fn redo(&mut self, out: &mut String) {
        if let Some((line, cursor)) = self.redo.pop() {
            self.undo.push((std::mem::replace(&mut self.line, line), std::mem::replace(&mut self.cursor, cursor)));
            self.refresh(out);
        }
    }
}

/// JavaScript's `\s`.
fn is_space(c: char) -> bool {
    matches!(c, '\t'..='\r' | ' ' | '\u{a0}' | '\u{1680}' | '\u{2000}'..='\u{200a}' | '\u{2028}' | '\u{2029}')
        || matches!(c, '\u{202f}' | '\u{205f}' | '\u{3000}' | '\u{feff}')
}

/// JavaScript's `\w`.
fn is_word(c: char) -> bool {
    c.is_ascii_alphanumeric() || c == '_'
}

/// How many characters a word back from the end of `before` goes: readline's `/^\s*(?:[^\w\s]+|\w+)?/` on them reversed.
fn word_back(before: &[char]) -> usize {
    let mut back = before.iter().rev().copied().peekable();
    let mut n = 0;
    while back.next_if(|&c| is_space(c)).is_some() {
        n += 1;
    }
    match back.peek() {
        Some(&c) if is_word(c) => n + back.take_while(|&c| is_word(c)).count(),
        Some(_) => n + back.take_while(|&c| !is_word(c) && !is_space(c)).count(),
        None => n,
    }
}

/// How many characters a word on from the start of `after` goes: `/^(?:\s+|[^\w\s]+|\w+)\s*/`, or, to delete it,
/// `/^(?:\s+|\W+|\w+)\s*/`, where what is not a word takes the spaces in it too.
fn word_on(after: &[char], deleting: bool) -> usize {
    let first = after[0];
    let alike = |c: char| {
        if is_space(first) {
            is_space(c)
        } else if is_word(first) {
            is_word(c)
        } else {
            !is_word(c) && (deleting || !is_space(c))
        }
    };
    let n = after.iter().take_while(|&&c| alike(c)).count();
    n + after[n..].iter().take_while(|&&c| is_space(c)).count()
}
