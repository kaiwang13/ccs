//! One request on a control connection: `src/wire/ctlclient.js`. HELLO as `role: "control"`, one REQ, and the matching RES,
//! with any OUTPUT that came before it. Control connections never count in arbitration. A run loop that waits for nothing
//! else uses this; it blocks for at most the time it is given.

use std::fmt;
use std::io::{self, Read};
use std::path::Path;
use std::time::{Duration, Instant};

use nmux_io::{InBuf, OutBuf, UnixStream};
use nmux_wire::{Control, Frame, Hello};
use rustix::event::{PollFd, PollFlags, Timespec};
use serde_json::Value;

/// A request that did not get an answer: the code says why, as `err.code` does in the Node code.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct CtlError {
    /// `TIMEOUT`, `CLOSED`, `BYE`, `REFUSED`, `ENOENT`, `ECONNREFUSED`, `DOWN` and so on.
    pub code: String,
    /// For a person.
    pub message: String,
}

impl CtlError {
    /// An error with this code and message.
    pub fn new(code: &str, message: impl Into<String>) -> Self {
        Self { code: code.to_owned(), message: message.into() }
    }
}

impl fmt::Display for CtlError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.message)
    }
}

impl std::error::Error for CtlError {}

/// The answer to a request.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Reply {
    /// It worked.
    pub ok: bool,
    /// What it returned, or null.
    pub data: Value,
    /// Why it did not work.
    pub error: Option<String>,
    /// The text that came before the answer, in OUTPUT frames.
    pub output: Vec<u8>,
}

/// The name Node gives an error from the system, as `err.code`.
pub(crate) fn errno_code(e: &io::Error) -> String {
    let named = match e.kind() {
        io::ErrorKind::NotFound => "ENOENT",
        io::ErrorKind::ConnectionRefused => "ECONNREFUSED",
        io::ErrorKind::PermissionDenied => "EACCES",
        io::ErrorKind::ConnectionReset => "ECONNRESET",
        io::ErrorKind::BrokenPipe => "EPIPE",
        io::ErrorKind::WouldBlock => "EAGAIN",
        io::ErrorKind::NotADirectory => "ENOTDIR",
        io::ErrorKind::InvalidInput => "EINVAL",
        _ => "ESOCKET",
    };
    named.to_owned()
}

/// A connection read and written with deadlines, for code that waits for its answers.
#[derive(Debug)]
pub(crate) struct Wire {
    stream: UnixStream,
    inbuf: InBuf,
    pub(crate) out: OutBuf,
    closed: bool,
    buf: Vec<u8>,
}

/// A frame read off a [`Wire`], owned.
#[derive(Debug)]
#[allow(clippy::large_enum_variant)] // handled as it is read, and never kept
pub(crate) enum Owned {
    Control(Control),
    Output(Vec<u8>),
}

impl Wire {
    /// Connects to the socket at `path`.
    pub(crate) fn connect(path: &Path) -> Result<Self, CtlError> {
        let stream = UnixStream::connect(path).map_err(|e| {
            let code = errno_code(&e);
            CtlError::new(&code, format!("connect {code} {}", path.display()))
        })?;
        Ok(Self { stream, inbuf: InBuf::new(), out: OutBuf::new(), closed: false, buf: vec![0; 65536] })
    }

    /// Waits until the socket is ready for `flags`, or `deadline`. False when the time ran out.
    fn wait(&self, flags: PollFlags, deadline: Option<Instant>) -> io::Result<bool> {
        let left = deadline.map(|d| d.saturating_duration_since(Instant::now()));
        let timeout = left.map(|l| Timespec::try_from(l.min(Duration::from_secs(3600))).unwrap_or_default());
        let mut fds = [PollFd::new(&self.stream, flags)];
        match rustix::event::poll(&mut fds, timeout.as_ref()) {
            Ok(n) => Ok(n > 0),
            Err(rustix::io::Errno::INTR) => Ok(false),
            Err(e) => Err(e.into()),
        }
    }

    /// Writes what is queued, waiting for the socket as long as `deadline` allows.
    pub(crate) fn flush(&mut self, deadline: Option<Instant>) -> io::Result<()> {
        while !self.out.is_empty() {
            if self.out.write_to(&mut self.stream)? {
                return Ok(());
            }
            if !self.wait(PollFlags::OUT, deadline)? && deadline.is_some_and(|d| Instant::now() >= d) {
                return Err(io::ErrorKind::TimedOut.into());
            }
        }
        Ok(())
    }

    /// Writes what is queued as far as the socket takes it now.
    pub(crate) fn flush_now(&mut self) -> io::Result<()> {
        self.out.write_to(&mut self.stream).map(|_| ())
    }

    /// The frames that have come, after waiting for some until `deadline`: none when the time ran out. `Ok(None)` when the
    /// peer has closed and everything it sent has been handed out.
    pub(crate) fn read(&mut self, deadline: Option<Instant>) -> io::Result<Option<Vec<Owned>>> {
        loop {
            let mut frames = Vec::new();
            let decoded = self.inbuf.frames(|f| match f {
                Frame::Control(c) => frames.push(Owned::Control(c)),
                Frame::Output(b) => frames.push(Owned::Output(b.to_vec())),
                _ => {}
            });
            if let Err(e) = decoded {
                return Err(io::Error::new(io::ErrorKind::InvalidData, e));
            }
            if !frames.is_empty() {
                return Ok(Some(frames));
            }
            if self.closed {
                return Ok(None);
            }
            if !self.out.is_empty() {
                self.flush_now()?;
            }
            match self.stream.read(&mut self.buf) {
                Ok(0) => self.closed = true,
                Ok(n) => self.inbuf.push(&self.buf[..n]),
                Err(e) if e.kind() == io::ErrorKind::WouldBlock => {
                    let flags = if self.out.is_empty() { PollFlags::IN } else { PollFlags::IN | PollFlags::OUT };
                    if !self.wait(flags, deadline)? && deadline.is_some_and(|d| Instant::now() >= d) {
                        return Ok(Some(Vec::new()));
                    }
                }
                Err(e) if e.kind() == io::ErrorKind::Interrupted => {}
                Err(e) => return Err(e),
            }
        }
    }
}

/// Sends `op` with `args` to the session listening at `sock`, and waits up to `timeout_ms` for the answer. `label` is what the
/// session's list of connections calls this one.
pub fn control_request(sock: &Path, op: &str, args: Value, timeout_ms: u64, label: &str) -> Result<Reply, CtlError> {
    let deadline = Instant::now() + Duration::from_millis(timeout_ms);
    let shown = sock.display().to_string();
    let timed_out = || CtlError::new("TIMEOUT", format!("no reply from {shown} within {timeout_ms} ms"));
    let failed = |e: io::Error| {
        if e.kind() == io::ErrorKind::TimedOut {
            return timed_out();
        }
        CtlError::new(&errno_code(&e), e.to_string())
    };
    let mut wire = Wire::connect(sock)?;
    let pid = u32::try_from(nmux_platform::pid()).unwrap_or(0);
    let _ = wire.out.control(&Control::Hello(Hello::control(pid, label)));
    let _ = wire.out.control(&Control::Req { id: Value::from(1), op: op.to_owned(), args });
    wire.flush(Some(deadline)).map_err(failed)?;
    let mut output = Vec::new();
    loop {
        if Instant::now() >= deadline {
            return Err(timed_out());
        }
        let Some(frames) = wire.read(Some(deadline)).map_err(failed)? else {
            return Err(CtlError::new("CLOSED", format!("{shown} closed before replying")));
        };
        for frame in frames {
            match frame {
                Owned::Output(bytes) => output.extend_from_slice(&bytes),
                Owned::Control(Control::Ping { seq }) => {
                    let _ = wire.out.control(&Control::Pong { seq });
                    let _ = wire.flush_now();
                }
                Owned::Control(Control::Res(res)) if res.id == 1 => {
                    return Ok(Reply { ok: res.ok, data: res.data.unwrap_or(Value::Null), error: res.error, output });
                }
                Owned::Control(Control::Refuse { code, text, .. }) => {
                    let message = if text.is_empty() { format!("refused: {code}") } else { text };
                    let code = if code.is_empty() { "REFUSED".to_owned() } else { code };
                    return Err(CtlError::new(&code, message));
                }
                Owned::Control(Control::Bye(bye)) => {
                    let message = if bye.text.is_empty() { format!("closed: {}", bye.reason) } else { bye.text };
                    return Err(CtlError::new("BYE", message));
                }
                Owned::Control(_) => {}
            }
        }
    }
}

/// Whether something accepts connections at `sock`.
pub fn probe_socket(sock: &Path) -> bool {
    std::os::unix::net::UnixStream::connect(sock).is_ok()
}
