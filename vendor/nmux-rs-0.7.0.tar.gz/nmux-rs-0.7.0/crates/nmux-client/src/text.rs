//! Everything the attach client prints, in one place: `DEFAULT_TEXT` in `src/client/text.js`. What a program that embeds nmux
//! may say in its own words is a table of templates, [`Words`], since it comes as data rather than as functions.

use nmux_wire::ClientInfo;
use serde_json::Value;

use crate::keytable::KeySpec;

/// Why a client stopped, for the line it leaves.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Leaving {
    /// The person detached.
    Detached,
    /// The server let it go and the session runs on.
    ClientExit,
    /// Someone sent it away.
    Kicked,
    /// The session ended.
    Ended,
    /// It could not reconnect.
    Lost,
    /// It stopped trying.
    GaveUp,
}

/// What the client says that a program embedding it may say otherwise: nmux's own words unless it does. Each is a template, and
/// `{name}` in it is filled in with what that hole holds. A program gives any of them, by their names in camelCase; the lines a
/// client leaves behind are dimmed, and a refusal's lines end as a terminal in raw mode needs.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Words {
    /// Who is speaking: `nmux`.
    pub brand: String,
    /// What a shell in a session has, naming it: `NMUX_ID`.
    pub nest_env: String,
    /// Said when attaching from inside another multiplexer.
    pub inside_multiplexer: String,
    /// Refusing to attach from inside a session: `{id}`.
    pub refuse_nested: String,
    /// The line left on detaching, with nobody else attached: `{name}`, `{time}`.
    pub detached: String,
    /// The same, with one other terminal attached.
    pub detached_one: String,
    /// The same, with `{others}` attached.
    pub detached_many: String,
    /// Sent away, saying by whom: `{reason}`.
    pub kicked_by: String,
    /// Sent away, saying nothing.
    pub kicked: String,
    /// Let go by the server, the session running on.
    pub client_exit: String,
    /// The session ended, saying why: `{reason}`.
    pub ended_why: String,
    /// The session ended.
    pub ended: String,
    /// It stopped trying to reconnect, saying why: `{reason}`.
    pub gave_up_why: String,
    /// It stopped trying.
    pub gave_up: String,
    /// It could not reconnect.
    pub lost: String,
    /// A terminal too short to join, a line at a time: `{cols}`, `{rows}`, `{need}` rows, `{name}`.
    pub too_short: String,
    /// A terminal too narrow to join, `{need}` columns, where `--shrink` would not help or is already given; also
    /// `{hardMinCols}`.
    pub too_narrow: String,
    /// The same, where `--shrink` would let it join.
    pub too_narrow_shrink: String,
}

impl Default for Words {
    fn default() -> Self {
        let narrow = "nmux: this terminal is {cols}x{rows} — below the {need}-column floor for shared sessions\n     resize it (I will attach automatically)\n     (Ctrl+C gives up)";
        let own = |s: &str| s.to_owned();
        Self {
            brand: own("nmux"),
            nest_env: own("NMUX_ID"),
            inside_multiplexer: own(
                "nmux: warning: running inside tmux/screen — its own scrollback handling may hide history\n",
            ),
            refuse_nested: own(
                "nmux: refusing to attach from inside a session (NMUX_ID={id}) — that would nest one session inside another; detach first",
            ),
            detached: own("── nmux · detached from {name} {time} · still running · nmux a {name} ──"),
            detached_one: own(
                "── nmux · detached from {name} {time} · still running (1 other client) · nmux a {name} ──",
            ),
            detached_many: own(
                "── nmux · detached from {name} {time} · still running ({others} other clients) · nmux a {name} ──",
            ),
            kicked_by: own("── nmux · detached from {name} {time} by {reason} · still running · nmux a {name} ──"),
            kicked: own("── nmux · detached from {name} {time} · still running · nmux a {name} ──"),
            client_exit: own("── nmux · detached from {name} {time} · the session keeps running ──"),
            ended_why: own("── nmux · {name} ended {time} ({reason}) ──"),
            ended: own("── nmux · {name} ended {time} ──"),
            gave_up_why: own("── nmux · disconnected from {name} {time} · {reason} ──"),
            gave_up: own("── nmux · disconnected from {name} {time} ──"),
            lost: own("── nmux · lost connection to {name} {time} ──"),
            too_short: own(
                "nmux: this terminal is {cols}x{rows} — below the {need}-row floor for shared sessions\n     resize it (I will attach automatically)\n     (Ctrl+C gives up)",
            ),
            too_narrow: own(narrow),
            too_narrow_shrink: own(narrow),
        }
    }
}

/// `template` with each `{hole}` it has a value for filled in, once: what goes in is not looked through again.
fn fill(template: &str, holes: &[(&str, &str)]) -> String {
    let mut out = String::with_capacity(template.len());
    let mut rest = template;
    while let Some(open) = rest.find('{') {
        out.push_str(&rest[..open]);
        let after = &rest[open + 1..];
        let hole = after
            .find('}')
            .and_then(|close| holes.iter().find(|(k, _)| *k == &after[..close]).map(|(_, v)| (close, v)));
        if let Some((close, value)) = hole {
            out.push_str(value);
            rest = &after[close + 1..];
        } else {
            out.push('{');
            rest = after;
        }
    }
    out.push_str(rest);
    out
}

impl Words {
    /// These words with those `table` gives in place of them: an object whose fields are named as [`Words`]'s are, in
    /// camelCase. What is not text is passed over.
    #[must_use]
    pub fn over(mut self, table: &Value) -> Self {
        let fields: [(&str, &mut String); 18] = [
            ("brand", &mut self.brand),
            ("nestEnv", &mut self.nest_env),
            ("insideMultiplexer", &mut self.inside_multiplexer),
            ("refuseNested", &mut self.refuse_nested),
            ("detached", &mut self.detached),
            ("detachedOne", &mut self.detached_one),
            ("detachedMany", &mut self.detached_many),
            ("kickedBy", &mut self.kicked_by),
            ("kicked", &mut self.kicked),
            ("clientExit", &mut self.client_exit),
            ("endedWhy", &mut self.ended_why),
            ("ended", &mut self.ended),
            ("gaveUpWhy", &mut self.gave_up_why),
            ("gaveUp", &mut self.gave_up),
            ("lost", &mut self.lost),
            ("tooShort", &mut self.too_short),
            ("tooNarrow", &mut self.too_narrow),
            ("tooNarrowShrink", &mut self.too_narrow_shrink),
        ];
        for (name, field) in fields {
            if let Some(text) = table.get(name).and_then(Value::as_str) {
                text.clone_into(field);
            }
        }
        self
    }

    /// The refusal of a client attaching from inside a session.
    pub fn refuse_nested(&self, id: &str) -> String {
        fill(&self.refuse_nested, &[("id", id)])
    }

    /// The line a client leaves in the terminal when it goes. `hhmm` is the time, as `14:03`.
    pub fn detach_line(&self, kind: Leaving, name: &str, others: usize, hhmm: &str, reason: Option<&str>) -> String {
        let template = match (kind, reason) {
            (Leaving::Detached, _) => match others {
                0 => &self.detached,
                1 => &self.detached_one,
                _ => &self.detached_many,
            },
            (Leaving::Kicked, Some(_)) => &self.kicked_by,
            (Leaving::Kicked, None) => &self.kicked,
            (Leaving::ClientExit, _) => &self.client_exit,
            (Leaving::Ended, Some(_)) => &self.ended_why,
            (Leaving::Ended, None) => &self.ended,
            (Leaving::GaveUp, Some(_)) => &self.gave_up_why,
            (Leaving::GaveUp, None) => &self.gave_up,
            (Leaving::Lost, _) => &self.lost,
        };
        let others = others.to_string();
        let line =
            fill(template, &[("name", name), ("time", hhmm), ("others", &others), ("reason", reason.unwrap_or(""))]);
        format!("\x1b[2m{line}\x1b[0m\r\n")
    }

    /// What a terminal too small to join is told, `name` being the session's: each line ends in CRLF.
    pub fn floor_message(
        &self,
        code: &str,
        (cols, rows): (u32, u32),
        (need_cols, need_rows): (u32, u32),
        name: &str,
        shrink: bool,
        hard_min_cols: u32,
    ) -> String {
        let (template, need) = if code == "TOO_SHORT" {
            (&self.too_short, need_rows)
        } else if shrink || cols < hard_min_cols {
            (&self.too_narrow, need_cols)
        } else {
            (&self.too_narrow_shrink, need_cols)
        };
        let (cols, rows, need, hard) =
            (cols.to_string(), rows.to_string(), need.to_string(), hard_min_cols.to_string());
        let text = fill(
            template,
            &[("cols", &cols), ("rows", &rows), ("need", &need), ("name", name), ("hardMinCols", &hard)],
        );
        text.split('\n').flat_map(|l| [l, "\r\n"]).collect()
    }

    /// Why a terminal cannot attach, checked before anything else: its exit code and what to say.
    pub fn precheck(&self, stdin_tty: bool, stdout_tty: bool, nested: Option<&str>) -> Option<(i32, String)> {
        if !stdin_tty || !stdout_tty {
            let brand = &self.brand;
            return Some((
                2,
                format!("{brand}: attach needs an interactive terminal (stdin and stdout must both be a TTY)"),
            ));
        }
        nested.filter(|v| !v.is_empty()).map(|id| (2, self.refuse_nested(id)))
    }
}

/// `C-\` as a person writes it.
fn spoken(key: &str) -> String {
    key.strip_prefix("C-").map_or_else(|| key.to_owned(), |k| format!("Ctrl+{k}"))
}

fn action_text(action: &str) -> &str {
    match action {
        "detach" => "detach",
        "clients" => "who is attached",
        "history" => "history, in a pager",
        "bar" => "the bar at the bottom, on or off",
        "help" => "this help",
        other => other,
    }
}

/// `padEnd` in characters, as JavaScript counts them for these.
fn pad_end(s: &str, width: usize) -> String {
    let len = s.encode_utf16().count();
    format!("{s}{}", " ".repeat(width.saturating_sub(len)))
}

/// The help screen.
pub fn help(brand: &str, name: &str, keys: &KeySpec) -> Vec<String> {
    let leader = spoken(keys.leader.as_deref().unwrap_or(""));
    let mut lines = vec![format!("{brand} · {name}"), String::new()];
    for (k, a) in &keys.bindings {
        lines.push(format!("  {leader} {}{}", pad_end(&spoken(k), 8), action_text(a)));
    }
    lines.push(format!("  {leader} {}send a literal {leader}", pad_end(&leader, 8)));
    lines.extend([String::new(), "Any key to go back.".to_owned()]);
    lines
}

/// Who is attached.
pub fn who_is_attached(brand: &str, name: &str, clients: &[ClientInfo]) -> Vec<String> {
    let mut lines = vec![format!("{brand} · {name}"), String::new()];
    for c in clients {
        let view = if c.view { "  view only" } else { "" };
        lines.push(format!("  {}{}  {}x{}{view}", pad_end(&c.id, 5), c.label, c.cols, c.rows));
    }
    lines.extend([String::new(), "Any key to go back.".to_owned()]);
    lines
}
