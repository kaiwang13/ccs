//! The terminal's default colours, as it answers OSC 10 and 11: `src/client/termcolors.js`. They are said in HELLO, where a
//! tint behind the screen is worked out from them, and kept in a session's spec, where the holder answers a program's own
//! one-shot query with them. They are written into a pty as an escape sequence, so only the one reply form is ever kept, and
//! it is checked again at every boundary it crosses.

/// What asks a terminal for both colours.
pub const QUERY: &str = "\x1b]10;?\x1b\\\x1b]11;?\x1b\\";

/// Whether `spec` is `rgb:R/G/B` with one to four hex digits each: the only reply form ever echoed back into a pty.
pub fn is_color(spec: &[u8]) -> bool {
    let Some(rest) = spec.strip_prefix(b"rgb:") else { return false };
    let parts: Vec<&[u8]> = rest.split(|&b| b == b'/').collect();
    parts.len() == 3 && parts.iter().all(|p| (1..=4).contains(&p.len()) && p.iter().all(u8::is_ascii_hexdigit))
}

/// One reply to OSC 10 or 11 in a terminal's input.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Reply<'a> {
    start: usize,
    end: usize,
    foreground: bool,
    spec: &'a [u8],
}

/// The replies in `s`, in order: `ESC ] 10|11 ; spec` ended by BEL or `ESC \`.
fn replies(s: &[u8]) -> Vec<Reply<'_>> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < s.len() {
        if let Some(r) = reply_at(s, i) {
            i = r.end;
            out.push(r);
        } else {
            i += 1;
        }
    }
    out
}

fn reply_at(s: &[u8], i: usize) -> Option<Reply<'_>> {
    let rest = s.get(i..)?;
    let foreground = if rest.starts_with(b"\x1b]10;") {
        true
    } else if rest.starts_with(b"\x1b]11;") {
        false
    } else {
        return None;
    };
    let from = i + 5;
    let len = s[from..].iter().take_while(|&&b| b != 0x07 && b != 0x1b).count();
    let at = from + len;
    let end = match s.get(at..)? {
        [0x07, ..] => at + 1,
        [0x1b, b'\\', ..] => at + 2,
        _ => return None,
    };
    Some(Reply { start: i, end, foreground, spec: &s[from..at] })
}

/// The colours a terminal said, foreground and background, as `rgb:…`; a reply in any other form is none.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Colors {
    /// OSC 10.
    pub fg: Option<String>,
    /// OSC 11.
    pub bg: Option<String>,
}

/// The colours in a terminal's replies. A later reply for the same colour wins.
pub fn parse_color_replies(s: &[u8]) -> Colors {
    let mut out = Colors::default();
    for r in replies(s) {
        let value = is_color(r.spec).then(|| String::from_utf8_lossy(r.spec).into_owned());
        if r.foreground {
            out.fg = value;
        } else {
            out.bg = value;
        }
    }
    out
}

/// What is left of a terminal's input once the replies are taken out: what was typed meanwhile.
pub fn without_replies(s: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(s.len());
    let mut last = 0;
    for r in replies(s) {
        out.extend_from_slice(&s[last..r.start]);
        last = r.end;
    }
    out.extend_from_slice(&s[last..]);
    out
}

/// Whether input is a terminal's whole answer to OSC 10 or 11, and not something typed.
pub fn is_color_reply(bytes: &[u8]) -> bool {
    bytes.starts_with(b"\x1b]") && without_replies(bytes).is_empty()
}
