//! What the client knows about the user's terminal from what it wrote there: `src/client/terminal.js`, without the I/O, which
//! is the run loop's. Whether the session left it on the alternate screen, the kitty keyboard flags it was told and whether
//! it speaks that protocol at all, what turns everything a program set off again, and the cursor report it answers with.

use nmux_vt::kitty::{self, Stack};

const ALT_MODES: [&[u8]; 3] = [b"47", b"1047", b"1049"];

/// A cursor position report, `CSI row ; col R`, found in what the terminal sent.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Cpr {
    /// The row, from 1.
    pub row: u32,
    /// The column, from 1.
    pub col: u32,
    /// Where it starts.
    pub index: usize,
    /// How long it is.
    pub length: usize,
}

/// The first cursor position report in `s`.
pub fn parse_cpr(s: &[u8]) -> Option<Cpr> {
    let digits = |from: usize| s.get(from..).map_or(0, |r| r.iter().take_while(|b| b.is_ascii_digit()).count());
    let number = |from: usize, len: usize| {
        s[from..from + len].iter().fold(0u32, |n, &b| n.saturating_mul(10).saturating_add(u32::from(b - b'0')))
    };
    (0..s.len()).find_map(|i| {
        if !s[i..].starts_with(b"\x1b[") {
            return None;
        }
        let row_len = digits(i + 2);
        let semi = i + 2 + row_len;
        if row_len == 0 || s.get(semi) != Some(&b';') {
            return None;
        }
        let col_len = digits(semi + 1);
        let end = semi + 1 + col_len;
        (col_len > 0 && s.get(end) == Some(&b'R')).then(|| Cpr {
            row: number(i + 2, row_len),
            col: number(semi + 1, col_len),
            index: i,
            length: end + 1 - i,
        })
    })
}

/// What a program set that would confuse whatever has the terminal next: reports of the mouse, focus and pastes, the kitty
/// keyboard, margins, the alternate screen. The keyboard flags come off the screen they were told on, before it is left.
pub fn modes_off(alt: bool, kitty_depth: usize) -> String {
    let mut s = String::from("\x1b[?2026l");
    s.push_str("\x1b[?2004l\x1b[?1004l\x1b[?2031l");
    s.push_str("\x1b[?1000l\x1b[?1002l\x1b[?1003l\x1b[?1005l\x1b[?1006l\x1b[?1015l\x1b[?1016l");
    s.push_str("\x1b[?25h\x1b[0m");
    s.push_str("\x1b7\x1b[r\x1b8");
    s.push_str(&kitty_pop(kitty_depth));
    if alt {
        s.push_str("\x1b[?1049l");
    }
    s
}

/// What pops this many kitty keyboard entries.
pub fn kitty_pop(depth: usize) -> String {
    match depth {
        0 => String::new(),
        1 => "\x1b[<u".to_owned(),
        n => format!("\x1b[<{n}u"),
    }
}

/// The terminal as a detach leaves it. Order matters: margins are reset with ESC 7 / ESC[r / ESC 8 before leaving the
/// alternate screen, then the cursor goes to the last row and one CRLF scrolls a fresh line into view. No RIS, ED2 or ED0,
/// ever: each of those wipes or truncates the user's scrollback in some terminal.
/// With nmux's bar there, its row is the fresh line: it is cleared rather than scrolled up into what is left on the screen.
pub fn detach_bytes(rows: u32, alt: bool, kitty_depth: usize, bar: bool) -> String {
    format!("{}\x1b[{};1H{}", modes_off(alt, kitty_depth), rows.max(1), if bar { "\x1b[2K" } else { "\r\n" })
}

/// What takes nmux's bar off a terminal `rows` tall, its row given back, with the cursor where it was.
pub fn bar_gone(rows: u32) -> String {
    format!("\x1b7\x1b[r\x1b[{rows};1H\x1b[2K\x1b8")
}

/// The kitty keyboard flags in relayed output (`CSI > flags u`, `CSI < n u`, `CSI = flags ; how u`), so that detaching pops
/// only what was pushed, and so that keys from a terminal that does not speak the protocol can be put in the form they ask
/// for. A server of this version pushes at most one entry, and says nothing else of the program's.
#[derive(Debug, Default)]
pub struct KittyTracker {
    stack: Stack,
    carry: Vec<u8>,
}

impl KittyTracker {
    /// Takes in more output.
    pub fn feed(&mut self, buf: &[u8]) {
        let s = joined(&mut self.carry, buf);
        let mut i = 0;
        while i < s.len() {
            if s[i] != 0x1b {
                i += 1;
            } else if s.get(i + 1) == Some(&b'c') {
                self.stack = Stack::default(); // RIS
                i += 2;
            } else if let Some((op, len)) = kitty::op_at(&s[i..]) {
                self.stack.apply(op);
                i += len;
            } else {
                i += 1;
            }
        }
        let tail = s.iter().rposition(|&b| b == 0x1b).map(|at| &s[at..]);
        self.carry = tail.filter(|t| t.len() < 12 && !t.contains(&b'u')).map(<[u8]>::to_vec).unwrap_or_default();
    }

    /// How many entries were pushed.
    pub fn depth(&self) -> usize {
        self.stack.entries().len()
    }

    /// The flags in force.
    pub fn flags(&self) -> u8 {
        self.stack.flags()
    }

    /// The terminal was told to pop them all.
    pub fn popped(&mut self) {
        self.stack = Stack::default();
    }
}

/// What asks a terminal for its kitty keyboard flags. Asked before its colours, its answer comes before theirs, as a
/// terminal answers in order, so one that has said its colours and not this does not speak the protocol.
pub const KEYBOARD_QUERY: &str = "\x1b[?u";

/// Where a terminal's answer to [`KEYBOARD_QUERY`], `CSI ? flags u`, is in its input.
fn keyboard_reply(s: &[u8]) -> Option<std::ops::Range<usize>> {
    (0..s.len()).find_map(|i| {
        let digits = s.get(i..)?.strip_prefix(b"\x1b[?")?.iter().take_while(|b| b.is_ascii_digit()).count();
        (digits > 0 && s.get(i + 3 + digits) == Some(&b'u')).then_some(i..i + 3 + digits + 1)
    })
}

/// A terminal's input with its answer to [`KEYBOARD_QUERY`] taken out, and whether it was there.
pub fn without_keyboard_reply(s: &[u8]) -> (Vec<u8>, bool) {
    match keyboard_reply(s) {
        Some(r) => ([&s[..r.start], &s[r.end..]].concat(), true),
        None => (s.to_vec(), false),
    }
}

/// What was held over, and the new bytes after it.
fn joined(carry: &mut Vec<u8>, buf: &[u8]) -> Vec<u8> {
    let mut s = std::mem::take(carry);
    s.extend_from_slice(buf);
    s
}

/// Whether the output so far left the terminal on the alternate screen. Read from the bytes themselves, because the only
/// thing that decides what state a terminal is in is what was written to it.
#[derive(Debug, Default)]
pub struct AltTracker {
    /// It is on the alternate screen.
    pub alt: bool,
    carry: Vec<u8>,
}

impl AltTracker {
    /// Takes in more output.
    pub fn feed(&mut self, buf: &[u8]) {
        let s = joined(&mut self.carry, buf);
        let mut i = 0;
        while i < s.len() {
            if s[i] != 0x1b {
                i += 1;
                continue;
            }
            if s.get(i + 1) == Some(&b'c') {
                // RIS
                self.alt = false;
                i += 2;
                continue;
            }
            if s.get(i + 1..i + 3) == Some(b"[?") {
                let len = s[i + 3..].iter().take_while(|&&b| b.is_ascii_digit() || b == b';').count();
                let end = i + 3 + len;
                if len > 0 && matches!(s.get(end), Some(b'h' | b'l')) {
                    if s[i + 3..end].split(|&b| b == b';').any(|p| ALT_MODES.contains(&p)) {
                        self.alt = s[end] == b'h';
                    }
                    i = end + 1;
                    continue;
                }
            }
            i += 1;
        }
        let tail = s.iter().rposition(|&b| b == 0x1b).map(|at| &s[at..]);
        self.carry = tail.filter(|t| could_be_mode(t)).map(<[u8]>::to_vec).unwrap_or_default();
    }
}

/// `^\x1b(?:\[\??[\d;]*)?$`: the start of a mode change that may go on in the next output.
fn could_be_mode(t: &[u8]) -> bool {
    match t {
        [0x1b] => true,
        [0x1b, b'[', rest @ ..] => {
            let rest = rest.strip_prefix(b"?").unwrap_or(rest);
            rest.iter().all(|&b| b.is_ascii_digit() || b == b';')
        }
        _ => false,
    }
}
