//! A long-lived control connection to one session: `SessionClient` in `src/sdk/client.js`. Requests, STATE and EVENT
//! pushes, and connecting again by itself, because a session's server can restart at any moment and the session goes on.
//!
//! It is driven by its user, who waits in [`SessionClient::next`] for whatever comes next, up to a deadline, and so needs no
//! thread: what came is handed out as an [`Incoming`].

use std::collections::VecDeque;
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use nmux_wire::{Control, Hello};
use serde_json::{Map, Value};

use crate::ctl::{CtlError, Owned, Reply, Wire};

const BACKOFF_MS: [u64; 6] = [100, 250, 500, 1000, 2000, 5000];

/// What came on the connection.
#[derive(Debug)]
pub enum Incoming {
    /// The server let this connection in.
    Up,
    /// A connection that was up has gone. It is being made again.
    Down,
    /// The server answered SUBSCRIBE: where things stand.
    Subscribed(Value),
    /// Something subscribed to happened. The fields are the event's, `event` and all.
    Event(Map<String, Value>),
    /// The server refused this connection.
    Refused,
    /// The answer to a request, or why there is none.
    Answer {
        /// The request's.
        id: u64,
        /// What came.
        result: Result<Reply, CtlError>,
    },
}

#[derive(Debug)]
struct Pending {
    id: u64,
    op: String,
    timeout_ms: u64,
    deadline: Instant,
    text: bool,
    subscribe: bool,
}

#[derive(Debug)]
struct Queued {
    id: u64,
    op: String,
    args: Value,
    timeout_ms: u64,
}

/// A control connection that keeps itself up.
#[derive(Debug)]
pub struct SessionClient {
    sock: PathBuf,
    label: String,
    subscription: Option<Value>,
    wire: Option<Wire>,
    up: bool,
    stopped: bool,
    attempt: usize,
    retry_at: Option<Instant>,
    next_id: u64,
    pending: Vec<Pending>,
    /// Text of an answer on its way.
    reply: Vec<u8>,
    /// Events that came before the answer to SUBSCRIBE: they are newer than it.
    early: Option<Vec<Map<String, Value>>>,
    /// One text answer at a time: nothing in OUTPUT frames says which request they answer.
    text_busy: bool,
    text_queue: VecDeque<Queued>,
    incoming: VecDeque<Incoming>,
}

impl SessionClient {
    /// A client of the session at `sock`, not yet open. `subscription` is what to SUBSCRIBE to each time it is let in.
    pub fn new(sock: &Path, label: &str, subscription: Option<Value>) -> Self {
        Self {
            sock: sock.to_owned(),
            label: label.to_owned(),
            subscription,
            wire: None,
            up: false,
            stopped: true,
            attempt: 0,
            retry_at: None,
            next_id: 1,
            pending: Vec::new(),
            reply: Vec::new(),
            early: None,
            text_busy: false,
            text_queue: VecDeque::new(),
            incoming: VecDeque::new(),
        }
    }

    /// Starts connecting.
    pub fn open(&mut self) {
        if !self.stopped {
            return;
        }
        self.stopped = false;
        self.connect();
    }

    /// Closes it for good.
    pub fn close(&mut self) {
        self.stopped = true;
        self.retry_at = None;
        if self.wire.is_some() {
            self.closed();
        }
    }

    /// It has been closed.
    pub fn stopped(&self) -> bool {
        self.stopped
    }

    fn connect(&mut self) {
        match Wire::connect(&self.sock) {
            Ok(mut wire) => {
                let pid = u32::try_from(nmux_platform::pid()).unwrap_or(0);
                let mut hello = Hello::control(pid, &self.label);
                hello.flags = nmux_wire::Flags::default();
                let _ = wire.out.control(&Control::Hello(hello));
                let _ = wire.flush_now();
                self.wire = Some(wire);
            }
            Err(_) => self.schedule_retry(),
        }
    }

    fn schedule_retry(&mut self) {
        if self.stopped {
            return;
        }
        let delay = BACKOFF_MS[self.attempt.min(BACKOFF_MS.len() - 1)];
        self.attempt += 1;
        self.retry_at = Some(Instant::now() + Duration::from_millis(delay));
    }

    /// The connection has gone: everything waiting on it fails, and it is made again unless this was closed.
    fn closed(&mut self) {
        let was_up = self.up;
        self.up = false;
        self.wire = None;
        let down = || CtlError::new("DOWN", "control connection closed");
        for p in std::mem::take(&mut self.pending) {
            self.incoming.push_back(Incoming::Answer { id: p.id, result: Err(down()) });
        }
        self.text_busy = false;
        self.fail_queued();
        self.reply.clear();
        self.early = None;
        if was_up {
            self.incoming.push_back(Incoming::Down);
        }
        self.schedule_retry();
    }

    /// Text requests that were waiting their turn have none.
    fn fail_queued(&mut self) {
        for q in std::mem::take(&mut self.text_queue) {
            let e = CtlError::new("DOWN", format!("{} is not connected", self.sock.display()));
            self.incoming.push_back(Incoming::Answer { id: q.id, result: Err(e) });
        }
    }

    fn send(&mut self, id: u64, op: &str, args: Value, timeout_ms: u64, text: bool) {
        let (Some(wire), true) = (&mut self.wire, self.up) else {
            let e = CtlError::new("DOWN", format!("{} is not connected", self.sock.display()));
            self.incoming.push_back(Incoming::Answer { id, result: Err(e) });
            return;
        };
        let _ = wire.out.control(&Control::Req { id: Value::from(id), op: op.to_owned(), args });
        let _ = wire.flush_now();
        let deadline = Instant::now() + Duration::from_millis(timeout_ms);
        self.pending.push(Pending { id, op: op.to_owned(), timeout_ms, deadline, text, subscribe: false });
    }

    /// Asks the session, and gives the id its [`Incoming::Answer`] will have. A client that is not up answers at once that
    /// it is not connected.
    pub fn request(&mut self, op: &str, args: Value, timeout_ms: u64) -> u64 {
        let id = self.next_id;
        self.next_id += 1;
        self.send(id, op, args, timeout_ms, false);
        id
    }

    /// A request whose answer carries text, which waits for any other such request to be answered first.
    pub fn request_text(&mut self, op: &str, args: Value, timeout_ms: u64) -> u64 {
        let id = self.next_id;
        self.next_id += 1;
        if self.text_busy {
            self.text_queue.push_back(Queued { id, op: op.to_owned(), args, timeout_ms });
        } else {
            self.text_busy = self.up;
            self.send(id, op, args, timeout_ms, true);
        }
        id
    }

    fn next_text(&mut self) {
        self.text_busy = false;
        if let Some(q) = self.text_queue.pop_front() {
            self.text_busy = self.up;
            self.send(q.id, &q.op, q.args, q.timeout_ms, true);
        }
    }

    fn welcomed(&mut self) {
        self.up = true;
        self.attempt = 0;
        self.incoming.push_back(Incoming::Up);
        let Some(subscription) = self.subscription.clone() else { return };
        self.early = Some(Vec::new());
        let id = self.request("SUBSCRIBE", subscription, 5000);
        if let Some(p) = self.pending.iter_mut().find(|p| p.id == id) {
            p.subscribe = true;
        }
    }

    fn answered(&mut self, id: &Value, ok: bool, data: Option<Value>, error: Option<String>) {
        let Some(at) = self.pending.iter().position(|p| id.as_u64() == Some(p.id)) else {
            // An answer given up on: its text is not the next one's.
            self.reply.clear();
            return;
        };
        let p = self.pending.remove(at);
        let output = std::mem::take(&mut self.reply);
        let reply = Reply { ok, data: data.unwrap_or(Value::Null), error, output };
        if p.subscribe {
            let held = self.early.take().unwrap_or_default();
            if reply.ok {
                self.incoming.push_back(Incoming::Subscribed(reply.data));
            }
            self.incoming.extend(held.into_iter().map(Incoming::Event));
            return;
        }
        self.incoming.push_back(Incoming::Answer { id: p.id, result: Ok(reply) });
        if p.text {
            self.next_text();
        }
    }

    fn take(&mut self, frame: Owned) {
        match frame {
            Owned::Output(bytes) => self.reply.extend_from_slice(&bytes),
            Owned::Control(Control::Welcome(_)) => self.welcomed(),
            Owned::Control(Control::Event(e)) => {
                let mut ordered = Map::new();
                ordered.insert("event".to_owned(), Value::from(e.event));
                ordered.extend(e.fields);
                match &mut self.early {
                    Some(early) => early.push(ordered),
                    None => self.incoming.push_back(Incoming::Event(ordered)),
                }
            }
            Owned::Control(Control::Ping { seq }) => {
                if let Some(wire) = &mut self.wire {
                    let _ = wire.out.control(&Control::Pong { seq });
                    let _ = wire.flush_now();
                }
            }
            Owned::Control(Control::Res(res)) => self.answered(&res.id, res.ok, res.data, res.error),
            Owned::Control(Control::Refuse { .. }) => {
                self.incoming.push_back(Incoming::Refused);
                self.closed();
            }
            Owned::Control(_) => {}
        }
    }

    /// Requests that have waited too long fail.
    fn expire(&mut self, now: Instant) {
        let (late, waiting): (Vec<_>, Vec<_>) =
            std::mem::take(&mut self.pending).into_iter().partition(|p| p.deadline <= now);
        self.pending = waiting;
        for p in late {
            if p.subscribe {
                self.early = None;
                continue;
            }
            let e = CtlError::new("TIMEOUT", format!("{} got no reply within {} ms", p.op, p.timeout_ms));
            self.incoming.push_back(Incoming::Answer { id: p.id, result: Err(e) });
            if p.text {
                self.next_text();
            }
        }
    }

    /// Waits for what comes next, until `deadline`: `None` when nothing came by then, or when it is closed and nothing is
    /// left to hand out.
    pub fn next(&mut self, deadline: Option<Instant>) -> Option<Incoming> {
        loop {
            if let Some(i) = self.incoming.pop_front() {
                return Some(i);
            }
            let now = Instant::now();
            self.expire(now);
            if !self.incoming.is_empty() {
                continue;
            }
            if self.retry_at.is_some_and(|at| at <= now) && self.wire.is_none() {
                self.retry_at = None;
                if !self.stopped {
                    self.connect();
                }
                continue;
            }
            if deadline.is_some_and(|d| d <= now) || (self.stopped && self.wire.is_none()) {
                return None;
            }
            let wake =
                [deadline, self.retry_at, self.pending.iter().map(|p| p.deadline).min()].into_iter().flatten().min();
            match &mut self.wire {
                Some(wire) => match wire.read(wake) {
                    Ok(Some(frames)) => {
                        for frame in frames {
                            self.take(frame);
                        }
                    }
                    Ok(None) | Err(_) => self.closed(),
                },
                None => {
                    if let Some(wake) = wake {
                        std::thread::sleep(wake.saturating_duration_since(Instant::now()));
                    }
                }
            }
        }
    }
}
