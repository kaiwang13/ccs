//! When to try connecting again, and when to stop: `src/client/reconnect.js`, with the time handed in.

use nmux_io::Time;

const BACKOFF_MS: [u64; 5] = [500, 1000, 2000, 4000, 5000];
const RECONNECT_WINDOW_MS: u64 = 120_000;

/// How long to wait before the next connection attempt, and when to stop trying.
#[derive(Debug, Default)]
pub struct ReconnectPolicy {
    lost_at: Option<Time>,
    attempt: usize,
}

impl ReconnectPolicy {
    /// The delay before the next attempt, or `None` once the window is over.
    pub fn next(&mut self, immediate: bool, now: Time) -> Option<u64> {
        let lost_at = *self.lost_at.get_or_insert(now);
        if now.since(lost_at) > RECONNECT_WINDOW_MS {
            return None;
        }
        let delay = if immediate { 0 } else { BACKOFF_MS[self.attempt.min(BACKOFF_MS.len() - 1)] };
        self.attempt += 1;
        Some(delay)
    }

    /// Joined again: the next loss starts over.
    pub fn reset(&mut self) {
        self.lost_at = None;
        self.attempt = 0;
    }
}

/// How many times a terminal may fall behind, or fail to take a snapshot, before rejoining stops being the answer.
#[derive(Debug)]
pub struct RejoinPolicy {
    /// Overflows allowed in the window.
    pub max: usize,
    /// The window.
    pub window_ms: u64,
    /// Snapshot timeouts in a row that give up.
    pub snapshot_timeout_max: u32,
    overflows: Vec<Time>,
    snapshot_timeouts: u32,
}

impl RejoinPolicy {
    /// `max` overflows in `window_ms`, and three snapshot timeouts in a row.
    pub fn new(max: usize, window_ms: u64) -> Self {
        Self { max, window_ms, snapshot_timeout_max: 3, overflows: Vec::new(), snapshot_timeouts: 0 }
    }

    /// An OVERFLOW rejoin is allowed at most `max` times per `window_ms`.
    pub fn allow_overflow(&mut self, now: Time) -> bool {
        let window = self.window_ms;
        self.overflows.retain(|&t| now.since(t) < window);
        if self.overflows.len() >= self.max {
            return false;
        }
        self.overflows.push(now);
        true
    }

    /// `SNAPSHOT_TIMEOUT` never draws on the overflow budget; the `snapshot_timeout_max`-th in a row gives up.
    pub fn allow_snapshot_timeout(&mut self) -> bool {
        self.snapshot_timeouts += 1;
        self.snapshot_timeouts < self.snapshot_timeout_max
    }

    /// A join completed.
    pub fn on_snapshot_end(&mut self) {
        self.snapshot_timeouts = 0;
    }
}
