//! The configuration file, as `src/server/config.js` reads it: the user's file over the defaults, one section at a time. A
//! missing file is the normal case, and a broken one must never stop anything from starting. Only the values a client and the
//! command read have accessors here; the rest are kept for whoever reads them.

use std::path::Path;

use serde_json::{Map, Value, json};

use crate::keytable::KeySpec;

/// The defaults, as `DEFAULTS` has them. `clients.dropMs` is `Infinity` there, which JSON cannot say: it is left out, and
/// what reads it takes its absence for that.
fn defaults() -> Value {
    json!({
        "size": {
            "floorCols": 2, "hardMinCols": 2, "floorRows": 1, "maxCols": 500, "maxRows": 500, "defaultCols": 120, "defaultRows": 40,
            "shrinkDebounceMs": 50, "shrinkMaxWaitMs": 200, "growDebounceMs": 50, "growMinCols": 1, "growMinRows": 1,
            "joinRepaintWaitMs": 400, "growResetCheckMs": 300,
        },
        "snapshot": { "scrollback": 10000, "joinHistory": "all", "snapshotTimeoutMs": 30000, "chunkBytes": 65536 },
        "clients": {
            "pingMs": 5000, "stallMs": 20000, "queueCapBytes": 1_048_576,
            "rejoinMax": 3, "rejoinWindowMs": 300_000, "osc52": "last-typist", "dsrProbe": true,
        },
        "input": { "escFlushMs": 40, "escHoldMs": 60, "escHoldMaxMs": 1500, "crossClientEscMs": 800, "answerCollisionMs": 1000, "pasteIdleCloseMs": 1500 },
        "stop": { "hangupWaitMs": 30000, "termWaitMs": 60000 },
        "holder": { "ringBytes": 8_388_608 },
        "notices": { "bellOnAttention": true },
        "stream": { "repaint": false },
        "shell": { "integration": true },
        "history": { "spoolBytes": 0, "keep": false, "dir": null },
        "overlay": { "bar": true, "dayLines": false, "timeZone": null },
        "keys": { "leader": "C-\\", "bindings": { "d": "detach", "c": "clients", "h": "history", "s": "bar", "?": "help" }, "direct": {} },
    })
}

/// The configuration in effect.
#[derive(Clone, Debug)]
pub struct Config {
    sections: Map<String, Value>,
}

impl Default for Config {
    fn default() -> Self {
        let Value::Object(sections) = defaults() else { unreachable!("the defaults are an object") };
        Self { sections }
    }
}

impl Config {
    /// The user's file at `file` over the defaults.
    pub fn load(file: Option<&Path>) -> Self {
        let user = file.and_then(|f| std::fs::read(f).ok()).and_then(|b| serde_json::from_slice::<Value>(&b).ok());
        user.map_or_else(Self::default, |user| Self::from_value(&user))
    }

    /// `user`, a configuration as the file has it, over the defaults.
    pub fn from_value(user: &Value) -> Self {
        let mut config = Self::default();
        for (section, values) in &mut config.sections {
            // `{...defaults, ...user[section]}`: only an object's own fields count.
            if let (Some(Value::Object(theirs)), Value::Object(ours)) = (user.get(section), values) {
                for (k, v) in theirs {
                    ours.insert(k.clone(), v.clone());
                }
            }
        }
        config
    }

    /// A value, as the merged section has it.
    pub fn get(&self, section: &str, key: &str) -> Option<&Value> {
        self.sections.get(section)?.get(key)
    }

    /// A number, or its default where the file has something else.
    pub fn number(&self, section: &str, key: &str) -> f64 {
        self.get(section, key).and_then(Value::as_f64).unwrap_or_else(|| {
            let defaults = Self::default();
            defaults.get(section, key).and_then(Value::as_f64).unwrap_or(0.0)
        })
    }

    /// A number of milliseconds or of anything else that is whole and not negative.
    #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)] // clamped to what it can be
    pub fn count(&self, section: &str, key: &str) -> u64 {
        let n = self.number(section, key);
        if n.is_finite() { n.max(0.0) as u64 } else { u64::MAX }
    }

    /// Whether a value is set, as JavaScript tests one.
    pub fn truthy(&self, section: &str, key: &str) -> bool {
        self.get(section, key).is_some_and(truthy)
    }

    /// A text, or none where it is not set.
    pub fn text(&self, section: &str, key: &str) -> Option<String> {
        match self.get(section, key)? {
            Value::String(s) if !s.is_empty() => Some(s.clone()),
            _ => None,
        }
    }

    /// The keys a client takes for itself.
    pub fn keys(&self) -> KeySpec {
        let keys = self.sections.get("keys");
        let field = |name: &str| keys.and_then(|k| k.get(name));
        KeySpec {
            leader: field("leader").and_then(Value::as_str).filter(|s| !s.is_empty()).map(str::to_owned),
            bindings: entries(field("bindings")),
            direct: entries(field("direct")),
        }
    }
}

/// JavaScript's truthiness.
pub fn truthy(v: &Value) -> bool {
    match v {
        Value::Null => false,
        Value::Bool(b) => *b,
        Value::Number(n) => n.as_f64().is_some_and(|n| n != 0.0 && !n.is_nan()),
        Value::String(s) => !s.is_empty(),
        Value::Array(_) | Value::Object(_) => true,
    }
}

/// An object's entries as `Object.entries` lists them: names that are array indices first, in order, then the rest as they
/// were written. Values that are not text are left out, as no action has such a name.
fn entries(v: Option<&Value>) -> Vec<(String, String)> {
    let Some(Value::Object(map)) = v else { return Vec::new() };
    let index = |k: &str| k.parse::<u32>().ok().filter(|n| n.to_string() == k && *n != u32::MAX);
    let mut indexed: Vec<_> =
        map.iter().filter_map(|(k, v)| Some((index(k)?, k.clone(), v.as_str()?.to_owned()))).collect();
    indexed.sort_by_key(|(n, _, _)| *n);
    let rest =
        map.iter().filter(|(k, _)| index(k).is_none()).filter_map(|(k, v)| Some((k.clone(), v.as_str()?.to_owned())));
    indexed.into_iter().map(|(_, k, v)| (k, v)).chain(rest).collect()
}
