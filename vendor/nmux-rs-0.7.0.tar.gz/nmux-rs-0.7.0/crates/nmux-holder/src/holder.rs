//! The holder's logic, with no I/O: `main.js`, `server.js` and `child.js` of the Node holder, as one state machine. The
//! run loop hands it what happened ([`Event`]) and the time, and does what it asks ([`Effect`]). The bytes it sends are
//! in buffers it owns, one for the server's connection and one for the pty, which the run loop writes out.
//!
//! What a server is told, and when, is the Node holder's, to the timer: flow control, the keeping of a server around, the
//! orphan and no-connection timers, the heartbeat, and the exit that never overtakes the child's last output.

use std::collections::{BTreeMap, HashMap, VecDeque};

use nmux_io::{Now, OutBuf, Time, TimerId, Timers};
use nmux_platform::{Lflags, Signal, iso_utc, signal_name};
use nmux_wire::{
    ChildInfo, Control, ErrorMessage, Exit, Frame, HHello, HOLDER_PROTO, Lflag, Resized, Ring as RingInfo, Size,
    decode_write,
};
use serde_json::Map;

use crate::consume::{ConsumeWatcher, Consumed, Poll};
use crate::feed::Feed;
use crate::log::{Level, Log};
use crate::ptyout::PtyOut;
use crate::responder::Forward;
use crate::ring::ZeroCapacity;
use crate::spec::{HolderSpec, HolderTimers};
use crate::timer::Timer;
use crate::writequeue::{Enqueued, WriteQueue, Written};

/// The release this holder speaks for, in its greeting.
pub const HOLDER_VERSION: &str = "0.2.0";
/// The most one DATA frame carries.
const DATA_CHUNK: usize = 256 * 1024;
/// Output queued for the server past which nothing more is sent until it drains.
const SOCK_HIGH_WATER: usize = 4 * 1024 * 1024;
/// What this holder can do beyond the base protocol. A server opts in when it attaches, so older ones keep working.
const CAPS: [&str; 2] = ["flow", "colors"];
/// How often a paused holder looks for the child having gone.
const PAUSED_WATCH_MS: u64 = 40;
/// How long node-pty waits, after the child exits, for the pty to close by itself.
const CLOSE_WAIT_MS: u64 = 200;
/// How long a cursor report is waited for.
const CPR_TIMEOUT_MS: u64 = 100;
/// How long a forwarded query is waited for.
const QUERY_TIMEOUT_MS: u64 = 1000;
/// After it is asked to end, how long the connection has to flush before the holder exits.
const FINISH_FLUSH_MS: u64 = 50;

/// A connection to pty.sock, as the run loop numbers them.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct ConnId(pub u64);

/// What happened, for [`Holder::on_event`].
#[derive(Debug)]
#[allow(clippy::large_enum_variant)] // an event is handled where it is made, and never stored
pub enum Event<'a> {
    /// The child runs, holder.json is written, and pty.sock listens.
    Started,
    /// The child printed this.
    Output(&'a [u8]),
    /// The pty is closed: nobody holds its slave any more, or it was closed as asked.
    PtyClosed,
    /// The child exited, as `waitpid` told it.
    ChildExited {
        /// Its exit status, if it exited.
        code: Option<i32>,
        /// The signal that ended it, if one did.
        signal: Option<i32>,
    },
    /// What [`Effect::ReadTail`] asked for has been read, and the pty is still open.
    TailRead,
    /// The answer to [`Effect::ReadLflag`]: the pty's local modes and foreground group, or `None` when they cannot be read.
    Lflag(Option<(Lflags, i32)>),
    /// The answer to [`Effect::ReadInq`]: bytes waiting on the slave, or why that could not be read.
    Inq(Result<usize, String>),
    /// The answer to [`Effect::ReadExiting`]: the child is on its way out.
    Exiting(bool),
    /// A connection came, from a process of this user id, if that could be read.
    Accepted {
        /// The connection.
        conn: ConnId,
        /// Its peer's user id.
        peer_uid: Option<u32>,
    },
    /// A frame came on a connection.
    Frame {
        /// The connection.
        conn: ConnId,
        /// The frame.
        frame: Frame<'a>,
    },
    /// A connection closed.
    ConnClosed(ConnId),
    /// What was queued on a connection has all been written.
    Drained(ConnId),
    /// The answer to [`Effect::IdentifyServer`].
    ServerIdentified {
        /// The pid asked about.
        pid: i32,
        /// When it started, if it is there.
        start: Option<String>,
    },
    /// SIGTERM came. `corroborated`: there is independent evidence that the host is shutting down.
    Sigterm {
        /// See above.
        corroborated: bool,
    },
    /// Time passed: timers that are due fire.
    Tick,
}

/// What the run loop is asked to do, in order.
#[derive(Debug, PartialEq)]
pub enum Effect {
    /// Stop reading the pty: its buffer fills and the child blocks, as on a slow terminal.
    PauseOutput,
    /// Read the pty again.
    ResumeOutput,
    /// Read the pty's local modes and foreground process group, and answer with [`Event::Lflag`].
    ReadLflag,
    /// Read how much written input waits on the slave, opening it if need be, and answer with [`Event::Inq`].
    ReadInq,
    /// Say whether the child is on its way out, with [`Event::Exiting`]: a paused holder asks, as the child may be unable to
    /// finish exiting while what it wrote waits unread.
    ReadExiting,
    /// Close the slave held for [`Effect::ReadInq`], if it is open.
    CloseSlave,
    /// Give the pty this size.
    Resize {
        /// Columns.
        cols: u16,
        /// Rows.
        rows: u16,
    },
    /// Send the child this signal, if it is still the process that was started, and log it.
    SignalChild(Signal),
    /// Read what the pty has left, up to 4 MiB, as [`Event::Output`]s, unless `read` is false; then, with `then_close`,
    /// close the pty and answer with [`Event::PtyClosed`], or else answer with [`Event::TailRead`].
    ReadTail {
        /// Read before closing.
        read: bool,
        /// Close the pty after.
        then_close: bool,
    },
    /// Close the pty, which hangs it up, and send the child SIGHUP.
    HangUp,
    /// Start a server, and log it.
    SpawnServer {
        /// What to run.
        argv: Vec<String>,
        /// How many have been started in the window.
        attempt: usize,
    },
    /// Read when the process `pid` started, and answer with [`Event::ServerIdentified`].
    IdentifyServer {
        /// The server's pid, as it gave it.
        pid: i32,
    },
    /// SIGTERM for the server, if it is still the process that attached.
    EndServer {
        /// Its pid.
        pid: i32,
        /// When it started.
        start: String,
    },
    /// Refuse a connection: send it `ERR` with this code, and end it.
    Refuse {
        /// The connection.
        conn: ConnId,
        /// `FORBIDDEN` or `BUSY`.
        code: &'static str,
    },
    /// End a connection once what is queued on it is written.
    EndConn(ConnId),
    /// Close a connection now, and answer with [`Event::ConnClosed`].
    DestroyConn(ConnId),
    /// Stop listening.
    CloseListener,
    /// Write this to the log.
    Log(Log),
    /// The holder is done: remove pty.sock, hang the pty up if `hang_up`, release the lock, and exit.
    Exit {
        /// The child has not exited: close the pty and send it SIGHUP.
        hang_up: bool,
    },
}

/// What the holder is told about itself and its child when it starts, beyond the spec.
#[derive(Clone, Debug)]
pub struct Started {
    /// This process.
    pub pid: i32,
    /// When it started.
    pub proc_start: Option<String>,
    /// This user, the only one let in.
    pub uid: u32,
    /// The child.
    pub child_pid: i32,
    /// When the child started.
    pub child_start: Option<String>,
    /// The pty's slave.
    pub pts_name: String,
    /// The child did not become a session leader, and was sent SIGTERM.
    pub leader_error: Option<String>,
}

/// The server's connection.
#[derive(Debug)]
struct Connection {
    id: ConnId,
    out: OutBuf,
}

/// `HolderServer`'s state.
#[derive(Debug)]
#[allow(clippy::struct_excessive_bools)] // the Node holder's flags, one each
struct Server {
    conn: Option<Connection>,
    attached: bool,
    conn_pid: i32,
    conn_start: Option<String>,
    sent_offset: u64,
    /// Cleared only by a server that attached without asking for flow control.
    flow: bool,
    /// Everything before this offset has been parsed.
    acked_offset: u64,
    last_ack_at: Time,
    paused: bool,
    /// The server went quiet while the holder waited: nothing pauses again until it acknowledges something.
    draining: bool,
    exit_sent: bool,
    flow_timer: Option<TimerId>,
    last_pong_at: Time,
    ping_seq: u64,
    ping_due: Time,
    /// SIGTERM came: no new server is started from here on.
    closing: bool,
    stuck_timer: Option<TimerId>,
    no_conn_timer: Option<TimerId>,
    orphan_timer: Option<TimerId>,
    ping_timer: Option<TimerId>,
    spawn_times: Vec<Time>,
    spawn_index: usize,
    gave_up: bool,
    connected_at: Time,
    short_lived: u32,
    paused_at: Time,
    query_id: u32,
    /// Forwarded queries the server has not answered: the responder's entry for each, and its timer.
    pending_queries: BTreeMap<u32, (u64, TimerId)>,
}

/// `PtyChild`'s state.
#[derive(Debug)]
#[allow(clippy::struct_excessive_bools)] // the Node holder's flags, one each
struct Child {
    pid: i32,
    start: Option<String>,
    size: Size,
    pts_name: String,
    exit: Option<Exit>,
    shutting_down: bool,
    leader_error: Option<String>,
    last_lflag: Option<Lflag>,
    lflag_timer: Option<TimerId>,
    proc_timer: Option<TimerId>,
    grace_timer: Option<TimerId>,
    close_timer: Option<TimerId>,
    hanging_up: bool,
    /// What node-pty reports of the exit: an exit code, 0 after a signal, and the signal's name.
    reaped: Option<(i64, Option<String>)>,
    /// The pty is closed: node-pty's `_emittedClose`.
    pty_closed: bool,
    /// The exit was found by looking for the child, and waits for the pty's tail to be read.
    reading_tail: bool,
    /// The child is on its way out: its output is read whatever the server has acknowledged, since on macOS it cannot finish
    /// exiting until what it wrote has been.
    exiting: bool,
}

/// The holder.
#[derive(Debug)]
pub struct Holder {
    now: Now,
    timers: Timers<Timer>,
    effects: VecDeque<Effect>,
    t: HolderTimers,
    generation: u64,
    sessiond_cmd: Option<Vec<String>>,
    me: Started,
    feed: Feed,
    queue: WriteQueue,
    consume: ConsumeWatcher,
    pty_out: PtyOut,
    server: Server,
    child: Child,
    /// The timer of each cursor report waited for, by the responder's entry.
    cpr_timers: HashMap<u64, TimerId>,
    term_timer: Option<TimerId>,
    finishing: bool,
}

impl Holder {
    /// A holder for `spec`, whose child has started as `me` says.
    pub fn new(spec: &HolderSpec, me: Started) -> Result<Self, ZeroCapacity> {
        let size = Size { cols: spec.cols, rows: spec.rows };
        let feed = Feed::new(spec.ring_bytes, size, spec.term_colors.clone())?;
        let child = Child {
            pid: me.child_pid,
            start: me.child_start.clone(),
            size,
            pts_name: me.pts_name.clone(),
            exit: None,
            shutting_down: false,
            leader_error: me.leader_error.clone(),
            last_lflag: None,
            lflag_timer: None,
            proc_timer: None,
            grace_timer: None,
            close_timer: None,
            hanging_up: false,
            reaped: None,
            pty_closed: false,
            reading_tail: false,
            exiting: false,
        };
        let server = Server {
            conn: None,
            attached: false,
            conn_pid: 0,
            conn_start: None,
            sent_offset: 0,
            flow: true,
            acked_offset: 0,
            last_ack_at: Time::ZERO,
            paused: false,
            draining: false,
            exit_sent: false,
            flow_timer: None,
            last_pong_at: Time::ZERO,
            ping_seq: 0,
            ping_due: Time::ZERO,
            closing: false,
            stuck_timer: None,
            no_conn_timer: None,
            orphan_timer: None,
            ping_timer: None,
            spawn_times: Vec::new(),
            spawn_index: 0,
            gave_up: false,
            connected_at: Time::ZERO,
            short_lived: 0,
            paused_at: Time::ZERO,
            query_id: 0,
            pending_queries: BTreeMap::new(),
        };
        Ok(Self {
            now: Now::default(),
            timers: Timers::new(),
            effects: VecDeque::new(),
            t: spec.timers.clone(),
            generation: spec.generation,
            sessiond_cmd: spec.sessiond_cmd.clone(),
            me,
            feed,
            queue: WriteQueue::default(),
            consume: ConsumeWatcher::new(spec.timers.watch_poll_ms),
            pty_out: PtyOut::new(),
            server,
            child,
            cpr_timers: HashMap::new(),
            term_timer: None,
            finishing: false,
        })
    }

    // ---- the run loop's side ------------------------------------------------------------------------------------------

    /// Takes in what happened at `now`.
    pub fn on_event(&mut self, event: Event<'_>, now: Now) {
        self.now = now;
        match event {
            Event::Started => self.start(),
            Event::Output(bytes) => self.on_output(bytes),
            Event::PtyClosed => self.on_pty_closed(),
            Event::ChildExited { code, signal } => self.on_reaped(code, signal),
            Event::TailRead => self.on_tail_read(),
            Event::Lflag(reading) => self.on_lflag(reading),
            Event::Inq(result) => self.on_inq(result),
            Event::Exiting(exiting) => self.on_exiting(exiting),
            Event::Accepted { conn, peer_uid } => self.accept(conn, peer_uid),
            Event::Frame { conn, frame } => self.on_frame(conn, frame),
            Event::ConnClosed(conn) => self.on_close(conn),
            Event::Drained(conn) => {
                if self.is_conn(conn) {
                    self.pump();
                }
            }
            Event::ServerIdentified { pid, start } => {
                if self.server.conn_pid == pid {
                    self.server.conn_start = start;
                }
            }
            Event::Sigterm { corroborated } => self.on_sigterm(corroborated),
            Event::Tick => {
                while let Some((_, timer)) = self.timers.pop_due(now.time) {
                    self.on_timer(timer);
                }
            }
        }
    }

    /// The next thing to do, in order.
    pub fn next_effect(&mut self) -> Option<Effect> {
        self.effects.pop_front()
    }

    /// When the next timer is due.
    pub fn next_deadline(&mut self) -> Option<Time> {
        self.timers.next_due()
    }

    /// What waits to be written on `conn`, if it is the server's connection.
    pub fn conn_out(&mut self, conn: ConnId) -> Option<&mut OutBuf> {
        self.server.conn.as_mut().filter(|c| c.id == conn).map(|c| &mut c.out)
    }

    /// What waits to be written to the pty.
    pub fn pty_out(&mut self) -> &mut PtyOut {
        &mut self.pty_out
    }

    /// SIGTERM has come.
    pub fn closing(&self) -> bool {
        self.server.closing
    }

    /// The child's exit has been seen.
    pub fn child_exited(&self) -> bool {
        self.child.exit.is_some()
    }

    /// The pty is paused for flow control.
    pub fn paused(&self) -> bool {
        self.server.paused
    }

    // ---- helpers ------------------------------------------------------------------------------------------------------

    fn set(&mut self, ms: u64, timer: Timer) -> TimerId {
        self.timers.set(self.now.time, ms, timer)
    }

    fn cancel(&mut self, slot: Option<TimerId>) {
        if let Some(id) = slot {
            self.timers.cancel(id);
        }
    }

    fn log(&mut self, log: Log) {
        self.effects.push_back(Effect::Log(log));
    }

    fn is_conn(&self, conn: ConnId) -> bool {
        self.server.conn.as_ref().is_some_and(|c| c.id == conn)
    }

    /// Sends a control message to the server, if one is connected, attached or not.
    fn send(&mut self, message: &Control) {
        if let Some(conn) = &mut self.server.conn {
            let _ = conn.out.control(message);
        }
    }

    fn error(code: &str) -> Control {
        Control::Err(ErrorMessage { code: code.to_owned(), sig: None, extra: Map::new() })
    }

    // ---- main.js ------------------------------------------------------------------------------------------------------

    /// `child.watch()`, then what `server.listen()` does once it listens.
    fn start(&mut self) {
        self.poll_lflag();
        self.child.proc_timer = Some(self.set(self.t.proc_poll_ms, Timer::Proc));
        self.arm_no_conn(self.t.no_conn_ms);
        self.server.ping_due = self.now.time.after(self.t.ping_ms);
        self.server.ping_timer = Some(self.set(self.t.ping_ms, Timer::Ping));
    }

    /// `child.on('data')`.
    fn on_output(&mut self, bytes: &[u8]) {
        let mut writes = Vec::new();
        let mut forwards = Vec::new();
        self.feed.push(bytes, &mut writes, &mut forwards);
        for answer in writes {
            self.enqueue(answer, false, 0);
        }
        for forward in forwards {
            self.forward(forward);
        }
        self.pump();
    }

    /// `child.on('exit')`.
    fn on_child_exit(&mut self) {
        self.consume.stop(&mut self.timers);
        self.effects.push_back(Effect::CloseSlave);
        self.pump();
        if self.server.closing {
            self.finish();
            return;
        }
        self.arm_orphan_timer();
    }

    fn on_sigterm(&mut self, corroborated: bool) {
        if self.server.closing {
            return;
        }
        self.server.closing = true;
        self.child.shutting_down = corroborated;
        self.log(Log::new(Level::Info, "sigterm").with("shuttingDown", corroborated));
        if self.child.exit.is_some() {
            self.finish();
            return;
        }
        self.term_timer = Some(self.set(self.t.term_wait_ms, Timer::TermWait));
    }

    fn finish(&mut self) {
        if self.finishing {
            return;
        }
        self.finishing = true;
        self.close_server();
        self.stop_child_timers();
        self.consume.stop(&mut self.timers);
        self.effects.push_back(Effect::CloseSlave);
        if let Some(conn) = &self.server.conn {
            self.effects.push_back(Effect::EndConn(conn.id));
            self.set(FINISH_FLUSH_MS, Timer::FinishEnd);
        } else {
            self.end();
        }
    }

    /// `if (!child.exit) child.destroy()`, which does nothing to a pty that is already closed.
    fn end(&mut self) {
        let hang_up = self.child.exit.is_none() && !self.child.pty_closed;
        self.effects.push_back(Effect::Exit { hang_up });
    }

    // ---- the write queue and the responder ------------------------------------------------------------------------

    fn enqueue(&mut self, bytes: Vec<u8>, lone_esc: bool, watch_id: u32) {
        let mut written = Vec::new();
        let backlog = self.pty_out.backlog();
        let now = self.now.time;
        if self.queue.enqueue(bytes, lone_esc, watch_id, backlog, &mut self.timers, now, &mut written)
            == Enqueued::Overflow
        {
            self.pty_out.drop_backlog();
            self.log(Log::new(Level::Warn, "write.overflow"));
            self.send(&Self::error("WRITE_OVERFLOW"));
        }
        self.wrote(written);
    }

    /// What the write queue let go: to the child, and to the consume watcher.
    fn wrote(&mut self, written: Vec<Written>) {
        for w in written {
            if self.child.exit.is_none() {
                self.pty_out.push(w.bytes);
            }
            self.consume.add(w.watch_id, w.end, w.lone_esc, &mut self.timers, self.now.time);
        }
    }

    /// A query only the server can answer: `forwardQuery`, with the responder's own wait beside it.
    fn forward(&mut self, f: Forward) {
        let timer = self.set(CPR_TIMEOUT_MS, Timer::Cpr(f.entry));
        self.cpr_timers.insert(f.entry, timer);
        if self.server.conn.is_none() || !self.server.attached {
            self.resolve(f.entry, None);
            return;
        }
        self.server.query_id = self.server.query_id.wrapping_add(1);
        let id = self.server.query_id;
        let timeout = self.set(QUERY_TIMEOUT_MS, Timer::QueryTimeout(id));
        if let Some((_, old)) = self.server.pending_queries.insert(id, (f.entry, timeout)) {
            self.timers.cancel(old);
        }
        self.send(&Control::QueryFwd { id, kind: f.kind.as_str().to_owned(), offset: f.offset });
    }

    /// The answer to a forwarded query, or none.
    fn resolve(&mut self, entry: u64, bytes: Option<Vec<u8>>) {
        if !self.feed.responder.resolve(entry, bytes) {
            return;
        }
        let timer = self.cpr_timers.remove(&entry);
        self.cancel(timer);
        if let Some(answers) = self.feed.responder.drain() {
            self.enqueue(answers, false, 0);
        }
    }

    // ---- child.js -------------------------------------------------------------------------------------------------

    /// The foreground process group tells the child apart from anything it started.
    fn poll_lflag(&mut self) {
        self.child.lflag_timer = None;
        if self.child.exit.is_none() {
            self.effects.push_back(Effect::ReadLflag);
        }
    }

    fn on_lflag(&mut self, reading: Option<(Lflags, i32)>) {
        if let Some((l, fg)) = reading {
            let message = Lflag {
                icanon: l.icanon,
                isig: l.isig,
                echo: l.echo,
                fg_is_child: fg == self.child.pid,
                fg: Some(i64::from(fg)),
            };
            if self.child.last_lflag != Some(message) {
                self.child.last_lflag = Some(message);
                self.send(&Control::Lflag(message));
            }
        }
        if self.child.exit.is_none() && !self.finishing && self.child.lflag_timer.is_none() {
            self.child.lflag_timer = Some(self.set(self.t.lflag_poll_ms, Timer::Lflag));
        }
    }

    /// The backstop: the child found gone, by looking.
    fn poll_proc(&mut self) {
        self.child.proc_timer = None;
        if self.child.exit.is_some() {
            return;
        }
        if self.child.reaped.is_some() {
            // node-pty reports the real exit within its 200 ms wait: give it that long before reporting nothing.
            if self.child.grace_timer.is_none() {
                self.child.grace_timer = Some(self.set(self.t.exit_grace_ms, Timer::Grace));
            }
            return;
        }
        self.child.proc_timer = Some(self.set(self.t.proc_poll_ms, Timer::Proc));
    }

    /// The child exited: once the pty is closed too, its exit is reported. node-pty waits for that, so that no output
    /// comes after the exit, and gives up waiting after 200 ms, when something the child left behind holds the pty open.
    fn on_reaped(&mut self, code: Option<i32>, signal: Option<i32>) {
        if self.child.reaped.is_some() {
            return;
        }
        let code = i64::from(code.unwrap_or(0));
        let signal = signal.filter(|&s| s != 0).map(signal_name);
        self.child.reaped = Some((code, signal.clone()));
        if self.child.pty_closed {
            self.exited(Some(code), signal, "pty");
        } else {
            self.child.close_timer = Some(self.set(CLOSE_WAIT_MS, Timer::Close));
        }
    }

    fn on_pty_closed(&mut self) {
        if self.child.pty_closed {
            return;
        }
        self.child.pty_closed = true;
        let timer = self.child.close_timer.take();
        self.cancel(timer);
        if let Some((code, signal)) = self.child.reaped.clone() {
            self.exited(Some(code), signal, "pty");
        }
    }

    fn on_tail_read(&mut self) {
        if std::mem::take(&mut self.child.reading_tail) {
            self.record_exit(None, None, "proc");
        }
    }

    /// `_exited`.
    fn exited(&mut self, code: Option<i64>, signal: Option<String>, by: &'static str) {
        if self.child.exit.is_some() || self.child.reading_tail {
            return;
        }
        self.stop_child_timers();
        if by == "proc" {
            // node-pty has not got that far yet: what the pty still has is read first.
            self.child.reading_tail = true;
            self.effects.push_back(Effect::ReadTail { read: true, then_close: false });
            return;
        }
        self.record_exit(code, signal, by);
    }

    fn record_exit(&mut self, code: Option<i64>, signal: Option<String>, by: &'static str) {
        if self.child.exit.is_some() {
            return;
        }
        self.log(
            Log::new(Level::Info, "child.exit")
                .with("code", code)
                .with("signal", signal.clone())
                .with("by", by)
                .with("shuttingDown", self.child.shutting_down),
        );
        self.child.exit = Some(Exit {
            code,
            signal,
            at: iso_utc(self.now.wall_ms),
            shutting_down: self.child.shutting_down,
            detected_by: by.to_owned(),
            error: self.child.leader_error.clone(),
            extra: Map::new(),
        });
        self.on_child_exit();
    }

    fn stop_child_timers(&mut self) {
        for slot in [self.child.lflag_timer.take(), self.child.proc_timer.take(), self.child.grace_timer.take()] {
            self.cancel(slot);
        }
    }

    fn signal_child(&mut self, signal: Signal) {
        if self.child.exit.is_none() {
            self.effects.push_back(Effect::SignalChild(signal));
        }
    }

    /// node-pty's `destroy()`: the pty is closed and the child sent SIGHUP. A pty already closed is left as it is.
    fn destroy_child(&mut self) {
        self.child.hanging_up = true;
        if self.child.pty_closed {
            return;
        }
        self.child.pty_closed = true;
        let timer = self.child.close_timer.take();
        self.cancel(timer);
        self.effects.push_back(Effect::HangUp);
        if let Some((code, signal)) = self.child.reaped.clone() {
            self.exited(Some(code), signal, "pty");
        }
    }

    // ---- consume.js ---------------------------------------------------------------------------------------------------

    fn on_inq(&mut self, result: Result<usize, String>) {
        let inq = match result {
            Ok(n) => Some(n),
            Err(error) => {
                self.log(Log::new(Level::Warn, "watch.poll_failed").with("error", error));
                None
            }
        };
        let consumable = self.queue.written_total().saturating_sub(self.pty_out.backlog() as u64);
        let mut consumed = Vec::new();
        let exited = self.child.exit.is_some();
        let now = self.now.time;
        let close = self.consume.on_inq(inq, consumable, exited, &mut self.timers, now, &mut consumed);
        for c in consumed {
            match c {
                Consumed::Watch(watch_id) => self.send(&Control::Consumed { watch_id }),
                Consumed::Esc => self.queue.on_consumed(&mut self.timers, now),
            }
        }
        if close {
            self.effects.push_back(Effect::CloseSlave);
        }
    }

    // ---- server.js: output, and flow control ------------------------------------------------------------------------

    /// Sends what the attached server has not seen yet, then the child's exit, which must not overtake its last output.
    fn pump(&mut self) {
        let Some(conn) = self.server.conn.as_mut().filter(|_| self.server.attached) else {
            self.flow();
            return;
        };
        let ring = &self.feed.ring;
        while self.server.sent_offset < ring.end() && conn.out.len() < SOCK_HIGH_WATER {
            let (offset, bytes, gap) = ring.chunk_from(self.server.sent_offset, DATA_CHUNK);
            if let Some(gap) = gap {
                let _ = conn.out.control(&Control::Gap { from: gap.from, to: gap.to });
            }
            let _ = conn.out.data(offset, bytes);
            self.server.sent_offset = offset + bytes.len() as u64;
        }
        let stuck = conn.out.len() >= SOCK_HIGH_WATER;
        if let (Some(exit), false) = (&self.child.exit, self.server.exit_sent) {
            if self.server.sent_offset >= ring.end() {
                self.server.exit_sent = true;
                let _ = conn.out.control(&Control::Exit(exit.clone()));
            }
        }
        if stuck {
            if self.server.stuck_timer.is_none() {
                self.server.stuck_timer = Some(self.set(self.t.stuck_ms, Timer::Stuck));
            }
        } else {
            let timer = self.server.stuck_timer.take();
            self.cancel(timer);
        }
        self.flow();
    }

    fn flow_limits(&self) -> (i64, i64) {
        let half = i64::try_from(self.feed.ring.capacity() / 2).unwrap_or(i64::MAX);
        let high = i64::try_from(self.t.flow_high_bytes).unwrap_or(i64::MAX).min(half);
        (high, high / 2)
    }

    #[allow(clippy::cast_possible_wrap)] // offsets are below 2^53
    fn flow(&mut self) {
        let (high, low) = self.flow_limits();
        let unparsed = self.feed.ring.end() as i64 - self.server.acked_offset as i64;
        if !self.server.flow || self.server.draining || self.child.exit.is_some() || self.child.exiting {
            self.resume_child();
            return;
        }
        if !self.server.paused && unparsed >= high {
            self.pause_child();
        } else if self.server.paused && unparsed <= low {
            self.resume_child();
        }
    }

    fn pause_child(&mut self) {
        self.server.paused = true;
        self.server.paused_at = self.now.time;
        self.effects.push_back(Effect::PauseOutput);
        self.arm_flow_timer();
    }

    fn resume_child(&mut self) {
        if !self.server.paused {
            return;
        }
        self.server.paused = false;
        self.effects.push_back(Effect::ResumeOutput);
        let timer = self.server.flow_timer.take();
        self.cancel(timer);
    }

    /// A child on its way out has what it wrote read, and is not paused again: it may be waiting for that to finish exiting.
    fn on_exiting(&mut self, exiting: bool) {
        if !exiting || self.child.exiting || self.child.exit.is_some() {
            return;
        }
        self.child.exiting = true;
        self.log(Log::new(Level::Info, "flow.child_exiting"));
        self.flow();
    }

    fn arm_flow_timer(&mut self) {
        self.server.flow_timer = Some(self.set(PAUSED_WATCH_MS, Timer::Flow));
    }

    fn on_flow_timer(&mut self) {
        self.server.flow_timer = None;
        if !self.server.paused {
            return;
        }
        if self.child.reaped.is_some() {
            // Read what it left behind.
            self.resume_child();
            return;
        }
        self.effects.push_back(Effect::ReadExiting);
        let quiet_since = self.server.last_ack_at.max(self.server.paused_at);
        if self.now.time.since(quiet_since) >= self.t.drain_after_ms {
            let unparsed = self.feed.ring.end().saturating_sub(self.server.acked_offset);
            self.log(Log::new(Level::Warn, "flow.server_quiet").with("unparsed", unparsed));
            self.server.draining = true;
            self.resume_child();
            return;
        }
        self.arm_flow_timer();
    }

    // ---- server.js: keeping a server around ------------------------------------------------------------------------

    fn arm_no_conn(&mut self, ms: u64) {
        let old = self.server.no_conn_timer.take();
        self.cancel(old);
        self.server.no_conn_timer = Some(self.set(ms, Timer::NoConn));
    }

    fn spawn_server(&mut self) {
        let len = self.sessiond_cmd.as_ref().map_or(1, Vec::len);
        if self.server.gave_up || self.server.conn.is_some() || self.server.closing || self.finishing || len == 0 {
            return;
        }
        let now = self.now.time;
        let window = self.t.give_up_window_ms;
        self.server.spawn_times.retain(|&t| now.since(t) < window);
        if self.server.spawn_times.len() as u64 >= self.t.give_up_count {
            self.server.gave_up = true;
            let spawns = self.server.spawn_times.len();
            self.log(Log::new(Level::Error, "SESSIOND_GAVE_UP").with("spawns", spawns));
            return;
        }
        self.server.spawn_times.push(now);
        let argv = self.sessiond_cmd.clone().unwrap_or_default();
        self.effects.push_back(Effect::SpawnServer { argv, attempt: self.server.spawn_times.len() });
        let backoff = &self.t.backoff_ms;
        // Still nobody after the backoff: again.
        let wait = backoff.get(self.server.spawn_index.min(backoff.len().saturating_sub(1))).copied().unwrap_or(1);
        self.arm_no_conn(wait);
        self.server.spawn_index += 1;
    }

    fn end_server(&mut self) {
        if self.server.conn_pid > 0 {
            if let Some(start) = self.server.conn_start.clone() {
                self.effects.push_back(Effect::EndServer { pid: self.server.conn_pid, start });
            }
        }
        if let Some(conn) = &self.server.conn {
            self.effects.push_back(Effect::DestroyConn(conn.id));
        }
    }

    /// The child is gone: nobody may be left waiting for a server that will never come.
    fn arm_orphan_timer(&mut self) {
        let old = self.server.orphan_timer.take();
        self.cancel(old);
        if self.child.exit.is_some() && self.server.conn.is_none() {
            self.server.orphan_timer = Some(self.set(self.t.orphan_exit_ms, Timer::Orphan));
        }
    }

    fn heartbeat(&mut self) {
        let now = self.now.time;
        // Time this process lost is not the server's silence.
        self.server.last_pong_at = self.server.last_pong_at.after(now.since(self.server.ping_due));
        self.server.ping_due = now.after(self.t.ping_ms);
        self.server.ping_timer = Some(self.set(self.t.ping_ms, Timer::Ping));
        if self.server.conn.is_none() {
            return;
        }
        if now.since(self.server.last_pong_at) > self.t.pong_timeout_ms {
            self.log(Log::new(Level::Warn, "sessiond.pong_timeout"));
            self.end_server();
            return;
        }
        self.server.ping_seq += 1;
        self.send(&Control::Ping { seq: self.server.ping_seq });
    }

    /// Stops listening at once, so that nothing can connect to a holder on its way out.
    fn close_server(&mut self) {
        self.effects.push_back(Effect::CloseListener);
        let s = &mut self.server;
        let slots = [
            s.ping_timer.take(),
            s.no_conn_timer.take(),
            s.orphan_timer.take(),
            s.stuck_timer.take(),
            s.flow_timer.take(),
        ];
        for slot in slots {
            self.cancel(slot);
        }
    }

    // ---- server.js: pty.sock ------------------------------------------------------------------------------------------

    fn accept(&mut self, conn: ConnId, peer_uid: Option<u32>) {
        if peer_uid != Some(self.me.uid) {
            self.effects.push_back(Effect::Refuse { conn, code: "FORBIDDEN" });
            return;
        }
        if self.server.conn.is_some() {
            self.effects.push_back(Effect::Refuse { conn, code: "BUSY" });
            return;
        }
        let now = self.now.time;
        self.server.conn = Some(Connection { id: conn, out: OutBuf::new() });
        self.server.attached = false;
        self.server.conn_pid = 0;
        self.server.conn_start = None;
        self.server.last_pong_at = now;
        self.server.connected_at = now;
        self.server.gave_up = false;
        let (no_conn, orphan) = (self.server.no_conn_timer.take(), self.server.orphan_timer.take());
        self.cancel(no_conn);
        self.cancel(orphan);
        self.server.spawn_index = 0;
        let hello = self.hello();
        self.send(&Control::HHello(hello));
        if let Some(lflag) = self.child.last_lflag {
            self.send(&Control::Lflag(lflag));
        }
    }

    fn hello(&self) -> HHello {
        let ring = &self.feed.ring;
        HHello {
            proto: HOLDER_PROTO,
            holder_version: HOLDER_VERSION.to_owned(),
            generation: self.generation,
            pid: u32::try_from(self.me.pid).unwrap_or_default(),
            proc_start: self.me.proc_start.clone(),
            pty: self.child.size,
            ring: RingInfo { start: ring.start(), end: ring.end() },
            resize_log: self.feed.resize_log().to_vec(),
            exited: self.child.exit.clone(),
            pts_name: self.child.pts_name.clone(),
            caps: Some(CAPS.iter().map(|&c| c.to_owned()).collect()),
            extra: Map::new(),
            child: ChildInfo {
                pid: u32::try_from(self.child.pid).unwrap_or_default(),
                proc_start: self.child.start.clone(),
            },
        }
    }

    fn on_frame(&mut self, conn: ConnId, frame: Frame<'_>) {
        if !self.is_conn(conn) {
            return;
        }
        match frame {
            Frame::Write(payload) => {
                if let Ok(w) = decode_write(payload) {
                    self.enqueue(w.bytes.to_vec(), w.lone_esc, w.watch_id);
                }
            }
            Frame::Control(message) => self.control(message),
            Frame::Input(_) | Frame::Output(_) | Frame::Data(_) => {}
        }
    }

    fn control(&mut self, message: Control) {
        match message {
            Control::Attach { from_offset, pid, flow } => {
                let s = &mut self.server;
                s.conn_pid = i32::try_from(pid).unwrap_or(0);
                s.conn_start = None;
                s.sent_offset = from_offset;
                s.flow = flow;
                s.acked_offset = from_offset.max(self.feed.ring.start());
                s.last_ack_at = self.now.time;
                s.draining = false;
                s.exit_sent = false;
                s.attached = true;
                if s.conn_pid > 0 {
                    self.effects.push_back(Effect::IdentifyServer { pid: s.conn_pid });
                }
                self.pump();
            }
            Control::Ack { offset } => {
                if offset > self.server.acked_offset {
                    self.server.acked_offset = offset;
                }
                self.server.last_ack_at = self.now.time;
                self.server.draining = false;
                self.flow();
            }
            Control::Resize { cols, rows, .. } => {
                if self.child.exit.is_some() {
                    return;
                }
                // `Number(m.cols) | 0`, held to 1..500.
                #[allow(clippy::cast_possible_wrap, clippy::cast_sign_loss)]
                let clamp = |n: u32| (n as i32).clamp(1, 500) as u32;
                let (cols, rows) = (clamp(cols), clamp(rows));
                self.effects.push_back(Effect::Resize {
                    cols: u16::try_from(cols).unwrap_or(500),
                    rows: u16::try_from(rows).unwrap_or(500),
                });
                self.child.size = Size { cols, rows };
                let entry = self.feed.note_resize(cols, rows);
                self.send(&Control::Resized(Resized { offset: entry.offset, cols, rows }));
            }
            Control::Signal { sig } => {
                match Signal::from_name(&sig).filter(|s| matches!(s, Signal::Cont | Signal::Term)) {
                    Some(signal) => self.signal_child(signal),
                    None => self.send(&Control::Err(ErrorMessage {
                        code: "FORBIDDEN".to_owned(),
                        sig: Some(sig),
                        extra: Map::new(),
                    })),
                }
            }
            Control::CloseMaster => {
                if self.child.exit.is_none() {
                    self.log(Log::new(Level::Info, "close_master"));
                    self.destroy_child();
                }
            }
            Control::Release => {
                if self.child.exit.is_some() {
                    self.finish();
                }
            }
            Control::QueryReply { id, bytes } => {
                if let Some((entry, timer)) = self.server.pending_queries.remove(&id) {
                    self.timers.cancel(timer);
                    self.resolve(entry, (!bytes.is_empty()).then_some(bytes));
                }
            }
            Control::Colors(colors) => self.feed.responder.set_colors(colors),
            Control::Ping { seq } => self.send(&Control::Pong { seq }),
            Control::Pong { .. } => self.server.last_pong_at = self.now.time,
            _ => {}
        }
    }

    fn on_close(&mut self, conn: ConnId) {
        if !self.is_conn(conn) {
            return;
        }
        let lived = self.now.time.since(self.server.connected_at);
        self.server.conn = None;
        self.server.attached = false;
        self.flow();
        for (_, (entry, timer)) in std::mem::take(&mut self.server.pending_queries) {
            self.timers.cancel(timer);
            self.resolve(entry, None);
        }
        self.log(Log::new(Level::Info, "sessiond.disconnected"));
        self.server.short_lived = if lived >= self.t.stable_ms { 0 } else { self.server.short_lived + 1 };
        if !self.server.closing {
            // One that keeps crashing is no emergency.
            let wait = if self.server.short_lived > 1 { self.t.no_conn_ms } else { self.t.respawn_ms };
            self.arm_no_conn(wait);
        }
        self.arm_orphan_timer();
    }

    // ---- timers -------------------------------------------------------------------------------------------------------

    fn on_timer(&mut self, timer: Timer) {
        match timer {
            Timer::Ping => self.heartbeat(),
            Timer::NoConn => {
                self.server.no_conn_timer = None;
                if self.server.conn.is_none() {
                    self.spawn_server();
                }
            }
            Timer::Orphan => {
                self.server.orphan_timer = None;
                self.log(Log::new(Level::Info, "exit.orphaned"));
                self.finish();
            }
            Timer::Stuck => {
                self.server.stuck_timer = None;
                if self.server.conn.as_ref().is_some_and(|c| c.out.len() >= SOCK_HIGH_WATER) {
                    self.log(Log::new(Level::Warn, "sessiond.stuck"));
                    self.end_server();
                }
            }
            Timer::Flow => self.on_flow_timer(),
            Timer::QueryTimeout(id) => {
                if let Some((entry, _)) = self.server.pending_queries.remove(&id) {
                    self.resolve(entry, None);
                }
            }
            Timer::Lflag => self.poll_lflag(),
            Timer::Proc => self.poll_proc(),
            Timer::Grace => {
                self.child.grace_timer = None;
                self.exited(None, None, "proc");
            }
            Timer::Close => {
                // node-pty closes the pty itself; the tail is read first, unless it is being hung up.
                self.child.close_timer = None;
                self.effects.push_back(Effect::ReadTail { read: !self.child.hanging_up, then_close: true });
            }
            Timer::Consume => match self.consume.on_timer(self.child.exit.is_some()) {
                Poll::Read => self.effects.push_back(Effect::ReadInq),
                Poll::Close => self.effects.push_back(Effect::CloseSlave),
            },
            Timer::EscMax | Timer::EscRelease => {
                let mut written = Vec::new();
                let now = self.now.time;
                if self.queue.on_timer(timer, &mut self.timers, now, &mut written) {
                    self.log(Log::new(Level::Warn, "write.esc_hold_expired"));
                    self.send(&Self::error("ESC_HOLD_EXPIRED"));
                }
                self.wrote(written);
            }
            Timer::Cpr(entry) => {
                self.cpr_timers.remove(&entry);
                if self.feed.responder.resolve(entry, None) {
                    if let Some(answers) = self.feed.responder.drain() {
                        self.enqueue(answers, false, 0);
                    }
                }
            }
            Timer::TermWait => {
                self.term_timer = None;
                self.log(Log::new(Level::Warn, "sigterm.child_still_alive"));
                self.finish();
            }
            Timer::FinishEnd => self.end(),
        }
    }
}
