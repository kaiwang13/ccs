//! A byte ring of fixed capacity, addressed by absolute stream offsets: `ring.js`. It keeps the last `capacity` bytes of
//! the child's output, so that a server started again can rebuild from them.

use std::fmt;

/// Output that was overwritten before it could be read: from `from` to `to`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Gap {
    /// The first offset lost.
    pub from: u64,
    /// The offset reading goes on from.
    pub to: u64,
}

/// What [`Ring::read_from`] found.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RingRead {
    /// Where the bytes start.
    pub offset: u64,
    /// The bytes.
    pub bytes: Vec<u8>,
    /// What was asked for and is gone.
    pub gap: Option<Gap>,
}

/// A ring with no room: `RangeError` in the Node code.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ZeroCapacity;

impl fmt::Display for ZeroCapacity {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("Ring capacity must be a positive integer")
    }
}

impl std::error::Error for ZeroCapacity {}

/// The ring.
pub struct Ring {
    buf: Vec<u8>,
    end: u64,
}

impl fmt::Debug for Ring {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ring")
            .field("capacity", &self.buf.len())
            .field("start", &self.start())
            .field("end", &self.end)
            .finish()
    }
}

impl Ring {
    /// An empty ring of `capacity` bytes. Its memory is zero pages until it is written.
    pub fn new(capacity: usize) -> Result<Self, ZeroCapacity> {
        if capacity == 0 {
            return Err(ZeroCapacity);
        }
        Ok(Self { buf: vec![0; capacity], end: 0 })
    }

    /// How much it keeps.
    pub fn capacity(&self) -> usize {
        self.buf.len()
    }

    /// The oldest offset it still has.
    pub fn start(&self) -> u64 {
        self.end.saturating_sub(self.cap())
    }

    /// Just past the newest.
    pub fn end(&self) -> u64 {
        self.end
    }

    fn cap(&self) -> u64 {
        self.buf.len() as u64
    }

    /// Where `offset` is in the buffer.
    fn pos(&self, offset: u64) -> usize {
        // The remainder is below the capacity, which is a usize.
        usize::try_from(offset % self.cap()).unwrap_or(0)
    }

    /// Appends `bytes`, and returns the offset of the first of them. Of more than the capacity only the tail is kept.
    pub fn push(&mut self, bytes: &[u8]) -> u64 {
        let start = self.end;
        let kept = &bytes[bytes.len().saturating_sub(self.buf.len())..];
        let mut pos = self.pos(self.end + (bytes.len() - kept.len()) as u64);
        let mut rest = kept;
        while !rest.is_empty() {
            let n = rest.len().min(self.buf.len() - pos);
            self.buf[pos..pos + n].copy_from_slice(&rest[..n]);
            rest = &rest[n..];
            pos = (pos + n) % self.buf.len();
        }
        self.end += bytes.len() as u64;
        start
    }

    /// Up to `max` bytes from `offset`, or from the start of what is kept when that is later, with the gap between.
    pub fn read_from(&self, offset: u64, max: usize) -> RingRead {
        let mut bytes = Vec::new();
        let mut at = offset;
        let mut first = None;
        let mut gap = None;
        while bytes.len() < max {
            let (from, chunk, g) = self.chunk_from(at, max - bytes.len());
            first.get_or_insert(from);
            gap = gap.or(g);
            if chunk.is_empty() {
                break;
            }
            bytes.extend_from_slice(chunk);
            at = from + chunk.len() as u64;
        }
        RingRead { offset: first.unwrap_or(offset), bytes, gap }
    }

    /// As [`Ring::read_from`], but only as far as the bytes lie together in the buffer, so that nothing is copied: a read
    /// that would wrap stops at the end of the buffer, and the next one goes on from its start.
    pub fn chunk_from(&self, offset: u64, max: usize) -> (u64, &[u8], Option<Gap>) {
        let start = self.start();
        let gap = (offset < start).then_some(Gap { from: offset, to: start });
        let from = offset.clamp(start, self.end);
        let available = usize::try_from(self.end - from).unwrap_or(usize::MAX);
        let pos = self.pos(from);
        let len = available.min(max).min(self.buf.len() - pos);
        (from, &self.buf[pos..pos + len], gap)
    }
}
