//! What each of the holder's timers is for. They all live in one heap, so that those due at the same moment fire in the
//! order they were set, as Node's do.

/// A holder timer.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Timer {
    /// Ping the server.
    Ping,
    /// Nobody connected: start a server.
    NoConn,
    /// The child is gone and nobody came for it: the holder goes.
    Orphan,
    /// The server has taken nothing for too long.
    Stuck,
    /// While reading is paused, look again.
    Flow,
    /// The server did not answer a forwarded query.
    QueryTimeout(u32),
    /// Read the pty's modes.
    Lflag,
    /// Look for the child.
    Proc,
    /// The child was found gone and has not reported its exit.
    Grace,
    /// The child exited and the pty is still open: node-pty closes it after this long.
    Close,
    /// See whether written input has been read.
    Consume,
    /// A lone ESC has been held as long as it may be.
    EscMax,
    /// A lone ESC was read: let what follows go.
    EscRelease,
    /// A cursor position report that is waited for.
    Cpr(u64),
    /// After SIGTERM, the child has not gone.
    TermWait,
    /// The connection has had its moment to flush: the holder exits.
    FinishEnd,
}
