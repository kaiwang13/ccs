//! Telling when bytes written to the child have been read by it: `consume.js`. TIOCINQ reads 0 on a Linux master, so this
//! needs a slave fd, which the run loop holds only while something is being watched.

use nmux_io::{Time, TimerId, Timers};

use crate::timer::Timer;

/// Something written that has now been read.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Consumed {
    /// The WRITE with this watch id.
    Watch(u32),
    /// The most recent lone ESC.
    Esc,
}

#[derive(Clone, Copy, Debug)]
struct Watch {
    id: u32,
    end: u64,
    esc: bool,
}

/// What to do now that the poll timer fired.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Poll {
    /// Read how much input waits on the slave, and give it to [`ConsumeWatcher::on_inq`].
    Read,
    /// Nothing to watch: let the slave go.
    Close,
}

/// The watcher.
#[derive(Debug)]
pub struct ConsumeWatcher {
    poll_ms: u64,
    watches: Vec<Watch>,
    timer: Option<TimerId>,
}

impl ConsumeWatcher {
    /// A watcher that looks every `poll_ms`.
    pub fn new(poll_ms: u64) -> Self {
        Self { poll_ms, watches: Vec::new(), timer: None }
    }

    /// Bytes were written: `watch_id`, 0 for none, is reported once the child has read up to `end`, and so is a lone ESC.
    pub fn add(&mut self, watch_id: u32, end: u64, lone_esc: bool, timers: &mut Timers<Timer>, now: Time) {
        if watch_id != 0 {
            self.watches.push(Watch { id: watch_id, end, esc: false });
        }
        if lone_esc {
            self.watches.push(Watch { id: 0, end, esc: true });
        }
        if (watch_id != 0 || lone_esc) && self.timer.is_none() {
            self.timer = Some(timers.set(now, 0, Timer::Consume));
        }
    }

    /// The poll timer fired.
    pub fn on_timer(&mut self, child_exited: bool) -> Poll {
        self.timer = None;
        if self.watches.is_empty() || child_exited { Poll::Close } else { Poll::Read }
    }

    /// What the slave said: `inq` bytes wait on it, of the `consumable` written and taken by the pty. What has now been
    /// read goes into `out`. True when the slave is to be let go; otherwise the next poll is set.
    #[allow(clippy::too_many_arguments)]
    pub fn on_inq(
        &mut self,
        inq: Option<usize>,
        consumable: u64,
        child_exited: bool,
        timers: &mut Timers<Timer>,
        now: Time,
        out: &mut Vec<Consumed>,
    ) -> bool {
        if let Some(inq) = inq {
            let consumed = consumable.saturating_sub(inq as u64);
            self.watches.retain(|w| {
                if w.end > consumed {
                    return true;
                }
                out.push(if w.esc { Consumed::Esc } else { Consumed::Watch(w.id) });
                false
            });
        }
        if self.watches.is_empty() || child_exited {
            return true;
        }
        self.timer = Some(timers.set(now, self.poll_ms, Timer::Consume));
        false
    }

    /// Stops watching.
    pub fn stop(&mut self, timers: &mut Timers<Timer>) {
        self.watches.clear();
        if let Some(id) = self.timer.take() {
            timers.cancel(id);
        }
    }
}
