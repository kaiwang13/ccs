//! The terminal query responder: `responder.js`. Answers leave strictly in the order the queries came in the child's
//! output. A cursor position report waits, up to 100 ms, for the server's emulator, and holds up the answers behind it.
//!
//! The default colours (OSC 10 and 11) come from the terminal of whoever started the session, recorded in the spec, and
//! then from each terminal that attaches, as the server says; they are never asked for live. Unset or malformed, those
//! queries stay unanswered. OSC 12, the cursor colour, never is answered.
//!
//! The kitty keyboard flags are answered with what the program has set, as a terminal that speaks the protocol answers:
//! every terminal attached gets keys in the form the flags ask for, whether or not it speaks it itself.

use std::collections::VecDeque;

use nmux_vt::seq::{self, QueryKind};
use nmux_vt::{Kind, ModeState, Token};

use crate::spec::Colors;

/// The replies of Cursor's xterm.js 6.1.0-beta.291, byte for byte.
pub const XTVERSION: &[u8] = b"\x1bP>|xterm.js(6.0.0)\x1b\\";
/// Primary device attributes.
pub const DA1: &[u8] = b"\x1b[?1;2c";
/// Secondary device attributes.
pub const DA2: &[u8] = b"\x1b[>0;276;0c";
/// Device status: OK.
pub const DSR5: &[u8] = b"\x1b[0n";

/// Which cursor report a forwarded query asks for.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Cpr {
    /// `CSI 6 n`.
    Cpr,
    /// `CSI ? 6 n`.
    Decxcpr,
}

impl Cpr {
    /// As the wire names it.
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Cpr => "CPR",
            Self::Decxcpr => "DECXCPR",
        }
    }
}

/// A query only the server can answer: its answer is to be given to [`Responder::resolve`] with `entry`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Forward {
    /// The answer's place in line.
    pub entry: u64,
    /// What is asked.
    pub kind: Cpr,
    /// Where the query ends in the stream.
    pub offset: u64,
}

#[derive(Debug)]
struct Entry {
    id: u64,
    done: bool,
    bytes: Option<Vec<u8>>,
}

/// The responder.
#[derive(Debug, Default)]
pub struct Responder {
    colors: Option<Colors>,
    fifo: VecDeque<Entry>,
    next: u64,
}

/// The only form of colour ever written into a pty: `rgb:` and three groups of one to four hex digits. It is checked
/// here, right before it is used, whatever was checked when it was recorded.
pub fn valid_color(c: &str) -> bool {
    let Some(rest) = c.strip_prefix("rgb:") else { return false };
    let groups: Vec<&str> = rest.split('/').collect();
    groups.len() == 3 && groups.iter().all(|g| (1..=4).contains(&g.len()) && g.bytes().all(|b| b.is_ascii_hexdigit()))
}

/// The number `parseInt` reads at the start of `digits`, if any.
fn leading_number(digits: &[u8]) -> Option<u128> {
    let run: Vec<u8> = digits.iter().copied().take_while(u8::is_ascii_digit).collect();
    if run.is_empty() {
        return None;
    }
    Some(run.iter().fold(0u128, |n, &d| n.saturating_mul(10).saturating_add(u128::from(d - b'0'))))
}

impl Responder {
    /// A responder that answers OSC 10 and 11 from `colors`, if they are given and well formed.
    pub fn new(colors: Option<Colors>) -> Self {
        Self { colors, fifo: VecDeque::new(), next: 0 }
    }

    /// The colours OSC 10 and 11 are answered with from now on.
    pub fn set_colors(&mut self, colors: Colors) {
        self.colors = Some(colors);
    }

    fn push(&mut self, done: bool, bytes: Option<Vec<u8>>) -> u64 {
        self.next += 1;
        self.fifo.push_back(Entry { id: self.next, done, bytes });
        self.next
    }

    /// Takes in one token, after `modes` has. A query only the server can answer comes back to be forwarded.
    pub fn on_token(&mut self, tok: &Token<'_>, modes: &ModeState) -> Option<Forward> {
        let kind = seq::query_kind(tok)?;
        match kind {
            QueryKind::Xtversion => self.push(true, Some(XTVERSION.to_vec())),
            QueryKind::Da1 => self.push(true, Some(DA1.to_vec())),
            QueryKind::Da2 => self.push(true, Some(DA2.to_vec())),
            QueryKind::Dsr5 => self.push(true, Some(DSR5.to_vec())),
            QueryKind::Decrqm => {
                let Kind::Csi(csi) = tok.kind else { return None };
                let first = csi.params.as_bytes().split(|&b| b == b';').next().unwrap_or_default();
                let mode = leading_number(first)?;
                let state = u32::try_from(mode).map_or(0, |m| modes.state(m));
                self.push(true, Some(format!("\x1b[?{mode};{state}$y").into_bytes()))
            }
            QueryKind::Cpr | QueryKind::Decxcpr => {
                let entry = self.push(false, None);
                let kind = if kind == QueryKind::Cpr { Cpr::Cpr } else { Cpr::Decxcpr };
                return Some(Forward { entry, kind, offset: tok.end() });
            }
            QueryKind::OscColor => {
                let n = seq::osc_number(tok)?;
                let colors = self.colors.as_ref();
                let value = match n {
                    10 => colors.and_then(|c| c.fg.as_deref()),
                    11 => colors.and_then(|c| c.bg.as_deref()),
                    _ => None,
                };
                let value = value.filter(|v| valid_color(v))?;
                self.push(true, Some(format!("\x1b]{n};{value}\x1b\\").into_bytes()))
            }
            QueryKind::Keyboard => self.push(true, Some(format!("\x1b[?{}u", modes.keyboard()).into_bytes())),
            QueryKind::Other => return None,
        };
        None
    }

    /// The answer to a forwarded query, or `None` for none: the server's, or nothing when it did not answer in time. Only
    /// the first word on an entry counts: true when this was it.
    pub fn resolve(&mut self, entry: u64, bytes: Option<Vec<u8>>) -> bool {
        let Some(e) = self.fifo.iter_mut().find(|e| e.id == entry && !e.done) else { return false };
        e.done = true;
        e.bytes = bytes;
        true
    }

    /// The answers ready to be written, in order, up to the first that is still waited for.
    pub fn drain(&mut self) -> Option<Vec<u8>> {
        let mut out = Vec::new();
        while self.fifo.front().is_some_and(|e| e.done) {
            if let Some(Entry { bytes: Some(bytes), .. }) = self.fifo.pop_front() {
                out.extend_from_slice(&bytes);
            }
        }
        (!out.is_empty()).then_some(out)
    }

    /// Answers waiting in line, ready or not.
    pub fn waiting(&self) -> usize {
        self.fifo.len()
    }
}
