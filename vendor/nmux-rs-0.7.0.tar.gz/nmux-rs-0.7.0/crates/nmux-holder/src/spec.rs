//! The holder spec, `nmux.holderspec/1`: what a server writes before it starts a holder (`src/server/main.js`), checked
//! as `validateHolderSpec` checks it, and the timers, as `DEFAULT_TIMERS` with whatever the spec overrides.

use std::fmt;

pub use nmux_wire::Colors;
use serde_json::{Map, Value};

/// The schema a spec must name.
pub const SCHEMA: &str = "nmux.holderspec/1";

/// A spec that cannot be used, with the words of the Node holder's error.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SpecError(pub String);

impl fmt::Display for SpecError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

impl std::error::Error for SpecError {}

/// The holder's timers and limits: `DEFAULT_TIMERS`.
#[derive(Clone, Debug, PartialEq, Eq)]
#[allow(clippy::struct_field_names)] // the Node names
pub struct HolderTimers {
    /// Nobody has connected for this long: start a server.
    pub no_conn_ms: u64,
    /// A server left: start another after this long.
    pub respawn_ms: u64,
    /// A server that stayed this long was not crashing.
    pub stable_ms: u64,
    /// How often the holder pings its server.
    pub ping_ms: u64,
    /// A server that has not answered for this long is ended.
    pub pong_timeout_ms: u64,
    /// A server that has taken nothing for this long is ended.
    pub stuck_ms: u64,
    /// After SIGTERM, how long the child has to exit by itself.
    pub term_wait_ms: u64,
    /// After the child exited, how long the holder waits for a server to collect it.
    pub orphan_exit_ms: u64,
    /// Waits between starting servers that do not connect.
    pub backoff_ms: Vec<u64>,
    /// This many starts within `give_up_window_ms`, and the holder stops starting servers.
    pub give_up_count: u64,
    /// See `give_up_count`.
    pub give_up_window_ms: u64,
    /// How often the pty's modes are read.
    pub lflag_poll_ms: u64,
    /// How often written input is checked for having been read.
    pub watch_poll_ms: u64,
    /// How often the child is checked for being there.
    pub proc_poll_ms: u64,
    /// How long a child found gone is given to report its own exit.
    pub exit_grace_ms: u64,
    /// Unacknowledged output past which the holder stops reading the pty.
    pub flow_high_bytes: u64,
    /// A server that acknowledges nothing for this long while the holder waits for it is drained around.
    pub drain_after_ms: u64,
}

impl Default for HolderTimers {
    fn default() -> Self {
        Self {
            no_conn_ms: 5000,
            respawn_ms: 250,
            stable_ms: 10000,
            ping_ms: 5000,
            pong_timeout_ms: 30000,
            stuck_ms: 30000,
            term_wait_ms: 20000,
            orphan_exit_ms: 600_000,
            backoff_ms: vec![1000, 2000, 5000, 10000, 30000, 60000],
            give_up_count: 10,
            give_up_window_ms: 600_000,
            lflag_poll_ms: 250,
            watch_poll_ms: 10,
            proc_poll_ms: 200,
            exit_grace_ms: 220,
            flow_high_bytes: 2_097_152,
            drain_after_ms: 5000,
        }
    }
}

impl HolderTimers {
    /// The defaults with what `overrides` says instead. A value that is not a number is passed over.
    fn with(overrides: &Map<String, Value>) -> Self {
        let mut t = Self::default();
        for (name, value) in overrides {
            if name == "backoffMs" {
                if let Some(list) = value.as_array() {
                    t.backoff_ms = list.iter().filter_map(millis).collect();
                }
                continue;
            }
            let Some(ms) = millis(value) else { continue };
            let field = match name.as_str() {
                "noConnMs" => &mut t.no_conn_ms,
                "respawnMs" => &mut t.respawn_ms,
                "stableMs" => &mut t.stable_ms,
                "pingMs" => &mut t.ping_ms,
                "pongTimeoutMs" => &mut t.pong_timeout_ms,
                "stuckMs" => &mut t.stuck_ms,
                "termWaitMs" => &mut t.term_wait_ms,
                "orphanExitMs" => &mut t.orphan_exit_ms,
                "giveUpCount" => &mut t.give_up_count,
                "giveUpWindowMs" => &mut t.give_up_window_ms,
                "lflagPollMs" => &mut t.lflag_poll_ms,
                "watchPollMs" => &mut t.watch_poll_ms,
                "procPollMs" => &mut t.proc_poll_ms,
                "exitGraceMs" => &mut t.exit_grace_ms,
                "flowHighBytes" => &mut t.flow_high_bytes,
                "drainAfterMs" => &mut t.drain_after_ms,
                _ => continue,
            };
            *field = ms;
        }
        t
    }
}

/// A number of milliseconds or bytes: a non-negative number, its fraction dropped.
fn millis(value: &Value) -> Option<u64> {
    let n = value.as_f64()?;
    #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)] // clamped to the range first
    (n.is_finite()).then(|| n.clamp(0.0, 9_007_199_254_740_991.0) as u64)
}

/// A holder spec.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct HolderSpec {
    /// The session.
    pub id: String,
    /// The program and its arguments.
    pub argv: Vec<String>,
    /// The program's environment, in the order JavaScript gives an object's keys.
    pub env: Vec<(String, String)>,
    /// Where it starts.
    pub cwd: String,
    /// The pty's columns.
    pub cols: u32,
    /// The pty's rows.
    pub rows: u32,
    /// How much output the ring keeps.
    pub ring_bytes: usize,
    /// How to start a server, or `None` when the spec names it with something other than strings, which can never be
    /// started.
    pub sessiond_cmd: Option<Vec<String>>,
    /// Which holder of the session this is.
    pub generation: u64,
    /// The runtime directory.
    pub runtime_dir: String,
    /// The colours of the terminal the session was started from, for OSC 10 and 11. Neither is trusted: the responder checks
    /// each again before it answers with it.
    pub term_colors: Option<Colors>,
    /// `TERM` for the program, `xterm-256color` when it is not given.
    pub term: Option<String>,
    /// The timers.
    pub timers: HolderTimers,
}

impl HolderSpec {
    /// Reads and checks a spec.
    pub fn parse(text: &[u8]) -> Result<Self, SpecError> {
        let value: Value =
            serde_json::from_slice(text).map_err(|e| SpecError(format!("holder spec is not JSON: {e}")))?;
        let o = value.as_object().filter(|o| o.get("schema").and_then(Value::as_str) == Some(SCHEMA));
        let o = o.ok_or_else(|| SpecError(format!("holder spec: schema must be \"{SCHEMA}\"")))?;
        let bad = |k: &str| SpecError(format!("holder spec: {k}"));
        let text = |k: &str| {
            o.get(k).and_then(Value::as_str).filter(|s| !s.is_empty()).map(str::to_owned).ok_or_else(|| bad(k))
        };
        let (id, cwd, runtime_dir) = (text("id")?, text("cwd")?, text("runtimeDir")?);
        let argv: Option<Vec<String>> = o.get("argv").and_then(Value::as_array).and_then(|a| strings(a));
        let argv = argv.filter(|a| !a.is_empty()).ok_or_else(|| bad("argv"))?;
        let sessiond_cmd = o.get("sessiondCmd").and_then(Value::as_array).ok_or_else(|| bad("sessiondCmd"))?;
        let env = match o.get("env") {
            Some(Value::Object(map)) => js_entries(map.iter().map(|(k, v)| (k.clone(), js_string(v)))),
            Some(Value::Array(list)) => list.iter().enumerate().map(|(i, v)| (i.to_string(), js_string(v))).collect(),
            _ => return Err(bad("env")),
        };
        let count = |k: &str| o.get(k).and_then(whole).ok_or_else(|| bad(k));
        let (cols, rows, ring_bytes, generation) = (count("cols")?, count("rows")?, count("ringBytes")?, count("gen")?);
        let size = |k: &str, n: u64| u32::try_from(n).map_err(|_| bad(k));
        let term_colors = o.get("termColors").and_then(Value::as_object).map(|c| Colors {
            fg: c.get("fg").and_then(Value::as_str).map(str::to_owned),
            bg: c.get("bg").and_then(Value::as_str).map(str::to_owned),
        });
        let timers = o.get("timers").and_then(Value::as_object).map_or_else(HolderTimers::default, HolderTimers::with);
        Ok(Self {
            id,
            argv,
            env,
            cwd,
            cols: size("cols", cols)?,
            rows: size("rows", rows)?,
            ring_bytes: usize::try_from(ring_bytes).map_err(|_| bad("ringBytes"))?,
            sessiond_cmd: strings(sessiond_cmd),
            generation,
            runtime_dir,
            term_colors,
            term: o.get("term").and_then(Value::as_str).filter(|t| !t.is_empty()).map(str::to_owned),
            timers,
        })
    }

    /// The program's environment as node-pty hands it over: the spec's, with `PWD` set to where it starts and `TERM` to
    /// the spec's terminal, as `NAME=value` strings.
    pub fn child_env(&self) -> Vec<String> {
        let mut env = self.env.clone();
        let mut set = |name: &str, value: &str| match env.iter_mut().find(|(n, _)| n == name) {
            Some((_, v)) => value.clone_into(v),
            None => env.push((name.to_owned(), value.to_owned())),
        };
        set("PWD", &self.cwd);
        set("TERM", self.term.as_deref().unwrap_or("xterm-256color"));
        env.into_iter().map(|(n, v)| format!("{n}={v}")).collect()
    }
}

/// A whole number that is not negative, as `Number.isInteger(n) && n >= 0` takes it.
fn whole(value: &Value) -> Option<u64> {
    if let Some(n) = value.as_u64() {
        return Some(n);
    }
    let n = value.as_f64()?;
    #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)] // checked to be a whole number in range
    (n.fract() == 0.0 && (0.0..1.8e19).contains(&n)).then_some(n as u64)
}

fn strings(list: &[Value]) -> Option<Vec<String>> {
    list.iter().map(|v| v.as_str().map(str::to_owned)).collect()
}

/// A value as JavaScript's `String()` writes it into `NAME=value`.
fn js_string(value: &Value) -> String {
    match value {
        Value::String(s) => s.clone(),
        Value::Null => "null".to_owned(),
        Value::Bool(b) => b.to_string(),
        Value::Number(n) => n.to_string(),
        Value::Array(items) => {
            items.iter().map(|v| if v.is_null() { String::new() } else { js_string(v) }).collect::<Vec<_>>().join(",")
        }
        Value::Object(_) => "[object Object]".to_owned(),
    }
}

/// An object's entries in the order JavaScript gives its keys: those that are array indices first, by number, then the
/// rest as they came.
fn js_entries(entries: impl Iterator<Item = (String, String)>) -> Vec<(String, String)> {
    let index = |k: &str| {
        let canonical = !k.is_empty() && (k == "0" || !k.starts_with('0')) && k.bytes().all(|b| b.is_ascii_digit());
        canonical.then(|| k.parse::<u64>().ok()).flatten().filter(|&n| n < u64::from(u32::MAX))
    };
    let (mut indexed, rest): (Vec<_>, Vec<_>) = entries.partition(|(k, _)| index(k).is_some());
    indexed.sort_by_key(|(k, _)| index(k));
    indexed.extend(rest);
    indexed
}
