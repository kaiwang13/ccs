//! What has been written to the child and not yet taken by the pty: node-pty's write queue, which counts towards the write
//! queue's cap, and which an overflow drops.

use std::collections::VecDeque;

/// The backlog, write by write.
#[derive(Debug, Default)]
pub struct PtyOut {
    items: VecDeque<Vec<u8>>,
    /// How much of the first write the pty has taken.
    offset: usize,
}

impl PtyOut {
    /// Nothing waiting.
    pub fn new() -> Self {
        Self::default()
    }

    /// A write for the pty. An empty one is nothing.
    pub fn push(&mut self, bytes: Vec<u8>) {
        if !bytes.is_empty() {
            self.items.push_back(bytes);
        }
    }

    /// Bytes not yet taken.
    pub fn backlog(&self) -> usize {
        self.items.iter().map(Vec::len).sum::<usize>() - self.offset
    }

    /// Nothing waits.
    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    /// Drops what waits, except the rest of a write the pty has taken part of, which would otherwise arrive cut.
    pub fn drop_backlog(&mut self) {
        let keep = usize::from(self.offset > 0);
        self.items.truncate(keep);
    }

    /// Drops everything.
    pub fn clear(&mut self) {
        self.items.clear();
        self.offset = 0;
    }

    /// The bytes to give the pty next.
    pub fn front(&self) -> Option<&[u8]> {
        self.items.front().map(|item| &item[self.offset..])
    }

    /// The pty took `n` bytes of [`PtyOut::front`].
    pub fn consume(&mut self, n: usize) {
        let Some(first) = self.items.front() else { return };
        self.offset += n;
        if self.offset >= first.len() {
            self.items.pop_front();
            self.offset = 0;
        }
    }
}
