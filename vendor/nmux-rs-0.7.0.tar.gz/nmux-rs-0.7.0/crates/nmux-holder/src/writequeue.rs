//! The holder's write queue: `writequeue.js`. One queue, in order, for client input and the responder's answers. After a
//! write that is a lone ESC, what follows waits until the child has read that ESC and `esc_hold_ms` more, and at most
//! `esc_hold_max_ms`, so that the child's input parser does not take the two for one key. What is queued, with what the
//! pty has not taken yet, is capped at `cap_bytes`.

use std::collections::VecDeque;

use nmux_io::{Time, TimerId, Timers};

use crate::timer::Timer;

/// Bytes waiting to be written to the child.
#[derive(Debug)]
struct Item {
    bytes: Vec<u8>,
    lone_esc: bool,
    watch_id: u32,
}

/// Bytes handed to the child, with what the consume watcher needs to know of them.
#[derive(Debug, PartialEq, Eq)]
pub struct Written {
    /// The bytes.
    pub bytes: Vec<u8>,
    /// Report CONSUMED with this id once they are read, and 0 for no report.
    pub watch_id: u32,
    /// The total written once these are.
    pub end: u64,
    /// They are a lone ESC.
    pub lone_esc: bool,
}

/// What the queue did with what it was given.
#[derive(Debug, PartialEq, Eq)]
pub enum Enqueued {
    /// Queued, and perhaps written.
    Queued,
    /// Over the cap: everything queued is dropped, and the pty's own backlog is to be dropped too, rather than replay
    /// stale input into a process that resumes.
    Overflow,
}

/// The queue.
#[derive(Debug)]
pub struct WriteQueue {
    cap_bytes: usize,
    esc_hold_ms: u64,
    esc_hold_max_ms: u64,
    items: VecDeque<Item>,
    queued_bytes: usize,
    written: u64,
    holding: bool,
    max_timer: Option<TimerId>,
    release_timer: Option<TimerId>,
}

impl Default for WriteQueue {
    fn default() -> Self {
        Self::new(1_048_576, 60, 1500)
    }
}

impl WriteQueue {
    /// A queue with these limits. The holder uses the defaults: 1 MiB, 60 ms and 1500 ms.
    pub fn new(cap_bytes: usize, esc_hold_ms: u64, esc_hold_max_ms: u64) -> Self {
        Self {
            cap_bytes,
            esc_hold_ms,
            esc_hold_max_ms,
            items: VecDeque::new(),
            queued_bytes: 0,
            written: 0,
            holding: false,
            max_timer: None,
            release_timer: None,
        }
    }

    /// Everything handed to the child so far.
    pub fn written_total(&self) -> u64 {
        self.written
    }

    /// Bytes waiting in the queue.
    pub fn queued_bytes(&self) -> usize {
        self.queued_bytes
    }

    /// Queues `bytes`, given that the pty has `backlog` bytes it has not taken yet, and writes what may be written into
    /// `out`.
    #[allow(clippy::too_many_arguments)]
    pub fn enqueue(
        &mut self,
        bytes: Vec<u8>,
        lone_esc: bool,
        watch_id: u32,
        backlog: usize,
        timers: &mut Timers<Timer>,
        now: Time,
        out: &mut Vec<Written>,
    ) -> Enqueued {
        if self.queued_bytes + backlog + bytes.len() > self.cap_bytes {
            self.items.clear();
            self.queued_bytes = 0;
            return Enqueued::Overflow;
        }
        self.queued_bytes += bytes.len();
        self.items.push_back(Item { bytes, lone_esc, watch_id });
        self.pump(timers, now, out);
        Enqueued::Queued
    }

    /// The most recent lone ESC has been read by the child.
    pub fn on_consumed(&mut self, timers: &mut Timers<Timer>, now: Time) {
        if !self.holding || self.release_timer.is_some() {
            return;
        }
        self.release_timer = Some(timers.set(now, self.esc_hold_ms, Timer::EscRelease));
    }

    /// One of the queue's timers fired. True when the hold expired without the ESC being read, which is reported.
    pub fn on_timer(&mut self, timer: Timer, timers: &mut Timers<Timer>, now: Time, out: &mut Vec<Written>) -> bool {
        match timer {
            Timer::EscMax => {
                self.max_timer = None;
                self.release(true, timers, now, out)
            }
            Timer::EscRelease => {
                self.release_timer = None;
                self.release(false, timers, now, out)
            }
            _ => false,
        }
    }

    fn pump(&mut self, timers: &mut Timers<Timer>, now: Time, out: &mut Vec<Written>) {
        while !self.holding {
            let Some(item) = self.items.pop_front() else { return };
            self.queued_bytes -= item.bytes.len();
            self.written += item.bytes.len() as u64;
            if item.lone_esc {
                self.holding = true;
                self.max_timer = Some(timers.set(now, self.esc_hold_max_ms, Timer::EscMax));
            }
            out.push(Written {
                bytes: item.bytes,
                watch_id: item.watch_id,
                end: self.written,
                lone_esc: item.lone_esc,
            });
        }
    }

    fn release(&mut self, expired: bool, timers: &mut Timers<Timer>, now: Time, out: &mut Vec<Written>) -> bool {
        if !self.holding {
            return false;
        }
        self.holding = false;
        for id in [self.max_timer.take(), self.release_timer.take()].into_iter().flatten() {
            timers.cancel(id);
        }
        self.pump(timers, now, out);
        expired
    }
}
