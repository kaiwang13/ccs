//! The holder's log: JSON lines, one object per line, `{ts, lvl, comp, session, ev, ...data}`, as `log.js` writes them.
//! Logs carry lifecycle events only: never terminal bytes or keystrokes. A failed write is counted and never fails the
//! holder.

use std::fs::{self, File, OpenOptions};
use std::io::Write;
use std::os::unix::fs::{DirBuilderExt, OpenOptionsExt};
use std::path::PathBuf;

use serde_json::{Map, Value};

/// How much a record matters.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Level {
    /// For whoever debugs.
    Debug,
    /// Something that happened.
    Info,
    /// Something that should not have.
    Warn,
    /// Something that went wrong.
    Error,
}

impl Level {
    /// As the log spells it.
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Debug => "debug",
            Self::Info => "info",
            Self::Warn => "warn",
            Self::Error => "error",
        }
    }
}

/// One record, without the fields every record has.
#[derive(Clone, Debug, PartialEq)]
pub struct Log {
    /// How much it matters.
    pub level: Level,
    /// What happened, such as `child.exit`.
    pub ev: &'static str,
    /// What it says about it, in order.
    pub fields: Map<String, Value>,
}

impl Log {
    /// A record with no fields.
    pub fn new(level: Level, ev: &'static str) -> Self {
        Self { level, ev, fields: Map::new() }
    }

    /// The record with one more field.
    #[must_use]
    pub fn with(mut self, name: &str, value: impl Into<Value>) -> Self {
        self.fields.insert(name.to_owned(), value.into());
        self
    }
}

/// Appends records to one file, which is made, with its directory, the first time a record is written.
#[derive(Debug)]
pub struct Logger {
    path: PathBuf,
    comp: &'static str,
    session: String,
    file: Option<File>,
    /// Records that could not be written.
    pub dropped: u64,
}

impl Logger {
    /// A logger for `comp` of `session`, into `path`.
    pub fn new(path: PathBuf, comp: &'static str, session: &str) -> Self {
        Self { path, comp, session: session.to_owned(), file: None, dropped: 0 }
    }

    /// Writes `log`, stamped with `ts`, an ISO 8601 time.
    pub fn write(&mut self, log: &Log, ts: &str) {
        let mut record = Map::new();
        record.insert("ts".to_owned(), ts.into());
        record.insert("lvl".to_owned(), log.level.as_str().into());
        record.insert("comp".to_owned(), self.comp.into());
        record.insert("session".to_owned(), self.session.clone().into());
        record.insert("ev".to_owned(), log.ev.into());
        for (k, v) in &log.fields {
            if !matches!(k.as_str(), "ts" | "lvl" | "comp" | "session" | "ev") {
                record.insert(k.clone(), v.clone());
            }
        }
        let Ok(mut line) = serde_json::to_vec(&Value::Object(record)) else {
            self.dropped += 1;
            return;
        };
        line.push(b'\n');
        if self.append(&line).is_err() {
            self.dropped += 1;
            self.file = None;
        }
    }

    fn append(&mut self, line: &[u8]) -> std::io::Result<()> {
        if self.file.is_none() {
            if let Some(dir) = self.path.parent() {
                fs::DirBuilder::new().recursive(true).mode(0o700).create(dir)?;
            }
            self.file = Some(OpenOptions::new().append(true).create(true).mode(0o600).open(&self.path)?);
        }
        match &mut self.file {
            Some(file) => file.write_all(line),
            None => Ok(()),
        }
    }
}
