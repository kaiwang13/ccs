//! The holder: the process that owns a session's pty and outlives everything else, ported from `src/holder` of the Node
//! code. It runs the child, keeps the last of its output in a ring, answers the terminal queries a server cannot be
//! trusted to answer in time, and keeps a server around.
//!
//! [`Holder`] is the logic, with no I/O: events in, effects out, time handed in. [`run`] is the thin loop that connects
//! it to the pty, pty.sock and the clock, on `nmux-io` and `nmux-platform`. It is the process with the most to lose, so
//! it holds no emulator, nothing that grows without bound, and nothing that can panic at run time.

mod consume;
mod feed;
mod holder;
mod log;
mod ptyout;
mod responder;
mod ring;
mod run;
mod spec;
mod timer;
mod writequeue;

pub use consume::{ConsumeWatcher, Consumed, Poll};
pub use feed::Feed;
pub use holder::{ConnId, Effect, Event, HOLDER_VERSION, Holder, Started};
pub use log::{Level, Log, Logger};
pub use ptyout::PtyOut;
pub use responder::{Cpr, DA1, DA2, DSR5, Forward, Responder, XTVERSION, valid_color};
pub use ring::{Gap, Ring, RingRead, ZeroCapacity};
pub use run::{main, run};
pub use spec::{Colors, HolderSpec, HolderTimers, SCHEMA, SpecError};
pub use timer::Timer;
pub use writequeue::{Enqueued, WriteQueue, Written};
