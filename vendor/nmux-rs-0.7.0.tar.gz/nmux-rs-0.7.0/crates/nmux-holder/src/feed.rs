//! The child's output as the holder keeps it: the ring, the modes, the answers to terminal queries, and the resize log.
//! `feed.js`.

use nmux_vt::{Lexer, ModeState};
use nmux_wire::{Resized, Size};

use crate::responder::{Forward, Responder};
use crate::ring::{Ring, ZeroCapacity};
use crate::spec::Colors;

/// The spawn size, and the last 63 resizes.
const RESIZE_LOG: usize = 64;

/// The feed.
#[derive(Debug)]
pub struct Feed {
    /// The output.
    pub ring: Ring,
    /// The modes the output set, for DECRQM answers.
    pub modes: ModeState,
    lexer: Lexer,
    /// The answers.
    pub responder: Responder,
    resize_log: Vec<Resized>,
}

impl Feed {
    /// A feed for a child started at `size`.
    pub fn new(ring_bytes: usize, size: Size, colors: Option<Colors>) -> Result<Self, ZeroCapacity> {
        Ok(Self {
            ring: Ring::new(ring_bytes)?,
            modes: ModeState::new(),
            lexer: Lexer::new(0),
            responder: Responder::new(colors),
            resize_log: vec![Resized { offset: 0, cols: size.cols, rows: size.rows }],
        })
    }

    /// Takes in output. Each answer the responder can give now goes into `writes`, in order and as the Node code would
    /// write it; each query only the server can answer goes into `forwards`.
    pub fn push(&mut self, bytes: &[u8], writes: &mut Vec<Vec<u8>>, forwards: &mut Vec<Forward>) {
        self.ring.push(bytes);
        let Self { lexer, modes, responder, .. } = self;
        lexer.feed(bytes, |tok| {
            modes.apply(&tok);
            if let Some(forward) = responder.on_token(&tok, modes) {
                forwards.push(forward);
            }
            if let Some(answer) = responder.drain() {
                writes.push(answer);
            }
        });
    }

    /// The pty has a new size from the end of the ring on.
    pub fn note_resize(&mut self, cols: u32, rows: u32) -> Resized {
        let entry = Resized { offset: self.ring.end(), cols, rows };
        self.resize_log.push(entry);
        if self.resize_log.len() > RESIZE_LOG {
            self.resize_log.remove(1);
        }
        entry
    }

    /// The spawn size and the resizes since.
    pub fn resize_log(&self) -> &[Resized] {
        &self.resize_log
    }
}
