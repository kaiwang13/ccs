//! Unix-socket connections that carry frames, and a socket that listens for them.
//!
//! Sockets are registered for reading and writing at once, edge-triggered, and never registered again: a connection
//! remembers whether it was last seen readable and writable, and only stops trying when the kernel says it would block.

use std::fs;
use std::io;
use std::os::fd::{AsFd, BorrowedFd};
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};

use mio::net::{UnixListener, UnixStream};
use mio::{Interest, Registry, Token};
use nmux_wire::{Control, Frame, FrameType, ProtocolError};

use crate::buf::{InBuf, OutBuf, ReadStatus};
use crate::reactor::Ready;

/// How much one call to [`Conn::read`] takes before it lets other work in.
const READ_LIMIT: usize = 1024 * 1024;

/// How a read of a connection ended.
#[derive(Debug)]
pub enum ReadEnd {
    /// It is still open.
    Open,
    /// The peer closed it.
    Closed,
    /// It failed: an I/O error, or a frame that could not be decoded. Good frames before it were delivered.
    Failed(io::Error),
}

/// A connected unix socket and what has been read from it. The bytes it writes come from an [`OutBuf`], which may live
/// elsewhere, such as in a sans-IO core.
#[derive(Debug)]
pub struct Conn {
    stream: UnixStream,
    inbuf: InBuf,
    readable: bool,
    writable: bool,
}

impl Conn {
    /// A connection on `stream`.
    pub fn new(stream: UnixStream) -> Self {
        Self { stream, inbuf: InBuf::new(), readable: true, writable: true }
    }

    /// Watches it for reading and writing, under `token`.
    pub fn register(&mut self, registry: &Registry, token: Token) -> io::Result<()> {
        registry.register(&mut self.stream, token, Interest::READABLE | Interest::WRITABLE)
    }

    /// Stops watching it.
    pub fn deregister(&mut self, registry: &Registry) -> io::Result<()> {
        registry.deregister(&mut self.stream)
    }

    /// Takes in what the reactor said about it.
    pub fn on_ready(&mut self, ready: &Ready) {
        self.readable |= ready.readable || ready.closed;
        self.writable |= ready.writable || ready.closed;
    }

    /// There may be something to read.
    pub fn wants_read(&self) -> bool {
        self.readable
    }

    /// It has not said it would block on a write since it last said it could take more.
    pub fn writable(&self) -> bool {
        self.writable
    }

    /// Reads what is there, up to a limit, and hands each whole frame to `on_frame`.
    pub fn read(&mut self, on_frame: impl FnMut(Frame<'_>)) -> ReadEnd {
        if !self.readable {
            return ReadEnd::Open;
        }
        let status = self.inbuf.read_from(&mut self.stream, READ_LIMIT);
        let decoded = self.inbuf.frames(on_frame);
        match (status, decoded) {
            (_, Err(e)) => ReadEnd::Failed(protocol_error(e)),
            (Err(e), Ok(())) => ReadEnd::Failed(e),
            (Ok(ReadStatus::Closed), Ok(())) => ReadEnd::Closed,
            (Ok(ReadStatus::Drained), Ok(())) => {
                self.readable = false;
                ReadEnd::Open
            }
            (Ok(ReadStatus::More), Ok(())) => ReadEnd::Open,
        }
    }

    /// Writes what `out` holds, as far as the socket takes it. True when it is all written.
    pub fn flush(&mut self, out: &mut OutBuf) -> io::Result<bool> {
        if out.is_empty() {
            return Ok(true);
        }
        if !self.writable {
            return Ok(false);
        }
        let done = out.write_to(&mut self.stream)?;
        self.writable = done;
        Ok(done)
    }

    /// Ends the writing half: the peer reads to the end of what was written, and then sees the end.
    pub fn shutdown_write(&self) -> io::Result<()> {
        self.stream.shutdown(std::net::Shutdown::Write)
    }

    /// The user id of the peer.
    pub fn peer_uid(&self) -> io::Result<u32> {
        nmux_platform::peer_uid(self.stream.as_fd())
    }
}

impl AsFd for Conn {
    fn as_fd(&self) -> BorrowedFd<'_> {
        self.stream.as_fd()
    }
}

fn protocol_error(e: ProtocolError) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, e)
}

/// A connection that owns its [`OutBuf`] too: `FramedSocket` in the Node code.
#[derive(Debug)]
pub struct FramedConn {
    conn: Conn,
    out: OutBuf,
    ending: bool,
}

impl FramedConn {
    /// A framed connection on `stream`.
    pub fn new(stream: UnixStream) -> Self {
        Self { conn: Conn::new(stream), out: OutBuf::new(), ending: false }
    }

    /// Connects to the socket at `path`. The connection may still be in progress: it is writable once it is made.
    pub fn connect(path: &Path) -> io::Result<Self> {
        Ok(Self::new(UnixStream::connect(path)?))
    }

    /// The connection underneath.
    pub fn conn(&mut self) -> &mut Conn {
        &mut self.conn
    }

    /// What waits to be written.
    pub fn out(&mut self) -> &mut OutBuf {
        &mut self.out
    }

    /// Bytes accepted and not yet handed to the kernel.
    pub fn writable_length(&self) -> usize {
        self.out.len()
    }

    /// Queues a control message.
    pub fn send_control(&mut self, message: &Control) -> Result<(), ProtocolError> {
        self.out.control(message)
    }

    /// Queues a frame.
    pub fn send(&mut self, frame_type: FrameType, payload: &[u8]) -> Result<(), ProtocolError> {
        self.out.frame(frame_type, payload)
    }

    /// Writes what is queued, as far as the socket takes it, and once it is all written after [`FramedConn::end`], ends
    /// the writing half. True when nothing is left to write.
    pub fn flush(&mut self) -> io::Result<bool> {
        let done = self.conn.flush(&mut self.out)?;
        if done && self.ending {
            self.ending = false;
            self.conn.shutdown_write()?;
        }
        Ok(done)
    }

    /// Ends the connection once what is queued is written.
    pub fn end(&mut self) -> io::Result<()> {
        self.ending = true;
        self.flush().map(|_| ())
    }
}

/// A unix socket that listens, at a path.
#[derive(Debug)]
pub struct Listener {
    inner: UnixListener,
    path: PathBuf,
}

impl Listener {
    /// Listens at `path`, which is removed first if it is there, and then given `mode`.
    pub fn bind(path: &Path, mode: u32) -> io::Result<Self> {
        match fs::remove_file(path) {
            Err(e) if e.kind() != io::ErrorKind::NotFound => return Err(e),
            _ => {}
        }
        let inner = UnixListener::bind(path)?;
        fs::set_permissions(path, fs::Permissions::from_mode(mode))?;
        Ok(Self { inner, path: path.to_owned() })
    }

    /// Where it listens.
    pub fn path(&self) -> &Path {
        &self.path
    }

    /// Watches it for connections, under `token`.
    pub fn register(&mut self, registry: &Registry, token: Token) -> io::Result<()> {
        registry.register(&mut self.inner, token, Interest::READABLE)
    }

    /// Stops watching it.
    pub fn deregister(&mut self, registry: &Registry) -> io::Result<()> {
        registry.deregister(&mut self.inner)
    }

    /// The next connection waiting, or `None` when there is none.
    pub fn accept(&self) -> io::Result<Option<UnixStream>> {
        loop {
            match self.inner.accept() {
                Ok((stream, _)) => return Ok(Some(stream)),
                Err(e) if e.kind() == io::ErrorKind::WouldBlock => return Ok(None),
                Err(e) if e.kind() == io::ErrorKind::Interrupted => {}
                Err(e) => return Err(e),
            }
        }
    }
}
