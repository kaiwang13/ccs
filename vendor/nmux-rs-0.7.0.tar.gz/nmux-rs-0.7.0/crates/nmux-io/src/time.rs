//! Time as a value: a monotonic clock in milliseconds that the run loop reads and hands in, and a heap of deadlines that
//! knows nothing of clocks. What took a fake clock in Node is a plain test here.

use std::cmp::Reverse;
use std::collections::{BinaryHeap, HashMap};

/// A moment on a monotonic clock, in milliseconds from some start. Only differences mean anything.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct Time(u64);

impl Time {
    /// The start of the clock.
    pub const ZERO: Self = Self(0);

    /// `ms` milliseconds after the start of the clock.
    pub const fn from_ms(ms: u64) -> Self {
        Self(ms)
    }

    /// Milliseconds since the start of the clock.
    pub const fn ms(self) -> u64 {
        self.0
    }

    /// `ms` milliseconds later.
    #[must_use]
    pub const fn after(self, ms: u64) -> Self {
        Self(self.0.saturating_add(ms))
    }

    /// Milliseconds since `earlier`, and 0 if it is not earlier.
    pub const fn since(self, earlier: Self) -> u64 {
        self.0.saturating_sub(earlier.0)
    }
}

/// What a run loop hands its core with every event: the monotonic time, for timers and durations, and the wall clock,
/// for what is written down for people.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Now {
    /// The monotonic time.
    pub time: Time,
    /// Milliseconds since 1970, in UTC.
    pub wall_ms: i64,
}

impl Now {
    /// `ms` milliseconds later on both clocks.
    #[must_use]
    pub fn after(self, ms: u64) -> Self {
        Self { time: self.time.after(ms), wall_ms: self.wall_ms.saturating_add(i64::try_from(ms).unwrap_or(i64::MAX)) }
    }
}

/// A timer that was set, to cancel it by.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct TimerId(u64);

/// Deadlines with a key each. Due timers come out in the order of their deadlines, and those with the same deadline in
/// the order they were set, as Node's timers fire.
#[derive(Debug)]
pub struct Timers<K> {
    heap: BinaryHeap<Reverse<(Time, u64)>>,
    live: HashMap<u64, (Time, K)>,
    seq: u64,
}

impl<K> Default for Timers<K> {
    fn default() -> Self {
        Self { heap: BinaryHeap::new(), live: HashMap::new(), seq: 0 }
    }
}

impl<K> Timers<K> {
    /// No timers.
    pub fn new() -> Self {
        Self::default()
    }

    /// A timer `ms` after `now`.
    pub fn set(&mut self, now: Time, ms: u64, key: K) -> TimerId {
        self.set_at(now.after(ms), key)
    }

    /// A timer at `due`.
    pub fn set_at(&mut self, due: Time, key: K) -> TimerId {
        self.seq += 1;
        self.heap.push(Reverse((due, self.seq)));
        self.live.insert(self.seq, (due, key));
        TimerId(self.seq)
    }

    /// Cancels a timer, and gives its key back if it had not fired.
    pub fn cancel(&mut self, id: TimerId) -> Option<K> {
        let (_, key) = self.live.remove(&id.0)?;
        // What was cancelled stays in the heap until its deadline. Many cancelled far deadlines would make it grow, so
        // it is rebuilt from what is live once they are most of it.
        if self.heap.len() > 64 + 2 * self.live.len() {
            self.heap = self.live.iter().map(|(&seq, &(due, _))| Reverse((due, seq))).collect();
        }
        Some(key)
    }

    /// Whether the timer is set and has not fired.
    pub fn is_set(&self, id: TimerId) -> bool {
        self.live.contains_key(&id.0)
    }

    /// The earliest deadline.
    pub fn next_due(&mut self) -> Option<Time> {
        while let Some(&Reverse((due, seq))) = self.heap.peek() {
            if self.live.contains_key(&seq) {
                return Some(due);
            }
            self.heap.pop();
        }
        None
    }

    /// The earliest timer due at `now`, which is then no longer set.
    pub fn pop_due(&mut self, now: Time) -> Option<(TimerId, K)> {
        while let Some(&Reverse((due, seq))) = self.heap.peek() {
            if due > now {
                return None;
            }
            self.heap.pop();
            if let Some((_, key)) = self.live.remove(&seq) {
                return Some((TimerId(seq), key));
            }
        }
        None
    }

    /// How many are set.
    pub fn len(&self) -> usize {
        self.live.len()
    }

    /// None is set.
    pub fn is_empty(&self) -> bool {
        self.live.is_empty()
    }
}
