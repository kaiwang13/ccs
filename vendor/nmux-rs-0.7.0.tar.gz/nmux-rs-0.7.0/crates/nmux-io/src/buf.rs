//! The two halves of a framed connection's buffering, with no socket in them: what is waiting to be written, and what has
//! been read and not yet decoded. A core that owns an [`OutBuf`] stays free of I/O; its run loop writes it out.

use std::io::{self, Read, Write};

use nmux_wire::{Control, Frame, FrameDecoder, FrameType, ProtocolError, encode_control, encode_data, encode_frame};

/// After a burst, memory above this goes back once the buffer has emptied.
const KEEP_CAPACITY: usize = 256 * 1024;
/// What is read at a time.
const READ_CHUNK: usize = 64 * 1024;

/// Frames waiting to be written, in order. [`OutBuf::len`] is what Node calls a socket's `writableLength`: bytes accepted
/// and not yet handed to the kernel, which is what backpressure is measured by.
#[derive(Debug, Default)]
pub struct OutBuf {
    buf: Vec<u8>,
    sent: usize,
}

impl OutBuf {
    /// Nothing waiting.
    pub fn new() -> Self {
        Self::default()
    }

    /// Bytes waiting to be written.
    pub fn len(&self) -> usize {
        self.buf.len() - self.sent
    }

    /// Nothing is waiting.
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// The bytes waiting, in order.
    pub fn pending(&self) -> &[u8] {
        &self.buf[self.sent..]
    }

    /// `n` bytes of [`OutBuf::pending`] were written.
    pub fn consume(&mut self, n: usize) {
        self.sent = (self.sent + n).min(self.buf.len());
        if self.sent == self.buf.len() {
            self.clear();
        } else if self.sent >= KEEP_CAPACITY && self.sent * 2 >= self.buf.len() {
            self.buf.drain(..self.sent);
            self.sent = 0;
        }
    }

    /// Drops everything waiting.
    pub fn clear(&mut self) {
        self.buf.clear();
        self.sent = 0;
        if self.buf.capacity() > KEEP_CAPACITY {
            self.buf.shrink_to(KEEP_CAPACITY);
        }
    }

    /// A control message.
    pub fn control(&mut self, message: &Control) -> Result<(), ProtocolError> {
        encode_control(&mut self.buf, message)
    }

    /// A frame of this type.
    pub fn frame(&mut self, frame_type: FrameType, payload: &[u8]) -> Result<(), ProtocolError> {
        encode_frame(&mut self.buf, frame_type, payload)
    }

    /// A DATA frame: output from `offset`.
    pub fn data(&mut self, offset: u64, bytes: &[u8]) -> Result<(), ProtocolError> {
        encode_data(&mut self.buf, offset, bytes)
    }

    /// A WRITE frame.
    pub fn write(&mut self, write: &nmux_wire::Write<'_>) -> Result<(), ProtocolError> {
        nmux_wire::encode_write(&mut self.buf, write)
    }

    /// Writes as much as `w` takes without blocking. True when everything was written, false when `w` would block.
    pub fn write_to(&mut self, w: &mut impl Write) -> io::Result<bool> {
        while !self.is_empty() {
            match w.write(self.pending()) {
                Ok(0) => return Err(io::ErrorKind::WriteZero.into()),
                Ok(n) => self.consume(n),
                Err(e) if e.kind() == io::ErrorKind::WouldBlock => return Ok(false),
                Err(e) if e.kind() == io::ErrorKind::Interrupted => {}
                Err(e) => return Err(e),
            }
        }
        Ok(true)
    }
}

/// What a read found.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ReadStatus {
    /// Everything there was has been read; more may come.
    Drained,
    /// There may be more to read: the read stopped at its limit.
    More,
    /// The peer has closed its end.
    Closed,
}

/// Bytes read and not yet decoded, and the decoder. Frames are decoded in place: a binary payload borrows this buffer
/// for as long as the callback that is handed it.
#[derive(Debug, Default)]
pub struct InBuf {
    /// Initialised throughout: bytes `start..end` are read and not yet decoded.
    buf: Vec<u8>,
    start: usize,
    end: usize,
    decoder: FrameDecoder,
}

impl InBuf {
    /// Nothing read.
    pub fn new() -> Self {
        Self::default()
    }

    /// Bytes read and not yet decoded.
    pub fn len(&self) -> usize {
        self.end - self.start
    }

    /// Nothing waits to be decoded.
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Room for at least one read at the end, made by moving what is held to the front, or by growing.
    fn room(&mut self) -> &mut [u8] {
        if self.start == self.end {
            self.start = 0;
            self.end = 0;
            if self.buf.len() > KEEP_CAPACITY {
                self.buf.truncate(READ_CHUNK);
                self.buf.shrink_to(KEEP_CAPACITY);
            }
        }
        if self.buf.len() - self.end < READ_CHUNK {
            self.buf.copy_within(self.start..self.end, 0);
            self.end -= self.start;
            self.start = 0;
            if self.buf.len() - self.end < READ_CHUNK {
                self.buf.resize(self.end + READ_CHUNK, 0);
            }
        }
        &mut self.buf[self.end..]
    }

    /// Bytes from elsewhere, as if they had been read.
    pub fn push(&mut self, bytes: &[u8]) {
        for chunk in bytes.chunks(READ_CHUNK) {
            self.room()[..chunk.len()].copy_from_slice(chunk);
            self.end += chunk.len();
        }
    }

    /// Reads from `r` without blocking, up to `limit` bytes.
    pub fn read_from(&mut self, r: &mut impl Read, limit: usize) -> io::Result<ReadStatus> {
        let mut total = 0;
        while total < limit {
            match r.read(self.room()) {
                Ok(0) => return Ok(ReadStatus::Closed),
                Ok(n) => {
                    self.end += n;
                    total += n;
                }
                Err(e) if e.kind() == io::ErrorKind::WouldBlock => return Ok(ReadStatus::Drained),
                Err(e) if e.kind() == io::ErrorKind::Interrupted => {}
                Err(e) => return Err(e),
            }
        }
        Ok(ReadStatus::More)
    }

    /// Hands each whole frame to `on_frame`, in order. A frame that cannot be decoded ends it, after the good ones before
    /// it; the decoder then stays failed, and the connection must be dropped.
    pub fn frames(&mut self, mut on_frame: impl FnMut(Frame<'_>)) -> Result<(), ProtocolError> {
        loop {
            let (frame, len) = match self.decoder.decode(&self.buf[self.start..self.end]) {
                Ok(Some(decoded)) => decoded,
                Ok(None) => return Ok(()),
                Err(e) => {
                    self.start = self.end;
                    return Err(e);
                }
            };
            on_frame(frame);
            self.start += len;
        }
    }
}
