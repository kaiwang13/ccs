//! The reactor every nmux process runs on: readiness on `mio`, deadlines as values, signals on a self-pipe, and framed
//! connections over unix sockets with the buffering and backpressure of Node's `FramedSocket`. One thread, no async
//! runtime: a run loop waits here, hands what happened to its sans-IO core, and does what the core asks.
//!
//! [`OutBuf`] and [`InBuf`] hold no socket, so a core can own its outgoing frames and stay free of I/O; [`Conn`] is the
//! socket they are written to and read from, and [`FramedConn`] puts the two together for code that is not a core.

mod buf;
mod conn;
mod reactor;
mod time;

pub use buf::{InBuf, OutBuf, ReadStatus};
pub use conn::{Conn, FramedConn, Listener, ReadEnd};
pub use mio::net::UnixStream;
pub use mio::unix::SourceFd;
pub use mio::{Interest, Registry, Token, Waker};
pub use reactor::{Reactor, Ready, SIGNAL_TOKEN};
pub use time::{Now, Time, TimerId, Timers};
