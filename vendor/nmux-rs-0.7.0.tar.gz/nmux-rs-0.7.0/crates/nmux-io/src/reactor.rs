//! The reactor: one thread waits on every descriptor, on the signals it catches, and on the next deadline, whichever comes
//! first. It does not run anything: it says what is ready, and the run loop decides.

use std::io;
use std::os::fd::AsRawFd;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use mio::unix::SourceFd;
use mio::{Events, Interest, Poll, Registry, Token};
use nmux_platform::{Signal, SignalPipe};

use crate::time::{Now, Time};

/// The token the reactor keeps for its signals. Others are the caller's.
pub const SIGNAL_TOKEN: Token = Token(usize::MAX);

/// What the reactor saw on one descriptor.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)] // one for each thing a descriptor can say
pub struct Ready {
    /// Whose it is.
    pub token: Token,
    /// There is something to read.
    pub readable: bool,
    /// It takes more writing.
    pub writable: bool,
    /// The other end hung up, or one direction is closed: a read or write will now say how.
    pub closed: bool,
    /// It has an error waiting.
    pub error: bool,
}

/// One thread's wait for descriptors, signals and time.
#[derive(Debug)]
pub struct Reactor {
    poll: Poll,
    events: Events,
    ready: Vec<Ready>,
    origin: Instant,
    signals: Option<SignalPipe>,
    caught: Vec<Signal>,
}

impl Reactor {
    /// A reactor with nothing to watch. Its clock starts now.
    pub fn new() -> io::Result<Self> {
        Ok(Self {
            poll: Poll::new()?,
            events: Events::with_capacity(256),
            ready: Vec::new(),
            origin: Instant::now(),
            signals: None,
            caught: Vec::new(),
        })
    }

    /// Where descriptors are registered.
    pub fn registry(&self) -> &Registry {
        self.poll.registry()
    }

    /// The time on both clocks.
    pub fn now(&self) -> Now {
        let time = Time::from_ms(u64::try_from(self.origin.elapsed().as_millis()).unwrap_or(u64::MAX));
        let wall = SystemTime::now().duration_since(UNIX_EPOCH).map_or(0, |d| d.as_millis());
        Now { time, wall_ms: i64::try_from(wall).unwrap_or(i64::MAX) }
    }

    /// Catches `signals` from now on: they come out of [`Reactor::take_signals`] instead of doing what they would.
    pub fn catch_signals(&mut self, signals: &[Signal]) -> io::Result<()> {
        let pipe = SignalPipe::install(signals)?;
        let fd = pipe.fd().as_raw_fd();
        self.poll.registry().register(&mut SourceFd(&fd), SIGNAL_TOKEN, Interest::READABLE)?;
        self.signals = Some(pipe);
        Ok(())
    }

    /// Waits until something is ready, a signal comes, or `deadline` passes, whichever is first. No deadline waits for
    /// the others; a deadline that has passed only looks.
    pub fn wait(&mut self, deadline: Option<Time>) -> io::Result<()> {
        let timeout = deadline.map(|due| Duration::from_millis(due.since(self.now().time)));
        self.ready.clear();
        match self.poll.poll(&mut self.events, timeout) {
            Ok(()) => {}
            Err(e) if e.kind() == io::ErrorKind::Interrupted => return Ok(()),
            Err(e) => return Err(e),
        }
        for event in &self.events {
            if event.token() == SIGNAL_TOKEN {
                if let Some(pipe) = &mut self.signals {
                    pipe.drain(&mut self.caught);
                }
                continue;
            }
            self.ready.push(Ready {
                token: event.token(),
                readable: event.is_readable(),
                writable: event.is_writable(),
                closed: event.is_read_closed() || event.is_write_closed(),
                error: event.is_error(),
            });
        }
        Ok(())
    }

    /// What the last wait found ready.
    pub fn ready(&self) -> &[Ready] {
        &self.ready
    }

    /// The signals caught since the last call, in order, each once.
    pub fn take_signals(&mut self) -> Vec<Signal> {
        std::mem::take(&mut self.caught)
    }
}
