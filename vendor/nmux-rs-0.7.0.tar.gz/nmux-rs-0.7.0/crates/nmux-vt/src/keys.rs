//! Line-by-line port of the key decoders of a widely used terminal UI, so that a key means here exactly what it means to a
//! program built on it. `keys.js` is the reference, and names the minified functions each part came from. Behaviour must
//! stay byte-for-byte identical: a differential test in the project that depends on this compares the Node file with the
//! functions extracted from the binary, and a golden test in this crate compares this one with the Node file.
//!
//! Linux defaults are baked in, as they are there: backspace is not ctrl+backspace, and altgr-as-text is off, which is why
//! the code for those two switches is not here.
//!
//! The tokenizer glue around these functions (paste buffering, kitty codes 128 to 255 re-assembled into UTF-8, terminal
//! responses, SGR mouse) is not ported. None of it can turn a token into a C0 control key, so classification of Z, Q, C and
//! D is unaffected.

/// A key as the terminal UI sees it.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)] // the shape every test and every caller of the original knows
pub struct KeyEvent {
    /// The name, which is empty for a sequence with no meaning, and `None` where a table had nothing to say, as
    /// `undefined` in the original.
    pub name: Option<String>,
    /// Ctrl is held.
    pub ctrl: bool,
    /// Alt is held.
    pub meta: bool,
    /// Shift is held.
    pub shift: bool,
    /// A second ESC was in front of the sequence.
    pub option: bool,
    /// Super is held.
    pub super_key: bool,
    /// The sequence this came from.
    pub sequence: String,
}

impl KeyEvent {
    fn plain(seq: &str, name: &str, ctrl: bool) -> Self {
        Self { name: Some(name.to_owned()), ctrl, sequence: seq.to_owned(), ..Self::default() }
    }

    fn is_named(&self, name: &str) -> bool {
        self.name.as_deref() == Some(name)
    }
}

/// What carries over between tokens: the first half of a surrogate pair split across two win32 key events.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct KeyState {
    /// The first half, if it came.
    pub high_surrogate: Option<u16>,
}

/// The result of [`decode_win32`].
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Win32 {
    /// The ordinary sequences the event stands for.
    pub sequences: Vec<String>,
    /// The state for the next token.
    pub high_surrogate: Option<u16>,
}

/// What a key is to the input policy.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum KeyClass {
    /// Ctrl+Z
    Z,
    /// Ctrl+\
    Q,
    /// Ctrl+C
    C,
    /// Ctrl+D
    D,
    /// Escape
    Esc,
    /// Return or Enter
    Return,
    /// Backspace
    Backspace,
    /// One printable character.
    Printable,
    /// Decodes to nothing, but holds a C0 byte that means something to a tty.
    Ignored,
    /// Anything else.
    Other,
}

impl KeyClass {
    /// The name config and messages use.
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Z => "Z",
            Self::Q => "Q",
            Self::C => "C",
            Self::D => "D",
            Self::Esc => "ESC",
            Self::Return => "RETURN",
            Self::Backspace => "BACKSPACE",
            Self::Printable => "PRINTABLE",
            Self::Ignored => "IGNORED",
            Self::Other => "OTHER",
        }
    }
}

/// A number as the original holds it: the double `parseInt` gives. It compares as a double and wraps only on its way to a
/// bit mask or a character code, so `65562`, which is 26 modulo 65536, is a Ctrl+Z there and has to be one here.
#[derive(Clone, Copy)]
struct Number(f64);

impl Number {
    fn parse(digits: &str) -> Self {
        Self(digits.parse().unwrap_or(f64::NAN))
    }

    /// For comparisons, which are all with small numbers: past `u32` it saturates, and saturates to nothing in any table.
    #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)]
    fn int(self) -> u32 {
        self.0 as u32
    }

    /// `ToUint32`, for what a JavaScript `&` sees.
    #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)]
    fn bits(self) -> u32 {
        if self.0.is_finite() { self.0.rem_euclid(4_294_967_296.0) as u32 } else { 0 }
    }

    /// `String.fromCharCode`, which truncates to 16 bits.
    fn to_char(self) -> char {
        code_unit_char(self.bits() & 0xffff)
    }
}

/// A UTF-16 code unit as a character. Half a surrogate pair has no `char` of its own, so it becomes U+FFFD, which every
/// decoder here treats as the original treats the lone half.
fn code_unit_char(unit: u32) -> char {
    char::from_u32(unit).unwrap_or(char::REPLACEMENT_CHARACTER)
}

/// The run of digits at the start of `s` and what follows it, as `\d+`.
fn digits(s: &str) -> Option<(&str, &str)> {
    let n = s.bytes().take_while(u8::is_ascii_digit).count();
    (n > 0).then(|| s.split_at(n))
}

// ---- win32-input-mode (bS, gS, SS, Vp, Oa, ll, jp) ----------------------------

/// The fields of `\x1b[\d*(;\d*){0,5}_`, as `bS`.
fn win32_fields(seq: &str) -> Option<Vec<&str>> {
    let body = seq.strip_prefix("\x1b[")?.strip_suffix('_')?;
    let valid = body.bytes().all(|b| b.is_ascii_digit() || b == b';') && body.matches(';').count() <= 5;
    valid.then(|| body.split(';').collect())
}

/// `Oa`: a number, with a default for one missing or empty.
fn param(fields: &[&str], i: usize, default: f64) -> Number {
    fields.get(i).filter(|f| !f.is_empty()).map_or(Number(default), |f| Number::parse(f))
}

/// `gS`
fn special_vk(vk: u32) -> Option<(u32, char)> {
    match vk {
        33 => Some((5, '~')),
        34 => Some((6, '~')),
        35 => Some((1, 'F')),
        36 => Some((1, 'H')),
        37 => Some((1, 'D')),
        38 => Some((1, 'A')),
        39 => Some((1, 'C')),
        40 => Some((1, 'B')),
        45 => Some((2, '~')),
        46 => Some((3, '~')),
        _ => None,
    }
}

/// `SS`: F5 to F12.
const FKEY_CODES: [u32; 8] = [15, 17, 18, 19, 20, 21, 23, 24];

/// `jp`: a character code as Ctrl changes it.
fn ctrl_code(y: Number) -> Number {
    let n = y.int();
    let code = match n {
        0..=31 => n,
        64..=95 | 97..=122 => n & 0x1f,
        32 | 50 => 0,
        51..=55 => n - 51 + 27,
        56 | 63 => 127,
        47 => 31,
        _ => return y,
    };
    Number(f64::from(code))
}

/// The sequence of a key that has one of its own whatever the keyboard layout: arrows, editing keys, function keys.
fn named_key_sequence(vk: u32, modifier: u32) -> Option<String> {
    if let Some((code, last)) = special_vk(vk) {
        return Some(match (last, modifier) {
            ('~', 1) => format!("\x1b[{code}~"),
            ('~', _) => format!("\x1b[{code};{modifier}~"),
            (_, 1) => format!("\x1b[{last}"),
            _ => format!("\x1b[1;{modifier}{last}"),
        });
    }
    match vk {
        112..=115 => {
            let p = code_unit_char(80 + vk - 112);
            Some(if modifier == 1 { format!("\x1bO{p}") } else { format!("\x1b[1;{modifier}{p}") })
        }
        116..=123 => {
            let p = FKEY_CODES[(vk - 116) as usize];
            Some(if modifier == 1 { format!("\x1b[{p}~") } else { format!("\x1b[{p};{modifier}~") })
        }
        _ => None,
    }
}

/// `Vp`: a win32-input-mode key event, `ESC [ Vk ; Sc ; Uc ; Kd ; Cs ; Rc _`, as the ordinary sequences it stands for, or
/// `None` if `seq` is not one. `high_surrogate` is the first half of a character that an earlier event left.
pub fn decode_win32(seq: &str, high_surrogate: Option<u16>) -> Option<Win32> {
    let f = win32_fields(seq)?;
    let vk = param(&f, 0, 0.0).int();
    let uc = param(&f, 2, 0.0);
    let key_down = param(&f, 3, 0.0).int() != 0;
    let cs = param(&f, 4, 0.0).bits();
    let rc = param(&f, 5, 1.0).int().clamp(1, 8) as usize;
    let none = |high_surrogate| Some(Win32 { sequences: Vec::new(), high_surrogate });
    let repeat = |seq: String| Some(Win32 { sequences: vec![seq; rc], high_surrogate: None });
    if !key_down {
        if vk == 18 && uc.int() != 0 {
            return Some(Win32 { sequences: vec![uc.to_char().to_string()], high_surrogate: None });
        }
        return none(high_surrogate);
    }
    // The control key state: right and left Alt, right and left Ctrl, Shift.
    let alt = cs & 0b11 != 0;
    let ctl = cs & 0b1100 != 0;
    let shift = cs & 0b1_0000 != 0;
    let alt_gr = alt && ctl && uc.int() > 32 && uc.int() != 127;
    let c = ctl && !alt_gr; // Vp's A
    let a = alt && !alt_gr; // Vp's H
    let modifier = 1 + u32::from(shift) + if a { 2 } else { 0 } + if c { 4 } else { 0 };
    if let Some(seq) = named_key_sequence(vk, modifier) {
        return repeat(seq);
    }
    let prefix = if a { "\x1b" } else { "" };
    match vk {
        8 => return repeat(format!("{prefix}{}", if c { "\x08" } else { "\x7f" })),
        9 => return repeat(format!("{prefix}{}", if shift { "\x1b[Z" } else { "\t" })),
        13 => return repeat(format!("{prefix}{}", if c { "\n" } else { "\r" })),
        27 => return repeat(format!("{prefix}\x1b")),
        _ => {}
    }
    let mut y = uc;
    if c && vk == 32 {
        y = Number(0.0);
    } else if y.int() == 0 {
        let letter = (65..=90).contains(&vk);
        let digit = (48..=57).contains(&vk);
        if !(c || a) || !(letter || digit) {
            return none(high_surrogate);
        }
        y = Number(f64::from(if letter && !shift { vk + 32 } else { vk }));
        if c {
            y = ctrl_code(y);
        }
    } else if c {
        y = ctrl_code(y);
    }
    if (0xd800..=0xdbff).contains(&y.int()) {
        return none(u16::try_from(y.int()).ok());
    }
    if !(0xdc00..=0xdfff).contains(&y.int()) {
        return repeat(format!("{prefix}{}", y.to_char()));
    }
    let Some(high) = high_surrogate else { return none(None) };
    let low = u16::try_from(y.int()).unwrap_or_default();
    let pair: String = char::decode_utf16([high, low]).map(|c| c.unwrap_or(char::REPLACEMENT_CHARACTER)).collect();
    repeat(format!("{prefix}{pair}"))
}

// ---- keypress parser (ES, xS, xf, Cf, Mf, YS, KS, kS, Ef, Ip, Jp, iy, Pl, Cr) --

/// `YS`
fn key_name(code: &str) -> Option<&'static str> {
    Some(match code {
        "OP" | "[11~" | "[[A" => "f1",
        "OQ" | "[12~" | "[[B" => "f2",
        "OR" | "[13~" | "[[C" => "f3",
        "OS" | "[14~" | "[[D" => "f4",
        "[15~" | "[[E" => "f5",
        "[17~" => "f6",
        "[18~" => "f7",
        "[19~" => "f8",
        "[20~" => "f9",
        "[21~" => "f10",
        "[23~" => "f11",
        "[24~" => "f12",
        "Op" => "0",
        "Oq" => "1",
        "Or" => "2",
        "Os" => "3",
        "Ot" => "4",
        "Ou" => "5",
        "Ov" => "6",
        "Ow" => "7",
        "Ox" => "8",
        "Oy" => "9",
        "Oj" => "*",
        "Ok" => "+",
        "Ol" => ",",
        "Om" => "-",
        "On" => ".",
        "Oo" => "/",
        "OM" => "return",
        "[A" | "OA" | "[a" | "Oa" => "up",
        "[B" | "OB" | "[b" | "Ob" => "down",
        "[C" | "OC" | "[c" | "Oc" => "right",
        "[D" | "OD" | "[d" | "Od" => "left",
        "[E" | "OE" | "[e" | "Oe" => "clear",
        "[F" | "OF" | "[4~" | "[8~" | "[8$" | "[8^" => "end",
        "[H" | "OH" | "[1~" | "[7~" | "[7$" | "[7^" => "home",
        "[2~" | "[2$" | "[2^" => "insert",
        "[3~" | "[3$" | "[3^" => "delete",
        "[5~" | "[[5~" | "[5$" | "[5^" => "pageup",
        "[6~" | "[[6~" | "[6$" | "[6^" => "pagedown",
        "[Z" => "tab",
        _ => return None,
    })
}

/// `KS`
const SHIFTED_CODES: [&str; 12] = ["[a", "[b", "[c", "[d", "[e", "[2$", "[3$", "[5$", "[6$", "[7$", "[8$", "[Z"];
/// `kS`
const CTRL_CODES: [&str; 11] = ["Oa", "Ob", "Oc", "Od", "Oe", "[2^", "[3^", "[5^", "[6^", "[7^", "[8^"];

/// Flags from a kitty or xterm modifier parameter, lock bits ignored.
#[derive(Clone, Copy)]
#[allow(clippy::struct_excessive_bools)] // one for each modifier key
struct Modifiers {
    shift: bool,
    meta: bool,
    ctrl: bool,
    super_key: bool,
}

/// `Ef`
fn modifiers(v: Number) -> Modifiers {
    let s = Number(v.0 - 1.0).bits();
    Modifiers { shift: s & 1 != 0, meta: s & 2 != 0, ctrl: s & 4 != 0, super_key: s & 8 != 0 }
}

/// `Ip`: a key code's name.
fn code_name(code: Number) -> Option<String> {
    let name = match code.int() {
        8 | 127 => "backspace",
        9 => "tab",
        13 | 57414 => "return",
        27 => "escape",
        32 => "space",
        57399 => "0",
        57400 => "1",
        57401 => "2",
        57402 => "3",
        57403 => "4",
        57404 => "5",
        57405 => "6",
        57406 => "7",
        57407 => "8",
        57408 => "9",
        57409 => ".",
        57410 => "/",
        57411 => "*",
        57412 => "-",
        57413 => "+",
        57415 => "=",
        57416 => ",",
        57417 => "left",
        57418 => "right",
        57419 => "up",
        57420 => "down",
        57421 => "pageup",
        57422 => "pagedown",
        57423 => "home",
        57424 => "end",
        57425 => "insert",
        57426 => "delete",
        n @ 33..=126 => return Some(code_unit_char(n).to_ascii_lowercase().to_string()),
        n @ 160..=55295 => return Some(code_unit_char(n).to_string()),
        _ => return None,
    };
    Some(name.to_owned())
}

/// `Jp`: the names a code has when Ctrl is the only modifier.
fn ctrl_alias(m: Modifiers, code: Number) -> Option<&'static str> {
    if !m.ctrl || m.shift || m.meta || m.super_key {
        return None;
    }
    match code.int() {
        91 => Some("escape"),
        109 | 77 => Some("return"),
        105 | 73 => Some("tab"),
        104 | 72 => Some("backspace"),
        _ => None,
    }
}

/// The event for a kitty or modifyOtherKeys code.
fn coded_key(seq: &str, m: Modifiers, code: Number) -> KeyEvent {
    let alias = ctrl_alias(m, code);
    KeyEvent {
        name: alias.map(str::to_owned).or_else(|| code_name(code)),
        ctrl: alias.is_none() && m.ctrl,
        meta: m.meta,
        shift: m.shift,
        option: false,
        super_key: m.super_key,
        sequence: seq.to_owned(),
    }
}

/// `xf`: `\x1b[code(:shifted(:base)?)?(;mods)?u`, at the start of the sequence.
fn kitty_key(n: &str) -> Option<KeyEvent> {
    let (code, mut rest) = digits(n.strip_prefix("\x1b[")?)?;
    let mut base = None;
    if let Some(shifted) = rest.strip_prefix(':') {
        rest = shifted.trim_start_matches(|c: char| c.is_ascii_digit());
        if let Some((found, tail)) = rest.strip_prefix(':').and_then(digits) {
            base = Some(Number::parse(found));
            rest = tail;
        }
    }
    let mut modifier = Number(1.0);
    if let Some((found, tail)) = rest.strip_prefix(';').and_then(digits) {
        modifier = Number::parse(found);
        rest = tail;
    }
    if !rest.starts_with('u') {
        return None;
    }
    let m = modifiers(modifier);
    let code = Number::parse(code);
    Some(coded_key(n, m, base.filter(|_| m.ctrl && code.int() > 127).unwrap_or(code)))
}

/// `Cf`: `\x1b[27;mods;code~`, at the start of the sequence.
fn modify_other_keys_key(n: &str) -> Option<KeyEvent> {
    let (modifier, rest) = digits(n.strip_prefix("\x1b[27;")?)?;
    let (code, rest) = digits(rest.strip_prefix(';')?)?;
    rest.starts_with('~').then(|| coded_key(n, modifiers(Number::parse(modifier)), Number::parse(code)))
}

/// `iy`: a legacy or SGR mouse report as a wheel key.
fn wheel_key(seq: &str, button: Number) -> Option<KeyEvent> {
    let button = button.bits();
    let wheel = button & 0x43;
    if wheel != 64 && wheel != 65 {
        return None;
    }
    Some(KeyEvent {
        ctrl: button & 16 != 0,
        meta: button & 8 != 0,
        shift: button & 4 != 0,
        ..KeyEvent::plain(seq, if wheel == 64 { "wheelup" } else { "wheeldown" }, false)
    })
}

/// A coordinate, which may be negative for a drag off the grid. This tracks the later upstream version that widened both
/// coordinate groups: the recorded baseline accepts only non-negative ones, so the two differ on exactly this input.
fn coordinate(s: &str) -> Option<&str> {
    digits(s.strip_prefix('-').unwrap_or(s)).map(|(_, rest)| rest)
}

/// `Mf`: `\x1b[<button;x;y[Mm]`.
fn sgr_mouse_button(n: &str) -> Option<Number> {
    let (button, rest) = digits(n.strip_prefix("\x1b[<")?)?;
    let rest = coordinate(rest.strip_prefix(';')?)?;
    let rest = coordinate(rest.strip_prefix(';')?)?;
    matches!(rest, "M" | "m").then(|| Number::parse(button))
}

/// `\x1b[M` and three more: `n.length` in the original counts UTF-16 units, and so does this.
fn x10_mouse_button(n: &str) -> Option<Number> {
    if !n.starts_with("\x1b[M") || n.encode_utf16().count() != 6 {
        return None;
    }
    n.encode_utf16().nth(3).map(|unit| Number(f64::from(unit) - 32.0))
}

/// A function key: what `xS` captures of it.
struct FunctionKey {
    code: String,
    modifier: Number,
}

/// What follows the introducer in `xS`: `\d+(;\d+)?[~^$]`, or else `(1;)?\d*[a-zA-Z]`.
fn function_key_tail(introducer: &str, tail: &str) -> Option<FunctionKey> {
    if let Some((number, rest)) = digits(tail) {
        let (modifier, rest) = rest.strip_prefix(';').and_then(digits).map_or((None, rest), |(m, r)| (Some(m), r));
        if let Some(last) = rest.chars().next().filter(|c| matches!(c, '~' | '^' | '$')) {
            let modifier = modifier.map_or(Number(1.0), Number::parse);
            return Some(FunctionKey { code: format!("{introducer}{number}{last}"), modifier });
        }
    }
    let rest = tail.strip_prefix("1;").unwrap_or(tail);
    let (number, rest) = digits(rest).map_or((None, rest), |(d, r)| (Some(d), r));
    let last = rest.chars().next().filter(char::is_ascii_alphabetic)?;
    let modifier = number.map_or(Number(1.0), Number::parse);
    Some(FunctionKey { code: format!("{introducer}{last}"), modifier })
}

/// `xS`: `\x1b+(O|N|\[|\[\[)` and a tail, at the start of the sequence. Its alternatives are tried in that order.
fn function_key(n: &str) -> Option<FunctionKey> {
    let rest = n.strip_prefix('\x1b')?.trim_start_matches('\x1b');
    ["O", "N", "[", "[["]
        .into_iter()
        .find_map(|introducer| function_key_tail(introducer, rest.strip_prefix(introducer)?))
}

/// The only character of `n`, if it is one UTF-16 unit long, as `n.length === 1`.
fn single_unit(n: &str) -> Option<char> {
    let mut chars = n.chars();
    chars.next().filter(|c| chars.next().is_none() && c.len_utf16() == 1)
}

/// What is left of `Cr` for a sequence that is none of the modern forms: the C0 keys and the legacy escape sequences.
fn legacy_key(n: &str) -> KeyEvent {
    let mut c = KeyEvent::plain(n, "", false);
    let escaped = n.len() == 2;
    let (name, meta) = match n {
        "\r" | "\x1b\r" => ("return", escaped),
        "\n" | "\x1b\n" => ("enter", escaped),
        "\t" | "\x1b\t" => ("tab", escaped),
        "\x08" | "\x1b\x08" | "\x7f" | "\x1b\x7f" => ("backspace", escaped),
        "\x1b" | "\x1b\x1b" => ("escape", escaped),
        " " | "\x1b " => ("space", escaped),
        _ => return other_key(n, c),
    };
    c.name = Some(name.to_owned());
    c.meta = meta;
    c
}

/// The rest of [`legacy_key`]: single characters, Alt and a letter, and function keys.
fn other_key(n: &str, mut c: KeyEvent) -> KeyEvent {
    let name = |s: &str| Some(s.to_owned());
    if let Some(one) = single_unit(n) {
        match one {
            '\x1c' => (c.name, c.ctrl) = (name("\\"), true),
            '\x1d' => (c.name, c.ctrl) = (name("]"), true),
            '\x1e' => (c.name, c.ctrl) = (name("^"), true),
            '\x1f' => (c.name, c.ctrl) = (name("_"), true),
            '\0'..='\x1a' => (c.name, c.ctrl) = (Some(code_unit_char(u32::from(one) + 96).to_string()), true),
            '0'..='9' => c.name = name("number"),
            'a'..='z' => c.name = name(n),
            'A'..='Z' => (c.name, c.shift) = (Some(n.to_ascii_lowercase()), true),
            _ => {}
        }
        return c;
    }
    if let Some(letter) = n.strip_prefix('\x1b').and_then(single_unit).filter(char::is_ascii_alphanumeric) {
        c.meta = true;
        c.shift = letter.is_ascii_uppercase();
        c.name = Some(letter.to_ascii_lowercase().to_string());
    } else if let Some(key) = function_key(n) {
        let m = modifiers(key.modifier);
        c.option = n.starts_with("\x1b\x1b");
        c.ctrl = m.ctrl || CTRL_CODES.contains(&key.code.as_str());
        c.meta = m.meta;
        c.super_key = m.super_key;
        c.shift = m.shift || SHIFTED_CODES.contains(&key.code.as_str());
        c.name = key_name(&key.code).map(str::to_owned);
    }
    c
}

/// `Cr`: what one key sequence is.
pub fn decode_key(seq: &str) -> KeyEvent {
    if let Some(key) = kitty_key(seq).or_else(|| modify_other_keys_key(seq)) {
        return key;
    }
    if let Some(button) = sgr_mouse_button(seq).or_else(|| x10_mouse_button(seq)) {
        return wheel_key(seq, button).unwrap_or_else(|| KeyEvent::plain(seq, "mouse", false));
    }
    let mut c = legacy_key(seq);
    match seq {
        "\x1bb" => (c.meta, c.name) = (true, Some("left".to_owned())),
        "\x1bf" => (c.meta, c.name) = (true, Some("right".to_owned())),
        "\x1b[1~" => return KeyEvent::plain(seq, "home", false),
        "\x1b[4~" => return KeyEvent::plain(seq, "end", false),
        "\x1b[5~" => return KeyEvent::plain(seq, "pageup", false),
        "\x1b[6~" => return KeyEvent::plain(seq, "pagedown", false),
        "\x1b[1;5D" => return KeyEvent::plain(seq, "left", true),
        "\x1b[1;5C" => return KeyEvent::plain(seq, "right", true),
        _ => {}
    }
    c
}

/// Decodes one input token the way that UI's input loop does: win32-input-mode first, with each sequence it produces
/// decoded by the keypress parser, and otherwise the keypress parser directly.
pub fn decode_input_token(seq: &str, state: &mut KeyState) -> Vec<KeyEvent> {
    match decode_win32(seq, state.high_surrogate) {
        Some(win32) => {
            state.high_surrogate = win32.high_surrogate;
            win32.sequences.iter().map(|s| decode_key(s)).collect()
        }
        None => vec![decode_key(seq)],
    }
}

/// What this key is to the input policy.
pub fn classify(ev: &KeyEvent) -> KeyClass {
    if ev.is_named("z") && ev.ctrl {
        KeyClass::Z
    } else if ev.is_named("\\") && ev.ctrl {
        KeyClass::Q
    } else if ev.is_named("c") && ev.ctrl {
        KeyClass::C
    } else if ev.is_named("d") && ev.ctrl {
        KeyClass::D
    } else if ev.is_named("escape") && !ev.meta {
        KeyClass::Esc
    } else if ev.is_named("return") || ev.is_named("enter") {
        KeyClass::Return
    } else if ev.is_named("backspace") {
        KeyClass::Backspace
    } else if is_printable(ev) {
        KeyClass::Printable
    } else if ev.is_named("") && ev.sequence.contains(['\x03', '\x04', '\x1a', '\x1c']) {
        KeyClass::Ignored
    } else {
        KeyClass::Other
    }
}

fn is_printable(ev: &KeyEvent) -> bool {
    let mut chars = ev.name.as_deref().unwrap_or_default().chars();
    let one = chars.next().filter(|_| chars.next().is_none());
    one.is_some_and(|c| !ev.ctrl && !ev.meta && c >= ' ' && c != '\x7f')
}
