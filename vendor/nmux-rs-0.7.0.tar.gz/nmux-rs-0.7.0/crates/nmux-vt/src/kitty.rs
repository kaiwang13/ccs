//! The kitty keyboard protocol (<https://sw.kovidgoyal.net/kitty/keyboard-protocol/>): the flags a program pushes, pops and
//! sets, the stack each screen keeps them on, how nmux tells a terminal what the program has set, and a key from a terminal
//! that does not speak the protocol, as one that does would send it.
//!
//! A program's own pushes and pops never reach a terminal. nmux keeps at most one entry of its own on a terminal's stack,
//! with the flags the program has now on the screen it is on, so that leaving the terminal, by detaching or by losing the
//! connection, takes off exactly what nmux put on, whatever the program did.

use std::fmt::Write as _;

use crate::token::{Csi, Kind, Token};

/// Keys that would be read as something else are sent as `CSI u`: Esc, and a key with Alt or Ctrl.
pub const DISAMBIGUATE: u8 = 1;
/// Key releases and repeats are reported.
pub const EVENT_TYPES: u8 = 2;
/// The key's shifted and base-layout forms go with it.
pub const ALTERNATE_KEYS: u8 = 4;
/// Every key is sent as `CSI u`, text and Enter, Tab and Backspace too.
pub const ALL_KEYS: u8 = 8;
/// With [`ALL_KEYS`], the text a key types goes with it.
pub const ASSOCIATED_TEXT: u8 = 16;
/// Every flag there is.
const FLAGS: u8 = 0x1f;
/// The entries a stack keeps: a push past them drops the oldest, as kitty and Ghostty do.
const DEPTH: usize = 8;

/// How `CSI = flags ; how u` changes the flags on top.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum How {
    /// To these: 1.
    Replace,
    /// These on as well: 2.
    Add,
    /// These off: 3.
    Remove,
}

/// What a program does to its flags.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Op {
    /// `CSI > flags u`.
    Push(u8),
    /// `CSI < n u`: this many off the top, at least one.
    Pop(u32),
    /// `CSI = flags ; how u`.
    Set(u8, How),
}

/// The digits of a field as a number, saturating; none is 0.
fn number(field: &[u8]) -> u32 {
    field.iter().fold(0u32, |n, &d| n.saturating_mul(10).saturating_add(u32::from(d - b'0')))
}

fn flags(field: &[u8]) -> u8 {
    u8::try_from(number(field) & u32::from(FLAGS)).unwrap_or(0)
}

/// The operation `ESC [ prefix params u` is, from its prefix and params.
fn parse(prefix: u8, params: &[u8]) -> Option<Op> {
    if !params.iter().all(|&b| b.is_ascii_digit() || b == b';') {
        return None;
    }
    let mut fields = params.split(|&b| b == b';');
    let first = fields.next().unwrap_or_default();
    let second = fields.next();
    if fields.next().is_some() || (prefix != b'=' && second.is_some()) {
        return None;
    }
    match prefix {
        b'>' => Some(Op::Push(flags(first))),
        b'<' => Some(Op::Pop(number(first).max(1))),
        b'=' => {
            let how = match second.map_or(1, number) {
                0 | 1 => How::Replace,
                2 => How::Add,
                3 => How::Remove,
                _ => return None,
            };
            Some(Op::Set(flags(first), how))
        }
        _ => None,
    }
}

/// The operation this token is, if it is one.
pub fn op(t: &Token<'_>) -> Option<Op> {
    match t.kind {
        Kind::Csi(Csi { prefix: Some(prefix), intermediates: b"", final_byte: b'u', params, malformed: false }) => {
            parse(prefix, params.as_bytes())
        }
        _ => None,
    }
}

/// The operation at the start of `s`, and its length: for a reader of bytes that has no lexer.
pub fn op_at(s: &[u8]) -> Option<(Op, usize)> {
    let rest = s.strip_prefix(b"\x1b[")?;
    let prefix = *rest.first()?;
    let len = rest[1..].iter().take_while(|&&b| b.is_ascii_digit() || b == b';').count();
    if rest.get(1 + len) != Some(&b'u') {
        return None;
    }
    parse(prefix, &rest[1..=len]).map(|op| (op, 2 + 1 + len + 1))
}

/// One screen's stack of flags, as kitty keeps it. A set changes the entry on top, or makes the first.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Stack(Vec<u8>);

impl Stack {
    /// Does what the program asked.
    pub fn apply(&mut self, op: Op) {
        match op {
            Op::Push(f) => {
                if self.0.len() == DEPTH {
                    self.0.remove(0);
                }
                self.0.push(f);
            }
            Op::Pop(n) => self.0.truncate(self.0.len().saturating_sub(usize::try_from(n).unwrap_or(usize::MAX))),
            Op::Set(f, how) => {
                let top = self.flags();
                let now = match how {
                    How::Replace => f,
                    How::Add => top | f,
                    How::Remove => top & !f,
                };
                match self.0.last_mut() {
                    Some(t) => *t = now,
                    None => self.0.push(now),
                }
            }
        }
    }

    /// The flags in force: the entry on top, or none.
    pub fn flags(&self) -> u8 {
        self.0.last().copied().unwrap_or(0)
    }

    /// The entries, oldest first.
    pub fn entries(&self) -> &[u8] {
        &self.0
    }
}

/// What brings a terminal from the flags nmux has told it to `to`: a push of an entry of nmux's own for the first flags, a
/// set of that entry for others, and a pop of it for none.
pub fn tell(from: u8, to: u8) -> String {
    match (from, to) {
        (a, b) if a == b => String::new(),
        (0, b) => format!("\x1b[>{b}u"),
        (_, 0) => "\x1b[<u".to_owned(),
        (_, b) => format!("\x1b[={b};1u"),
    }
}

/// A key as a terminal with no protocol says it.
struct Key {
    code: u32,
    shift: bool,
    ctrl: bool,
    /// What it types, if it types something.
    text: Option<char>,
}

impl Key {
    fn new(code: u32) -> Self {
        Self { code, shift: false, ctrl: false, text: None }
    }

    fn ctrl(code: u8) -> Self {
        Self { ctrl: true, ..Self::new(u32::from(code)) }
    }

    fn typed(c: char) -> Self {
        let mut lower = c.to_lowercase();
        match (lower.next(), lower.next()) {
            (Some(l), None) if l != c => Self { shift: true, text: Some(c), ..Self::new(u32::from(l)) },
            _ => Self { text: Some(c), ..Self::new(u32::from(c)) },
        }
    }
}

/// One key with no Alt: a control byte is Ctrl and a letter, the only way such a terminal says Ctrl, and a capital is the
/// only way it says Shift.
fn key(bytes: &[u8]) -> Option<Key> {
    Some(match *bytes {
        [0x1b] => Key::new(27),
        [b'\r'] => Key::new(13),
        [b'\t'] => Key::new(9),
        [0x7f] => Key::new(127),
        [0] => Key::ctrl(b' '),
        [b @ 1..=0x1a] => Key::ctrl(b + 0x60),
        [b @ 0x1c..=0x1f] => Key::ctrl(b + 0x40),
        _ => {
            let s = std::str::from_utf8(bytes).ok()?;
            let mut chars = s.chars();
            let c = chars.next().filter(|c| !c.is_control() && chars.next().is_none())?;
            Key::typed(c)
        }
    })
}

/// A key from a terminal that does not speak the protocol, as one that does would send it with these flags, or `None` when
/// it would send the same bytes. Such a terminal says Ctrl only with a control byte, Alt only with an ESC in front, and
/// Shift only in a capital, so nothing here is a release, a keypad key, or a key whose layout has to be asked about. Cursor
/// and function keys, and anything that is not one key, are as the protocol leaves them.
pub fn encode(input: &[u8], flags: u8) -> Option<Vec<u8>> {
    let all = flags & ALL_KEYS != 0;
    if flags & DISAMBIGUATE == 0 && !all {
        return None;
    }
    let (alt, k) = match input {
        [0x1b, rest @ ..] if !rest.is_empty() => (true, key(rest)?),
        _ => (false, key(input)?),
    };
    if !alt && !k.ctrl && !all && k.code != 27 {
        return None; // text, and Enter, Tab and Backspace, which disambiguating leaves alone
    }
    let mods = 1 + u32::from(k.shift) + 2 * u32::from(alt) + 4 * u32::from(k.ctrl);
    let text = k.text.filter(|_| all && flags & ASSOCIATED_TEXT != 0 && !alt && !k.ctrl);
    let mut out = format!("\x1b[{}", k.code);
    let _ = match (mods, text) {
        (1, None) => Ok(()),
        (m, None) => write!(out, ";{m}"),
        (1, Some(t)) => write!(out, ";;{}", u32::from(t)),
        (m, Some(t)) => write!(out, ";{m};{}", u32::from(t)),
    };
    out.push('u');
    Some(out.into_bytes())
}
