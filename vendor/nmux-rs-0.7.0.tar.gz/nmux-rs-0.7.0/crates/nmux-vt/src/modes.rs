//! DEC private mode tracker, shared by the holder's query responder for its DECRQM answers and the server's tracker for
//! its join prelude. [`ModeState::state`] answers exactly what xterm.js 6.x answers to `CSI ? Ps $ p`, measured against
//! `@xterm/headless` 6.0.0 and Cursor's 6.1.0-beta.291. [`ModeState::raw`] is the last explicit set or reset seen in the
//! stream. It keeps each screen's kitty keyboard flags too, which the holder says when asked and a join restates.

use std::collections::BTreeMap;

use crate::kitty::{self, Stack};
use crate::seq::dec_private;
use crate::token::{Csi, Kind, Token};

const SET: u8 = 1;
const RESET: u8 = 2;
/// Where ?25 is in [`SIMPLE_DEFAULTS`].
const CURSOR_VISIBLE: usize = 3;

/// Modes xterm.js tracks with a plain set or reset flag, and their power-on value.
const SIMPLE_DEFAULTS: [(u32, u8); 9] = [
    (1, RESET),
    (6, RESET),
    (7, SET),
    (25, SET),
    (45, RESET),
    (66, RESET),
    (1004, RESET),
    (2004, RESET),
    (2026, RESET),
];
/// Modes whose DECRQM answer never changes: 3 is permanently set and 4 permanently reset. 12 is always 2 in Cursor's build.
const CONSTANT: [(u32, u8); 6] = [(8, 3), (12, 2), (67, 4), (1005, 4), (1015, 4), (1048, 1)];
const MOUSE_PROTOCOL: [u32; 4] = [9, 1000, 1002, 1003];
const MOUSE_ENCODING: [u32; 2] = [1006, 1016];
const ALT: [u32; 3] = [47, 1047, 1049];
/// Programs use a few dozen modes. A stream that names thousands is not one, and the modes nobody tracks are not
/// remembered past this.
pub const RAW_MODES: usize = 256;
/// Reports of the terminal's colour scheme changing: a join restates it, though no DECRQM answer here is about it.
const RESTATED: [u32; 1] = [2031];

/// Every mode something here or a join restates: these are remembered however many others a stream has named.
fn tracked(mode: u32) -> bool {
    simple_index(mode).is_some()
        || CONSTANT.iter().any(|&(m, _)| m == mode)
        || MOUSE_PROTOCOL.contains(&mode)
        || MOUSE_ENCODING.contains(&mode)
        || ALT.contains(&mode)
        || RESTATED.contains(&mode)
}

/// The digits at the start, as `parseInt` reads them, and 0 when there are none. It saturates where `parseInt` would go on
/// growing: a style that large means nothing either way.
fn leading_number(params: &[u8]) -> u32 {
    params
        .iter()
        .take_while(|b| b.is_ascii_digit())
        .fold(0u32, |n, &d| n.saturating_mul(10).saturating_add(u32::from(d - b'0')))
}

fn simple_index(mode: u32) -> Option<usize> {
    SIMPLE_DEFAULTS.iter().position(|&(m, _)| m == mode)
}

/// Which DEC private modes a stream has set.
#[derive(Clone, Debug)]
pub struct ModeState {
    simple: [u8; SIMPLE_DEFAULTS.len()],
    protocol: u32,
    encoding: u32,
    alt: bool,
    raw_modes: BTreeMap<u32, u8>,
    cursor_style: Option<u32>,
    keypad: bool,
    /// The kitty keyboard flags of the main screen and of the alternate one.
    keyboard: [Stack; 2],
}

impl Default for ModeState {
    fn default() -> Self {
        Self::new()
    }
}

impl ModeState {
    /// The power-on state.
    pub fn new() -> Self {
        Self {
            simple: SIMPLE_DEFAULTS.map(|(_, value)| value),
            protocol: 0,
            encoding: 0,
            alt: false,
            raw_modes: BTreeMap::new(),
            cursor_style: None,
            keypad: false,
            keyboard: [Stack::default(), Stack::default()],
        }
    }

    /// Takes in one token.
    pub fn apply(&mut self, tok: &Token<'_>) {
        match tok.kind {
            Kind::Esc { intermediates: b"", final_byte: b'c' } => self.reset(),
            Kind::Esc { intermediates: b"", final_byte: b'=' } => self.keypad = true, // DECKPAM
            Kind::Esc { intermediates: b"", final_byte: b'>' } => self.keypad = false, // DECKPNM
            Kind::Csi(Csi { prefix: None, intermediates: b" ", final_byte: b'q', params, .. }) => {
                // DECSCUSR: the first number, as xterm.js reads it, and as `parseInt(params, 10) || 0` does.
                self.cursor_style = Some(leading_number(params.as_bytes()));
            }
            Kind::Csi(_) => match kitty::op(tok) {
                Some(op) => self.keyboard[usize::from(self.alt)].apply(op),
                None => self.apply_private(tok),
            },
            _ => {}
        }
    }

    /// RIS, except that xterm.js is measured to keep ?25 across it.
    fn reset(&mut self) {
        let visible = self.simple[CURSOR_VISIBLE];
        *self = Self::new();
        self.simple[CURSOR_VISIBLE] = visible;
    }

    fn apply_private(&mut self, tok: &Token<'_>) {
        let Some(dec) = dec_private(tok) else { return };
        let value = if dec.set { SET } else { RESET };
        for m in dec.modes() {
            if tracked(m) || self.raw_modes.len() < RAW_MODES || self.raw_modes.contains_key(&m) {
                self.raw_modes.insert(m, value);
            }
            if m == 66 {
                self.keypad = dec.set;
            }
            if let Some(i) = simple_index(m) {
                self.simple[i] = value;
            } else if MOUSE_PROTOCOL.contains(&m) {
                self.protocol = if dec.set { m } else { 0 }; // one protocol at a time, and any reset clears it
            } else if MOUSE_ENCODING.contains(&m) {
                self.encoding = if dec.set { m } else { 0 };
            } else if ALT.contains(&m) {
                self.alt = dec.set;
            }
        }
    }

    /// The DECRQM Ps value xterm.js would report for this mode: 0 to 4.
    pub fn state(&self, mode: u32) -> u8 {
        let on = |active: bool| if active { SET } else { RESET };
        if let Some(&(_, value)) = CONSTANT.iter().find(|&&(m, _)| m == mode) {
            value
        } else if let Some(i) = simple_index(mode) {
            self.simple[i]
        } else if MOUSE_PROTOCOL.contains(&mode) {
            on(self.protocol == mode)
        } else if MOUSE_ENCODING.contains(&mode) {
            on(self.encoding == mode)
        } else if ALT.contains(&mode) {
            on(self.alt)
        } else {
            0
        }
    }

    /// 0 if this mode was never seen, 1 if it was last set, 2 if it was last reset.
    pub fn raw(&self, mode: u32) -> u8 {
        self.raw_modes.get(&mode).copied().unwrap_or(0)
    }

    /// How many modes [`ModeState::raw`] remembers: at most [`RAW_MODES`].
    pub fn raw_count(&self) -> usize {
        self.raw_modes.len()
    }

    /// The last DECSCUSR parameter.
    pub fn cursor_style(&self) -> Option<u32> {
        self.cursor_style
    }

    /// Application keypad, set by DECKPAM and ?66 alike.
    pub fn keypad(&self) -> bool {
        self.keypad
    }

    /// The kitty keyboard flags in force, on the screen the stream is on.
    pub fn keyboard(&self) -> u8 {
        self.keyboard[usize::from(self.alt)].flags()
    }
}
