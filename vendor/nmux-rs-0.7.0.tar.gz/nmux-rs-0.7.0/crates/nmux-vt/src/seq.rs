//! Classifiers over lexer tokens. Pure functions, no state.

use crate::token::{Csi, Kind, Params, Token, number};

/// What a query asks for: the terminal's identity and state, which the holder answers.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum QueryKind {
    /// `CSI > q`
    Xtversion,
    /// `CSI c`
    Da1,
    /// `CSI > c`
    Da2,
    /// `CSI ? Ps $ p`
    Decrqm,
    /// `CSI 5 n`
    Dsr5,
    /// `CSI 6 n`
    Cpr,
    /// `CSI ? 6 n`
    Decxcpr,
    /// `OSC 10`, `11` or `12` asking for a default colour.
    OscColor,
    /// `CSI ? u`: the kitty keyboard flags in force.
    Keyboard,
    /// A query nobody answers, which must not reach a client either.
    Other,
}

impl QueryKind {
    /// The name in `QUERY_FWD` on the wire.
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Xtversion => "XTVERSION",
            Self::Da1 => "DA1",
            Self::Da2 => "DA2",
            Self::Decrqm => "DECRQM",
            Self::Dsr5 => "DSR5",
            Self::Cpr => "CPR",
            Self::Decxcpr => "DECXCPR",
            Self::OscColor => "OSCCOLOR",
            Self::Keyboard => "KEYBOARD",
            Self::Other => "OTHER",
        }
    }
}

/// The query this token is, if it is one.
pub fn query_kind(t: &Token<'_>) -> Option<QueryKind> {
    match t.kind {
        Kind::Csi(csi) => csi_query(&csi),
        Kind::Osc(data) => osc_query(data),
        Kind::Dcs(data) if data.starts_with(b"+q") || data.starts_with(b"$q") => Some(QueryKind::Other), // XTGETTCAP, DECRQSS
        _ => None,
    }
}

fn csi_query(csi: &Csi<'_>) -> Option<QueryKind> {
    let p = csi.params.as_bytes();
    let unset = p.is_empty() || p == b"0";
    match (csi.prefix, csi.intermediates, csi.final_byte) {
        (Some(b'>'), b"", b'q') if unset => Some(QueryKind::Xtversion),
        (None, b"", b'c') if unset => Some(QueryKind::Da1),
        (Some(b'>'), b"", b'c') if unset => Some(QueryKind::Da2),
        (Some(b'?'), b"$", b'p') if is_number(p) => Some(QueryKind::Decrqm),
        (None, b"", b'n') if p == b"5" => Some(QueryKind::Dsr5),
        (None, b"", b'n') if p == b"6" => Some(QueryKind::Cpr),
        (Some(b'?'), b"", b'n') if p == b"6" => Some(QueryKind::Decxcpr),
        (None, b"", b't') => Some(QueryKind::Other), // window ops: XTWINOPS reports and the title stack
        (Some(b'?'), b"", b'u') if p.is_empty() => Some(QueryKind::Keyboard),
        _ => None,
    }
}

fn osc_query(data: &[u8]) -> Option<QueryKind> {
    let asked = data.split(|&b| b == b';').skip(1).any(|field| field == b"?");
    match osc_number_of(data) {
        Some(10..=12) if asked => Some(QueryKind::OscColor), // default fg, bg or cursor colour
        Some(4) if asked => Some(QueryKind::Other),          // a palette colour
        _ => None,
    }
}

/// Queries are answered by the holder and never forwarded to clients.
pub fn is_query(t: &Token<'_>) -> bool {
    query_kind(t).is_some()
}

/// The mode a program sets to be told when the terminal's colour scheme changes, as `CSI ? 997 ; 1 n` (dark) or `2 n`
/// (light).
pub const SCHEME_MODE: u32 = 2031;

/// `CSI ? 996 n`: the program asks for the colour scheme. Unlike the queries above it goes on to the terminals, as only
/// they know, and their answer comes back as input.
pub fn is_scheme_query(t: &Token<'_>) -> bool {
    matches!(t.kind, Kind::Csi(Csi { prefix: Some(b'?'), intermediates: b"", final_byte: b'n', params, .. })
        if params.as_bytes() == b"996")
}

/// What asks a terminal for its default foreground and background colours: OSC 10 and 11.
pub const COLOR_QUERY: &[u8] = b"\x1b]10;?\x1b\\\x1b]11;?\x1b\\";

/// A terminal's answer to OSC 10 or 11 in its input, ended by BEL or ST: which of the two, and the colour as it said it.
pub fn color_report(input: &[u8]) -> Option<(u32, &[u8])> {
    let rest = input.strip_prefix(b"\x1b]")?;
    let body = rest.strip_suffix(b"\x07").or_else(|| rest.strip_suffix(b"\x1b\\"))?;
    let at = body.iter().position(|&b| b == b';')?;
    let n = match &body[..at] {
        b"10" => 10,
        b"11" => 11,
        _ => return None,
    };
    Some((n, &body[at + 1..]))
}

/// The scheme in a terminal's report, `CSI ? 997 ; n n`: 1 is dark and 2 light.
pub fn scheme_report(input: &[u8]) -> Option<u8> {
    match input.strip_prefix(b"\x1b[?997;")?.strip_suffix(b"n")? {
        b"1" => Some(1),
        b"2" => Some(2),
        _ => None,
    }
}

/// `CSI ? Pm h` or `l`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct DecPrivate<'a> {
    params: Params<'a>,
    /// `h` rather than `l`.
    pub set: bool,
}

impl<'a> DecPrivate<'a> {
    /// The modes named, leaving out any field that is not a number.
    pub fn modes(self) -> impl Iterator<Item = u32> + 'a {
        self.params.iter().filter_map(|p| number(p.as_bytes()))
    }
}

/// The token as a DEC private mode change, if it is one.
pub fn dec_private<'a>(t: &Token<'a>) -> Option<DecPrivate<'a>> {
    let Kind::Csi(Csi {
        prefix: Some(b'?'), intermediates: b"", final_byte: final_byte @ (b'h' | b'l'), params, ..
    }) = t.kind
    else {
        return None;
    };
    Some(DecPrivate { params, set: final_byte == b'h' })
}

/// How an [`AbsoluteRow`] was written.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RowForm {
    /// `CSI H`
    Home,
    /// `CSI row ; col H`
    Cup,
    /// `CSI row ; col f`
    Hvp,
    /// `CSI row d`
    Vpa,
}

/// Absolute row positioning on the main screen.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct AbsoluteRow {
    /// How it was written.
    pub form: RowForm,
    /// 1-based.
    pub row: u32,
    /// 1-based, and `None` for [`RowForm::Vpa`].
    pub col: Option<u32>,
}

/// ECMA-48: missing or 0 means 1.
fn at_least_1(field: &[u8]) -> u32 {
    number(field).filter(|&n| n > 0).unwrap_or(1)
}

/// The token as absolute row positioning, if it is that.
pub fn absolute_row(t: &Token<'_>) -> Option<AbsoluteRow> {
    let Kind::Csi(Csi { prefix: None, intermediates: b"", final_byte, params, .. }) = t.kind else { return None };
    let p = params.as_bytes();
    if !p.iter().all(|b| b.is_ascii_digit() || *b == b';') {
        return None;
    }
    let mut fields = p.split(|&b| b == b';').map(at_least_1);
    let row = fields.next().unwrap_or(1);
    match final_byte {
        b'H' if p.is_empty() => Some(AbsoluteRow { form: RowForm::Home, row: 1, col: Some(1) }),
        b'H' => Some(AbsoluteRow { form: RowForm::Cup, row, col: Some(fields.next().unwrap_or(1)) }),
        b'f' => Some(AbsoluteRow { form: RowForm::Hvp, row, col: Some(fields.next().unwrap_or(1)) }),
        b'd' => Some(AbsoluteRow { form: RowForm::Vpa, row, col: None }),
        _ => None,
    }
}

/// The params of a CSI with this final, no prefix and no intermediates.
fn plain_csi<'a>(t: &Token<'a>, final_byte: u8) -> Option<Params<'a>> {
    match t.kind {
        Kind::Csi(Csi { prefix: None, intermediates: b"", final_byte: f, params, .. }) if f == final_byte => {
            Some(params)
        }
        _ => None,
    }
}

fn plain_csi_is(t: &Token<'_>, final_byte: u8, params: &[u8]) -> bool {
    plain_csi(t, final_byte).is_some_and(|p| p.as_bytes() == params)
}

fn esc_is(t: &Token<'_>, final_byte: u8) -> bool {
    t.kind == Kind::Esc { intermediates: b"", final_byte }
}

/// DECSC: `ESC 7`, or `CSI s` with no parameters.
pub fn is_decsc(t: &Token<'_>) -> bool {
    esc_is(t, b'7') || plain_csi_is(t, b's', b"")
}

/// DECRC: `ESC 8`, or `CSI u` with no parameters and no prefix.
pub fn is_decrc(t: &Token<'_>) -> bool {
    esc_is(t, b'8') || plain_csi_is(t, b'u', b"")
}

/// The number that starts an OSC, as in `OSC 0 ; title`.
pub fn osc_number(t: &Token<'_>) -> Option<u32> {
    match t.kind {
        Kind::Osc(data) => osc_number_of(data),
        _ => None,
    }
}

fn osc_number_of(data: &[u8]) -> Option<u32> {
    number(data.split(|&b| b == b';').next()?)
}

/// `CSI 2 K`
pub fn is_erase_line_2(t: &Token<'_>) -> bool {
    plain_csi_is(t, b'K', b"2")
}

/// `CSI 1 B`, or `CSI B`.
pub fn is_cursor_down_1(t: &Token<'_>) -> bool {
    plain_csi_is(t, b'B', b"1") || plain_csi_is(t, b'B', b"")
}

/// `CSI H` with no parameters.
pub fn is_bare_home(t: &Token<'_>) -> bool {
    plain_csi_is(t, b'H', b"")
}

/// The margins DECSTBM sets.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ScrollRegion {
    /// 1-based.
    pub top: u32,
    /// 1-based, and `None` for the last row of the screen.
    pub bottom: Option<u32>,
}

/// The token as DECSTBM, if it is that.
pub fn scroll_region(t: &Token<'_>) -> Option<ScrollRegion> {
    let params = plain_csi(t, b'r')?;
    let margin = |index| params.iter().nth(index).and_then(|p| number(p.as_bytes())).filter(|&n| n > 0);
    Some(ScrollRegion { top: margin(0).unwrap_or(1), bottom: margin(1) })
}

/// A sequence that damages a client's native scrollback, for the drift census.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ScrollbackHostile {
    /// `CSI 2 J`
    Ed2,
    /// `CSI 3 J`
    Ed3,
    /// `ESC c`
    Ris,
    /// `CSI top ; bottom r` with parameters.
    Decstbm,
    /// `CSI S`
    Su,
    /// `CSI T`
    Sd,
    /// `CSI ? 47 h`
    Alt47,
    /// `CSI ? 1047 h`
    Alt1047,
}

/// The kind of damage this token does to a client's scrollback, if any.
pub fn is_scrollback_hostile(t: &Token<'_>) -> Option<ScrollbackHostile> {
    if esc_is(t, b'c') {
        return Some(ScrollbackHostile::Ris);
    }
    if plain_csi_is(t, b'J', b"2") {
        return Some(ScrollbackHostile::Ed2);
    }
    if plain_csi_is(t, b'J', b"3") {
        return Some(ScrollbackHostile::Ed3);
    }
    if plain_csi(t, b'r').is_some_and(|p| !p.as_bytes().is_empty()) {
        return Some(ScrollbackHostile::Decstbm);
    }
    if plain_csi(t, b'S').is_some() {
        return Some(ScrollbackHostile::Su);
    }
    if plain_csi(t, b'T').is_some() {
        return Some(ScrollbackHostile::Sd);
    }
    let dec = dec_private(t).filter(|d| d.set)?;
    if dec.modes().any(|m| m == 1047) {
        return Some(ScrollbackHostile::Alt1047);
    }
    dec.modes().any(|m| m == 47).then_some(ScrollbackHostile::Alt47)
}

fn is_number(field: &[u8]) -> bool {
    !field.is_empty() && field.iter().all(u8::is_ascii_digit)
}
