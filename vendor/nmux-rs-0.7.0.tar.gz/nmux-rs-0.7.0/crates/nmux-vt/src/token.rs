//! What the lexer hands out: one token per piece of the stream, with everything the pipeline and the emulator need.

/// One token of the output stream.
///
/// Everything here borrows from the input, or from the lexer's own buffer when the token spanned two feeds, so a token
/// lives for one call of the sink. Copy what is kept: a token's place in the stream is `start..end()`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Token<'a> {
    /// Absolute stream offset of the first byte.
    pub start: u64,
    /// The bytes exactly as they came, always in one slice, even when they arrived in several feeds.
    pub raw: &'a [u8],
    /// What the bytes are.
    pub kind: Kind<'a>,
}

impl Token<'_> {
    /// Absolute stream offset just past the last byte.
    pub fn end(&self) -> u64 {
        self.start + self.raw.len() as u64
    }
}

/// The kinds of token, as in the module comment of `lexer.js`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Kind<'a> {
    /// A run of printable ASCII and bytes from 0x80 up. `raw` is the text, and never ends inside a valid UTF-8
    /// character, so it can be decoded on its own; `<[u8]>::utf8_chunks` gives the invalid bytes that the emulator
    /// shows as U+FFFD. With `ascii` set it holds nothing but printable ASCII and needs no decoding at all.
    Text {
        /// The run is all printable ASCII.
        ascii: bool,
    },
    /// One C0 control byte other than ESC, or DEL.
    C0(u8),
    /// `ESC intermediates final`, other than the introducers below.
    Esc {
        /// Bytes 0x20 to 0x2f.
        intermediates: &'a [u8],
        /// The byte that ended the sequence, 0x30 to 0x7e.
        final_byte: u8,
    },
    /// `ESC [ prefix params intermediates final`.
    Csi(Csi<'a>),
    /// `ESC O x`.
    Ss3 {
        /// The byte after `ESC O`, 0x20 to 0x7e.
        final_byte: u8,
    },
    /// `ESC ] data`, ended by BEL, `ESC \` or another ESC. Data is raw bytes: decode it lossily to read it as text.
    Osc(&'a [u8]),
    /// `ESC P data`, ended by `ESC \` or another ESC.
    Dcs(&'a [u8]),
    /// `ESC X data`, ended by `ESC \` or another ESC.
    Sos(&'a [u8]),
    /// `ESC ^ data`, ended by `ESC \` or another ESC.
    Pm(&'a [u8]),
    /// `ESC _ data`, ended by `ESC \` or another ESC.
    Apc(&'a [u8]),
    /// The held bytes of an unfinished sequence: from `Lexer::flush_partial`, or when a byte that cannot continue it
    /// arrives. That byte starts a new token.
    Partial,
}

/// A control sequence, split the way `lexer.js` splits it.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Csi<'a> {
    /// `?`, `>`, `<` or `=` when it is the first byte after `ESC [`.
    pub prefix: Option<u8>,
    /// Every byte from 0x30 up, as text and as numbers.
    pub params: Params<'a>,
    /// Every byte from 0x20 to 0x2f.
    pub intermediates: &'a [u8],
    /// The byte that ended the sequence, 0x40 to 0x7e.
    pub final_byte: u8,
    /// The body is not `params intermediates`: `<=>?` after the start, or a parameter byte after an intermediate. The
    /// lexer accepts these and `params` and `intermediates` still hold what the Node lexer put there, but a terminal
    /// ignores such a sequence, and an emulator should too.
    pub malformed: bool,
}

impl<'a> Csi<'a> {
    /// Splits `raw`, the whole of `ESC [ .. final`. Only a malformed body needs `scratch`: its parameters do not lie
    /// next to each other in `raw`.
    pub(crate) fn parse(raw: &'a [u8], scratch: &'a mut Vec<u8>) -> Self {
        let final_byte = raw[raw.len() - 1];
        let mut body = &raw[2..raw.len() - 1];
        let prefix = body.first().copied().filter(|b| matches!(b, b'?' | b'>' | b'<' | b'='));
        if prefix.is_some() {
            body = &body[1..];
        }
        let digits = body.iter().position(|b| !matches!(b, b'0'..=b';')).unwrap_or(body.len());
        let (params, rest) = body.split_at(digits);
        if rest.iter().all(|&b| b <= b'/') {
            return Csi { prefix, params: Params(params), intermediates: rest, final_byte, malformed: false };
        }
        scratch.clear();
        scratch.extend(body.iter().filter(|&&b| b > b'/'));
        let count = scratch.len();
        scratch.extend(body.iter().filter(|&&b| b <= b'/'));
        let (params, intermediates) = scratch.split_at(count);
        Csi { prefix, params: Params(params), intermediates, final_byte, malformed: true }
    }
}

/// The parameter bytes of a [`Csi`]. Nothing is parsed until it is asked for, because most tokens only pass through.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Params<'a>(&'a [u8]);

impl<'a> Params<'a> {
    /// The parameters as they came, such as `38:2::1:2:3;1`.
    pub fn as_bytes(self) -> &'a [u8] {
        self.0
    }

    /// The parameters between semicolons. No parameter bytes at all still gives one, empty, as `CSI m` means `CSI 0 m`.
    pub fn iter(self) -> impl Iterator<Item = Param<'a>> {
        self.0.split(|&b| b == b';').map(Param)
    }

    /// The number at this position, or `None` when it is missing, empty or not a number. A terminal reads that as the
    /// sequence's default.
    pub fn get(self, index: usize) -> Option<u32> {
        self.iter().nth(index).and_then(Param::value)
    }
}

/// One parameter: a number, or several separated by colons, as in `38:2::r:g:b`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Param<'a>(&'a [u8]);

impl<'a> Param<'a> {
    /// The parameter as it came.
    pub fn as_bytes(self) -> &'a [u8] {
        self.0
    }

    /// The number before any colon, or `None` when it is empty or not a number.
    pub fn value(self) -> Option<u32> {
        self.subparams().next().flatten()
    }

    /// Each colon-separated part: the first is [`Param::value`], and an empty one is `None`, as the third of
    /// `38:2::r:g:b`.
    pub fn subparams(self) -> impl Iterator<Item = Option<u32>> + 'a {
        self.0.split(|&b| b == b':').map(number)
    }

    /// There is a colon, so this is more than one number.
    pub fn has_subparams(self) -> bool {
        self.0.contains(&b':')
    }
}

/// The value of a run of digits. It saturates: a number that long means nothing, and must not wrap into one that does.
pub(crate) fn number(digits: &[u8]) -> Option<u32> {
    if digits.is_empty() || !digits.iter().all(u8::is_ascii_digit) {
        return None;
    }
    Some(digits.iter().fold(0u32, |n, &d| n.saturating_mul(10).saturating_add(u32::from(d - b'0'))))
}
