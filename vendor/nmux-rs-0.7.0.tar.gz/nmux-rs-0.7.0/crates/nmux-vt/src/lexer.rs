//! Streaming ECMA-48 lexer for the pty output stream, child to terminals. This is the only output parser in the project:
//! the pipeline uses a token's raw bytes and offsets, and the emulator its parsed fields.
//!
//! It only annotates, and every byte still reaches the emulator and the clients. It guarantees that:
//!
//!  1. Every input byte ends up in exactly one token. Tokens are contiguous and in order, and offsets are absolute.
//!  2. The tokens do not depend on how the stream was chunked, except that text runs are emitted eagerly at the end of
//!     each feed, so adjacent text tokens may be split differently, and that an overlong sequence is cut into
//!     [`Kind::Partial`] tokens where feeds end.
//!  3. An incomplete trailing sequence or UTF-8 character is held until more bytes arrive. [`Lexer::feed`] returns true
//!     when nothing is held, which makes the end of the chunk a safe place for a snapshot or an injected sequence.
//!
//! Inside OSC, DCS, SOS, PM and APC an ESC that is not followed by `\` ends the string, as in xterm: the string token ends
//! before that ESC, which starts the next sequence. 8-bit C1 controls are not recognised, because the stream is UTF-8.

use crate::token::{Csi, Kind, Token};

const ESC: u8 = 0x1b;
const BEL: u8 = 0x07;
const CAN: u8 = 0x18;
const SUB: u8 = 0x1a;

/// No sequence anyone answers or tracks comes near this. Past it, what a sequence holds is let go: an `ESC P` with no end,
/// followed by a stream of output, would otherwise hold all of it, and the holder must never grow without bound.
pub const HOLD_BYTES: usize = 1_048_576;

/// `held` keeps its memory from one split sequence to the next, up to this much. Past it, the memory goes back: the holder
/// lexes everything a child prints, and one image sent to a terminal must not keep a megabyte in it for good.
const MAX_HELD_CAPACITY: usize = 64 * 1024;

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
enum State {
    #[default]
    Ground,
    Esc {
        intermediates: bool,
    },
    Csi,
    Ss3,
    Str(StringKind),
    StrEsc(StringKind),
    Utf8 {
        need: usize,
    },
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum StringKind {
    Osc,
    Dcs,
    Sos,
    Pm,
    Apc,
}

impl StringKind {
    fn token(self, data: &[u8]) -> Kind<'_> {
        match self {
            Self::Osc => Kind::Osc(data),
            Self::Dcs => Kind::Dcs(data),
            Self::Sos => Kind::Sos(data),
            Self::Pm => Kind::Pm(data),
            Self::Apc => Kind::Apc(data),
        }
    }
}

/// The lexer for one stream.
///
/// ```
/// use nmux_vt::{Kind, Lexer};
///
/// let mut lexer = Lexer::new(0);
/// let mut text = Vec::new();
/// let ground = lexer.feed(b"one\x1b[1", |t| {
///     if let Kind::Text { .. } = t.kind {
///         text.extend_from_slice(t.raw);
///     }
/// });
/// assert_eq!(text, b"one");
/// assert!(!ground, "the CSI is held for the next feed");
/// ```
#[derive(Debug, Default)]
pub struct Lexer {
    /// Absolute offset of the start of the chunk being fed, and otherwise just past the last byte fed.
    offset: u64,
    state: State,
    /// Bytes of the unfinished token that arrived in earlier feeds. A token that ends in a later feed is completed here,
    /// so its raw bytes are one slice for a price only split tokens pay.
    held: Vec<u8>,
    /// Index in the chunk where the unfinished token's bytes begin: 0 between feeds.
    from: usize,
    /// Where the parameters of a malformed CSI are gathered: see [`Csi::parse`].
    scratch: Vec<u8>,
    /// The unfinished sequence went past [`HOLD_BYTES`]: what is left of it is [`Kind::Partial`].
    overlong: bool,
}

impl Lexer {
    /// A lexer whose first byte is at this absolute stream offset.
    pub fn new(start_offset: u64) -> Self {
        Self { offset: start_offset, ..Self::default() }
    }

    /// Absolute offset just past the last byte fed.
    pub fn offset(&self) -> u64 {
        self.offset
    }

    /// Lexes `chunk`, handing each finished token to `sink`, and returns true when nothing is held, as `groundAfter` in
    /// `lexer.js`. Nothing is allocated for a token that lies in one chunk.
    pub fn feed<F: FnMut(Token<'_>)>(&mut self, chunk: &[u8], mut sink: F) -> bool {
        let mut i = 0;
        while i < chunk.len() {
            i = match self.state {
                State::Ground => self.ground(chunk, i, &mut sink),
                State::Utf8 { need } => self.utf8(chunk, i, need, &mut sink),
                State::Esc { intermediates } => self.esc(chunk, i, intermediates, &mut sink),
                State::Csi => self.csi(chunk, i, &mut sink),
                State::Ss3 => self.ss3(chunk, i, &mut sink),
                State::Str(kind) => self.string(chunk, i, kind, &mut sink),
                State::StrEsc(kind) => self.string_esc(chunk, i, kind, &mut sink),
            };
        }
        let ground = self.state == State::Ground;
        if !ground {
            self.held.extend_from_slice(&chunk[self.from..]);
        }
        self.from = 0;
        self.offset += chunk.len() as u64;
        if self.held.len() > HOLD_BYTES {
            self.let_go(&mut sink);
        }
        ground
    }

    /// Hands out what the unfinished sequence holds as [`Kind::Partial`], and marks the rest of it to go the same way. An
    /// ESC that may be the start of a string's terminator stays held, so that it is in one token whichever way it turns
    /// out.
    #[cold]
    fn let_go<F: FnMut(Token<'_>)>(&mut self, sink: &mut F) {
        let keep = usize::from(matches!(self.state, State::StrEsc(_)));
        let cut = self.held.len() - keep;
        sink(Token { start: self.offset - self.held.len() as u64, raw: &self.held[..cut], kind: Kind::Partial });
        self.held.drain(..cut);
        self.give_back();
        self.overlong = true;
    }

    /// Emits the held bytes, if any, as one [`Kind::Partial`] token and returns to ground. The caller runs this on its
    /// own timer, 100 ms in the pipeline.
    pub fn flush_partial<F: FnMut(Token<'_>)>(&mut self, mut sink: F) {
        if self.state == State::Ground {
            return;
        }
        // Right after an overlong sequence was let go nothing may be held, and there is no token without bytes.
        if !self.held.is_empty() {
            sink(Token { start: self.start(), raw: &self.held, kind: Kind::Partial });
        }
        self.clear();
        self.overlong = false;
    }

    /// Absolute offset of the unfinished token.
    fn start(&self) -> u64 {
        self.offset + self.from as u64 - self.held.len() as u64
    }

    fn clear(&mut self) {
        self.held.clear();
        self.give_back();
        self.state = State::Ground;
    }

    fn give_back(&mut self) {
        if self.held.capacity() > MAX_HELD_CAPACITY {
            self.held.shrink_to(MAX_HELD_CAPACITY);
        }
    }

    /// Closes the current token at `to`, an index in the chunk, and returns `to`.
    #[inline]
    fn emit<F, K>(&mut self, chunk: &[u8], to: usize, sink: &mut F, kind: K) -> usize
    where
        F: FnMut(Token<'_>),
        K: for<'r> FnOnce(&'r [u8], &'r mut Vec<u8>) -> Kind<'r>,
    {
        let start = self.start();
        let part = &chunk[self.from..to];
        let raw = if self.held.is_empty() {
            part
        } else {
            self.held.extend_from_slice(part);
            &self.held[..]
        };
        if !self.overlong {
            sink(Token { start, raw, kind: kind(raw, &mut self.scratch) });
        } else if !raw.is_empty() {
            // What is left of an overlong sequence, which may be nothing when its end came first in a feed.
            sink(Token { start, raw, kind: Kind::Partial });
        }
        self.overlong = false;
        self.clear();
        self.from = to;
        to
    }

    /// The hot loop: it stays here for as long as it can, and tokens that end in this state need none of the bookkeeping
    /// of a sequence that may span feeds.
    #[inline]
    fn ground<F: FnMut(Token<'_>)>(&mut self, chunk: &[u8], mut i: usize, sink: &mut F) -> usize {
        while i < chunk.len() {
            let b = chunk[i];
            if b == ESC {
                self.state = State::Esc { intermediates: false };
                self.from = i;
                return i + 1;
            }
            if is_control(b) {
                sink(Token { start: self.offset + i as u64, raw: &chunk[i..=i], kind: Kind::C0(b) });
                i += 1;
            } else {
                i = self.text(chunk, i, sink);
            }
        }
        i
    }

    /// A run of text from `i`, which holds no control. A valid character cut by the end of the chunk stays for the next.
    #[inline]
    fn text<F: FnMut(Token<'_>)>(&mut self, chunk: &[u8], i: usize, sink: &mut F) -> usize {
        let n = chunk.len();
        let mut j = i + ascii_run(&chunk[i..]);
        let mut ascii = true;
        let mut cut = None;
        while j < n && chunk[j] >= 0x80 {
            ascii = false;
            let need = utf8_len(chunk[j]);
            let found = 1 + chunk[j + 1..].iter().take(need - 1).take_while(|&&b| is_continuation(b)).count();
            if found == need {
                j += need;
            } else if j + found == n {
                cut = Some(need - found);
                break;
            } else {
                j += 1; // invalid: the lead byte is text on its own
            }
            j += ascii_run(&chunk[j..]);
        }
        if j > i {
            sink(Token { start: self.offset + i as u64, raw: &chunk[i..j], kind: Kind::Text { ascii } });
        }
        let Some(need) = cut else { return j };
        self.state = State::Utf8 { need };
        self.from = j;
        n
    }

    fn utf8<F: FnMut(Token<'_>)>(&mut self, chunk: &[u8], i: usize, need: usize, sink: &mut F) -> usize {
        if !is_continuation(chunk[i]) {
            // Invalid: the held bytes are text, and this byte is looked at again.
            return self.emit(chunk, i, sink, |_, _| Kind::Text { ascii: false });
        }
        if need == 1 {
            return self.emit(chunk, i + 1, sink, |_, _| Kind::Text { ascii: false });
        }
        self.state = State::Utf8 { need: need - 1 };
        i + 1
    }

    fn esc<F: FnMut(Token<'_>)>(&mut self, chunk: &[u8], i: usize, intermediates: bool, sink: &mut F) -> usize {
        let b = chunk[i];
        self.state = match b {
            0x20..=0x2f => State::Esc { intermediates: true },
            b'[' if !intermediates => State::Csi,
            b'O' if !intermediates => State::Ss3,
            b']' if !intermediates => State::Str(StringKind::Osc),
            b'P' if !intermediates => State::Str(StringKind::Dcs),
            b'X' if !intermediates => State::Str(StringKind::Sos),
            b'^' if !intermediates => State::Str(StringKind::Pm),
            b'_' if !intermediates => State::Str(StringKind::Apc),
            0x30..=0x7e => {
                return self.emit(chunk, i + 1, sink, |raw, _| Kind::Esc {
                    intermediates: &raw[1..raw.len() - 1],
                    final_byte: b,
                });
            }
            _ => return self.emit(chunk, i, sink, |_, _| Kind::Partial),
        };
        i + 1
    }

    fn csi<F: FnMut(Token<'_>)>(&mut self, chunk: &[u8], i: usize, sink: &mut F) -> usize {
        let Some(run) = chunk[i..].iter().position(|b| !matches!(b, 0x20..=0x3f)) else { return chunk.len() };
        let at = i + run;
        if matches!(chunk[at], 0x40..=0x7e) {
            self.emit(chunk, at + 1, sink, |raw, scratch| Kind::Csi(Csi::parse(raw, scratch)))
        } else {
            self.emit(chunk, at, sink, |_, _| Kind::Partial)
        }
    }

    fn ss3<F: FnMut(Token<'_>)>(&mut self, chunk: &[u8], i: usize, sink: &mut F) -> usize {
        let b = chunk[i];
        if matches!(b, 0x20..=0x7e) {
            self.emit(chunk, i + 1, sink, |_, _| Kind::Ss3 { final_byte: b })
        } else {
            self.emit(chunk, i, sink, |_, _| Kind::Partial)
        }
    }

    fn string<F: FnMut(Token<'_>)>(&mut self, chunk: &[u8], i: usize, kind: StringKind, sink: &mut F) -> usize {
        let stops = |b: &u8| matches!(*b, ESC | CAN | SUB) || (*b == BEL && kind == StringKind::Osc);
        let Some(run) = chunk[i..].iter().position(stops) else { return chunk.len() };
        let at = i + run;
        match chunk[at] {
            BEL => self.emit(chunk, at + 1, sink, |raw, _| kind.token(&raw[2..raw.len() - 1])),
            ESC => {
                self.state = State::StrEsc(kind);
                at + 1
            }
            _ => self.emit(chunk, at, sink, |_, _| Kind::Partial),
        }
    }

    fn string_esc<F: FnMut(Token<'_>)>(&mut self, chunk: &[u8], i: usize, kind: StringKind, sink: &mut F) -> usize {
        if chunk[i] == b'\\' {
            return self.emit(chunk, i + 1, sink, |raw, _| kind.token(&raw[2..raw.len() - 2]));
        }
        // The ESC just before this byte ends the string and starts a new sequence, which this byte may continue.
        if i == 0 {
            let start = self.start();
            let raw = &self.held[..self.held.len() - 1];
            if !self.overlong {
                sink(Token { start, raw, kind: kind.token(&raw[2..]) });
            } else if !raw.is_empty() {
                sink(Token { start, raw, kind: Kind::Partial });
            }
            self.overlong = false;
            self.held.clear();
            self.held.push(ESC);
        } else {
            self.emit(chunk, i - 1, sink, |raw, _| kind.token(&raw[2..]));
        }
        self.state = State::Esc { intermediates: false };
        i
    }
}

fn is_control(b: u8) -> bool {
    b < 0x20 || b == 0x7f
}

fn is_continuation(b: u8) -> bool {
    matches!(b, 0x80..=0xbf)
}

/// The expected length of a UTF-8 sequence starting with `b`, and 1 for anything that cannot start one.
fn utf8_len(b: u8) -> usize {
    match b {
        0xc2..=0xdf => 2,
        0xe0..=0xef => 3,
        0xf0..=0xf4 => 4,
        _ => 1,
    }
}

/// The length of the printable ASCII at the start of `bytes`, a word at a time.
#[inline]
fn ascii_run(bytes: &[u8]) -> usize {
    let mut rest = bytes;
    while let Some((word, tail)) = rest.split_first_chunk::<8>() {
        let stops = not_printable(u64::from_le_bytes(*word));
        if stops != 0 {
            return bytes.len() - rest.len() + (stops.trailing_zeros() / 8) as usize;
        }
        rest = tail;
    }
    bytes.len() - rest.len() + rest.iter().position(|&b| is_control(b) || b >= 0x80).unwrap_or(rest.len())
}

/// A word with the top bit set in the bytes that are not printable ASCII. A borrow can set bits above the first such byte
/// that do not belong there, but the lowest one set is always right, and it is the only one used.
#[inline]
const fn not_printable(word: u64) -> u64 {
    const ONES: u64 = 0x0101_0101_0101_0101;
    const TOPS: u64 = ONES * 0x80;
    let below_space = word.wrapping_sub(ONES * 0x20);
    let xor_del = word ^ (ONES * 0x7f);
    let del = xor_del.wrapping_sub(ONES) & !xor_del;
    (below_space | del | word) & TOPS
}
