//! What a shell says about itself: OSC 133, the marks terminals use for prompt jumping, with nmux's own fields beside the
//! standard ones. Anything a program prints can look like a mark, so only one carrying the session's token counts: without
//! that, `cat`-ing a file could end a `run` early. Fields nmux adds stop here, and a terminal gets the standard mark.
//!
//! - `A`: a prompt starts.
//! - `B`: the prompt ends, and what is typed goes here. `typed=1` if the line already holds something.
//! - `C`: a command starts. `cmdline_url=`
//! - `D;code`: a command ended, or a line was entered that ran none. `cwd=`, and `vi=1` for a line editor in vi mode. No
//!   code means it is not known.
//! - `N`: this shell cannot say any of the above.

const OSC: &str = "\x1b]133;";
const BEL: &str = "\x07";

/// Which mark.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MarkKind {
    /// A prompt starts.
    A,
    /// The prompt ends.
    B,
    /// A command starts.
    C,
    /// A command ended.
    D,
    /// The shell cannot say.
    N,
}

/// What a mark said.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Mark {
    /// Which mark.
    pub kind: MarkKind,
    /// The exit code of a `D`.
    pub exit: Option<u64>,
    /// The command line of a `C`, decoded.
    pub command: Option<String>,
    /// The directory, decoded.
    pub cwd: Option<String>,
    /// The line already held something.
    pub typed: bool,
    /// The line editor is in vi mode.
    pub vi: bool,
}

/// A mark from this session's shell.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParsedMark {
    /// What it said.
    pub mark: Mark,
    /// What goes on to a terminal: empty for `N`, which means nothing to one.
    pub standard: Vec<u8>,
}

/// `decodeURIComponent`, and the text as it came if that would throw: a bad encoding is shown rather than refused.
fn decoded(text: &str) -> String {
    percent_decoded(text).unwrap_or_else(|| text.to_owned())
}

fn percent_decoded(text: &str) -> Option<String> {
    let bytes = text.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'%' {
            let hex = bytes.get(i + 1..i + 3)?;
            out.push((hex_value(hex[0])? << 4) | hex_value(hex[1])?);
            i += 3;
        } else {
            out.push(bytes[i]);
            i += 1;
        }
    }
    String::from_utf8(out).ok()
}

fn hex_value(b: u8) -> Option<u8> {
    char::from(b).to_digit(16).and_then(|d| u8::try_from(d).ok())
}

/// The fields of a mark. A later one of a name replaces an earlier one, as it does in the Node code's object.
#[derive(Default)]
struct Fields<'a> {
    nmux: Option<&'a str>,
    cmdline_url: Option<&'a str>,
    cwd: Option<&'a str>,
    redraw: Option<&'a str>,
    typed: Option<&'a str>,
    vi: Option<&'a str>,
}

impl<'a> Fields<'a> {
    fn set(&mut self, name: &str, value: &'a str) {
        let slot = match name {
            "nmux" => &mut self.nmux,
            "cmdline_url" => &mut self.cmdline_url,
            "cwd" => &mut self.cwd,
            "redraw" => &mut self.redraw,
            "typed" => &mut self.typed,
            "vi" => &mut self.vi,
            _ => return,
        };
        *slot = Some(value);
    }
}

fn exit_code(field: &str) -> Option<u64> {
    if field.is_empty() || !field.bytes().all(|b| b.is_ascii_digit()) {
        return None;
    }
    Some(field.bytes().fold(0u64, |n, d| n.saturating_mul(10).saturating_add(u64::from(d - b'0'))))
}

/// The mark in an OSC 133 payload, or `None` if it is not from this session's shell.
pub fn parse_mark(data: &[u8], token: &str) -> Option<ParsedMark> {
    let data = String::from_utf8_lossy(data);
    let mut parts = data.split(';').skip(1);
    let (kind, letter) = match parts.next()? {
        "A" => (MarkKind::A, "A"),
        "B" => (MarkKind::B, "B"),
        "C" => (MarkKind::C, "C"),
        "D" => (MarkKind::D, "D"),
        "N" => (MarkKind::N, "N"),
        _ => return None,
    };
    let mut fields = Fields::default();
    let mut exit = None;
    for part in parts {
        match part.find('=') {
            Some(eq) if eq > 0 => fields.set(&part[..eq], &part[eq + 1..]),
            _ if kind == MarkKind::D => exit = exit_code(part).or(exit),
            _ => {}
        }
    }
    if fields.nmux != Some(token) {
        return None;
    }
    let rest = match kind {
        MarkKind::A => fields.redraw.map(|r| format!(";redraw={r}")),
        MarkKind::C => fields.cmdline_url.map(|c| format!(";cmdline_url={c}")),
        MarkKind::D => exit.map(|code| format!(";{code}")),
        MarkKind::B | MarkKind::N => None,
    };
    let standard = match kind {
        MarkKind::N => Vec::new(),
        _ => format!("{OSC}{letter}{}{BEL}", rest.unwrap_or_default()).into_bytes(),
    };
    let mark = Mark {
        kind,
        exit,
        command: fields.cmdline_url.map(decoded),
        cwd: fields.cwd.map(decoded),
        typed: fields.typed == Some("1"),
        vi: fields.vi == Some("1"),
    };
    Some(ParsedMark { mark, standard })
}
