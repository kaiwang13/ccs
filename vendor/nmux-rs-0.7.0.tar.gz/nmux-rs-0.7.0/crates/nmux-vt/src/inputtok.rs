//! Per-client input tokenizer: client keyboard bytes become tokens the policy layer can classify with `keys`. Bytes go on
//! to the child verbatim afterwards, and the tokenization only decides what each key is.
//!
//!  - Every C0 byte other than ESC, and DEL, is its own token, and so is every printable ASCII byte and every complete
//!    UTF-8 character.
//!  - ESC starts a sequence: CSI, SS3, X10 mouse, a string (to BEL or `ESC \`), an ESC-prefixed CSI or SS3, or ESC and one
//!    character (Alt+key, including ESC and a C0 byte such as ESC 0x1a, which `keys` decodes to an empty name and
//!    `classify` reports as ignored).
//!  - An incomplete sequence or UTF-8 character at the end of a feed is held until more bytes arrive. Only a trailing ESC
//!    or ESC ESC is flushed by time: the decoders in `keys` join an ESC with bytes arriving within 50 ms. Other partial
//!    sequences are held indefinitely, so a split `ESC[122;5u` can never slip through as unclassified pieces.
//!  - A byte that cannot continue a sequence ends it: the bytes so far become a token and the byte is looked at again.
//!  - Bracketed paste: the content between `ESC[200~` and `ESC[201~` is never classified. A paste idle for a while is
//!    closed with a synthetic end, because a TUI may close a paste itself after 2 s and read the rest as keys.
//!    [`InputTokenizer::close`] does the same for a disconnect.
//!  - Strings over 8192 bytes and CSI over 256 bytes are cut into a token: clients never legitimately send those.
//!
//! There are no timers here. [`InputTokenizer::deadline`] says when [`InputTokenizer::on_timer`] is next due, and time is
//! a value passed in, in milliseconds on any monotonic clock.

use std::borrow::Cow;

const ESC: u8 = 0x1b;
const PASTE_START: &[u8] = b"\x1b[200~";
const PASTE_END: &[u8] = b"\x1b[201~";
const MAX_STRING: usize = 8192;
const MAX_CSI: usize = 256;

/// The time a trailing ESC waits for more, by default.
pub const ESC_FLUSH_MS: u64 = 40;
/// The time an open paste may stay idle, by default.
pub const PASTE_IDLE_CLOSE_MS: u64 = 1500;

/// What an [`InputToken`] is.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum InputKind {
    /// A key: decode it with `keys`.
    Seq,
    /// `ESC[200~`
    PasteStart,
    /// Pasted bytes, never classified. One paste can be many of these.
    PasteData,
    /// `ESC[201~`, which may be synthetic.
    PasteEnd,
    /// A trailing ESC or ESC ESC that nothing followed.
    LoneEsc,
}

/// One token of a client's input. It borrows, and lives for one call of the sink.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct InputToken<'a> {
    /// What it is.
    pub kind: InputKind,
    /// Its bytes.
    pub bytes: &'a [u8],
}

impl<'a> InputToken<'a> {
    /// The bytes as text, which is what `keys` decodes.
    pub fn seq(&self) -> Cow<'a, str> {
        String::from_utf8_lossy(self.bytes)
    }
}

fn utf8_len(b: u8) -> usize {
    match b {
        0xc2..=0xdf => 2,
        0xe0..=0xef => 3,
        0xf0..=0xf4 => 4,
        _ => 1,
    }
}

/// The length of one UTF-8 character at `i`, 1 for an invalid or non-lead byte, or `None` if more may complete it.
fn char_len(buf: &[u8], i: usize) -> Option<usize> {
    let need = utf8_len(buf[i]);
    for k in 1..need {
        match buf.get(i + k)? {
            0x80..=0xbf => {}
            _ => return Some(1),
        }
    }
    Some(need)
}

/// The length of a CSI at `i`, where `buf[i]` is ESC and `buf[i + 1]` is `[`, or `None` if more may complete it. A byte
/// that cannot continue the sequence ends it there.
fn csi_len(buf: &[u8], i: usize) -> Option<usize> {
    // SGR mouse (prefix `<`) reports negative coordinates when a drag leaves the grid, and the decoder `keys` follows takes
    // `-` as part of the parameters there. Under the strict ECMA-48 split it is an intermediate byte, which would end the
    // run and leave the final M or m to be read as a keypress. Every other CSI keeps the strict behaviour.
    let sgr_mouse = buf.get(i + 2) == Some(&0x3c);
    let mut j = i + 2;
    while j < buf.len() && (matches!(buf[j], 0x30..=0x3f) || (sgr_mouse && buf[j] == 0x2d)) {
        j += 1;
    }
    while j < buf.len() && matches!(buf[j], 0x20..=0x2f) {
        j += 1;
    }
    if j - i > MAX_CSI {
        return Some(MAX_CSI);
    }
    let f = *buf.get(j)?;
    if !matches!(f, 0x40..=0x7e) {
        return Some(j - i);
    }
    if f == b'M' && j == i + 2 {
        // X10 mouse: ESC [ M Cb Cx Cy
        return (j + 3 < buf.len()).then_some(j + 4 - i);
    }
    Some(j + 1 - i)
}

/// The length of a string sequence at `i`, OSC to BEL or ST and DCS, SOS, PM and APC to ST, or `None` if more may
/// complete it.
fn string_len(buf: &[u8], i: usize) -> Option<usize> {
    let osc = buf[i + 1] == b']';
    for j in i + 2..buf.len() {
        if osc && buf[j] == 0x07 {
            return Some(j + 1 - i);
        }
        if buf[j] == ESC && *buf.get(j + 1)? == b'\\' {
            return Some(j + 2 - i);
        }
        if j + 1 - i >= MAX_STRING {
            return Some(j + 1 - i);
        }
    }
    (buf.len() - i >= MAX_STRING).then_some(buf.len() - i)
}

/// The length of the token starting with ESC at `i`, or `None` if more may complete it.
fn esc_len(buf: &[u8], i: usize) -> Option<usize> {
    match *buf.get(i + 1)? {
        b'[' => csi_len(buf, i),
        b'O' => Some(if matches!(buf.get(i + 2)?, 0x20..=0x7e) { 3 } else { 2 }),
        b']' | b'P' | b'X' | b'^' | b'_' => string_len(buf, i),
        ESC if matches!(buf.get(i + 2)?, b'[' | b'O') => Some(esc_len(buf, i + 1)? + 1),
        0x80.. => Some(char_len(buf, i + 1)? + 1),
        _ => Some(2),
    }
}

fn all_esc(bytes: &[u8]) -> bool {
    !bytes.is_empty() && bytes.iter().all(|&b| b == ESC)
}

fn find(haystack: &[u8], needle: &[u8]) -> Option<usize> {
    let mut from = 0;
    while let Some(at) = haystack[from..].iter().position(|&b| b == needle[0]) {
        from += at;
        if haystack[from..].starts_with(needle) {
            return Some(from);
        }
        from += 1;
    }
    None
}

/// How much of the end of `buf` could be the start of `ESC[201~`.
fn paste_end_prefix(buf: &[u8]) -> usize {
    (1..PASTE_END.len().min(buf.len() + 1)).rev().find(|&s| buf.ends_with(&PASTE_END[..s])).unwrap_or(0)
}

/// The tokenizer for one client.
#[derive(Debug)]
pub struct InputTokenizer {
    esc_flush_ms: u64,
    paste_idle_close_ms: u64,
    in_paste: bool,
    held: Vec<u8>,
    deadline: Option<u64>,
}

impl Default for InputTokenizer {
    fn default() -> Self {
        Self::new(ESC_FLUSH_MS, PASTE_IDLE_CLOSE_MS)
    }
}

impl InputTokenizer {
    /// `esc_flush_ms` is how long a trailing ESC waits for more, and `paste_idle_close_ms` how long a paste may stay idle.
    pub fn new(esc_flush_ms: u64, paste_idle_close_ms: u64) -> Self {
        Self { esc_flush_ms, paste_idle_close_ms, in_paste: false, held: Vec::new(), deadline: None }
    }

    /// Tokenizes `chunk`, which arrived at `now`, handing each token to `sink`.
    pub fn feed<F: FnMut(InputToken<'_>)>(&mut self, chunk: &[u8], now: u64, mut sink: F) {
        self.deadline = None;
        if self.held.is_empty() {
            let used = self.scan(chunk, &mut sink);
            self.held.extend_from_slice(&chunk[used..]);
        } else {
            let mut joined = std::mem::take(&mut self.held);
            joined.extend_from_slice(chunk);
            let used = self.scan(&joined, &mut sink);
            joined.drain(..used);
            self.held = joined;
        }
        if self.in_paste {
            self.deadline = Some(now + self.paste_idle_close_ms);
        } else if all_esc(&self.held) {
            self.deadline = Some(now + self.esc_flush_ms);
        }
    }

    /// Hands every whole token in `buf` to `sink`, and returns how much of `buf` they took.
    fn scan<F: FnMut(InputToken<'_>)>(&mut self, buf: &[u8], sink: &mut F) -> usize {
        let mut i = 0;
        while i < buf.len() {
            if self.in_paste {
                i = self.paste(buf, i, sink);
                if self.in_paste {
                    break;
                }
                continue;
            }
            let len = match buf[i] {
                ESC => esc_len(buf, i),
                0x80.. => char_len(buf, i),
                _ => Some(1),
            };
            let Some(len) = len else { break };
            let bytes = &buf[i..i + len];
            self.in_paste = bytes == PASTE_START;
            let kind = if self.in_paste { InputKind::PasteStart } else { InputKind::Seq };
            sink(InputToken { kind, bytes });
            i += len;
        }
        i
    }

    /// Paste content from `i`, up to its end or to what could be the start of its end. Returns where that left off.
    fn paste<F: FnMut(InputToken<'_>)>(&mut self, buf: &[u8], i: usize, sink: &mut F) -> usize {
        let end = find(&buf[i..], PASTE_END).map(|at| i + at);
        let to = end.unwrap_or(buf.len() - paste_end_prefix(&buf[i..]));
        if to > i {
            sink(InputToken { kind: InputKind::PasteData, bytes: &buf[i..to] });
        }
        let Some(end) = end else { return to };
        sink(InputToken { kind: InputKind::PasteEnd, bytes: &buf[end..end + PASTE_END.len()] });
        self.in_paste = false;
        end + PASTE_END.len()
    }

    /// When [`InputTokenizer::on_timer`] is next due, if it is.
    pub fn deadline(&self) -> Option<u64> {
        self.deadline
    }

    /// Hands to `sink` what time has flushed: a lone ESC, or the rest of an idle paste and its end.
    pub fn on_timer<F: FnMut(InputToken<'_>)>(&mut self, now: u64, mut sink: F) {
        if self.deadline.is_none_or(|at| now < at) {
            return;
        }
        self.deadline = None;
        if self.in_paste {
            self.close_paste(&mut sink);
        } else if all_esc(&self.held) {
            sink(InputToken { kind: InputKind::LoneEsc, bytes: &self.held });
            self.held.clear();
        }
    }

    /// The client is gone: close an open paste with a synthetic end, and drop any held partial sequence, which must never
    /// be forwarded or merged with another client's bytes.
    pub fn close<F: FnMut(InputToken<'_>)>(&mut self, mut sink: F) {
        self.deadline = None;
        if self.in_paste {
            self.close_paste(&mut sink);
        }
        self.held.clear();
    }

    fn close_paste<F: FnMut(InputToken<'_>)>(&mut self, sink: &mut F) {
        if !self.held.is_empty() {
            sink(InputToken { kind: InputKind::PasteData, bytes: &self.held });
        }
        sink(InputToken { kind: InputKind::PasteEnd, bytes: PASTE_END });
        self.held.clear();
        self.in_paste = false;
    }

    /// The bytes waiting for more: a partial sequence, or what could be the start of a paste's end.
    pub fn held(&self) -> &[u8] {
        &self.held
    }
}
