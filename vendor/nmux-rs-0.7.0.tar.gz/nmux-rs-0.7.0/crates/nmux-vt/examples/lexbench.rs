//! Lexer speed on files of terminal output: `cargo run --release -p nmux-vt --example lexbench -- FILE...`
//!
//! It feeds 64 KiB at a time, the size of a pty read, and counts tokens. Each file is run five times, and the best run is
//! reported, because the slower ones measure the machine.

use std::hint::black_box;
use std::time::Instant;

use nmux_vt::Lexer;

const PIECE: usize = 65536;
const RUNS: usize = 5;

fn lex(data: &[u8]) -> (f64, u64) {
    let started = Instant::now();
    let mut lexer = Lexer::new(0);
    let mut tokens = 0u64;
    for chunk in data.chunks(PIECE) {
        black_box(lexer.feed(black_box(chunk), |t| {
            tokens += 1;
            black_box(t.raw.len());
        }));
    }
    (started.elapsed().as_secs_f64(), black_box(tokens))
}

#[allow(clippy::cast_precision_loss)] // a rate needs no more precision than a double has
fn main() -> std::io::Result<()> {
    for path in std::env::args().skip(1) {
        let data = std::fs::read(&path)?;
        let (seconds, tokens) = (0..RUNS).map(|_| lex(&data)).fold((f64::MAX, 0), |a, b| (a.0.min(b.0), b.1));
        let megabytes = data.len() as f64 / 1e6;
        println!(
            "{path}: {:.0} MB/s, {:.1} ns/token, {tokens} tokens",
            megabytes / seconds,
            seconds * 1e9 / tokens as f64
        );
    }
    Ok(())
}
