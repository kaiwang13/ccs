//! Rows that have left the screen, packed as they leave it into blocks of bytes, with no allocation per row.
//!
//! A row is written as its text in UTF-8, with a byte or five for a cell that is not a plain character of its usual width,
//! the runs of its attributes as the two words themselves, and the strings of its combined cells. Cells after the last
//! that differs from an empty one are not written. A row that comes back to a screen, or that a reflow has to change, is
//! read back into cells; the bytes are what they were, so it comes back exactly as it went.
//!
//! Rows go into blocks of 64 KiB, none split between two, and a block is given back when its last row leaves: the history
//! holds what its rows take and one block more, and a row costs its bytes and sixteen more to find them.

use std::collections::VecDeque;

use crate::attr::{Attr, Attrs};
use crate::line::{Cell, IS_COMBINED, NULL_CONTENT, Row, WIDTH_SHIFT};
use crate::width::wcwidth;

/// A cell with no text and width 1, attributes apart.
const NULL_BYTE: u8 = 0x01;
/// A cell with no text and width 0: the right half of a wide character.
const HALF_BYTE: u8 = 0x02;
/// Any other cell: its content word follows.
const RAW_BYTE: u8 = 0x03;

/// The size of a block, and so the most an offset in one needs.
const BLOCK: usize = 1 << 16;
/// The trimmed length kept for a longer row, which is then read to find it.
const TRIMMED_UNKNOWN: u16 = 0x7FFF;
const WRAPPED_BIT: u16 = 0x8000;

/// What is known about a packed row without reading it.
#[derive(Clone, Copy, Debug)]
pub(crate) struct Entry {
    pub id: u64,
    /// `getTrimmedLength`.
    pub trimmed: u32,
    pub wrapped: bool,
}

/// Where a packed row is: sixteen bytes.
#[derive(Clone, Copy, Debug)]
struct Place {
    id: u64,
    /// Counted from the first block there ever was.
    block: u32,
    at: u16,
    /// The trimmed length, and the wrapped flag in the top bit.
    bits: u16,
}

/// The header of a packed row.
#[derive(Clone, Copy, Debug, Default)]
pub(crate) struct Header {
    /// The row's length in cells.
    pub length: usize,
    /// How many cells are written; the rest are empty.
    pub stored: usize,
    /// One past the largest column with a combined string, or 0.
    pub keys_end: usize,
}

/// Packed rows, oldest first.
#[derive(Debug, Default)]
pub(crate) struct History {
    places: VecDeque<Place>,
    blocks: VecDeque<Vec<u8>>,
    /// The number of `blocks[0]`.
    first_block: u32,
    /// A block given back, kept for the next.
    spare: Option<Vec<u8>>,
    /// Where a row is packed before it goes into a block.
    scratch: Vec<u8>,
}

impl History {
    pub fn len(&self) -> usize {
        self.places.len()
    }

    pub fn is_empty(&self) -> bool {
        self.places.is_empty()
    }

    pub fn entry(&self, i: usize) -> Entry {
        let p = self.places[i];
        let trimmed = p.bits & !WRAPPED_BIT;
        let trimmed = if trimmed == TRIMMED_UNKNOWN { self.trimmed_of(i) } else { u32::from(trimmed) };
        Entry { id: p.id, trimmed, wrapped: p.bits & WRAPPED_BIT != 0 }
    }

    /// The trimmed length of a row too long to keep it beside it.
    fn trimmed_of(&self, i: usize) -> u32 {
        let mut row = crate::cells::LineBuf::new();
        visit(self.bytes(i), false, &mut row);
        u32::try_from(row.trimmed_length()).unwrap_or(u32::MAX)
    }

    pub fn set_wrapped(&mut self, i: usize, wrapped: bool) {
        let p = &mut self.places[i];
        p.bits = if wrapped { p.bits | WRAPPED_BIT } else { p.bits & !WRAPPED_BIT };
    }

    /// How much memory the packed rows take.
    pub fn memory(&self) -> usize {
        self.blocks.iter().map(Vec::capacity).sum::<usize>()
            + self.spare.as_ref().map_or(0, Vec::capacity)
            + self.scratch.capacity()
            + self.places.capacity() * std::mem::size_of::<Place>()
    }

    fn block(&self, number: u32) -> &Vec<u8> {
        &self.blocks[(number - self.first_block) as usize]
    }

    pub fn bytes(&self, i: usize) -> &[u8] {
        let p = self.places[i];
        let block = self.block(p.block);
        let end = match self.places.get(i + 1) {
            Some(next) if next.block == p.block => usize::from(next.at),
            _ => block.len(),
        };
        &block[usize::from(p.at)..end]
    }

    pub fn clear(&mut self) {
        self.places.clear();
        while let Some(block) = self.blocks.pop_front() {
            self.give_back(block);
        }
        self.first_block = 0;
    }

    fn give_back(&mut self, mut block: Vec<u8>) {
        if self.spare.is_none() && block.capacity() == BLOCK {
            block.clear();
            self.spare = Some(block);
        }
    }

    /// Puts `scratch` in as the newest row.
    fn place(&mut self, id: u64, trimmed: u32, wrapped: bool) {
        let len = self.scratch.len();
        let fits = self.blocks.back().is_some_and(|b| b.len() + len <= b.capacity());
        if !fits {
            let block = match self.spare.take() {
                Some(b) if len <= BLOCK => b,
                _ => Vec::with_capacity(BLOCK.max(len)),
            };
            if self.blocks.is_empty() {
                self.first_block = 0;
            }
            self.blocks.push_back(block);
        }
        let number = self.first_block + u32::try_from(self.blocks.len() - 1).unwrap_or(0);
        let Some(block) = self.blocks.back_mut() else { return };
        let at = u16::try_from(block.len()).unwrap_or(u16::MAX);
        block.extend_from_slice(&self.scratch);
        let trimmed = u16::try_from(trimmed).ok().filter(|&t| t < TRIMMED_UNKNOWN).unwrap_or(TRIMMED_UNKNOWN);
        let bits = trimmed | if wrapped { WRAPPED_BIT } else { 0 };
        self.places.push_back(Place { id, block: number, at, bits });
    }

    /// Packs `row` as the newest.
    pub fn push(&mut self, row: &Row, attrs: &Attrs) {
        let mut scratch = std::mem::take(&mut self.scratch);
        scratch.clear();
        let trimmed = encode(row, attrs, &mut scratch);
        self.scratch = scratch;
        self.place(row.id, trimmed, row.wrapped);
    }

    /// Adds a row already packed, as `push` would have.
    pub fn push_packed(&mut self, bytes: &[u8], id: u64, trimmed: u32, wrapped: bool) {
        self.push_resized(bytes, id, trimmed, wrapped, None);
    }

    /// Adds a row packed for another length, as it is once resized to `length` (`None`: as it was). Cells it holds past
    /// a shorter length have been read out and cut before this.
    pub fn push_resized(&mut self, bytes: &[u8], id: u64, trimmed: u32, wrapped: bool, length: Option<usize>) {
        self.scratch.clear();
        match length {
            Some(length) => {
                let mut k = 0;
                get_varint(bytes, &mut k);
                put_varint(&mut self.scratch, length);
                self.scratch.extend_from_slice(&bytes[k..]);
            }
            None => self.scratch.extend_from_slice(bytes),
        }
        self.place(id, trimmed, wrapped);
    }

    /// Replaces row `i` with `row`, which rewrites everything after it: only DECALN does this, reaching into the history
    /// by mistake.
    pub fn replace(&mut self, i: usize, row: &Row, attrs: &Attrs) {
        let mut rebuilt = History::default();
        for k in 0..self.places.len() {
            let e = self.entry(k);
            if k == i {
                let mut r = row.clone();
                r.id = e.id;
                rebuilt.push(&r, attrs);
            } else {
                rebuilt.push_packed(self.bytes(k), e.id, e.trimmed, e.wrapped);
            }
        }
        *self = rebuilt;
    }

    /// Drops the oldest row, and its block with it if it was the last there.
    pub fn pop_front(&mut self) {
        let Some(p) = self.places.pop_front() else { return };
        let last_in_block = self.places.front().is_none_or(|next| next.block != p.block);
        if last_in_block {
            if let Some(block) = self.blocks.pop_front() {
                self.give_back(block);
            }
            self.first_block += 1;
        }
    }

    /// Unpacks the newest row into `into` and drops it.
    pub fn pop_back(&mut self, into: &mut Row, attrs: &mut Attrs) {
        let last = self.places.len() - 1;
        let e = self.entry(last);
        decode(self.bytes(last), e.id, e.wrapped, into, attrs);
        let Some(p) = self.places.pop_back() else { return };
        if let Some(block) = self.blocks.back_mut() {
            block.truncate(usize::from(p.at));
            if block.is_empty() {
                if let Some(block) = self.blocks.pop_back() {
                    self.give_back(block);
                }
            }
        }
    }

    /// Unpacks row `i` into `into`.
    pub fn read(&self, i: usize, into: &mut Row, attrs: &mut Attrs) {
        let p = self.places[i];
        decode(self.bytes(i), p.id, p.bits & WRAPPED_BIT != 0, into, attrs);
    }

    /// Reads row `i` cell by cell, with attributes as the words themselves.
    pub fn visit(&self, i: usize, into: &mut crate::cells::LineBuf) {
        let p = self.places[i];
        visit(self.bytes(i), p.bits & WRAPPED_BIT != 0, into);
    }

    pub fn header(&self, i: usize) -> Header {
        header(self.bytes(i)).0
    }
}

fn put_varint(out: &mut Vec<u8>, mut n: usize) {
    while n >= 0x80 {
        out.push(low_seven(n) | 0x80);
        n >>= 7;
    }
    out.push(low_seven(n));
}

/// The lowest seven bits.
fn low_seven(n: usize) -> u8 {
    u8::try_from(n & 0x7f).unwrap_or(0)
}

fn get_varint(bytes: &[u8], at: &mut usize) -> usize {
    let mut n = 0usize;
    let mut shift = 0;
    while let Some(&b) = bytes.get(*at) {
        *at += 1;
        n |= usize::from(b & 0x7f) << shift;
        if b < 0x80 {
            break;
        }
        shift += 7;
    }
    n
}

fn get_u32(bytes: &[u8], at: &mut usize) -> u32 {
    let mut word = [0u8; 4];
    if let Some(b) = bytes.get(*at..*at + 4) {
        word.copy_from_slice(b);
    }
    *at += 4;
    u32::from_le_bytes(word)
}

/// Whether a cell holding this word is a plain character of the width it would be printed with.
#[inline]
fn plain(content: u32) -> bool {
    let cp = content & 0x1F_FFFF;
    if !(0x20..0x7f).contains(&cp) {
        return cp >= 0xA0 && char::from_u32(cp).is_some() && content == cp | (wcwidth(cp) << WIDTH_SHIFT);
    }
    content == cp | (1 << WIDTH_SHIFT)
}

/// Writes `row` and returns its trimmed length.
fn encode(row: &Row, attrs: &Attrs, out: &mut Vec<u8>) -> u32 {
    let cells = &row.cells[..row.used.min(row.cells.len())];
    let stored = cells.iter().rposition(|&c| c != Cell::NULL).map_or(0, |i| i + 1);
    let cells = &cells[..stored];
    let trimmed = cells.iter().rposition(|c| c.has_content()).map_or(0, |i| i + cells[i].width() as usize);
    let mut runs = 0usize;
    let mut last = 0u32;
    for c in cells {
        if c.attr != last {
            runs += 1;
            last = c.attr;
        }
    }
    put_varint(out, row.cells.len());
    put_varint(out, stored);
    put_varint(out, runs);
    put_varint(out, row.combined.len());
    if runs > 0 {
        let mut last = 0u32;
        for (col, c) in cells.iter().enumerate() {
            if c.attr != last {
                last = c.attr;
                let a = attrs.get(c.attr);
                put_varint(out, col);
                out.extend_from_slice(&a.fg.to_le_bytes());
                out.extend_from_slice(&a.bg.to_le_bytes());
            }
        }
    }
    for (key, text) in &row.combined {
        put_varint(out, *key as usize);
        put_varint(out, text.len());
        out.extend_from_slice(text.as_bytes());
    }
    // The cells go eight at a time, looked at together rather than with a branch for each: most rows are mostly
    // printable ASCII, and the rest of most are empty cells, each a byte. A row's history push costs about half what it
    // did a cell at a time.
    out.reserve(cells.len());
    let mut eights = cells.chunks_exact(8);
    for eight in &mut eights {
        if eight.iter().fold(true, |all, c| all & ascii(c.content)) {
            out.extend(eight.iter().map(|c| low_seven(c.content as usize)));
            continue;
        }
        let bytes: [u8; 8] = std::array::from_fn(|i| one_byte(eight[i].content));
        if bytes.contains(&0) {
            for c in eight {
                encode_cell(c.content, out);
            }
        } else {
            out.extend_from_slice(&bytes);
        }
    }
    for c in eights.remainder() {
        encode_cell(c.content, out);
    }
    u32::try_from(trimmed).unwrap_or(u32::MAX)
}

/// Whether a cell holding this word is a printable ASCII character of width 1, which is written as itself.
#[inline]
fn ascii(content: u32) -> bool {
    content.wrapping_sub(0x20 | (1 << WIDTH_SHIFT)) < 0x7f - 0x20
}

/// The byte a cell is written as when it takes one, and 0 when it takes more.
#[inline]
fn one_byte(content: u32) -> u8 {
    if ascii(content) {
        low_seven(content as usize)
    } else if content == NULL_CONTENT {
        NULL_BYTE
    } else if content == 0 {
        HALF_BYTE
    } else {
        0
    }
}

/// One cell.
fn encode_cell(content: u32, out: &mut Vec<u8>) {
    let byte = one_byte(content);
    if byte != 0 {
        out.push(byte);
    } else if content & IS_COMBINED == 0 && plain(content) {
        let mut buf = [0u8; 4];
        let ch = char::from_u32(content & 0x1F_FFFF).unwrap_or('\u{FFFD}');
        out.extend_from_slice(ch.encode_utf8(&mut buf).as_bytes());
    } else {
        out.push(RAW_BYTE);
        out.extend_from_slice(&content.to_le_bytes());
    }
}

fn header(bytes: &[u8]) -> (Header, usize, usize, usize) {
    let mut at = 0;
    let length = get_varint(bytes, &mut at);
    let stored = get_varint(bytes, &mut at);
    let runs = get_varint(bytes, &mut at);
    let keys = get_varint(bytes, &mut at);
    let runs_from = at;
    // the largest key is the last, as they are sorted
    let mut keys_end = 0;
    let mut k = at;
    for _ in 0..runs {
        get_varint(bytes, &mut k);
        k += 8;
    }
    for _ in 0..keys {
        let key = get_varint(bytes, &mut k);
        let len = get_varint(bytes, &mut k);
        k += len;
        keys_end = key + 1;
    }
    (Header { length, stored, keys_end }, runs, keys, runs_from)
}

/// One cell of the byte stream, and where the next starts.
#[inline]
fn next_cell(bytes: &[u8], at: &mut usize) -> u32 {
    let b = bytes.get(*at).copied().unwrap_or(NULL_BYTE);
    *at += 1;
    match b {
        NULL_BYTE => NULL_CONTENT,
        HALF_BYTE => 0,
        RAW_BYTE => get_u32(bytes, at),
        0x20..=0x7e => u32::from(b) | (1 << WIDTH_SHIFT),
        _ => {
            let len = match b {
                0xC0..=0xDF => 2,
                0xE0..=0xEF => 3,
                _ => 4,
            };
            let mut cp = u32::from(b) & (0x7f >> len);
            for _ in 1..len {
                cp = (cp << 6) | (u32::from(bytes.get(*at).copied().unwrap_or(0x80)) & 0x3f);
                *at += 1;
            }
            cp | (wcwidth(cp) << WIDTH_SHIFT)
        }
    }
}

fn decode(bytes: &[u8], id: u64, wrapped: bool, into: &mut Row, attrs: &mut Attrs) {
    let (h, runs, keys, mut at) = header(bytes);
    into.cells.clear();
    into.cells.resize(h.length, Cell::NULL);
    into.combined.clear();
    into.wrapped = wrapped;
    into.id = id;
    into.used = h.stored.min(h.length);
    let runs_from = at;
    for _ in 0..runs {
        get_varint(bytes, &mut at);
        at += 8;
    }
    for _ in 0..keys {
        let key = get_varint(bytes, &mut at);
        let len = get_varint(bytes, &mut at);
        let text = String::from_utf8_lossy(bytes.get(at..at + len).unwrap_or_default()).into_owned();
        at += len;
        into.combined.push((u32::try_from(key).unwrap_or(u32::MAX), text));
    }
    let mut runs_left = runs;
    let mut run_at = runs_from;
    let mut next_col = if runs_left > 0 { get_varint(bytes, &mut run_at) } else { usize::MAX };
    let mut attr = 0;
    for col in 0..h.stored {
        if col == next_col {
            attr = attrs.intern(Attr { fg: get_u32(bytes, &mut run_at), bg: get_u32(bytes, &mut run_at) });
            runs_left -= 1;
            next_col = if runs_left > 0 { get_varint(bytes, &mut run_at) } else { usize::MAX };
        }
        let content = next_cell(bytes, &mut at);
        if let Some(c) = into.cells.get_mut(col) {
            *c = Cell { content, attr };
        }
    }
}

fn visit(bytes: &[u8], wrapped: bool, into: &mut crate::cells::LineBuf) {
    let (h, runs, keys, mut at) = header(bytes);
    into.clear(h.length, wrapped);
    let runs_from = at;
    for _ in 0..runs {
        get_varint(bytes, &mut at);
        at += 8;
    }
    for _ in 0..keys {
        let key = get_varint(bytes, &mut at);
        let len = get_varint(bytes, &mut at);
        let text = std::str::from_utf8(bytes.get(at..at + len).unwrap_or_default()).unwrap_or_default();
        at += len;
        into.add_combined(key, text);
    }
    let mut runs_left = runs;
    let mut run_at = runs_from;
    let mut next_col = if runs_left > 0 { get_varint(bytes, &mut run_at) } else { usize::MAX };
    let mut attr = Attr::DEFAULT;
    for col in 0..h.stored {
        if col == next_col {
            attr = Attr { fg: get_u32(bytes, &mut run_at), bg: get_u32(bytes, &mut run_at) };
            runs_left -= 1;
            next_col = if runs_left > 0 { get_varint(bytes, &mut run_at) } else { usize::MAX };
        }
        let content = next_cell(bytes, &mut at);
        into.set(col, content, attr);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Puts a kind of cell at a column.
    type Put = fn(&mut Row, usize);

    fn row_of(i: usize, attrs: &mut Attrs) -> Row {
        let red = attrs.intern(Attr { fg: 0x0100_0001, bg: 0 });
        let mut row = Row::new(200, Cell::NULL, i % 3 == 0, i as u64);
        for (x, c) in format!("row {i} {}", "x".repeat(i % 150)).chars().enumerate() {
            row.set_codepoint(x, u32::from(c), 1, if x % 7 == 0 { red } else { 0 });
        }
        row
    }

    #[test]
    fn rows_across_blocks() {
        let mut attrs = Attrs::default();
        let mut history = History::default();
        for i in 0..3000 {
            history.push(&row_of(i, &mut attrs), &attrs);
        }
        assert!(history.blocks.len() > 3);
        for _ in 0..1000 {
            history.pop_front();
        }
        let mut back = Row::default();
        for i in (2500..3000).rev() {
            history.pop_back(&mut back, &mut attrs);
            assert_eq!(back.cells, row_of(i, &mut attrs).cells);
        }
        assert_eq!(history.len(), 1500);
        for (k, i) in (1000..2500).enumerate() {
            let e = history.entry(k);
            assert_eq!((e.id, e.wrapped), (i as u64, i % 3 == 0));
            history.read(k, &mut back, &mut attrs);
            assert_eq!(back.cells, row_of(i, &mut attrs).cells, "row {i}");
        }
        for i in 2500..2600 {
            history.push(&row_of(i, &mut attrs), &attrs);
        }
        history.read(1550, &mut back, &mut attrs);
        assert_eq!(back.cells, row_of(2550, &mut attrs).cells);
        let held: usize = history.blocks.iter().map(Vec::len).sum();
        assert!(history.memory() < held + 3 * BLOCK + history.places.capacity() * 16);
    }

    #[test]
    fn a_row_comes_back_as_it_went() {
        let mut attrs = Attrs::default();
        let red = attrs.intern(Attr { fg: 0x0100_0001, bg: 0 });
        let mut row = Row::new(10, Cell::NULL, true, 7);
        row.set_codepoint(0, u32::from('a'), 1, 0);
        row.set_codepoint(1, u32::from('中'), 2, red);
        row.set_codepoint(2, 0, 0, red);
        row.set_codepoint(3, 0x301, 0, 0);
        row.set_codepoint(4, u32::from('e'), 1, 0);
        row.add_codepoint(4, 0x301, 1);
        row.set_codepoint(6, 0, 1, red);
        let mut history = History::default();
        history.push(&row, &attrs);
        assert_eq!(history.entry(0).trimmed, 5);
        let mut back = Row::default();
        history.pop_back(&mut back, &mut attrs);
        assert_eq!(back.cells, row.cells);
        assert_eq!(back.combined, row.combined);
        assert!(back.wrapped);
        assert_eq!(back.id, 7);
        assert!(history.is_empty());
    }

    #[test]
    fn cells_written_eight_at_a_time_are_written_as_one_at_a_time_would_be() {
        let mut attrs = Attrs::default();
        let kinds: [(&str, Put); 6] = [
            ("ascii", |r, x| r.set_codepoint(x, u32::from('q'), 1, 0)),
            ("empty", |r, x| r.set_codepoint(x, 0, 1, 0)),
            ("wide", |r, x| {
                r.set_codepoint(x, u32::from('中'), 2, 0);
                r.set_codepoint(x + 1, 0, 0, 0);
            }),
            ("other", |r, x| r.set_codepoint(x, u32::from('é'), 1, 0)),
            ("raw", |r, x| r.set_codepoint(x, 0x301, 0, 0)),
            ("combined", |r, x| {
                r.set_codepoint(x, u32::from('e'), 1, 0);
                r.add_codepoint(isize::try_from(x).unwrap(), 0x301, 1);
            }),
        ];
        // printable ASCII throughout, and every other cell empty
        let grounds: [fn(usize) -> u32; 2] = [|_| u32::from('a'), |x| if x % 2 == 0 { u32::from('a') } else { 0 }];
        for ground in grounds {
            for (name, put) in kinds {
                for at in 0..17 {
                    let mut row = Row::new(24, Cell::NULL, false, 1);
                    for x in 0..20 {
                        row.set_codepoint(x, ground(x), 1, 0);
                    }
                    put(&mut row, at);
                    let mut packed = Vec::new();
                    encode(&row, &attrs, &mut packed);
                    let stored = row.cells.iter().rposition(|&c| c != Cell::NULL).map_or(0, |i| i + 1);
                    let mut cells = Vec::new();
                    for c in &row.cells[..stored] {
                        encode_cell(c.content, &mut cells);
                    }
                    assert!(packed.ends_with(&cells), "{name} at {at}");
                    let mut history = History::default();
                    history.push(&row, &attrs);
                    let mut back = Row::default();
                    history.pop_back(&mut back, &mut attrs);
                    assert_eq!((back.cells, back.combined), (row.cells, row.combined), "{name} at {at}");
                }
            }
        }
    }
}
