//! A row of cells on a screen: `BufferLine.ts`, with the same operations and the same results, down to what a read past
//! the end of a row gives (an empty cell of width 0, as reading past the end of a typed array gives `undefined`).

use crate::attr::Attrs;

/// The code point of a cell.
pub const CODEPOINT_MASK: u32 = 0x1F_FFFF;
/// The cell's text is in the row's combined strings.
pub const IS_COMBINED: u32 = 0x20_0000;
/// Either of the two above: the cell holds text.
pub const HAS_CONTENT: u32 = 0x3F_FFFF;
/// The width bits.
pub const WIDTH_MASK: u32 = 0xC0_0000;
/// Where the width starts.
pub const WIDTH_SHIFT: u32 = 22;
/// The content of an empty cell: no text, width 1.
pub const NULL_CONTENT: u32 = 1 << WIDTH_SHIFT;

/// A column or a count as a signed number, for arithmetic that goes below zero as JavaScript's does. Columns and counts
/// are far below where this could saturate.
#[inline]
pub(crate) fn signed(x: impl TryInto<isize>) -> isize {
    x.try_into().unwrap_or(isize::MAX)
}

/// A signed result back as an index: below zero is 0.
#[inline]
pub(crate) fn unsigned(x: isize) -> usize {
    usize::try_from(x).unwrap_or(0)
}

/// One cell: xterm's content word, and the number of its attributes in the screen's table. Eight bytes.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Cell {
    pub content: u32,
    pub attr: u32,
}

impl Cell {
    /// What a read past the end of a row gives.
    pub const OUTSIDE: Cell = Cell { content: 0, attr: 0 };
    /// An empty cell with no attributes.
    pub const NULL: Cell = Cell { content: NULL_CONTENT, attr: 0 };

    #[inline]
    pub fn width(self) -> u32 {
        self.content >> WIDTH_SHIFT
    }

    #[inline]
    pub fn has_content(self) -> bool {
        self.content & HAS_CONTENT != 0
    }
}

/// A row: its cells, the strings of its cells that hold more than one code point, and whether it carries on the row
/// above it.
///
/// `combined` is xterm's `_combined` object and behaves like it: an entry stays when its cell is overwritten, and
/// `copy_cells_from` copies entries it should not. Both can be seen, so both are kept.
#[derive(Clone, Debug, Default)]
pub(crate) struct Row {
    pub cells: Vec<Cell>,
    /// Sorted by column, as JavaScript orders the integer keys of an object.
    pub combined: Vec<(u32, String)>,
    pub wrapped: bool,
    /// Which line this is, for as long as it lasts: see `Terminal::line_id`.
    pub id: u64,
    /// No cell from here on differs from [`Cell::NULL`].
    pub used: usize,
}

impl Row {
    pub fn new(cols: usize, fill: Cell, wrapped: bool, id: u64) -> Row {
        let mut row = Row { cells: Vec::new(), combined: Vec::new(), wrapped, id, used: 0 };
        row.reset(cols, fill, wrapped, id);
        row
    }

    /// Makes this row what `new` would, keeping its memory.
    pub fn reset(&mut self, cols: usize, fill: Cell, wrapped: bool, id: u64) {
        if fill == Cell::NULL && self.cells.len() == cols {
            self.cells[..self.used.min(cols)].fill(Cell::NULL);
        } else {
            self.cells.clear();
            self.cells.resize(cols, fill);
        }
        self.used = if fill == Cell::NULL { 0 } else { cols };
        self.combined.clear();
        self.wrapped = wrapped;
        self.id = id;
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.cells.len()
    }

    #[inline]
    pub fn cell(&self, i: usize) -> Cell {
        self.cells.get(i).copied().unwrap_or(Cell::OUTSIDE)
    }

    /// `getWidth`, with a column that may be past either end.
    #[inline]
    pub fn width_at(&self, i: isize) -> u32 {
        usize::try_from(i).map_or(0, |i| self.cell(i).width())
    }

    #[inline]
    pub fn has_content(&self, i: usize) -> bool {
        self.cell(i).has_content()
    }

    #[inline]
    fn touch(&mut self, end: usize) {
        if end > self.used {
            self.used = end;
        }
    }

    /// `setCellFromCodepoint`: a write past the end is lost, as it is on a typed array.
    #[inline]
    pub fn set_codepoint(&mut self, i: usize, cp: u32, width: u32, attr: u32) {
        if let Some(c) = self.cells.get_mut(i) {
            *c = Cell { content: cp | (width << WIDTH_SHIFT), attr };
            self.touch(i + 1);
        }
    }

    /// `setCell`.
    #[inline]
    pub fn set_cell(&mut self, i: usize, cell: Cell, combined: Option<&str>) {
        if cell.content & IS_COMBINED != 0 {
            self.set_combined(i, combined.unwrap_or_default().to_owned());
        }
        if let Some(c) = self.cells.get_mut(i) {
            *c = cell;
            self.touch(i + 1);
        }
    }

    pub fn combined_at(&self, i: usize) -> Option<&str> {
        let key = u32::try_from(i).ok()?;
        self.combined.binary_search_by_key(&key, |e| e.0).ok().map(|at| self.combined[at].1.as_str())
    }

    pub fn set_combined(&mut self, i: usize, text: String) {
        let Ok(key) = u32::try_from(i) else { return };
        match self.combined.binary_search_by_key(&key, |e| e.0) {
            Ok(at) => self.combined[at].1 = text,
            Err(at) => self.combined.insert(at, (key, text)),
        }
    }

    /// The text of a cell: `getString`, and `getChars` of a cell read from it.
    pub fn text(&self, i: usize, out: &mut String) {
        let content = self.cell(i).content;
        if content & IS_COMBINED != 0 {
            out.push_str(self.combined_at(i).unwrap_or("undefined"));
        } else if content & CODEPOINT_MASK != 0 {
            push_codepoint(out, content & CODEPOINT_MASK);
        }
    }

    /// `addCodepointToCell`: a combining character joins the cell before it.
    pub fn add_codepoint(&mut self, i: isize, cp: u32, width: u32) {
        let Ok(i) = usize::try_from(i) else { return };
        if i >= self.cells.len() {
            return;
        }
        let mut content = self.cells[i].content;
        if content & IS_COMBINED != 0 {
            let mut text = self.combined_at(i).unwrap_or("undefined").to_owned();
            push_codepoint(&mut text, cp);
            self.set_combined(i, text);
        } else if content & CODEPOINT_MASK != 0 {
            let mut text = String::new();
            push_codepoint(&mut text, content & CODEPOINT_MASK);
            push_codepoint(&mut text, cp);
            self.set_combined(i, text);
            content &= !CODEPOINT_MASK;
            content |= IS_COMBINED;
        } else {
            // "should not happen": nothing in the cell yet
            content = cp | (1 << WIDTH_SHIFT);
        }
        if width != 0 {
            content &= !WIDTH_MASK;
            content |= width << WIDTH_SHIFT;
        }
        self.cells[i].content = content;
        self.touch(i + 1);
    }

    /// The text of cell `i` copied to `j` of `into`, as `loadCell` then `setCell` do.
    fn move_cell(&mut self, from: usize, to: usize) {
        let cell = self.cell(from);
        if cell.content & IS_COMBINED != 0 {
            let text = self.combined_at(from).map(str::to_owned);
            self.set_combined(to, text.unwrap_or_default());
        }
        if let Some(c) = self.cells.get_mut(to) {
            *c = cell;
            self.touch(to + 1);
        }
    }

    /// `insertCells`.
    pub fn insert_cells(&mut self, pos: usize, n: usize, fill: Cell) {
        let length = self.cells.len();
        if length == 0 {
            return;
        }
        let pos = pos % length;
        if pos != 0 && self.width_at(signed(pos) - 1) == 2 {
            self.set_codepoint(pos - 1, 0, 1, fill.attr);
        }
        if n < length - pos {
            for i in (0..length - pos - n).rev() {
                self.move_cell(pos + i, pos + n + i);
            }
            for i in 0..n {
                self.set_cell(pos + i, fill, None);
            }
        } else {
            for i in pos..length {
                self.set_cell(i, fill, None);
            }
        }
        if self.width_at(signed(length) - 1) == 2 {
            self.set_codepoint(length - 1, 0, 1, fill.attr);
        }
    }

    /// `deleteCells`.
    pub fn delete_cells(&mut self, pos: usize, n: usize, fill: Cell) {
        let length = self.cells.len();
        if length == 0 {
            return;
        }
        let pos = pos % length;
        if n < length - pos {
            for i in 0..length - pos - n {
                self.move_cell(pos + n + i, pos + i);
            }
            for i in length - n..length {
                self.set_cell(i, fill, None);
            }
        } else {
            for i in pos..length {
                self.set_cell(i, fill, None);
            }
        }
        if pos != 0 && self.width_at(signed(pos) - 1) == 2 {
            self.set_codepoint(pos - 1, 0, 1, fill.attr);
        }
        if self.width_at(signed(pos)) == 0 && !self.has_content(pos) {
            self.set_codepoint(pos, 0, 1, fill.attr);
        }
    }

    /// `replaceCells`.
    pub fn replace_cells(&mut self, mut start: usize, end: usize, fill: Cell, respect_protect: bool, attrs: &Attrs) {
        let length = self.cells.len();
        let protected = |row: &Row, i: usize| attrs.get(row.cell(i).attr).is_protected();
        if respect_protect {
            if start != 0 && self.width_at(signed(start) - 1) == 2 && !protected(self, start - 1) {
                self.set_codepoint(start - 1, 0, 1, fill.attr);
            }
            if end < length && self.width_at(signed(end) - 1) == 2 && !protected(self, end) {
                self.set_codepoint(end, 0, 1, fill.attr);
            }
            while start < end && start < length {
                if !protected(self, start) {
                    self.set_cell(start, fill, None);
                }
                start += 1;
            }
            return;
        }
        if start != 0 && self.width_at(signed(start) - 1) == 2 {
            self.set_codepoint(start - 1, 0, 1, fill.attr);
        }
        if end < length && self.width_at(signed(end) - 1) == 2 {
            self.set_codepoint(end, 0, 1, fill.attr);
        }
        let stop = end.min(length);
        if start < stop {
            self.cells[start..stop].fill(fill);
            self.touch(stop);
        }
    }

    /// `fill`.
    pub fn fill(&mut self, fill: Cell, respect_protect: bool, attrs: &Attrs) {
        if respect_protect {
            for i in 0..self.cells.len() {
                if !attrs.get(self.cells[i].attr).is_protected() {
                    self.set_cell(i, fill, None);
                }
            }
            return;
        }
        self.combined.clear();
        if fill == Cell::NULL {
            let used = self.used.min(self.cells.len());
            self.cells[..used].fill(fill);
            self.used = 0;
        } else {
            self.cells.fill(fill);
            self.used = self.cells.len();
        }
    }

    /// `resize`: new cells are empty with no attributes; cut cells take their strings with them.
    pub fn resize(&mut self, cols: usize) {
        if cols == self.cells.len() {
            return;
        }
        if cols > self.cells.len() {
            self.cells.resize(cols, Cell::NULL);
        } else {
            self.cells.truncate(cols);
            self.combined.retain(|e| (e.0 as usize) < cols);
            self.used = self.used.min(cols);
        }
    }

    /// `copyCellsFrom` with another row as the source.
    pub fn copy_cells_from(&mut self, src: &Row, src_col: usize, dest_col: usize, length: usize, reverse: bool) {
        let mut copy = |cell: usize| {
            let value = src.cell(src_col + cell);
            if let Some(c) = self.cells.get_mut(dest_col + cell) {
                *c = value;
                if dest_col + cell + 1 > self.used {
                    self.used = dest_col + cell + 1;
                }
            }
        };
        if reverse {
            (0..length).rev().for_each(&mut copy);
        } else {
            (0..length).for_each(&mut copy);
        }
        // Every string from `src_col` on, not only those copied: xterm's FIXME, kept.
        for (key, text) in &src.combined {
            let key = *key as usize;
            if key >= src_col {
                self.set_combined(key - src_col + dest_col, text.clone());
            }
        }
    }

    /// `copyCellsFrom` with this row as its own source.
    pub fn copy_cells_within(&mut self, src_col: usize, dest_col: usize, length: usize, reverse: bool) {
        let copy = |row: &mut Row, cell: usize| {
            let value = row.cell(src_col + cell);
            if let Some(c) = row.cells.get_mut(dest_col + cell) {
                *c = value;
                if dest_col + cell + 1 > row.used {
                    row.used = dest_col + cell + 1;
                }
            }
        };
        if reverse {
            for cell in (0..length).rev() {
                copy(self, cell);
            }
        } else {
            for cell in 0..length {
                copy(self, cell);
            }
        }
        let keys: Vec<u32> = self.combined.iter().map(|e| e.0).filter(|&k| k as usize >= src_col).collect();
        for key in keys {
            if let Some(text) = self.combined_at(key as usize).map(str::to_owned) {
                self.set_combined(key as usize - src_col + dest_col, text);
            }
        }
    }

    /// `getTrimmedLength`: up to the last cell with text, and past it by its width.
    pub fn trimmed_length(&self) -> usize {
        for i in (0..self.cells.len().min(self.used)).rev() {
            let c = self.cells[i];
            if c.has_content() {
                return i + c.width() as usize;
            }
        }
        0
    }
}

/// Appends a code point as `stringFromCodePoint` and a UTF-8 encoding of the result would: one that is not a scalar value
/// becomes U+FFFD.
pub fn push_codepoint(out: &mut String, cp: u32) {
    out.push(char::from_u32(cp).unwrap_or('\u{FFFD}'));
}
