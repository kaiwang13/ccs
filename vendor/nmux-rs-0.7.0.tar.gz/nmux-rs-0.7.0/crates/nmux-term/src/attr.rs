//! Character attributes in the two words xterm.js keeps them in (`Constants.ts`, `AttributeData.ts`), the pen that writes
//! them, and the table that interns them so a cell needs only a number for them.

use std::collections::HashMap;
use std::hash::{BuildHasherDefault, Hasher};

/// The colour mode bits of either word.
pub const CM_MASK: u32 = 0x0300_0000;
/// One of the 16 colours.
pub const CM_P16: u32 = 0x0100_0000;
/// One of the 256 colours.
pub const CM_P256: u32 = 0x0200_0000;
/// A colour given as red, green and blue.
pub const CM_RGB: u32 = 0x0300_0000;
/// The colour of a palette mode.
pub const PCOLOR_MASK: u32 = 0xFF;
/// The colour of the RGB mode.
pub const RGB_MASK: u32 = 0x00FF_FFFF;

/// Flags of the foreground word.
pub mod fg {
    /// SGR 7.
    pub const INVERSE: u32 = 0x0400_0000;
    /// SGR 1.
    pub const BOLD: u32 = 0x0800_0000;
    /// SGR 4.
    pub const UNDERLINE: u32 = 0x1000_0000;
    /// SGR 5.
    pub const BLINK: u32 = 0x2000_0000;
    /// SGR 8.
    pub const INVISIBLE: u32 = 0x4000_0000;
    /// SGR 9.
    pub const STRIKETHROUGH: u32 = 0x8000_0000;
}

/// Flags of the background word.
pub mod bg {
    /// SGR 3.
    pub const ITALIC: u32 = 0x0400_0000;
    /// SGR 2.
    pub const DIM: u32 = 0x0800_0000;
    /// The cell has extended attributes. In a cell here it means more than in xterm: that they make it underlined, which
    /// is all that can be seen of them. See [`super::Pen::cell_bg`].
    pub const HAS_EXTENDED: u32 = 0x1000_0000;
    /// DECSCA: selective erase leaves the cell alone.
    pub const PROTECTED: u32 = 0x2000_0000;
    /// SGR 53.
    pub const OVERLINE: u32 = 0x4000_0000;
}

/// The attributes of a cell: xterm's two words.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash)]
pub struct Attr {
    /// Foreground colour and the flags kept with it.
    pub fg: u32,
    /// Background colour and the flags kept with it.
    pub bg: u32,
}

impl Attr {
    /// No attributes at all.
    pub const DEFAULT: Attr = Attr { fg: 0, bg: 0 };

    /// Whether a cell with these attributes looks underlined, as `isUnderline` answers.
    pub fn is_underline(self) -> bool {
        self.fg & fg::UNDERLINE != 0 || self.bg & bg::HAS_EXTENDED != 0
    }

    /// Whether DECSCA protects the cell.
    pub fn is_protected(self) -> bool {
        self.bg & bg::PROTECTED != 0
    }
}

/// What writes characters: the current attributes, with the extended ones xterm keeps beside them.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Pen {
    /// The foreground word.
    pub fg: u32,
    /// The background word, with `HAS_EXTENDED` as xterm sets it.
    pub bg: u32,
    /// The underline style of SGR 4:n, 0 to 7.
    pub underline_style: u8,
    /// A hyperlink is open (OSC 8).
    pub url: bool,
}

impl Pen {
    /// Whether the extended attributes hold anything, as `ExtendedAttrs.isEmpty` answers.
    fn extended_empty(&self) -> bool {
        self.underline_style == 0 && !self.url
    }

    /// `updateExtended`: the flag follows whether there is anything to keep.
    pub fn update_extended(&mut self) {
        if self.extended_empty() {
            self.bg &= !bg::HAS_EXTENDED;
        } else {
            self.bg |= bg::HAS_EXTENDED;
        }
    }

    /// The background word a cell written with this pen gets. A cell keeps a reference to the pen's extended attributes,
    /// and `isUnderline` looks at them only when the flag is set. They are not always in agreement: DECRC brings back the
    /// flag without them. So a cell keeps the flag only when the two together make it underlined.
    pub fn cell_bg(&self) -> u32 {
        if self.bg & bg::HAS_EXTENDED != 0 && self.extended_empty() { self.bg & !bg::HAS_EXTENDED } else { self.bg }
    }

    /// The attributes of a cell written with this pen.
    pub fn attr(&self) -> Attr {
        Attr { fg: self.fg, bg: self.cell_bg() }
    }

    /// The attributes erasing fills with: the background colour only (`_eraseAttrData`).
    pub fn erase_attr(&self) -> Attr {
        Attr { fg: 0, bg: self.bg & (CM_MASK | RGB_MASK) }
    }
}

/// A hasher for two words, which is all this table hashes.
#[derive(Default)]
pub(crate) struct WordHasher(u64);

impl Hasher for WordHasher {
    fn finish(&self) -> u64 {
        self.0
    }

    fn write(&mut self, bytes: &[u8]) {
        for &b in bytes {
            self.write_u64(u64::from(b));
        }
    }

    fn write_u32(&mut self, n: u32) {
        self.write_u64(u64::from(n));
    }

    fn write_u64(&mut self, n: u64) {
        self.0 = (self.0.rotate_left(5) ^ n).wrapping_mul(0x517c_c1b7_2722_0a95);
    }
}

/// The attributes cells on the screens use, each once, so that a cell holds a number for them. History keeps the words
/// themselves, so this table only has to cover two screens and is compacted when it holds many more than that.
#[derive(Debug)]
pub(crate) struct Attrs {
    list: Vec<Attr>,
    index: HashMap<Attr, u32, BuildHasherDefault<WordHasher>>,
}

impl Default for Attrs {
    fn default() -> Self {
        Attrs { list: vec![Attr::DEFAULT], index: HashMap::default() }
    }
}

impl std::fmt::Debug for WordHasher {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("WordHasher")
    }
}

impl Attrs {
    /// The number for these attributes; 0 is the default.
    #[inline]
    pub fn intern(&mut self, a: Attr) -> u32 {
        if a == Attr::DEFAULT {
            return 0;
        }
        if let Some(&id) = self.index.get(&a) {
            return id;
        }
        let id = u32::try_from(self.list.len()).unwrap_or(u32::MAX);
        self.list.push(a);
        self.index.insert(a, id);
        id
    }

    /// The attributes with this number.
    #[inline]
    pub fn get(&self, id: u32) -> Attr {
        self.list.get(id as usize).copied().unwrap_or_default()
    }

    /// How many there are.
    pub fn len(&self) -> usize {
        self.list.len()
    }

    /// Keeps only `used`, renumbered in that order; the default stays 0.
    pub fn rebuild(&mut self, used: &[Attr]) {
        self.list.clear();
        self.index.clear();
        self.list.push(Attr::DEFAULT);
        for &a in used {
            self.intern(a);
        }
    }
}
