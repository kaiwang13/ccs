//! UTF-8 to code points the way xterm.js decodes them (`Utf8ToUtf32` in `TextDecoder.ts`), which is not the way Rust or
//! the WHATWG decoder does: a byte that does not make a character is dropped rather than shown as U+FFFD, a byte order
//! mark disappears, and a character cut by the end of a write is finished by the next one.
//!
//! The character cut at the end of a write is kept exactly as xterm keeps it, including its mistake: a continuation byte
//! of 0x80 that was already received stops it counting the bytes it has, so the character is lost.

/// The decoder for one stream. `interim` holds the start of a character the last call could not finish.
#[derive(Debug, Default, Clone)]
pub struct Utf8Decoder {
    interim: [u8; 3],
}

impl Utf8Decoder {
    /// Forgets a character cut short, as xterm does when the next byte cannot continue it.
    pub fn clear(&mut self) {
        self.interim = [0; 3];
    }

    /// Appends the code points of `input` to `out`.
    #[allow(clippy::too_many_lines)] // one function in xterm, kept as one so the two can be read side by side
    pub fn decode(&mut self, input: &[u8], out: &mut Vec<u32>) {
        let length = input.len();
        if length == 0 {
            return;
        }
        let mut start = 0;
        if self.interim[0] != 0 {
            let mut discard = false;
            let lead = self.interim[0];
            let mut cp = u32::from(lead)
                & if lead & 0xE0 == 0xC0 {
                    0x1F
                } else if lead & 0xF0 == 0xE0 {
                    0x0F
                } else {
                    0x07
                };
            let mut pos = 0usize;
            loop {
                pos += 1;
                let tmp = if pos < 3 { self.interim[pos] & 0x3F } else { 0 };
                if tmp == 0 || pos >= 4 {
                    break;
                }
                cp = (cp << 6) | u32::from(tmp);
            }
            let kind: usize = if lead & 0xE0 == 0xC0 {
                2
            } else if lead & 0xF0 == 0xE0 {
                3
            } else {
                4
            };
            let missing = kind.saturating_sub(pos);
            while start < missing {
                if start >= length {
                    return;
                }
                let tmp = input[start];
                start += 1;
                if tmp & 0xC0 != 0x80 {
                    start -= 1;
                    discard = true;
                    break;
                }
                if pos < 3 {
                    self.interim[pos] = tmp;
                }
                pos += 1;
                cp = (cp << 6) | u32::from(tmp & 0x3F);
            }
            if !discard {
                if kind == 2 {
                    if cp < 0x80 {
                        start = start.saturating_sub(1);
                    } else {
                        out.push(cp);
                    }
                } else if kind == 3 {
                    if !(cp < 0x0800 || (0xD800..=0xDFFF).contains(&cp) || cp == 0xFEFF) {
                        out.push(cp);
                    }
                } else if (0x1_0000..=0x10_FFFF).contains(&cp) {
                    out.push(cp);
                }
            }
            self.interim = [0; 3];
        }

        let mut i = start;
        while i < length {
            let b1 = input[i];
            i += 1;
            if b1 < 0x80 {
                out.push(u32::from(b1));
            } else if b1 & 0xE0 == 0xC0 {
                if i >= length {
                    self.interim[0] = b1;
                    return;
                }
                let b2 = input[i];
                i += 1;
                if b2 & 0xC0 != 0x80 {
                    i -= 1;
                    continue;
                }
                let cp = (u32::from(b1) & 0x1F) << 6 | (u32::from(b2) & 0x3F);
                if cp < 0x80 {
                    i -= 1;
                    continue;
                }
                out.push(cp);
            } else if b1 & 0xF0 == 0xE0 {
                if i >= length {
                    self.interim[0] = b1;
                    return;
                }
                let b2 = input[i];
                i += 1;
                if b2 & 0xC0 != 0x80 {
                    i -= 1;
                    continue;
                }
                if i >= length {
                    self.interim = [b1, b2, 0];
                    return;
                }
                let b3 = input[i];
                i += 1;
                if b3 & 0xC0 != 0x80 {
                    i -= 1;
                    continue;
                }
                let cp = (u32::from(b1) & 0x0F) << 12 | (u32::from(b2) & 0x3F) << 6 | (u32::from(b3) & 0x3F);
                if cp < 0x0800 || (0xD800..=0xDFFF).contains(&cp) || cp == 0xFEFF {
                    continue;
                }
                out.push(cp);
            } else if b1 & 0xF8 == 0xF0 {
                if i >= length {
                    self.interim[0] = b1;
                    return;
                }
                let b2 = input[i];
                i += 1;
                if b2 & 0xC0 != 0x80 {
                    i -= 1;
                    continue;
                }
                if i >= length {
                    self.interim = [b1, b2, 0];
                    return;
                }
                let b3 = input[i];
                i += 1;
                if b3 & 0xC0 != 0x80 {
                    i -= 1;
                    continue;
                }
                if i >= length {
                    self.interim = [b1, b2, b3];
                    return;
                }
                let b4 = input[i];
                i += 1;
                if b4 & 0xC0 != 0x80 {
                    i -= 1;
                    continue;
                }
                let cp = (u32::from(b1) & 0x07) << 18
                    | (u32::from(b2) & 0x3F) << 12
                    | (u32::from(b3) & 0x3F) << 6
                    | (u32::from(b4) & 0x3F);
                if !(0x1_0000..=0x10_FFFF).contains(&cp) {
                    continue;
                }
                out.push(cp);
            }
            // anything else is not a lead byte, and is dropped
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn decode(chunks: &[&[u8]]) -> Vec<u32> {
        let mut d = Utf8Decoder::default();
        let mut out = Vec::new();
        for c in chunks {
            d.decode(c, &mut out);
        }
        out
    }

    #[test]
    fn valid_and_invalid() {
        assert_eq!(decode(&[b"a\xc3\xa9"]), vec![0x61, 0xe9]);
        assert_eq!(decode(&[b"\xff a"]), vec![0x20, 0x61]);
        assert_eq!(decode(&[b"\xef\xbb\xbfx"]), vec![0x78]);
        assert_eq!(decode(&[b"\xc0\x80x"]), vec![0x78]);
        assert_eq!(decode(&[b"\xe2\x82", b"\xac"]), vec![0x20ac]);
        assert_eq!(decode(&[b"\xe2", b"\x41"]), vec![0x41]);
        assert_eq!(decode(&[b"\xc2\x9b"]), vec![0x9b]);
    }

    #[test]
    fn the_cut_character_xterm_loses() {
        // U+2026 is E2 80 A6: cut after the 0x80, xterm counts one byte held, reads two more, and gives up on it.
        assert_eq!(decode(&[b"\xe2\x80", b"\xa6z"]), vec![0x7a]);
        assert_eq!(decode(&[b"\xe2\x80\xa6z"]), vec![0x2026, 0x7a]);
    }
}
