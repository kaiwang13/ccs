//! A buffer given a new size: `Buffer.resize` and the reflow of `Buffer.ts` and `BufferReflow.ts`, step for step.
//!
//! xterm works on its whole list of lines. Here the list is laid out flat for the length of the resize, a packed row of
//! the history staying packed unless the reflow has to look inside it, and is split into history and screen again at
//! the end.

use std::collections::VecDeque;

use crate::attr::Attrs;
use crate::buffer::{Buffer, take_id};
use crate::history::History;
use crate::line::{Cell, Row, signed, unsigned};

/// A line of the flat list.
#[derive(Debug)]
enum Slot {
    /// Row `index` of the old history, unread; `length` is what a resize made its length, if it changed it.
    Packed {
        index: usize,
        wrapped: bool,
        length: Option<usize>,
    },
    Row(Row),
}

/// The list as xterm sees it during a resize. Its length can be less than its slots: a line popped off the end stays in
/// xterm's circular array, and the reflow goes on to read it there.
struct Lines<'a> {
    slots: Vec<Slot>,
    len: usize,
    /// `maxLength`: a push to a full list drops its first line.
    max: usize,
    /// Lines a push dropped.
    trims: usize,
    old: &'a History,
    attrs: &'a mut Attrs,
}

impl Lines<'_> {
    fn len(&self) -> usize {
        self.len
    }

    fn push(&mut self, slot: Slot) {
        if self.len >= self.max && self.max > 0 {
            // `CircularList.push` when full: the first line goes, and xterm leaves `ybase` as it was
            self.slots.truncate(self.len);
            self.slots.remove(0);
            self.len -= 1;
            self.trims += 1;
        }
        if self.len < self.slots.len() {
            self.slots[self.len] = slot;
        } else {
            self.slots.push(slot);
        }
        self.len += 1;
    }

    fn pop(&mut self) {
        self.len = self.len.saturating_sub(1);
    }

    /// The lines in the list, without those left behind it.
    fn take_live(&mut self) -> Vec<Slot> {
        self.slots.truncate(self.len);
        std::mem::take(&mut self.slots)
    }

    fn set_live(&mut self, slots: Vec<Slot>) {
        self.len = slots.len();
        self.slots = slots;
    }

    fn wrapped(&self, i: usize) -> bool {
        match &self.slots[i] {
            Slot::Packed { wrapped, .. } => *wrapped,
            Slot::Row(r) => r.wrapped,
        }
    }

    fn trimmed_length(&self, i: usize) -> usize {
        match &self.slots[i] {
            Slot::Packed { index, .. } => usize::try_from(self.old.entry(*index).trimmed).unwrap_or(usize::MAX),
            Slot::Row(r) => r.trimmed_length(),
        }
    }

    /// The row, read out of the history if it is still packed.
    fn take(&mut self, i: usize) -> Row {
        match std::mem::replace(&mut self.slots[i], Slot::Packed { index: 0, wrapped: false, length: None }) {
            Slot::Row(r) => r,
            Slot::Packed { index, wrapped, length } => {
                let mut row = Row::default();
                self.old.read(index, &mut row, self.attrs);
                row.wrapped = wrapped;
                if let Some(length) = length {
                    row.resize(length);
                }
                row
            }
        }
    }

    fn put(&mut self, i: usize, row: Row) {
        self.slots[i] = Slot::Row(row);
    }

    /// `BufferLine.resize` of line `i`: a packed row only has to be read when cells it holds are cut off.
    fn resize_line(&mut self, i: usize, cols: usize) {
        if let Slot::Packed { index, ref mut length, .. } = self.slots[i] {
            let h = self.old.header(index);
            let now = length.unwrap_or(h.length);
            // cells past the stored ones are empty, so only cutting stored cells or strings needs the row read
            if cols >= now || (h.stored <= cols && h.keys_end <= cols) {
                *length = Some(cols);
                return;
            }
        }
        let mut row = self.take(i);
        row.resize(cols);
        self.put(i, row);
    }
}

impl Buffer {
    /// `Buffer.resize`.
    #[allow(clippy::too_many_lines)] // one method in xterm
    pub fn resize(
        &mut self,
        new_cols: usize,
        new_rows: usize,
        scrollback: usize,
        attrs: &mut Attrs,
        next_id: &mut u64,
    ) {
        let new_max = self.correct_length(new_rows, scrollback);
        if new_max > self.max_length {
            self.max_length = new_max;
            self.start = 0;
        }
        let old_history = std::mem::take(&mut self.history);
        let mut slots: Vec<Slot> = (0..old_history.len())
            .map(|index| Slot::Packed { index, wrapped: old_history.entry(index).wrapped, length: None })
            .chain(self.screen.drain(..).map(Slot::Row))
            .collect();
        let mut ybase = old_history.len();
        let has_lines = !slots.is_empty();
        {
            let len = slots.len();
            let mut lines = Lines {
                slots: std::mem::take(&mut slots),
                len,
                max: self.max_length,
                trims: 0,
                old: &old_history,
                attrs,
            };
            if lines.len() > 0 {
                if self.cols < new_cols {
                    for i in 0..lines.len() {
                        lines.resize_line(i, new_cols);
                    }
                }
                let mut add_to_y = 0;
                if self.rows < new_rows {
                    for _ in self.rows..new_rows {
                        if lines.len() < new_rows + ybase {
                            if ybase > 0 && lines.len() <= ybase + self.y + add_to_y + 1 {
                                ybase -= 1;
                                add_to_y += 1;
                            } else {
                                lines.push(Slot::Row(Row::new(new_cols, Cell::NULL, false, take_id(next_id))));
                            }
                        }
                    }
                } else {
                    for _ in (new_rows + 1..=self.rows).rev() {
                        if lines.len() > new_rows + ybase {
                            if lines.len() > ybase + self.y + 1 {
                                lines.pop();
                            } else {
                                ybase += 1;
                            }
                        }
                    }
                }
                if lines.trims > 0 {
                    self.trimmed += lines.trims as u64;
                    self.start = (self.start + lines.trims) % self.max_length.max(1);
                    lines.trims = 0;
                }
                if new_max < self.max_length {
                    let trim = lines.len().saturating_sub(new_max);
                    if trim > 0 {
                        let mut live = lines.take_live();
                        live.drain(..trim);
                        lines.set_live(live);
                        self.trimmed += trim as u64;
                        ybase = ybase.saturating_sub(trim);
                        self.saved_y = self.saved_y.saturating_sub(trim);
                    }
                    self.max_length = new_max;
                    self.start = 0;
                }
                self.x = self.x.min(new_cols - 1);
                self.y = self.y.min(new_rows - 1);
                self.y += add_to_y;
                self.saved_x = self.saved_x.min(new_cols - 1);
                self.scroll_top = 0;
            }
            self.scroll_bottom = new_rows - 1;
            if self.has_scrollback {
                if self.cols != new_cols {
                    if new_cols > self.cols {
                        self.reflow_larger(&mut lines, &mut ybase, new_cols, new_rows, next_id);
                    } else {
                        self.reflow_smaller(&mut lines, &mut ybase, new_cols, new_rows, next_id);
                    }
                }
                if self.cols > new_cols {
                    for i in 0..lines.len() {
                        lines.resize_line(i, new_cols);
                    }
                }
            }
            slots = lines.take_live();
        }
        self.cols = new_cols;
        self.rows = new_rows;
        // split the list again: history above `ybase`, the screen below
        let mut history = History::default();
        let mut screen = VecDeque::with_capacity(new_rows);
        for (i, slot) in slots.into_iter().enumerate() {
            if i < ybase {
                match slot {
                    Slot::Packed { index, wrapped, length } => {
                        let e = old_history.entry(index);
                        history.push_resized(old_history.bytes(index), e.id, e.trimmed, wrapped, length);
                    }
                    Slot::Row(row) => history.push(&row, attrs),
                }
            } else {
                match slot {
                    Slot::Packed { index, wrapped, length } => {
                        let mut row = Row::default();
                        old_history.read(index, &mut row, attrs);
                        row.wrapped = wrapped;
                        if let Some(length) = length {
                            row.resize(length);
                        }
                        screen.push_back(row);
                    }
                    Slot::Row(row) => screen.push_back(row),
                }
            }
        }
        // xterm can end a reflow with fewer lines than its screen needs below `ybase`, when the reflow made more lines
        // than the list could hold before there was any history; its screen then reads past the end of its list. Here
        // the screen stays whole: the history gives back its last lines, and blank ones make up the rest.
        let mut back = Row::default();
        while screen.len() < new_rows && !history.is_empty() {
            history.pop_back(&mut back, attrs);
            screen.push_front(std::mem::take(&mut back));
        }
        while screen.len() < new_rows && (has_lines || !screen.is_empty()) {
            screen.push_back(Row::new(new_cols, Cell::NULL, false, take_id(next_id)));
        }
        self.history = history;
        self.screen = screen;
    }

    /// `_reflowLarger`.
    fn reflow_larger(
        &mut self,
        lines: &mut Lines<'_>,
        ybase: &mut usize,
        new_cols: usize,
        new_rows: usize,
        next_id: &mut u64,
    ) {
        let to_remove = lines_to_remove(lines, self.cols, new_cols, *ybase + self.y);
        if to_remove.is_empty() {
            return;
        }
        // `reflowLargerCreateNewLayout` and `reflowLargerApplyNewLayout`
        let mut kept = Vec::with_capacity(lines.len());
        let mut removed = 0usize;
        let mut next = 0usize;
        let old = lines.take_live();
        let mut skip_until = 0usize;
        for (i, slot) in old.into_iter().enumerate() {
            if i < skip_until {
                continue;
            }
            if next < to_remove.len() && to_remove[next] == i {
                let count = to_remove[next + 1];
                skip_until = i + count;
                removed += count;
                next += 2;
                continue;
            }
            kept.push(slot);
        }
        lines.set_live(kept);
        // `_reflowLargerAdjustViewport`
        for _ in 0..removed {
            if *ybase == 0 {
                if self.y > 0 {
                    self.y -= 1;
                }
                if lines.len() < new_rows {
                    lines.push(Slot::Row(Row::new(new_cols, Cell::NULL, false, take_id(next_id))));
                }
            } else {
                *ybase -= 1;
            }
        }
        self.saved_y = self.saved_y.saturating_sub(removed);
    }

    /// `_reflowSmaller`.
    #[allow(clippy::too_many_lines)] // one method in xterm
    fn reflow_smaller(
        &mut self,
        lines: &mut Lines<'_>,
        ybase: &mut usize,
        new_cols: usize,
        new_rows: usize,
        next_id: &mut u64,
    ) {
        struct Insert {
            start: usize,
            rows: Vec<Row>,
        }
        let old_cols = self.cols;
        let mut to_insert: Vec<Insert> = Vec::new();
        let mut count_to_insert = 0usize;
        let mut y = signed(lines.len()) - 1;
        while y >= 0 {
            let mut yu = unsigned(y);
            if yu >= lines.slots.len() || (!lines.wrapped(yu) && lines.trimmed_length(yu) <= new_cols) {
                y -= 1;
                continue;
            }
            let mut group = vec![yu];
            while lines.wrapped(yu) && yu > 0 {
                yu -= 1;
                group.insert(0, yu);
            }
            y = signed(yu);
            let absolute_y = *ybase + self.y;
            if absolute_y >= yu && absolute_y < yu + group.len() {
                y -= 1;
                continue;
            }
            let mut wrapped: Vec<Row> = group.iter().map(|&i| lines.take(i)).collect();
            let last_line_length = wrapped[wrapped.len() - 1].trimmed_length();
            let dest_lengths = new_line_lengths(&wrapped, old_cols, new_cols);
            let lines_to_add = signed(dest_lengths.len()) - signed(wrapped.len());
            let trimmed_lines = if *ybase == 0 && signed(self.y) != signed(lines.len()) - 1 {
                (signed(self.y) - signed(self.max_length) + lines_to_add).max(0)
            } else {
                (signed(lines.len()) - signed(self.max_length) + lines_to_add).max(0)
            };
            let added = usize::try_from(lines_to_add).unwrap_or(0);
            let group_len = wrapped.len();
            for _ in 0..added {
                wrapped.push(Row::new(new_cols, Cell::NULL, true, take_id(next_id)));
            }
            // copy backwards, in place
            let mut dest_index = signed(dest_lengths.len()) - 1;
            let mut dest_col = signed(dest_lengths.get(unsigned(dest_index)).copied().unwrap_or(0));
            if dest_col == 0 {
                dest_index -= 1;
                dest_col = length_at(&dest_lengths, dest_index);
            }
            let mut src_index = signed(wrapped.len()) - signed(added) - 1;
            let mut src_col = signed(last_line_length);
            while src_index >= 0 {
                let cells = src_col.min(dest_col);
                if dest_index < 0 || unsigned(dest_index) >= wrapped.len() {
                    break;
                }
                copy_cells(
                    &mut wrapped,
                    unsigned(dest_index),
                    unsigned(src_index),
                    unsigned(src_col - cells),
                    unsigned(dest_col - cells),
                    unsigned(cells),
                    true,
                );
                dest_col -= cells;
                if dest_col == 0 {
                    dest_index -= 1;
                    dest_col = length_at(&dest_lengths, dest_index);
                }
                src_col -= cells;
                if src_col == 0 {
                    src_index -= 1;
                    let at = unsigned(src_index);
                    src_col = signed(wrapped_trimmed_length(&wrapped, at, old_cols));
                }
            }
            for (i, row) in wrapped.iter_mut().enumerate() {
                if let Some(&len) = dest_lengths.get(i) {
                    if len < new_cols {
                        row.set_cell(len, Cell::NULL, None);
                    }
                }
            }
            let new_rows_vec: Vec<Row> = wrapped.split_off(group_len);
            for (row, &i) in wrapped.into_iter().zip(&group) {
                lines.put(i, row);
            }
            if !new_rows_vec.is_empty() {
                to_insert.push(Insert { start: yu + group_len + count_to_insert, rows: new_rows_vec });
                count_to_insert += added;
            }
            let mut adjustments = lines_to_add - trimmed_lines;
            while adjustments > 0 {
                adjustments -= 1;
                if *ybase == 0 {
                    if self.y < new_rows - 1 {
                        self.y += 1;
                        lines.pop();
                    } else {
                        *ybase += 1;
                    }
                } else if signed(*ybase)
                    < (signed(self.max_length.min(lines.len() + count_to_insert)) - signed(new_rows))
                {
                    *ybase += 1;
                }
            }
            self.saved_y = (self.saved_y + added).min(*ybase + new_rows - 1);
            y -= 1;
        }
        if to_insert.is_empty() {
            return;
        }
        // the rearrangement, from the end, as xterm does it
        let original: Vec<Slot> = lines.take_live();
        let original_len = original.len();
        let new_len = self.max_length.min(original_len + count_to_insert);
        let mut placed: Vec<Option<Slot>> = (0..new_len).map(|_| None).collect();
        let mut originals: Vec<Option<Slot>> = original.into_iter().map(Some).collect();
        let mut original_index = signed(original_len) - 1;
        let mut next = 0usize;
        let mut inserted = 0usize;
        let mut i = (signed(self.max_length) - 1).min(signed(original_len) + signed(count_to_insert) - 1);
        let mut pending: Vec<Insert> = to_insert;
        while i >= 0 {
            if next < pending.len() && signed(pending[next].start) > original_index + signed(inserted) {
                let rows = std::mem::take(&mut pending[next].rows);
                let n = rows.len();
                for row in rows.into_iter().rev() {
                    if let Some(at) = self.circular_index(i, new_len) {
                        placed[at] = Some(Slot::Row(row));
                    }
                    i -= 1;
                }
                i += 1;
                inserted += n;
                next += 1;
            } else {
                if original_index >= 0 {
                    if let Some(slot) = placed.get_mut(unsigned(i)) {
                        *slot = originals[unsigned(original_index)].take();
                    }
                }
                original_index -= 1;
            }
            i -= 1;
        }
        let trim = (original_len + count_to_insert).saturating_sub(self.max_length);
        self.trimmed += trim as u64;
        let placed: Vec<Slot> = placed
            .into_iter()
            .map(|s| s.unwrap_or_else(|| Slot::Row(Row::new(new_cols, Cell::NULL, false, take_id(next_id)))))
            .collect();
        lines.set_live(placed);
    }
}

impl Buffer {
    /// Which line `lines.set(i)` writes for an index that may be negative: `(startIndex + i) % maxLength`, with the sign
    /// JavaScript gives a remainder, picks a slot of the array when it is not negative (or is -0), and that slot holds
    /// the line its distance from the start says.
    fn circular_index(&self, i: isize, len: usize) -> Option<usize> {
        let max = signed(self.max_length);
        if max == 0 {
            return None;
        }
        let sum = signed(self.start) + i;
        let slot = sum % max;
        if slot < 0 {
            return None;
        }
        let line = usize::try_from((slot - signed(self.start)).rem_euclid(max)).ok()?;
        (line < len).then_some(line)
    }
}

fn length_at(lengths: &[usize], i: isize) -> isize {
    usize::try_from(i).ok().and_then(|i| lengths.get(i)).map_or(0, |&l| signed(l))
}

/// `copyCellsFrom` between two rows of a group, which may be the same row.
fn copy_cells(
    rows: &mut [Row],
    dest: usize,
    src: usize,
    src_col: usize,
    dest_col: usize,
    length: usize,
    reverse: bool,
) {
    match dest.cmp(&src) {
        std::cmp::Ordering::Equal => rows[dest].copy_cells_within(src_col, dest_col, length, reverse),
        std::cmp::Ordering::Less => {
            let (a, b) = rows.split_at_mut(src);
            a[dest].copy_cells_from(&b[0], src_col, dest_col, length, reverse);
        }
        std::cmp::Ordering::Greater => {
            let (a, b) = rows.split_at_mut(dest);
            b[0].copy_cells_from(&a[src], src_col, dest_col, length, reverse);
        }
    }
}

/// `getWrappedLineTrimmedLength`.
fn wrapped_trimmed_length(rows: &[Row], i: usize, cols: usize) -> usize {
    if i + 1 >= rows.len() {
        return rows.get(i).map_or(0, Row::trimmed_length);
    }
    let line = &rows[i];
    let ends_in_null = !line.has_content(cols - 1) && line.cell(cols - 1).width() == 1;
    let following_wide = rows[i + 1].cell(0).width() == 2;
    if ends_in_null && following_wide { cols - 1 } else { cols }
}

/// `reflowSmallerGetNewLineLengths`.
fn new_line_lengths(rows: &[Row], old_cols: usize, new_cols: usize) -> Vec<usize> {
    let mut lengths = Vec::new();
    let needed: usize = (0..rows.len()).map(|i| wrapped_trimmed_length(rows, i, old_cols)).sum();
    let mut src_col = 0usize;
    let mut src_line = 0usize;
    let mut available = 0usize;
    while available < needed {
        if needed - available < new_cols {
            lengths.push(needed - available);
            break;
        }
        src_col += new_cols;
        let old_trimmed = wrapped_trimmed_length(rows, src_line, old_cols);
        if src_col > old_trimmed {
            src_col -= old_trimmed;
            src_line += 1;
        }
        let ends_wide = rows.get(src_line).is_some_and(|r| r.width_at(signed(src_col) - 1) == 2);
        if ends_wide {
            src_col -= 1;
        }
        let length = if ends_wide { new_cols - 1 } else { new_cols };
        lengths.push(length);
        available += length;
    }
    lengths
}

/// `reflowLargerGetLinesToRemove`: the lines a wider screen makes empty, as `[index, count, ...]`, after moving their
/// cells up into the lines they carry on.
fn lines_to_remove(lines: &mut Lines<'_>, old_cols: usize, new_cols: usize, cursor: usize) -> Vec<usize> {
    let mut to_remove = Vec::new();
    let mut y = 0usize;
    while y + 1 < lines.len() {
        let mut i = y + 1;
        if !lines.wrapped(i) {
            y += 1;
            continue;
        }
        let mut group = vec![y];
        while i < lines.len() && lines.wrapped(i) {
            group.push(i);
            i += 1;
        }
        if cursor >= y && cursor < i {
            y += group.len();
            continue;
        }
        let mut rows: Vec<Row> = group.iter().map(|&g| lines.take(g)).collect();
        let mut dest_index = 0usize;
        let mut dest_col = wrapped_trimmed_length(&rows, 0, old_cols);
        let mut src_index = 1usize;
        let mut src_col = 0usize;
        while src_index < rows.len() {
            let src_trimmed = wrapped_trimmed_length(&rows, src_index, old_cols);
            let src_remaining = src_trimmed.saturating_sub(src_col);
            let dest_remaining = new_cols.saturating_sub(dest_col);
            let cells = src_remaining.min(dest_remaining);
            copy_cells(&mut rows, dest_index, src_index, src_col, dest_col, cells, false);
            dest_col += cells;
            if dest_col == new_cols {
                dest_index += 1;
                dest_col = 0;
            }
            src_col += cells;
            if src_col == src_trimmed {
                src_index += 1;
                src_col = 0;
            }
            if dest_col == 0 && dest_index != 0 && rows[dest_index - 1].cell(new_cols - 1).width() == 2 {
                copy_cells(&mut rows, dest_index, dest_index - 1, new_cols - 1, dest_col, 1, false);
                dest_col += 1;
                rows[dest_index - 1].set_cell(new_cols - 1, Cell::NULL, None);
            }
        }
        if let Some(row) = rows.get_mut(dest_index) {
            row.replace_cells(dest_col, new_cols, Cell::NULL, false, lines.attrs);
        }
        let mut count = 0;
        for k in (1..rows.len()).rev() {
            if k > dest_index || rows[k].trimmed_length() == 0 {
                count += 1;
            } else {
                break;
            }
        }
        let len = rows.len();
        for (row, &g) in rows.into_iter().zip(&group) {
            lines.put(g, row);
        }
        if count > 0 {
            to_remove.push(y + len - count);
            to_remove.push(count);
        }
        y += len;
    }
    to_remove
}
