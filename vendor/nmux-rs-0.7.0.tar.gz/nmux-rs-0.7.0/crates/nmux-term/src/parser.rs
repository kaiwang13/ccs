//! xterm.js's parser (`EscapeSequenceParser.ts`), for when a token cannot be taken as it is: a sequence the lexer had to
//! let go of half way, a C0 control in the middle of one, a C1 control spelled in UTF-8. The table is xterm's, built the
//! same way, so a code point in a state goes where it goes there.

/// The parser's states, numbered as in xterm.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(u8)]
pub(crate) enum State {
    Ground = 0,
    Escape = 1,
    EscapeIntermediate = 2,
    CsiEntry = 3,
    CsiParam = 4,
    CsiIntermediate = 5,
    CsiIgnore = 6,
    SosPmApcString = 7,
    OscString = 8,
    DcsEntry = 9,
    DcsParam = 10,
    DcsIgnore = 11,
    DcsIntermediate = 12,
    DcsPassthrough = 13,
}

impl State {
    pub fn from_index(i: u8) -> State {
        match i {
            1 => State::Escape,
            2 => State::EscapeIntermediate,
            3 => State::CsiEntry,
            4 => State::CsiParam,
            5 => State::CsiIntermediate,
            6 => State::CsiIgnore,
            7 => State::SosPmApcString,
            8 => State::OscString,
            9 => State::DcsEntry,
            10 => State::DcsParam,
            11 => State::DcsIgnore,
            12 => State::DcsIntermediate,
            13 => State::DcsPassthrough,
            _ => State::Ground,
        }
    }
}

/// What the parser does with a code point.
pub(crate) mod action {
    pub const IGNORE: u8 = 0;
    pub const ERROR: u8 = 1;
    pub const PRINT: u8 = 2;
    pub const EXECUTE: u8 = 3;
    pub const OSC_START: u8 = 4;
    pub const OSC_PUT: u8 = 5;
    pub const OSC_END: u8 = 6;
    pub const CSI_DISPATCH: u8 = 7;
    pub const PARAM: u8 = 8;
    pub const COLLECT: u8 = 9;
    pub const ESC_DISPATCH: u8 = 10;
    pub const CLEAR: u8 = 11;
    pub const DCS_HOOK: u8 = 12;
    pub const DCS_PUT: u8 = 13;
    pub const DCS_UNHOOK: u8 = 14;
}

/// Every code point from 0xA0 up is looked up as 0xA0.
pub(crate) const NON_ASCII_PRINTABLE: u32 = 0xA0;

const STATES: usize = 14;

/// `action << 4 | next state`, indexed by `state << 8 | code`.
pub(crate) static TABLE: [u8; STATES * 256] = build();

const fn pack(action: u8, next: State) -> u8 {
    (action << 4) | next as u8
}

const fn add(t: &mut [u8; STATES * 256], code: usize, state: State, action: u8, next: State) {
    t[(state as usize) << 8 | code] = pack(action, next);
}

const fn add_range(t: &mut [u8; STATES * 256], from: usize, to: usize, state: State, action: u8, next: State) {
    let mut c = from;
    while c < to {
        add(t, c, state, action, next);
        c += 1;
    }
}

/// `EXECUTABLES`: 0x00 to 0x17, 0x19, 0x1c to 0x1f.
const fn add_executables(t: &mut [u8; STATES * 256], state: State, action: u8, next: State) {
    add_range(t, 0x00, 0x18, state, action, next);
    add(t, 0x19, state, action, next);
    add_range(t, 0x1c, 0x20, state, action, next);
}

const fn state_of(i: usize) -> State {
    match i {
        0 => State::Ground,
        1 => State::Escape,
        2 => State::EscapeIntermediate,
        3 => State::CsiEntry,
        4 => State::CsiParam,
        5 => State::CsiIntermediate,
        6 => State::CsiIgnore,
        7 => State::SosPmApcString,
        8 => State::OscString,
        9 => State::DcsEntry,
        10 => State::DcsParam,
        11 => State::DcsIgnore,
        12 => State::DcsIntermediate,
        _ => State::DcsPassthrough,
    }
}

/// `VT500_TRANSITION_TABLE`, in the same order, as later entries replace earlier ones.
#[allow(clippy::too_many_lines)] // the table, line for line
const fn build() -> [u8; STATES * 256] {
    use State::{
        CsiEntry, CsiIgnore, CsiIntermediate, CsiParam, DcsEntry, DcsIgnore, DcsIntermediate, DcsParam, DcsPassthrough,
        Escape, EscapeIntermediate, Ground, OscString, SosPmApcString,
    };
    use action::{
        CLEAR, COLLECT, CSI_DISPATCH, DCS_HOOK, DCS_PUT, DCS_UNHOOK, ERROR, ESC_DISPATCH, EXECUTE, IGNORE, OSC_END,
        OSC_PUT, OSC_START, PARAM, PRINT,
    };
    let mut t = [pack(ERROR, Ground); STATES * 256];
    add_range(&mut t, 0x20, 0x7f, Ground, PRINT, Ground);
    let mut s = 0;
    while s < STATES {
        let state = state_of(s);
        add(&mut t, 0x18, state, EXECUTE, Ground);
        add(&mut t, 0x1a, state, EXECUTE, Ground);
        add(&mut t, 0x99, state, EXECUTE, Ground);
        add(&mut t, 0x9a, state, EXECUTE, Ground);
        add_range(&mut t, 0x80, 0x90, state, EXECUTE, Ground);
        add_range(&mut t, 0x90, 0x98, state, EXECUTE, Ground);
        add(&mut t, 0x9c, state, IGNORE, Ground);
        add(&mut t, 0x1b, state, CLEAR, Escape);
        add(&mut t, 0x9d, state, OSC_START, OscString);
        add(&mut t, 0x98, state, IGNORE, SosPmApcString);
        add(&mut t, 0x9e, state, IGNORE, SosPmApcString);
        add(&mut t, 0x9f, state, IGNORE, SosPmApcString);
        add(&mut t, 0x9b, state, CLEAR, CsiEntry);
        add(&mut t, 0x90, state, CLEAR, DcsEntry);
        s += 1;
    }
    add_executables(&mut t, Ground, EXECUTE, Ground);
    add_executables(&mut t, Escape, EXECUTE, Escape);
    add(&mut t, 0x7f, Escape, IGNORE, Escape);
    add_executables(&mut t, OscString, IGNORE, OscString);
    add_executables(&mut t, CsiEntry, EXECUTE, CsiEntry);
    add(&mut t, 0x7f, CsiEntry, IGNORE, CsiEntry);
    add_executables(&mut t, CsiParam, EXECUTE, CsiParam);
    add(&mut t, 0x7f, CsiParam, IGNORE, CsiParam);
    add_executables(&mut t, CsiIgnore, EXECUTE, CsiIgnore);
    add_executables(&mut t, CsiIntermediate, EXECUTE, CsiIntermediate);
    add(&mut t, 0x7f, CsiIntermediate, IGNORE, CsiIntermediate);
    add_executables(&mut t, EscapeIntermediate, EXECUTE, EscapeIntermediate);
    add(&mut t, 0x7f, EscapeIntermediate, IGNORE, EscapeIntermediate);
    // osc
    add(&mut t, 0x5d, Escape, OSC_START, OscString);
    add_range(&mut t, 0x20, 0x7f, OscString, OSC_PUT, OscString);
    add(&mut t, 0x7f, OscString, OSC_PUT, OscString);
    add(&mut t, 0x9c, OscString, OSC_END, Ground);
    add(&mut t, 0x1b, OscString, OSC_END, Ground);
    add(&mut t, 0x18, OscString, OSC_END, Ground);
    add(&mut t, 0x1a, OscString, OSC_END, Ground);
    add(&mut t, 0x07, OscString, OSC_END, Ground);
    add_range(&mut t, 0x1c, 0x20, OscString, IGNORE, OscString);
    // sos/pm/apc does nothing
    add(&mut t, 0x58, Escape, IGNORE, SosPmApcString);
    add(&mut t, 0x5e, Escape, IGNORE, SosPmApcString);
    add(&mut t, 0x5f, Escape, IGNORE, SosPmApcString);
    add_range(&mut t, 0x20, 0x7f, SosPmApcString, IGNORE, SosPmApcString);
    add_executables(&mut t, SosPmApcString, IGNORE, SosPmApcString);
    add(&mut t, 0x9c, SosPmApcString, IGNORE, Ground);
    add(&mut t, 0x7f, SosPmApcString, IGNORE, SosPmApcString);
    // csi entries
    add(&mut t, 0x5b, Escape, CLEAR, CsiEntry);
    add_range(&mut t, 0x40, 0x7f, CsiEntry, CSI_DISPATCH, Ground);
    add_range(&mut t, 0x30, 0x3c, CsiEntry, PARAM, CsiParam);
    add_range(&mut t, 0x3c, 0x40, CsiEntry, COLLECT, CsiParam);
    add_range(&mut t, 0x30, 0x3c, CsiParam, PARAM, CsiParam);
    add_range(&mut t, 0x40, 0x7f, CsiParam, CSI_DISPATCH, Ground);
    add_range(&mut t, 0x3c, 0x40, CsiParam, IGNORE, CsiIgnore);
    add_range(&mut t, 0x20, 0x40, CsiIgnore, IGNORE, CsiIgnore);
    add(&mut t, 0x7f, CsiIgnore, IGNORE, CsiIgnore);
    add_range(&mut t, 0x40, 0x7f, CsiIgnore, IGNORE, Ground);
    add_range(&mut t, 0x20, 0x30, CsiEntry, COLLECT, CsiIntermediate);
    add_range(&mut t, 0x20, 0x30, CsiIntermediate, COLLECT, CsiIntermediate);
    add_range(&mut t, 0x30, 0x40, CsiIntermediate, IGNORE, CsiIgnore);
    add_range(&mut t, 0x40, 0x7f, CsiIntermediate, CSI_DISPATCH, Ground);
    add_range(&mut t, 0x20, 0x30, CsiParam, COLLECT, CsiIntermediate);
    // esc_intermediate
    add_range(&mut t, 0x20, 0x30, Escape, COLLECT, EscapeIntermediate);
    add_range(&mut t, 0x20, 0x30, EscapeIntermediate, COLLECT, EscapeIntermediate);
    add_range(&mut t, 0x30, 0x7f, EscapeIntermediate, ESC_DISPATCH, Ground);
    add_range(&mut t, 0x30, 0x50, Escape, ESC_DISPATCH, Ground);
    add_range(&mut t, 0x51, 0x58, Escape, ESC_DISPATCH, Ground);
    add(&mut t, 0x59, Escape, ESC_DISPATCH, Ground);
    add(&mut t, 0x5a, Escape, ESC_DISPATCH, Ground);
    add(&mut t, 0x5c, Escape, ESC_DISPATCH, Ground);
    add_range(&mut t, 0x60, 0x7f, Escape, ESC_DISPATCH, Ground);
    // dcs entry
    add(&mut t, 0x50, Escape, CLEAR, DcsEntry);
    add_executables(&mut t, DcsEntry, IGNORE, DcsEntry);
    add(&mut t, 0x7f, DcsEntry, IGNORE, DcsEntry);
    add_range(&mut t, 0x1c, 0x20, DcsEntry, IGNORE, DcsEntry);
    add_range(&mut t, 0x20, 0x30, DcsEntry, COLLECT, DcsIntermediate);
    add_range(&mut t, 0x30, 0x3c, DcsEntry, PARAM, DcsParam);
    add_range(&mut t, 0x3c, 0x40, DcsEntry, COLLECT, DcsParam);
    add_executables(&mut t, DcsIgnore, IGNORE, DcsIgnore);
    add_range(&mut t, 0x20, 0x80, DcsIgnore, IGNORE, DcsIgnore);
    add_range(&mut t, 0x1c, 0x20, DcsIgnore, IGNORE, DcsIgnore);
    add_executables(&mut t, DcsParam, IGNORE, DcsParam);
    add(&mut t, 0x7f, DcsParam, IGNORE, DcsParam);
    add_range(&mut t, 0x1c, 0x20, DcsParam, IGNORE, DcsParam);
    add_range(&mut t, 0x30, 0x3c, DcsParam, PARAM, DcsParam);
    add_range(&mut t, 0x3c, 0x40, DcsParam, IGNORE, DcsIgnore);
    add_range(&mut t, 0x20, 0x30, DcsParam, COLLECT, DcsIntermediate);
    add_executables(&mut t, DcsIntermediate, IGNORE, DcsIntermediate);
    add(&mut t, 0x7f, DcsIntermediate, IGNORE, DcsIntermediate);
    add_range(&mut t, 0x1c, 0x20, DcsIntermediate, IGNORE, DcsIntermediate);
    add_range(&mut t, 0x20, 0x30, DcsIntermediate, COLLECT, DcsIntermediate);
    add_range(&mut t, 0x30, 0x40, DcsIntermediate, IGNORE, DcsIgnore);
    add_range(&mut t, 0x40, 0x7f, DcsIntermediate, DCS_HOOK, DcsPassthrough);
    add_range(&mut t, 0x40, 0x7f, DcsParam, DCS_HOOK, DcsPassthrough);
    add_range(&mut t, 0x40, 0x7f, DcsEntry, DCS_HOOK, DcsPassthrough);
    add_executables(&mut t, DcsPassthrough, DCS_PUT, DcsPassthrough);
    add_range(&mut t, 0x20, 0x7f, DcsPassthrough, DCS_PUT, DcsPassthrough);
    add(&mut t, 0x7f, DcsPassthrough, IGNORE, DcsPassthrough);
    add(&mut t, 0x1b, DcsPassthrough, DCS_UNHOOK, Ground);
    add(&mut t, 0x9c, DcsPassthrough, DCS_UNHOOK, Ground);
    add(&mut t, 0x18, DcsPassthrough, DCS_UNHOOK, Ground);
    add(&mut t, 0x1a, DcsPassthrough, DCS_UNHOOK, Ground);
    // special handling of unicode chars
    add(&mut t, 0xa0, Ground, PRINT, Ground);
    add(&mut t, 0xa0, OscString, OSC_PUT, OscString);
    add(&mut t, 0xa0, CsiIgnore, IGNORE, CsiIgnore);
    add(&mut t, 0xa0, DcsIgnore, IGNORE, DcsIgnore);
    add(&mut t, 0xa0, DcsPassthrough, DCS_PUT, DcsPassthrough);
    t
}

/// What a string of OSC 8 asks for, worked out as it arrives so that none of it has to be kept: xterm's `OscParser`
/// with only the one handler that changes cells.
#[derive(Clone, Copy, Debug, Default)]
pub(crate) struct Osc {
    state: OscState,
    /// The number before the first `;`, saturating; `None` until a digit arrives.
    id: Option<u64>,
    link: Link,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
enum OscState {
    #[default]
    Start,
    Id,
    Payload,
    Abort,
}

/// The parts of `setHyperlink`'s argument that decide what it does.
#[derive(Clone, Copy, Debug, Default)]
struct Link {
    /// Its length in UTF-16 units, as `PAYLOAD_LIMIT` counts it.
    units: u64,
    semicolon: bool,
    /// Something other than white space before the `;`.
    id_set: bool,
    /// Anything after the `;`.
    uri_set: bool,
}

/// `PAYLOAD_LIMIT`: a longer string is dropped.
const PAYLOAD_LIMIT: u64 = 10_000_000;

/// What an OSC string did to the pen.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum LinkChange {
    Open,
    Close,
}

impl Osc {
    /// `start`: an OSC begins.
    pub fn start(&mut self) {
        *self = Osc { state: OscState::Id, ..Osc::default() };
    }

    /// `put`: printable code points of the string.
    pub fn put(&mut self, codes: &[u32]) {
        let mut codes = codes;
        if self.state == OscState::Id {
            while let Some((&code, rest)) = codes.split_first() {
                codes = rest;
                if code == u32::from(b';') {
                    self.state = OscState::Payload;
                    break;
                }
                if !(0x30..=0x39).contains(&code) {
                    self.state = OscState::Abort;
                    return;
                }
                let id = self.id.unwrap_or(0);
                self.id = Some(id.saturating_mul(10).saturating_add(u64::from(code - 0x30)));
            }
        }
        if self.state == OscState::Payload && self.id == Some(8) {
            for &code in codes {
                let link = &mut self.link;
                link.units += if code > 0xFFFF { 2 } else { 1 };
                if link.semicolon {
                    link.uri_set = true;
                } else if code == u32::from(b';') {
                    link.semicolon = true;
                } else if !js_space(code) {
                    link.id_set = true;
                }
            }
        }
    }

    /// `end`: what the string asked of the pen, if it was OSC 8 and asked anything.
    pub fn end(&mut self, success: bool) -> Option<LinkChange> {
        let done = *self;
        *self = Osc::default();
        if done.state == OscState::Start || done.state == OscState::Abort || !success || done.id != Some(8) {
            return None;
        }
        let link = done.link;
        if link.units > PAYLOAD_LIMIT || !link.semicolon {
            return None;
        }
        if link.uri_set {
            Some(LinkChange::Open)
        } else if link.id_set {
            None
        } else {
            Some(LinkChange::Close)
        }
    }
}

/// What JavaScript's `trim` removes.
fn js_space(c: u32) -> bool {
    matches!(c, 0x09..=0x0D | 0x20 | 0xA0 | 0x1680 | 0x2000..=0x200A | 0x2028 | 0x2029 | 0x202F | 0x205F | 0x3000 | 0xFEFF)
}
