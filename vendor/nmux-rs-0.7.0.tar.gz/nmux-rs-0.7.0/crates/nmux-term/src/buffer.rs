//! A screen and the history above it: `Buffer.ts`, `BufferSet.ts` and the scrolling of `BufferService.ts`.
//!
//! xterm keeps every line in one circular list, `ybase` lines of history and then the screen. Here the history is packed
//! (see `history.rs`) and the screen is a deque of rows, so `ybase` is the length of the history. What xterm does with
//! the list as a whole, a resize, is done on both together in `reflow.rs`.

use std::collections::VecDeque;

use crate::attr::Attrs;
use crate::charset::Charset;
use crate::history::History;
use crate::line::{Cell, Row, signed, unsigned};

/// Tab stops: xterm's `tabs` object, which can hold a stop past the last column.
#[derive(Clone, Debug, Default)]
pub(crate) struct Tabs(Vec<bool>);

impl Tabs {
    #[inline]
    pub fn get(&self, x: isize) -> bool {
        usize::try_from(x).ok().and_then(|x| self.0.get(x)).copied().unwrap_or(false)
    }

    pub fn set(&mut self, x: usize) {
        if x >= self.0.len() {
            self.0.resize(x + 1, false);
        }
        self.0[x] = true;
    }

    pub fn unset(&mut self, x: usize) {
        if let Some(t) = self.0.get_mut(x) {
            *t = false;
        }
    }

    pub fn clear(&mut self) {
        self.0.clear();
    }
}

/// One buffer: the normal one, with history, or the alternate one.
#[derive(Debug)]
pub(crate) struct Buffer {
    pub history: History,
    pub screen: VecDeque<Row>,
    /// The circular list's `maxLength`.
    pub max_length: usize,
    pub has_scrollback: bool,
    pub x: usize,
    pub y: usize,
    pub scroll_top: usize,
    pub scroll_bottom: usize,
    pub tabs: Tabs,
    pub saved_x: usize,
    /// Absolute: `ybase + y` when it was saved.
    pub saved_y: usize,
    pub saved_fg: u32,
    pub saved_bg: u32,
    pub saved_charset: Charset,
    /// The size the buffer was last given.
    pub cols: usize,
    pub rows: usize,
    /// Lines that have left the front of the list, ever.
    pub trimmed: u64,
    /// Rows the alternate screen gave back when it was cleared, for the next time it is shown.
    pub spare: Vec<Row>,
    /// The circular list's `_startIndex`, modulo its length: where its first line is in its array. It only shows when
    /// a reflow writes to a negative index (see `reflow_smaller`).
    pub start: usize,
}

impl Buffer {
    pub fn new(cols: usize, rows: usize, scrollback: usize, has_scrollback: bool) -> Buffer {
        let mut b = Buffer {
            history: History::default(),
            screen: VecDeque::new(),
            max_length: 0,
            has_scrollback,
            x: 0,
            y: 0,
            scroll_top: 0,
            scroll_bottom: rows - 1,
            tabs: Tabs::default(),
            saved_x: 0,
            saved_y: 0,
            saved_fg: 0,
            saved_bg: 0,
            saved_charset: None,
            cols,
            rows,
            trimmed: 0,
            spare: Vec::new(),
            start: 0,
        };
        b.max_length = b.correct_length(rows, scrollback);
        b.setup_tabs(None);
        b
    }

    /// `_getCorrectBufferLength`.
    pub fn correct_length(&self, rows: usize, scrollback: usize) -> usize {
        if self.has_scrollback { rows.saturating_add(scrollback).min(u32::MAX as usize) } else { rows }
    }

    /// `ybase`: how many lines are above the screen.
    #[inline]
    pub fn ybase(&self) -> usize {
        self.history.len()
    }

    /// `lines.length`.
    #[inline]
    pub fn len(&self) -> usize {
        self.history.len() + self.screen.len()
    }

    /// `fillViewportRows`: a cleared buffer gets its blank screen.
    pub fn fill_viewport(&mut self, fill: Cell, next_id: &mut u64) {
        if self.len() == 0 {
            for _ in 0..self.rows {
                let id = take_id(next_id);
                let row = match self.spare.pop() {
                    Some(mut row) => {
                        row.reset(self.cols, fill, false, id);
                        row
                    }
                    None => Row::new(self.cols, fill, false, id),
                };
                self.screen.push_back(row);
            }
        }
    }

    /// `clear`: an empty list, the cursor home, no margins and default tab stops. The saved cursor stays.
    pub fn clear(&mut self, scrollback: usize) {
        self.x = 0;
        self.y = 0;
        self.history.clear();
        let keep = self.rows.saturating_sub(self.spare.len());
        self.spare.extend(self.screen.drain(..).take(keep));
        self.screen.clear();
        self.max_length = self.correct_length(self.rows, scrollback);
        self.start = 0;
        self.scroll_top = 0;
        self.scroll_bottom = self.rows - 1;
        self.setup_tabs(None);
    }

    /// `setupTabStops`.
    pub fn setup_tabs(&mut self, from: Option<usize>) {
        let mut i = match from {
            Some(i) if self.tabs.get(signed(i)) => i,
            Some(i) => self.prev_stop(signed(i)),
            None => {
                self.tabs.clear();
                0
            }
        };
        while i < self.cols {
            self.tabs.set(i);
            i += 8;
        }
    }

    /// `prevStop`.
    pub fn prev_stop(&self, x: isize) -> usize {
        let mut x = x;
        loop {
            x -= 1;
            if self.tabs.get(x) || x <= 0 {
                break;
            }
        }
        if x >= signed(self.cols) { self.cols - 1 } else { unsigned(x) }
    }

    /// `nextStop`.
    pub fn next_stop(&self, x: isize) -> usize {
        let mut x = x;
        let cols = signed(self.cols);
        loop {
            x += 1;
            if self.tabs.get(x) || x >= cols {
                break;
            }
        }
        if x >= cols { self.cols - 1 } else { unsigned(x) }
    }

    /// The row the cursor is on.
    #[inline]
    pub fn cursor_row(&mut self) -> &mut Row {
        let y = self.y.min(self.screen.len().saturating_sub(1));
        &mut self.screen[y]
    }

    /// `BufferService.scroll`: a blank line under the scroll region, and the line at its top leaves it, into the history
    /// when the region starts at the top of the screen.
    pub fn scroll(&mut self, fill: Cell, wrapped: bool, attrs: &Attrs, next_id: &mut u64) {
        let cols = self.cols;
        let top = self.scroll_top;
        let bottom = self.scroll_bottom.min(self.screen.len().saturating_sub(1));
        if self.screen.is_empty() {
            return;
        }
        if top == 0 {
            let at_max = self.len() >= self.max_length;
            let Some(mut row) = self.screen.pop_front() else { return };
            if at_max {
                self.trimmed += 1;
                self.start = (self.start + 1) % self.max_length.max(1);
                if !self.history.is_empty() {
                    self.history.pop_front();
                    self.history.push(&row, attrs);
                }
            } else {
                self.history.push(&row, attrs);
            }
            row.reset(cols, fill, wrapped, take_id(next_id));
            self.screen.insert(bottom.min(self.screen.len()), row);
        } else {
            let Some(mut row) = self.screen.remove(top) else { return };
            row.reset(cols, fill, wrapped, take_id(next_id));
            self.screen.insert(bottom.min(self.screen.len()), row);
        }
    }

    /// `lines.get(i)` of xterm for the two places where it reads past the end of the list: index `i` of the list as a
    /// circle when it is full, and nothing when it is not.
    pub fn line_at_circular(&self, i: usize) -> Option<LineRef> {
        let len = self.len();
        // the list's array is a circle as long as its longest, and index i of it is index i modulo that
        let i = if i < len {
            i
        } else if self.max_length > 0 && i % self.max_length < len {
            i % self.max_length
        } else {
            return None;
        };
        if i < self.history.len() { Some(LineRef::History(i)) } else { Some(LineRef::Screen(i - self.history.len())) }
    }

    /// Sets `isWrapped` of line `i` of the list.
    pub fn set_wrapped_at(&mut self, at: LineRef, wrapped: bool) {
        match at {
            LineRef::History(i) => self.history.set_wrapped(i, wrapped),
            LineRef::Screen(i) => self.screen[i].wrapped = wrapped,
        }
    }
}

/// Where line `i` of the list is.
#[derive(Clone, Copy, Debug)]
pub(crate) enum LineRef {
    History(usize),
    Screen(usize),
}

/// A number for a new line.
#[inline]
pub(crate) fn take_id(next_id: &mut u64) -> u64 {
    let id = *next_id;
    *next_id += 1;
    id
}
