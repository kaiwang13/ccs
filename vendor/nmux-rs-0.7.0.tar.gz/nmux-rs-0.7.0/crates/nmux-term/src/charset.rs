//! The character sets of `Charsets.ts`: DEC line drawing and the national replacement sets, each a short table of
//! printable ASCII characters drawn as something else.

/// A character set; `None` is US ASCII, which replaces nothing.
pub(crate) type Charset = Option<&'static [(u8, char)]>;

const DEC_GRAPHICS: &[(u8, char)] = &[
    (b'`', '\u{25c6}'),
    (b'a', '\u{2592}'),
    (b'b', '\u{2409}'),
    (b'c', '\u{240c}'),
    (b'd', '\u{240d}'),
    (b'e', '\u{240a}'),
    (b'f', '\u{00b0}'),
    (b'g', '\u{00b1}'),
    (b'h', '\u{2424}'),
    (b'i', '\u{240b}'),
    (b'j', '\u{2518}'),
    (b'k', '\u{2510}'),
    (b'l', '\u{250c}'),
    (b'm', '\u{2514}'),
    (b'n', '\u{253c}'),
    (b'o', '\u{23ba}'),
    (b'p', '\u{23bb}'),
    (b'q', '\u{2500}'),
    (b'r', '\u{23bc}'),
    (b's', '\u{23bd}'),
    (b't', '\u{251c}'),
    (b'u', '\u{2524}'),
    (b'v', '\u{2534}'),
    (b'w', '\u{252c}'),
    (b'x', '\u{2502}'),
    (b'y', '\u{2264}'),
    (b'z', '\u{2265}'),
    (b'{', '\u{03c0}'),
    (b'|', '\u{2260}'),
    (b'}', '\u{00a3}'),
    (b'~', '\u{00b7}'),
];
const UK: &[(u8, char)] = &[(b'#', '£')];
/// Dutch. Its `[` is "ij", of which xterm prints the first letter.
const DUTCH: &[(u8, char)] = &[
    (b'#', '£'),
    (b'@', '¾'),
    (b'[', 'i'),
    (b'\\', '½'),
    (b']', '|'),
    (b'{', '¨'),
    (b'|', 'f'),
    (b'}', '¼'),
    (b'~', '´'),
];
const FINNISH: &[(u8, char)] = &[
    (b'[', 'Ä'),
    (b'\\', 'Ö'),
    (b']', 'Å'),
    (b'^', 'Ü'),
    (b'`', 'é'),
    (b'{', 'ä'),
    (b'|', 'ö'),
    (b'}', 'å'),
    (b'~', 'ü'),
];
const FRENCH: &[(u8, char)] = &[
    (b'#', '£'),
    (b'@', 'à'),
    (b'[', '°'),
    (b'\\', 'ç'),
    (b']', '§'),
    (b'{', 'é'),
    (b'|', 'ù'),
    (b'}', 'è'),
    (b'~', '¨'),
];
const FRENCH_CANADIAN: &[(u8, char)] = &[
    (b'@', 'à'),
    (b'[', 'â'),
    (b'\\', 'ç'),
    (b']', 'ê'),
    (b'^', 'î'),
    (b'`', 'ô'),
    (b'{', 'é'),
    (b'|', 'ù'),
    (b'}', 'è'),
    (b'~', 'û'),
];
const GERMAN: &[(u8, char)] =
    &[(b'@', '§'), (b'[', 'Ä'), (b'\\', 'Ö'), (b']', 'Ü'), (b'{', 'ä'), (b'|', 'ö'), (b'}', 'ü'), (b'~', 'ß')];
const ITALIAN: &[(u8, char)] = &[
    (b'#', '£'),
    (b'@', '§'),
    (b'[', '°'),
    (b'\\', 'ç'),
    (b']', 'é'),
    (b'`', 'ù'),
    (b'{', 'à'),
    (b'|', 'ò'),
    (b'}', 'è'),
    (b'~', 'ì'),
];
const NORWEGIAN: &[(u8, char)] = &[
    (b'@', 'Ä'),
    (b'[', 'Æ'),
    (b'\\', 'Ø'),
    (b']', 'Å'),
    (b'^', 'Ü'),
    (b'`', 'ä'),
    (b'{', 'æ'),
    (b'|', 'ø'),
    (b'}', 'å'),
    (b'~', 'ü'),
];
const SPANISH: &[(u8, char)] =
    &[(b'#', '£'), (b'@', '§'), (b'[', '¡'), (b'\\', 'Ñ'), (b']', '¿'), (b'{', '°'), (b'|', 'ñ'), (b'}', 'ç')];
const SWEDISH: &[(u8, char)] = &[
    (b'@', 'É'),
    (b'[', 'Ä'),
    (b'\\', 'Ö'),
    (b']', 'Å'),
    (b'^', 'Ü'),
    (b'`', 'é'),
    (b'{', 'ä'),
    (b'|', 'ö'),
    (b'}', 'å'),
    (b'~', 'ü'),
];
const SWISS: &[(u8, char)] = &[
    (b'#', 'ù'),
    (b'@', 'à'),
    (b'[', 'é'),
    (b'\\', 'ç'),
    (b']', 'ê'),
    (b'^', 'î'),
    (b'_', 'è'),
    (b'`', 'ô'),
    (b'{', 'ä'),
    (b'|', 'ö'),
    (b'}', 'ü'),
    (b'~', 'û'),
];

/// The set a final byte designates, if xterm knows it: the outer `None` means it does not, and the sequence does nothing.
pub(crate) fn designated(final_byte: u8) -> Option<Charset> {
    Some(match final_byte {
        b'0' => Some(DEC_GRAPHICS),
        b'A' => Some(UK),
        b'B' => None,
        b'4' => Some(DUTCH),
        b'C' | b'5' => Some(FINNISH),
        b'R' => Some(FRENCH),
        b'Q' => Some(FRENCH_CANADIAN),
        b'K' => Some(GERMAN),
        b'Y' => Some(ITALIAN),
        b'E' | b'6' => Some(NORWEGIAN),
        b'Z' => Some(SPANISH),
        b'H' | b'7' => Some(SWEDISH),
        b'=' => Some(SWISS),
        _ => return None,
    })
}

/// What `code` is drawn as in `set`.
#[inline]
pub(crate) fn map(set: &'static [(u8, char)], code: u32) -> Option<u32> {
    set.iter().find(|e| u32::from(e.0) == code).map(|e| u32::from(e.1))
}
