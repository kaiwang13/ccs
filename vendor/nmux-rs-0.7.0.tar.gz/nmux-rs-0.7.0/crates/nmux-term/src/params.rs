//! The parameters of a control sequence as xterm.js holds them (`Params.ts`): at most 32, each with sub-parameters after
//! colons, at most 32 of those in all. An empty parameter is 0 and an empty sub-parameter is -1; a number saturates at
//! 2^31 - 1, which is where an i32 saturates. A sequence with more than that keeps what fitted.

const MAX_LENGTH: usize = 32;
const MAX_SUB_LENGTH: usize = 32;

/// The parameters of one sequence, built a byte at a time.
#[derive(Clone, Debug)]
pub struct Params {
    values: [i32; MAX_LENGTH],
    len: usize,
    sub: [i32; MAX_SUB_LENGTH],
    sub_len: usize,
    /// For each parameter, where its sub-parameters start and end in `sub`.
    sub_range: [(u8, u8); MAX_LENGTH],
    reject_digits: bool,
    reject_sub_digits: bool,
    digit_is_sub: bool,
}

impl Default for Params {
    fn default() -> Self {
        let mut p = Params {
            values: [0; MAX_LENGTH],
            len: 0,
            sub: [0; MAX_SUB_LENGTH],
            sub_len: 0,
            sub_range: [(0, 0); MAX_LENGTH],
            reject_digits: false,
            reject_sub_digits: false,
            digit_is_sub: false,
        };
        p.add_param(0);
        p
    }
}

impl Params {
    /// Back to one parameter, 0, as a sequence starts (`CLEAR` in the parser).
    pub fn clear(&mut self) {
        self.len = 0;
        self.sub_len = 0;
        self.reject_digits = false;
        self.reject_sub_digits = false;
        self.digit_is_sub = false;
        self.add_param(0);
    }

    /// The parameters of `bytes`, the digits, colons and semicolons of a sequence the lexer split.
    pub fn parse(&mut self, bytes: &[u8]) {
        self.clear();
        for &b in bytes {
            self.put(b);
        }
    }

    /// One byte of the parameters: a digit, `;` or `:`.
    #[inline]
    pub fn put(&mut self, b: u8) {
        match b {
            b';' => self.add_param(0),
            b':' => self.add_sub_param(-1),
            _ => self.add_digit(i32::from(b.wrapping_sub(b'0'))),
        }
    }

    fn add_param(&mut self, value: i32) {
        self.digit_is_sub = false;
        if self.len >= MAX_LENGTH {
            self.reject_digits = true;
            return;
        }
        let at = u8::try_from(self.sub_len).unwrap_or(u8::MAX);
        self.sub_range[self.len] = (at, at);
        self.values[self.len] = value;
        self.len += 1;
    }

    fn add_sub_param(&mut self, value: i32) {
        self.digit_is_sub = true;
        if self.len == 0 {
            return;
        }
        if self.reject_digits || self.sub_len >= MAX_SUB_LENGTH {
            self.reject_sub_digits = true;
            return;
        }
        self.sub[self.sub_len] = value;
        self.sub_len += 1;
        self.sub_range[self.len - 1].1 += 1;
    }

    fn add_digit(&mut self, value: i32) {
        let length = if self.digit_is_sub { self.sub_len } else { self.len };
        if self.reject_digits || length == 0 || (self.digit_is_sub && self.reject_sub_digits) {
            return;
        }
        let store = if self.digit_is_sub { &mut self.sub } else { &mut self.values };
        let cur = store[length - 1];
        store[length - 1] = if cur == -1 { value } else { cur.saturating_mul(10).saturating_add(value) };
    }

    /// How many parameters there are; never 0 in a sequence that came through the parser.
    #[inline]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Parameter `i`, as `params.params[i]` in xterm: 0 past the end.
    #[inline]
    pub fn get(&self, i: usize) -> i32 {
        if i < MAX_LENGTH { self.values[i] } else { 0 }
    }

    /// The sub-parameters of parameter `i`.
    pub fn sub_params(&self, i: usize) -> &[i32] {
        if i >= self.len {
            return &[];
        }
        let (from, to) = self.sub_range[i];
        &self.sub[usize::from(from)..usize::from(to)]
    }

    /// Whether parameter `i` has sub-parameters.
    pub fn has_sub_params(&self, i: usize) -> bool {
        !self.sub_params(i).is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parse(s: &str) -> Params {
        let mut p = Params::default();
        p.parse(s.as_bytes());
        p
    }

    #[test]
    fn defaults_and_sub_parameters() {
        let p = parse("");
        assert_eq!((p.len(), p.get(0)), (1, 0));
        let p = parse("38:2::1:2:3;1");
        assert_eq!((p.len(), p.get(0), p.get(1)), (2, 38, 1));
        assert_eq!(p.sub_params(0), &[2, -1, 1, 2, 3]);
        let p = parse("99999999999");
        assert_eq!(p.get(0), 0x7FFF_FFFF);
        let p = parse(&";".repeat(40));
        assert_eq!(p.len(), 32);
    }
}
