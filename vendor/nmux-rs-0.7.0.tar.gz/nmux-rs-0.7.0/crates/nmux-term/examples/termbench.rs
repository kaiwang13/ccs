//! Emulator speed and memory on files of terminal output: `cargo run --release -p nmux-term --example termbench -- FILE...`
//!
//! Each file goes through `nmux-vt`'s lexer and the emulator, 64 KiB at a time as from a pty, at 120x40 with 10,000 lines
//! of history, which is what ROUTE.md measured xterm.js and a prototype at. The rate counts lexing too, in MiB per second
//! as those measurements did; the best of three runs is reported. "Held" is what the terminal keeps for its lines when it
//! is done: the full history, packed, and the screens.

use std::hint::black_box;
use std::time::Instant;

use nmux_term::Terminal;
use nmux_vt::Lexer;

const PIECE: usize = 65536;
const RUNS: usize = 3;

fn run(data: &[u8]) -> (f64, Terminal) {
    let started = Instant::now();
    let mut term = Terminal::new(120, 40, 10_000);
    let mut lexer = Lexer::new(0);
    for chunk in data.chunks(PIECE) {
        lexer.feed(black_box(chunk), |t| term.advance(&t));
        term.end_write();
    }
    (started.elapsed().as_secs_f64(), term)
}

/// The peak resident memory of this process, where the system says it.
fn peak_rss_kib() -> Option<u64> {
    let status = std::fs::read_to_string("/proc/self/status").ok()?;
    status.lines().find(|l| l.starts_with("VmHWM"))?.split_whitespace().nth(1)?.parse().ok()
}

#[allow(clippy::cast_precision_loss)] // rates need no more precision than a double has
fn main() -> std::io::Result<()> {
    for path in std::env::args().skip(1) {
        let data = std::fs::read(&path)?;
        let mut best = f64::MAX;
        let mut kept = None;
        for _ in 0..RUNS {
            let (seconds, term) = run(&data);
            best = best.min(seconds);
            kept = Some(term);
        }
        let Some(term) = kept else { continue };
        let mib = data.len() as f64 / 1_048_576.0;
        let peak = peak_rss_kib()
            .map_or(String::new(), |kib| format!(", peak RSS {:.1} MiB with the input", kib as f64 / 1024.0));
        println!(
            "{path}: {:.0} MiB/s, held {:.2} MiB for {} lines{peak}",
            mib / best,
            term.memory() as f64 / 1_048_576.0,
            term.normal().len()
        );
    }
    Ok(())
}
