//! Who this process is, and who is on the other end of a unix socket.

use std::io;
use std::os::fd::BorrowedFd;

/// This process's real user id.
pub fn uid() -> u32 {
    rustix::process::getuid().as_raw()
}

/// This process's pid.
pub fn pid() -> i32 {
    rustix::process::getpid().as_raw_nonzero().get()
}

/// The user id of the process at the other end of a connected unix socket.
pub fn peer_uid(fd: BorrowedFd<'_>) -> io::Result<u32> {
    crate::os::peer_uid(fd)
}
