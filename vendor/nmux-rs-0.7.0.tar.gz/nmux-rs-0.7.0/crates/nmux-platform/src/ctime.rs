//! Times as text, in UTC: `ctime.js`, and the `Date.prototype.toISOString` that the holder's records and logs use.

const DAYS: [&str; 7] = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS: [&str; 12] = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const MS_PER_DAY: i64 = 86_400_000;

/// A moment split the way a calendar reads it.
struct Civil {
    year: i64,
    /// 1 to 12.
    month: usize,
    day: i64,
    weekday: usize,
    hours: i64,
    minutes: i64,
    seconds: i64,
    millis: i64,
}

impl Civil {
    /// Milliseconds since 1970 in UTC. Howard Hinnant's `civil_from_days`, which is exact over the whole range of a
    /// JavaScript date.
    fn of(ms: i64) -> Self {
        let days = ms.div_euclid(MS_PER_DAY);
        let in_day = ms.rem_euclid(MS_PER_DAY);
        let z = days + 719_468;
        let era = z.div_euclid(146_097);
        let doe = z.rem_euclid(146_097);
        let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
        let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
        let mp = (5 * doy + 2) / 153;
        let day = doy - (153 * mp + 2) / 5 + 1;
        let month = if mp < 10 { mp + 3 } else { mp - 9 };
        let year = yoe + era * 400 + i64::from(month <= 2);
        Self {
            year,
            month: usize::try_from(month).unwrap_or(1),
            day,
            // 1970-01-01 was a Thursday.
            weekday: usize::try_from((days + 4).rem_euclid(7)).unwrap_or(0),
            hours: in_day / 3_600_000,
            minutes: in_day / 60_000 % 60,
            seconds: in_day / 1000 % 60,
            millis: in_day % 1000,
        }
    }
}

/// ctime rendering in UTC, such as `Mon Sep 21 01:13:03 2026`.
///
/// This is a format, not an arbitrary choice: a program that records a process's start time for itself can only be
/// matched against this value as a string, and on macOS the ctime form in UTC is the one such programs write. The day is
/// padded with a space, as ctime pads it, not a zero. The cost is resolution: two processes started in the same second
/// on the same pid cannot be told apart.
pub fn ctime_utc(ms: i64) -> String {
    let c = Civil::of(ms);
    format!(
        "{} {} {:>2} {:02}:{:02}:{:02} {}",
        DAYS[c.weekday],
        MONTHS[c.month - 1],
        c.day,
        c.hours,
        c.minutes,
        c.seconds,
        c.year
    )
}

/// What `new Date(ms).toISOString()` says, such as `2026-11-01T22:00:00.000Z`.
pub fn iso_utc(ms: i64) -> String {
    let c = Civil::of(ms);
    let year = if (0..=9999).contains(&c.year) {
        format!("{:04}", c.year)
    } else {
        format!("{}{:06}", if c.year < 0 { '-' } else { '+' }, c.year.abs())
    };
    format!("{year}-{:02}-{:02}T{:02}:{:02}:{:02}.{:03}Z", c.month, c.day, c.hours, c.minutes, c.seconds, c.millis)
}
