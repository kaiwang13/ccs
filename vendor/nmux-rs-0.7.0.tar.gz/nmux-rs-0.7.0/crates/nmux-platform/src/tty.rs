//! What `ttyctl.c` answered about a terminal: its local modes, its foreground process group and how much input waits on
//! it, and a slave opened without making it anyone's controlling terminal.

use std::io;
use std::os::fd::{BorrowedFd, OwnedFd};

use rustix::fs::{Mode, OFlags};
use rustix::termios::LocalModes;

/// A terminal's local modes, the three the holder reports.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)] // one for each mode, as termios has them
pub struct Lflags {
    /// Canonical mode: the line discipline edits lines.
    pub icanon: bool,
    /// Control characters raise signals.
    pub isig: bool,
    /// Input is echoed.
    pub echo: bool,
}

/// The local modes of the terminal `fd` is on. On a pty master Linux answers with the slave's modes.
pub fn lflag(fd: BorrowedFd<'_>) -> io::Result<Lflags> {
    let modes = rustix::termios::tcgetattr(fd)?.local_modes;
    Ok(Lflags {
        icanon: modes.contains(LocalModes::ICANON),
        isig: modes.contains(LocalModes::ISIG),
        echo: modes.contains(LocalModes::ECHO),
    })
}

/// The terminal's foreground process group, and 0 when it has none, as `tcgetpgrp(3)` says it.
pub fn tcgetpgrp(fd: BorrowedFd<'_>) -> io::Result<i32> {
    match rustix::termios::tcgetpgrp(fd) {
        Ok(pid) => Ok(pid.as_raw_nonzero().get()),
        // rustix cannot hold a pid of 0, and says this instead.
        Err(rustix::io::Errno::OPNOTSUPP) => Ok(0),
        Err(e) => Err(e.into()),
    }
}

/// Bytes waiting to be read on `fd`. On a pty that means the slave: on Linux the master reads 0, and on macOS it counts
/// the same bytes. The holder only asks the slave.
pub fn inq(fd: BorrowedFd<'_>) -> io::Result<usize> {
    let n = rustix::io::ioctl_fionread(fd)?;
    usize::try_from(n).map_err(|_| io::Error::from(io::ErrorKind::InvalidData))
}

/// Opens a pty slave by its path without making it this process's controlling terminal. Only a path that looks like a
/// pty slave is opened, `/dev/pts/<n>` or `/dev/ttys<n>`: the point is to refuse anything else, not to spell one OS's layout.
pub fn open_slave(path: &str) -> io::Result<OwnedFd> {
    let named = |prefix: &str| path.strip_prefix(prefix).is_some_and(|rest| !rest.is_empty());
    if path.len() >= 255 || !(named("/dev/pts/") || named("/dev/ttys")) || path.contains('\0') {
        return Err(io::Error::new(io::ErrorKind::InvalidInput, "ptsPath must look like /dev/pts/<n> or /dev/ttys<n>"));
    }
    loop {
        match rustix::fs::open(path, OFlags::RDWR | OFlags::NOCTTY | OFlags::CLOEXEC, Mode::empty()) {
            Err(rustix::io::Errno::INTR) => {}
            result => return result.map_err(io::Error::from),
        }
    }
}
