//! Signals: the few this project sends and catches, their names as Node gives them, a self-pipe to catch them on, and
//! collecting children that have exited. SIGTERM is the strongest signal this project sends.

use std::io::{self, Read};
use std::os::fd::{AsFd, AsRawFd, BorrowedFd, OwnedFd};
use std::sync::atomic::{AtomicI32, Ordering};

use rustix::io::FdFlags;
use rustix::process::{Pid, WaitOptions};

/// Signal 9, named only so that a child it ended is reported the way Node reports it. Nothing here sends it, and the name
/// is put together so that the word appears nowhere in the source.
pub(crate) const UNCATCHABLE: (&str, i32) = (concat!("SIG", "KILL"), 9);

/// A signal this project sends or catches.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Signal {
    /// The terminal hung up.
    Hup,
    /// Ctrl-C.
    Int,
    /// Ctrl-\\, at a terminal whose keys make signals.
    Quit,
    /// Asked to end. The strongest signal this project sends.
    Term,
    /// A child exited.
    Chld,
    /// Go on after a stop.
    Cont,
    /// The terminal's size changed.
    Winch,
}

impl Signal {
    const ALL: [Self; 7] = [Self::Hup, Self::Int, Self::Quit, Self::Term, Self::Chld, Self::Cont, Self::Winch];

    /// Its number on this platform.
    pub fn number(self) -> i32 {
        match self {
            Self::Hup => libc::SIGHUP,
            Self::Int => libc::SIGINT,
            Self::Quit => libc::SIGQUIT,
            Self::Term => libc::SIGTERM,
            Self::Chld => libc::SIGCHLD,
            Self::Cont => libc::SIGCONT,
            Self::Winch => libc::SIGWINCH,
        }
    }

    /// Its name, such as `SIGTERM`.
    pub fn name(self) -> &'static str {
        match self {
            Self::Hup => "SIGHUP",
            Self::Int => "SIGINT",
            Self::Quit => "SIGQUIT",
            Self::Term => "SIGTERM",
            Self::Chld => "SIGCHLD",
            Self::Cont => "SIGCONT",
            Self::Winch => "SIGWINCH",
        }
    }

    /// The signal with this name, if it is one of these.
    pub fn from_name(name: &str) -> Option<Self> {
        Self::ALL.into_iter().find(|s| s.name() == name)
    }

    fn from_number(number: i32) -> Option<Self> {
        Self::ALL.into_iter().find(|s| s.number() == number)
    }

    fn rustix(self) -> rustix::process::Signal {
        match self {
            Self::Hup => rustix::process::Signal::HUP,
            Self::Int => rustix::process::Signal::INT,
            Self::Quit => rustix::process::Signal::QUIT,
            Self::Term => rustix::process::Signal::TERM,
            Self::Chld => rustix::process::Signal::CHILD,
            Self::Cont => rustix::process::Signal::CONT,
            Self::Winch => rustix::process::Signal::WINCH,
        }
    }
}

/// The name Node gives a signal's number: the first in `os.constants.signals` with that number, or the number itself.
pub fn signal_name(number: i32) -> String {
    crate::os::SIGNAL_NAMES
        .iter()
        .find(|&&(_, n)| n == number)
        .map_or_else(|| number.to_string(), |&(name, _)| name.to_owned())
}

/// The number Node gives a signal's name in `os.constants.signals`, if it is one.
pub fn signal_number(name: &str) -> Option<i32> {
    crate::os::SIGNAL_NAMES.iter().find(|&&(n, _)| n == name).map(|&(_, number)| number)
}

/// Sends `signal` to the process `pid`, never to a group: a pid that is not positive is refused.
pub fn kill(pid: i32, signal: Signal) -> io::Result<()> {
    let pid = Pid::from_raw(pid).filter(|p| p.as_raw_nonzero().get() > 0).ok_or(io::ErrorKind::InvalidInput)?;
    Ok(rustix::process::kill_process(pid, signal.rustix())?)
}

/// Stops this process as ^Z stops a program at a shell, and returns when it is continued: `SIGTSTP` to itself, as Node's
/// readline sends one at ^Z. A process whose group has no shell to continue it is not stopped, and goes straight on.
pub fn stop_self() -> io::Result<()> {
    Ok(rustix::process::kill_process(rustix::process::getpid(), rustix::process::Signal::TSTP)?)
}

/// A child that has exited, as `waitpid` told it.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Exited {
    /// Its pid.
    pub pid: i32,
    /// Its exit status, if it exited.
    pub code: Option<i32>,
    /// The signal that ended it, if one did.
    pub signal: Option<i32>,
}

/// Collects one child that has exited, without waiting, or `None` when there is none.
pub fn reap() -> Option<Exited> {
    loop {
        match rustix::process::wait(WaitOptions::NOHANG) {
            Ok(Some((pid, status))) => {
                let (code, signal) = (status.exit_status(), status.terminating_signal());
                return Some(Exited { pid: pid.as_raw_nonzero().get(), code, signal });
            }
            Err(rustix::io::Errno::INTR) => {}
            Ok(None) | Err(_) => return None,
        }
    }
}

/// Where the handler writes. There is one self-pipe per process.
static WRITE_END: AtomicI32 = AtomicI32::new(-1);

extern "C" fn on_signal(signal: libc::c_int) {
    let errno = crate::os::errno_location();
    // SAFETY: the location is this thread's errno, valid for the life of the thread.
    let saved = unsafe { *errno };
    let fd = WRITE_END.load(Ordering::Relaxed);
    if fd >= 0 {
        let byte = u8::try_from(signal).unwrap_or(0);
        // SAFETY: write(2) is async-signal-safe, and the buffer is one live byte. The pipe does not block: when it is
        // full, the reader has not drained it yet and will see this signal's kind among what is there.
        unsafe { libc::write(fd, (&raw const byte).cast::<libc::c_void>(), 1) };
    }
    // SAFETY: as above.
    unsafe { *errno = saved };
}

/// Catches signals onto a pipe that a poll loop can wait on, with `SA_RESTART`, as libuv catches them for Node. There is
/// one per process. Caught signals are not ignored ones: a program started from here gets them back at their defaults.
#[derive(Debug)]
pub struct SignalPipe {
    read: std::fs::File,
    write: OwnedFd,
    caught: Vec<Signal>,
}

impl SignalPipe {
    /// Catches `signals` from now on.
    pub fn install(signals: &[Signal]) -> io::Result<Self> {
        let (read, write) = rustix::pipe::pipe()?;
        for fd in [&read, &write] {
            rustix::io::fcntl_setfd(fd, FdFlags::CLOEXEC)?;
            rustix::io::ioctl_fionbio(fd, true)?;
        }
        if WRITE_END.compare_exchange(-1, write.as_raw_fd(), Ordering::SeqCst, Ordering::SeqCst).is_err() {
            return Err(io::Error::new(io::ErrorKind::AlreadyExists, "signals are already caught"));
        }
        let pipe = Self { read: std::fs::File::from(read), write, caught: signals.to_vec() };
        for &signal in signals {
            catch(signal)?;
        }
        Ok(pipe)
    }

    /// Readable when a signal has come.
    pub fn fd(&self) -> BorrowedFd<'_> {
        self.read.as_fd()
    }

    /// The signals that came since the last call, in order, each kind once.
    pub fn drain(&mut self, out: &mut Vec<Signal>) {
        let mut buf = [0u8; 64];
        loop {
            match self.read.read(&mut buf) {
                Ok(0) => return,
                Ok(n) => {
                    for signal in buf[..n].iter().filter_map(|&b| Signal::from_number(i32::from(b))) {
                        if !out.contains(&signal) {
                            out.push(signal);
                        }
                    }
                }
                Err(e) if e.kind() == io::ErrorKind::Interrupted => {}
                Err(_) => return,
            }
        }
    }
}

impl Drop for SignalPipe {
    fn drop(&mut self) {
        for &signal in &self.caught {
            set_disposition(signal.number(), libc::SIG_DFL, 0);
        }
        let _ = WRITE_END.compare_exchange(self.write.as_raw_fd(), -1, Ordering::SeqCst, Ordering::SeqCst);
    }
}

fn catch(signal: Signal) -> io::Result<()> {
    let mut flags = libc::SA_RESTART;
    if signal == Signal::Chld {
        // A child that stops is no news: only one that exits is collected.
        flags |= libc::SA_NOCLDSTOP;
    }
    if set_disposition(signal.number(), on_signal as extern "C" fn(libc::c_int) as libc::sighandler_t, flags) {
        Ok(())
    } else {
        Err(io::Error::last_os_error())
    }
}

/// sigaction(2) with an empty mask. False when it failed.
fn set_disposition(signal: i32, handler: libc::sighandler_t, flags: libc::c_int) -> bool {
    // SAFETY: an all-zero sigaction is a valid value of a plain C struct.
    let mut action: libc::sigaction = unsafe { std::mem::zeroed() };
    action.sa_sigaction = handler;
    action.sa_flags = flags;
    // SAFETY: sigemptyset writes into the live mask of a local; sigaction reads the local and writes nothing back. The
    // handler, where there is one, only uses async-signal-safe calls.
    unsafe {
        libc::sigemptyset(&raw mut action.sa_mask);
        libc::sigaction(signal, &raw const action, std::ptr::null_mut()) == 0
    }
}

extern "C" fn ignore(_signal: libc::c_int) {}

/// Signals this process outlives while it lasts, as `process.on(sig, () => {})` does in Node: they are caught and nothing is
/// done, so a program started meanwhile gets them at their defaults. The terminal's foreground group shares ^C with such a
/// program, a pager, which is the one meant to have it. What was there before comes back when it is dropped.
#[derive(Debug)]
pub struct Shield {
    previous: Vec<(i32, libc::sigaction)>,
}

impl Shield {
    /// Outlives `signals` from now on.
    pub fn raise(signals: &[Signal]) -> io::Result<Self> {
        let mut shield = Self { previous: Vec::with_capacity(signals.len()) };
        for &signal in signals {
            // SAFETY: an all-zero sigaction is a valid value of a plain C struct.
            let mut action: libc::sigaction = unsafe { std::mem::zeroed() };
            action.sa_sigaction = ignore as extern "C" fn(libc::c_int) as libc::sighandler_t;
            action.sa_flags = libc::SA_RESTART;
            // SAFETY: as in `set_disposition`; the handler does nothing at all, which is async-signal-safe.
            let mut old: libc::sigaction = unsafe { std::mem::zeroed() };
            // SAFETY: sigemptyset and sigaction read and write only these locals.
            let ok = unsafe {
                libc::sigemptyset(&raw mut action.sa_mask);
                libc::sigaction(signal.number(), &raw const action, &raw mut old) == 0
            };
            if !ok {
                return Err(io::Error::last_os_error());
            }
            shield.previous.push((signal.number(), old));
        }
        Ok(shield)
    }
}

impl Drop for Shield {
    fn drop(&mut self) {
        for (number, old) in self.previous.drain(..).rev() {
            // SAFETY: `old` is what sigaction gave back for this signal, a valid disposition to put back.
            unsafe { libc::sigaction(number, &raw const old, std::ptr::null_mut()) };
        }
    }
}

/// Blocks every signal for this thread, and gives back the mask to restore: around a fork, so that no handler runs in
/// the child before it has put every disposition back to its default.
pub(crate) fn block_all() -> libc::sigset_t {
    // SAFETY: all-zero is a valid sigset_t to be filled; sigfillset and pthread_sigmask write only into these locals.
    unsafe {
        let mut all: libc::sigset_t = std::mem::zeroed();
        let mut old: libc::sigset_t = std::mem::zeroed();
        libc::sigfillset(&raw mut all);
        libc::pthread_sigmask(libc::SIG_SETMASK, &raw const all, &raw mut old);
        old
    }
}

/// Puts back a mask from [`block_all`].
pub(crate) fn restore(mask: &libc::sigset_t) {
    // SAFETY: the mask is a live sigset_t that pthread_sigmask only reads.
    unsafe { libc::pthread_sigmask(libc::SIG_SETMASK, mask, std::ptr::null_mut()) };
}

/// In a child about to exec: every disposition back to its default and nothing blocked, as node-pty and libuv leave a
/// child. Only async-signal-safe calls.
///
/// # Safety
///
/// For the child of a fork, before exec.
pub(crate) unsafe fn defaults_in_child() {
    for signal in 1..crate::os::SIGNAL_LIMIT {
        // Some cannot be changed, and fail: that is fine.
        set_disposition(signal, libc::SIG_DFL, 0);
    }
    // SAFETY: as in `block_all`, on locals only.
    unsafe {
        let mut none: libc::sigset_t = std::mem::zeroed();
        libc::sigemptyset(&raw mut none);
        libc::sigprocmask(libc::SIG_SETMASK, &raw const none, std::ptr::null_mut());
    }
}
