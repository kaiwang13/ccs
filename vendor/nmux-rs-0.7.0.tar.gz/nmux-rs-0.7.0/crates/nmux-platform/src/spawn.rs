//! Starting a process that is not on a pty and is not waited for: how a holder starts a server.

use std::io;
use std::os::unix::process::CommandExt;
use std::path::Path;
use std::process::{Command, Stdio};

use crate::signals::defaults_in_child;

/// Starts `argv` in a session of its own, with no terminal and nothing on its standard streams, in `cwd`, with this
/// process's environment: `spawn(cmd, args, { detached: true, stdio: 'ignore' })`. It is not waited for here; whoever
/// collects this process's exited children collects it. Its pid, or why it could not be started.
pub fn spawn_detached(argv: &[String], cwd: &Path) -> io::Result<i32> {
    spawn_detached_with(argv, cwd, &[])
}

/// [`spawn_detached`], with `env` added to this process's environment: how a server starts a holder, or a managed
/// session's controller.
pub fn spawn_detached_with(argv: &[String], cwd: &Path, env: &[(String, String)]) -> io::Result<i32> {
    let (program, rest) = argv.split_first().ok_or(io::ErrorKind::InvalidInput)?;
    let mut command = Command::new(program);
    command.args(rest).current_dir(cwd).stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null());
    command.envs(env.iter().map(|(k, v)| (k.as_str(), v.as_str())));
    // SAFETY: the closure runs in the child between fork and exec, and makes only async-signal-safe calls.
    unsafe {
        command.pre_exec(|| {
            defaults_in_child();
            libc::setsid();
            Ok(())
        });
    }
    let child = command.spawn()?;
    i32::try_from(child.id()).map_err(|_| io::Error::from(io::ErrorKind::InvalidData))
}
