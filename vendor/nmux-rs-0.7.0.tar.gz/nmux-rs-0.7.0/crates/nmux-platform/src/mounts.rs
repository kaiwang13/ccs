//! The Linux mount table, read as text: `linux-mounts.js`. It is a pure function, so it is tested on any OS.

/// Whether `/proc` is mounted with `hidepid` other than `0` or `off`. When `/proc` is mounted more than once the last
/// entry is the one in effect, so the last matching line wins: an earlier mount's `hidepid` must not mask a later mount
/// without it.
pub fn hidepid_enabled(mounts: &str) -> bool {
    let mut enabled = false;
    for line in mounts.split('\n') {
        let fields: Vec<&str> = line.split(' ').collect();
        if fields.len() < 4 || fields[1] != "/proc" || fields[2] != "proc" {
            continue;
        }
        let value = fields[3].split(',').find_map(|option| option.strip_prefix("hidepid=").filter(|v| !v.is_empty()));
        enabled = value.is_some_and(|v| v != "0" && v != "off");
    }
    enabled
}
