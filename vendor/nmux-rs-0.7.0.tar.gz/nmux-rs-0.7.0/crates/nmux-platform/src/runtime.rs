//! The runtime directory holds sockets, locks and logs, as `runtime.js` keeps it. It may be under /tmp, where another account
//! could make the path first or plant a symlink, so every use checks it again with lstat: a real directory, not a symlink,
//! owned by this user, with mode exactly 0700. Anything else is refused.

use std::fmt;
use std::fs::{self, DirBuilder};
use std::io;
use std::os::unix::fs::{DirBuilderExt, MetadataExt, PermissionsExt};
use std::path::Path;

/// The directories under the runtime directory.
pub const SUBDIRS: [&str; 4] = ["s", "run", "log", "locks"];

/// Why a runtime directory cannot be used.
#[derive(Debug)]
pub enum RuntimeError {
    /// It is not safe to use: `RUNTIME_DIR_UNSAFE` in the Node code, with its words.
    Unsafe(String),
    /// It could not be made or looked at.
    Io(io::Error),
}

impl RuntimeError {
    /// `RUNTIME_DIR_UNSAFE` for a directory that is refused, as the Node code's `err.code`.
    pub fn code(&self) -> Option<&'static str> {
        match self {
            Self::Unsafe(_) => Some("RUNTIME_DIR_UNSAFE"),
            Self::Io(_) => None,
        }
    }
}

impl fmt::Display for RuntimeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Unsafe(message) => f.write_str(message),
            Self::Io(e) => e.fmt(f),
        }
    }
}

impl std::error::Error for RuntimeError {}

impl From<io::Error> for RuntimeError {
    fn from(e: io::Error) -> Self {
        Self::Io(e)
    }
}

/// Makes `dir` if it is not there, mode 0700 whatever the umask, then checks that it is safe to use.
pub fn ensure_safe_dir(dir: &Path, uid: u32) -> Result<(), RuntimeError> {
    match DirBuilder::new().mode(0o700).create(dir) {
        Ok(()) => fs::set_permissions(dir, fs::Permissions::from_mode(0o700))?,
        Err(e) if e.kind() == io::ErrorKind::AlreadyExists => {}
        Err(e) => return Err(e.into()),
    }
    let st = fs::symlink_metadata(dir)?;
    let shown = dir.display();
    if st.file_type().is_symlink() {
        return Err(RuntimeError::Unsafe(format!("{shown} is a symlink")));
    }
    if !st.is_dir() {
        return Err(RuntimeError::Unsafe(format!("{shown} is not a directory")));
    }
    if st.uid() != uid {
        return Err(RuntimeError::Unsafe(format!("{shown} is owned by uid {}, expected {uid}", st.uid())));
    }
    if st.mode() & 0o777 != 0o700 {
        return Err(RuntimeError::Unsafe(format!("{shown} has mode {:o}, expected 700", st.mode() & 0o777)));
    }
    Ok(())
}

/// The runtime directory and each of [`SUBDIRS`] in it, made if need be, and checked.
pub fn ensure_runtime(runtime_dir: &Path, uid: u32) -> Result<(), RuntimeError> {
    ensure_safe_dir(runtime_dir, uid)?;
    for sub in SUBDIRS {
        ensure_safe_dir(&runtime_dir.join(sub), uid)?;
    }
    Ok(())
}
