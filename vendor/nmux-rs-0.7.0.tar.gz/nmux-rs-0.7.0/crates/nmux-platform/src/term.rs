//! The terminal a client runs in, as Node's `tty.ReadStream` and `tty.WriteStream` gave it to the Node client: whether a
//! descriptor is one, its size, and raw mode as libuv sets it.

use std::io;
use std::os::fd::{AsFd, BorrowedFd, OwnedFd};

use rustix::termios::{
    ControlModes, InputModes, LocalModes, OptionalActions, OutputModes, SpecialCodeIndex, Termios, tcgetattr,
    tcgetwinsize, tcsetattr,
};

/// Whether `fd` is a terminal.
pub fn is_terminal(fd: BorrowedFd<'_>) -> bool {
    rustix::termios::isatty(fd)
}

/// The size of the terminal `fd` is on, as columns and rows. Either can be 0, where nobody has said.
pub fn window_size(fd: BorrowedFd<'_>) -> io::Result<(u16, u16)> {
    let size = tcgetwinsize(fd)?;
    Ok((size.ws_col, size.ws_row))
}

/// A terminal in raw mode, as `setRawMode(true)` leaves one: no echo, no line editing, no signals from keys and no
/// translation of what is typed, a byte at a time. Output is still processed, so a bare LF still becomes CRLF. The modes it
/// had are put back when this is dropped.
#[derive(Debug)]
pub struct RawMode {
    fd: OwnedFd,
    saved: Termios,
}

impl RawMode {
    /// Puts the terminal `fd` is on into raw mode, keeping the modes it had.
    pub fn enter(fd: BorrowedFd<'_>) -> io::Result<Self> {
        let saved = tcgetattr(fd)?;
        let raw = Self { fd: fd.try_clone_to_owned()?, saved };
        raw.again()?;
        Ok(raw)
    }

    /// Raw mode once more, for a terminal something else may have changed meanwhile, such as a pager that died.
    pub fn again(&self) -> io::Result<()> {
        let mut t = self.saved.clone();
        t.input_modes -=
            InputModes::BRKINT | InputModes::ICRNL | InputModes::INPCK | InputModes::ISTRIP | InputModes::IXON;
        t.output_modes |= OutputModes::ONLCR;
        t.control_modes |= ControlModes::CS8;
        t.local_modes -= LocalModes::ECHO | LocalModes::ICANON | LocalModes::IEXTEN | LocalModes::ISIG;
        t.special_codes[SpecialCodeIndex::VMIN] = 1;
        t.special_codes[SpecialCodeIndex::VTIME] = 0;
        Ok(tcsetattr(&self.fd, OptionalActions::Drain, &t)?)
    }

    /// The modes it had before.
    pub fn restore(&self) -> io::Result<()> {
        Ok(tcsetattr(&self.fd, OptionalActions::Drain, &self.saved)?)
    }

    /// The terminal.
    pub fn fd(&self) -> BorrowedFd<'_> {
        self.fd.as_fd()
    }
}

impl Drop for RawMode {
    fn drop(&mut self) {
        // A terminal that has gone cannot be given its modes back, and nothing else is left to do with it.
        let _ = self.restore();
    }
}
