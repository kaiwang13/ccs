//! Starting a program on a new pty, the way node-pty's `pty.fork` does, so that a program cannot tell which holder started
//! it: the same terminal modes, the same size defaults, the program found on the PATH as `execvp(3)` finds it, and the same
//! words on the pty when it cannot be started.
//!
//! Everything the child needs is built before the fork. After it, the child only makes async-signal-safe calls until it
//! execs or exits, which is what makes forking from a process with other threads sound.

use std::ffi::{CStr, CString, c_char};
use std::io;
use std::os::fd::{AsFd, AsRawFd, BorrowedFd, OwnedFd, RawFd};

use rustix::fs::{Mode, OFlags};
use rustix::pty::OpenptFlags;
use rustix::termios::Winsize;

use crate::os;
use crate::signals::{block_all, defaults_in_child, restore};

/// What to start, and on what size of terminal.
#[derive(Clone, Copy, Debug)]
pub struct PtyCommand<'a> {
    /// The program and its arguments. The program is found as `execvp(3)` finds it, on the PATH in `env`.
    pub argv: &'a [String],
    /// Its environment, as `NAME=value` strings, in order.
    pub env: &'a [String],
    /// Where it starts. Empty leaves it where this process is.
    pub cwd: &'a str,
    /// Columns. 0 is node-pty's default, 80.
    pub cols: u32,
    /// Rows. 0 is node-pty's default, 24.
    pub rows: u32,
}

/// A program started on a pty.
#[derive(Debug)]
pub struct Spawned {
    /// The pty's master, non-blocking and closed on exec. Closing it hangs the pty up.
    pub master: OwnedFd,
    /// The program's pid. It leads its own session, with the pty as its controlling terminal.
    pub pid: i32,
    /// The slave's path, such as `/dev/pts/3`.
    pub pts_name: String,
}

/// Gives the pty `fd` is on a new size.
pub fn set_winsize(fd: BorrowedFd<'_>, cols: u16, rows: u16) -> io::Result<()> {
    Ok(rustix::termios::tcsetwinsize(fd, Winsize { ws_row: rows, ws_col: cols, ws_xpixel: 0, ws_ypixel: 0 })?)
}

/// Starts `command` on a new pty. Like node-pty, a program that cannot be started is not an error here: the child exits
/// with 1, and on Linux says why on the pty first, so the session shows what went wrong.
pub fn spawn_pty(command: &PtyCommand<'_>) -> io::Result<Spawned> {
    let plan = Plan::new(command)?;
    let master = rustix::pty::openpt(OpenptFlags::RDWR | OpenptFlags::NOCTTY)?;
    // Not every platform takes CLOEXEC on the open. Without it, every process this one starts, a server among them, would
    // hold the master open too.
    rustix::io::fcntl_setfd(&master, rustix::io::FdFlags::CLOEXEC)?;
    rustix::pty::grantpt(&master)?;
    rustix::pty::unlockpt(&master)?;
    let name = rustix::pty::ptsname(&master, Vec::new())?;
    let slave = rustix::fs::open(name.as_c_str(), OFlags::RDWR | OFlags::NOCTTY | OFlags::CLOEXEC, Mode::empty())?;
    set_termios(slave.as_fd())?;
    // node-pty: `opt.cols || 80`, and C's conversion to an unsigned short.
    #[allow(clippy::cast_possible_truncation)]
    let size = |n: u32, default: u16| if n == 0 { default } else { n as u16 };
    set_winsize(slave.as_fd(), size(command.cols, 80), size(command.rows, 24))?;
    let mask = block_all();
    // SAFETY: the child calls only async-signal-safe functions before it execs or exits (see `child`), and everything it
    // reads was built before the fork and lives on in its copy of the address space.
    let pid = unsafe { libc::fork() };
    if pid == 0 {
        // SAFETY: this is the child of the fork above.
        unsafe { child(&plan, slave.as_raw_fd(), master.as_raw_fd()) }
    }
    let fork_error = io::Error::last_os_error();
    restore(&mask);
    if pid < 0 {
        return Err(io::Error::new(fork_error.kind(), format!("forkpty(3) failed: {fork_error}")));
    }
    drop(slave);
    rustix::io::ioctl_fionbio(&master, true)?;
    Ok(Spawned { master, pid, pts_name: name.to_string_lossy().into_owned() })
}

/// The modes node-pty gives a new pty: everything else is zero.
fn set_termios(slave: BorrowedFd<'_>) -> io::Result<()> {
    // SAFETY: an all-zero termios is a valid value of a plain C struct, and node-pty starts from one.
    let mut t: libc::termios = unsafe { std::mem::zeroed() };
    t.c_iflag = libc::ICRNL | libc::IXON | libc::IXANY | libc::IMAXBEL | libc::BRKINT | libc::IUTF8;
    t.c_oflag = libc::OPOST | libc::ONLCR;
    t.c_cflag = libc::CREAD | libc::CS8 | libc::HUPCL;
    t.c_lflag = libc::ICANON
        | libc::ISIG
        | libc::IEXTEN
        | libc::ECHO
        | libc::ECHOE
        | libc::ECHOK
        | libc::ECHOKE
        | libc::ECHOCTL;
    let cc = &mut t.c_cc;
    cc[libc::VEOF] = 4;
    cc[libc::VEOL] = 0xff;
    cc[libc::VEOL2] = 0xff;
    cc[libc::VERASE] = 0x7f;
    cc[libc::VWERASE] = 23;
    cc[libc::VKILL] = 21;
    cc[libc::VREPRINT] = 18;
    cc[libc::VINTR] = 3;
    cc[libc::VQUIT] = 0x1c;
    cc[libc::VSUSP] = 26;
    cc[libc::VSTART] = 17;
    cc[libc::VSTOP] = 19;
    cc[libc::VLNEXT] = 22;
    cc[libc::VDISCARD] = 15;
    cc[libc::VMIN] = 1;
    cc[libc::VTIME] = 0;
    os::more_special_chars(cc);
    // SAFETY: `t` is a live termios that these calls read and write, and the fd is borrowed for the calls.
    let set = unsafe {
        libc::cfsetispeed(&raw mut t, libc::B38400);
        libc::cfsetospeed(&raw mut t, libc::B38400);
        libc::tcsetattr(slave.as_raw_fd(), libc::TCSAFLUSH, &raw const t)
    };
    if set == 0 { Ok(()) } else { Err(io::Error::last_os_error()) }
}

/// What `perror` prefixes when the child cannot change directory or exec.
const CHDIR_FAILED: &[u8] = b"chdir(2) failed.: ";
const EXEC_FAILED: &[u8] = b"execvp(3) failed.: ";
/// `_PATH_BSHELL`, which runs a file the kernel cannot.
const SHELL: &CStr = c"/bin/sh";
/// Above every errno either OS has.
const ERRNO_LIMIT: i32 = 160;

/// Everything the child needs, built before the fork so that it allocates nothing.
struct Plan {
    /// Owns every string the pointers below point into. A `CString`'s bytes do not move when it does.
    _strings: Vec<CString>,
    argv: Vec<*const c_char>,
    envp: Vec<*const c_char>,
    /// The paths to try, in order, as `execvp(3)` would try them.
    candidates: Vec<*const c_char>,
    /// For each candidate, the arguments that run it as a shell script, for a file the kernel cannot run.
    scripts: Vec<Vec<*const c_char>>,
    /// The program was named with a `/`, so only that path is tried.
    direct: bool,
    /// The errno `execvp(3)` fails with before it tries anything.
    refused: Option<i32>,
    cwd: Option<CString>,
    /// `strerror` of each errno, for the child to say why it failed, where it does.
    reasons: Vec<Vec<u8>>,
}

/// A string as C reads it: up to its first NUL.
fn c_string(s: &str) -> CString {
    let bytes = s.as_bytes();
    let end = bytes.iter().position(|&b| b == 0).unwrap_or(bytes.len());
    CString::new(&bytes[..end]).unwrap_or_default()
}

fn pointers(strings: &[CString]) -> Vec<*const c_char> {
    strings.iter().map(|s| s.as_ptr()).chain(std::iter::once(std::ptr::null())).collect()
}

impl Plan {
    fn new(command: &PtyCommand<'_>) -> io::Result<Self> {
        let Some(file) = command.argv.first() else {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "nothing to run"));
        };
        let file = c_string(file);
        let argv: Vec<CString> = command.argv.iter().map(|a| c_string(a)).collect();
        let env: Vec<CString> = command.env.iter().map(|e| c_string(e)).collect();
        // getenv(3) takes the first.
        let path = env.iter().find_map(|e| e.to_bytes().strip_prefix(b"PATH=")).unwrap_or(os::DEFAULT_PATH);
        let direct = file.to_bytes().contains(&b'/');
        let mut refused = None;
        let paths: Vec<CString> = if file.is_empty() {
            refused = Some(libc::ENOENT);
            Vec::new()
        } else if direct {
            vec![file.clone()]
        } else if file.to_bytes().len() > 255 {
            refused = Some(libc::ENAMETOOLONG);
            Vec::new()
        } else {
            path.split(|&b| b == b':')
                .map(|dir| {
                    // An empty entry is the current directory: the bare name.
                    let joined =
                        if dir.is_empty() { file.to_bytes().to_vec() } else { [dir, b"/", file.to_bytes()].concat() };
                    CString::new(joined).unwrap_or_default()
                })
                .collect()
        };
        let argv_ptrs = pointers(&argv);
        let envp_ptrs = pointers(&env);
        let candidates: Vec<*const c_char> = paths.iter().map(|p| p.as_ptr()).collect();
        let scripts = candidates
            .iter()
            .map(|&candidate| {
                let rest = argv_ptrs.iter().skip(1).copied().take_while(|p| !p.is_null());
                [SHELL.as_ptr(), candidate].into_iter().chain(rest).chain(std::iter::once(std::ptr::null())).collect()
            })
            .collect();
        let reasons = if os::EXEC_FAILURE_SAYS_WHY {
            (0..ERRNO_LIMIT).map(|errno| reason(errno).into_bytes()).collect()
        } else {
            Vec::new()
        };
        let cwd = (!command.cwd.is_empty()).then(|| c_string(command.cwd));
        let mut strings = argv;
        strings.extend(env);
        strings.extend(paths);
        Ok(Self {
            _strings: strings,
            argv: argv_ptrs,
            envp: envp_ptrs,
            candidates,
            scripts,
            direct,
            refused,
            cwd,
            reasons,
        })
    }

    /// `execvp(3)`, as glibc's `__execvpe` does it. It only returns when nothing could be run, with the errno to report.
    ///
    /// # Safety
    ///
    /// Only async-signal-safe calls: for the child of a fork.
    unsafe fn exec(&self) -> i32 {
        if let Some(errno) = self.refused {
            return errno;
        }
        let mut eacces = false;
        let mut last = libc::ENOENT;
        for (candidate, script) in self.candidates.iter().zip(&self.scripts) {
            // SAFETY: every pointer is into strings the plan owns, and each list ends with a null.
            let errno = unsafe {
                libc::execve(*candidate, self.argv.as_ptr(), self.envp.as_ptr());
                last_errno()
            };
            match errno {
                libc::ENOEXEC => {
                    // SAFETY: as above.
                    return unsafe {
                        libc::execve(SHELL.as_ptr(), script.as_ptr(), self.envp.as_ptr());
                        last_errno()
                    };
                }
                _ if self.direct => return errno,
                libc::EACCES => eacces = true,
                libc::ENOENT | libc::ESTALE | libc::ENOTDIR | libc::ENODEV | libc::ETIMEDOUT => {}
                _ => return errno,
            }
            last = errno;
        }
        if eacces { libc::EACCES } else { last }
    }

    /// Says why the child could not start, where node-pty's does, and exits with 1.
    ///
    /// # Safety
    ///
    /// Only async-signal-safe calls: for the child of a fork.
    unsafe fn fail(&self, prefix: &[u8], errno: i32) -> ! {
        if let Some(reason) = usize::try_from(errno).ok().and_then(|i| self.reasons.get(i)) {
            for part in [prefix, reason.as_slice(), b"\n"] {
                // SAFETY: write(2) of a live buffer to stderr, which is the pty.
                unsafe { libc::write(2, part.as_ptr().cast::<libc::c_void>(), part.len()) };
            }
        }
        // SAFETY: _exit(2) is async-signal-safe and does not return.
        unsafe { libc::_exit(1) }
    }
}

/// `strerror` of an errno, as `perror` prints it.
fn reason(errno: i32) -> String {
    let text = io::Error::from_raw_os_error(errno).to_string();
    match text.rfind(" (os error ") {
        Some(at) => text[..at].to_owned(),
        None => text,
    }
}

fn last_errno() -> i32 {
    // SAFETY: the location is this thread's errno, valid for the life of the thread.
    unsafe { *os::errno_location() }
}

/// The child: its own session with the pty as its controlling terminal and standard streams, signals as a new program
/// expects them, then the program.
///
/// # Safety
///
/// For the child of a fork. It makes only async-signal-safe calls and never returns.
unsafe fn child(plan: &Plan, slave: RawFd, master: RawFd) -> ! {
    // SAFETY: each is an async-signal-safe call on descriptors this process holds, or on strings the plan owns.
    unsafe {
        defaults_in_child();
        libc::setsid();
        os::set_controlling_terminal(slave);
        for fd in 0..3 {
            libc::dup2(slave, fd);
            // Kept across exec, even where the slave already was one of these.
            libc::fcntl(fd, libc::F_SETFD, 0);
        }
        if slave > 2 {
            libc::close(slave);
        }
        libc::close(master);
        if let Some(cwd) = &plan.cwd {
            if libc::chdir(cwd.as_ptr()) == -1 {
                plan.fail(CHDIR_FAILED, last_errno());
            }
        }
        let errno = plan.exec();
        plan.fail(EXEC_FAILED, errno)
    }
}
