//! macOS: process information from libproc, as `darwin.js` and `ttyctl.c` read it, and the macOS answers to the rest of
//! the surface. macOS has no /proc, and some of what Linux can read about another process cannot be read here at all:
//! those answers are `None`, which callers take as "cannot tell".

use std::collections::HashMap;
use std::ffi::c_void;
use std::io;
use std::mem::{MaybeUninit, size_of};
use std::os::fd::{AsFd, AsRawFd, BorrowedFd};
use std::path::Path;
use std::process::Command;
use std::time::Duration;

use crate::process::{Capabilities, ProcState, Process, ShutdownEvidence, run_within};

pub(crate) const CAPABILITIES: Capabilities = Capabilities {
    // libproc says ESRCH for a defunct process, so its parent cannot be read.
    reports_zombie_parent: false,
    // Closing the master hangs up the slave here too: the session's leader gets SIGHUP, as the BSD pty driver sends it and
    // tests/native.rs sees on macOS.
    hangup_on_master_close: true,
    // Another process's environment has never been measured to be readable here.
    orphan_scan: false,
    proc_source: "libproc",
};

/// The memory-pressure killer cannot be steered per process.
pub(crate) const OOM_SCORE_ADJ_PATH: Option<&str> = None;

/// Nothing is looked for here: see [`shutdown_corroborated`].
pub(crate) const SHUTDOWN_SCHEDULED: &str = "";

/// What `execvp(3)` searches when the environment has no PATH: `_PATH_DEFPATH`.
pub(crate) const DEFAULT_PATH: &[u8] = b"/usr/bin:/bin";

/// node-pty's spawn helper exits with 1 and says nothing when it cannot start the program.
pub(crate) const EXEC_FAILURE_SAYS_WHY: bool = false;

/// `NSIG`: one more than the highest signal number.
pub(crate) const SIGNAL_LIMIT: i32 = 32;

/// `os.constants.signals` as Node lists it here, so that a number gets the name Node gives it: the first with that number.
pub(crate) const SIGNAL_NAMES: &[(&str, i32)] = &[
    ("SIGHUP", libc::SIGHUP),
    ("SIGINT", libc::SIGINT),
    ("SIGQUIT", libc::SIGQUIT),
    ("SIGILL", libc::SIGILL),
    ("SIGTRAP", libc::SIGTRAP),
    ("SIGABRT", libc::SIGABRT),
    ("SIGIOT", libc::SIGIOT),
    ("SIGBUS", libc::SIGBUS),
    ("SIGFPE", libc::SIGFPE),
    crate::signals::UNCATCHABLE,
    ("SIGUSR1", libc::SIGUSR1),
    ("SIGSEGV", libc::SIGSEGV),
    ("SIGUSR2", libc::SIGUSR2),
    ("SIGPIPE", libc::SIGPIPE),
    ("SIGALRM", libc::SIGALRM),
    ("SIGTERM", libc::SIGTERM),
    ("SIGCHLD", libc::SIGCHLD),
    ("SIGCONT", libc::SIGCONT),
    ("SIGSTOP", libc::SIGSTOP),
    ("SIGTSTP", libc::SIGTSTP),
    ("SIGTTIN", libc::SIGTTIN),
    ("SIGTTOU", libc::SIGTTOU),
    ("SIGURG", libc::SIGURG),
    ("SIGXCPU", libc::SIGXCPU),
    ("SIGXFSZ", libc::SIGXFSZ),
    ("SIGVTALRM", libc::SIGVTALRM),
    ("SIGPROF", libc::SIGPROF),
    ("SIGWINCH", libc::SIGWINCH),
    ("SIGIO", libc::SIGIO),
    ("SIGINFO", libc::SIGINFO),
    ("SIGSYS", libc::SIGSYS),
];

/// Where this thread's errno is, for a signal handler to keep it as it found it.
pub(crate) fn errno_location() -> *mut libc::c_int {
    // SAFETY: `__error` has no preconditions and returns this thread's errno, which lives as long as the thread.
    unsafe { libc::__error() }
}

/// `pbi_status` of a defunct process, from <sys/proc.h>.
const SZOMB: u32 = 5;
/// `PROC_ALL_PIDS`, from <libproc.h>.
const PROC_ALL_PIDS: u32 = 1;

/// What libproc says about a process.
struct Info {
    start_sec: u64,
    pgid: u32,
    ppid: u32,
    sid: i32,
    status: u32,
    /// `pbi_flags`.
    flags: u32,
    /// Present but defunct: libproc says ESRCH for it, while the pid is still listed.
    zombie: bool,
}

/// `PROC_FLAG_INEXIT` in `<sys/proc_info.h>`: the process is working its way through `exit()`.
const PROC_FLAG_INEXIT: u32 = 4;

fn proc_info(pid: i32) -> Option<Info> {
    let size = libc::c_int::try_from(size_of::<libc::proc_bsdinfo>()).ok()?;
    let mut info = MaybeUninit::<libc::proc_bsdinfo>::zeroed();
    // SAFETY: the buffer is a `proc_bsdinfo`, `size` bytes long, which is what PROC_PIDTBSDINFO writes into.
    let n = unsafe { libc::proc_pidinfo(pid, libc::PROC_PIDTBSDINFO, 0, info.as_mut_ptr().cast::<c_void>(), size) };
    if n != size {
        let esrch = io::Error::last_os_error().raw_os_error() == Some(libc::ESRCH);
        return (esrch && list_pids().contains(&pid)).then_some(Info {
            start_sec: 0,
            pgid: 0,
            ppid: 0,
            sid: 0,
            status: SZOMB,
            flags: 0,
            zombie: true,
        });
    }
    // SAFETY: zeroed is a valid `proc_bsdinfo` (it holds only integers and arrays of them), and the call filled it.
    let info = unsafe { info.assume_init() };
    // SAFETY: getsid has no memory preconditions; a pid that is gone gives -1.
    let sid = unsafe { libc::getsid(pid) };
    Some(Info {
        start_sec: info.pbi_start_tvsec,
        pgid: info.pbi_pgid,
        ppid: info.pbi_ppid,
        sid,
        status: info.pbi_status,
        flags: info.pbi_flags,
        zombie: false,
    })
}

/// The start time in whole seconds, as a ctime string: see [`crate::ctime_utc`]. A zombie has none.
pub(crate) fn proc_start(pid: i32) -> Option<String> {
    let info = proc_info(pid).filter(|i| !i.zombie)?;
    let ms = i64::try_from(info.start_sec).ok()?.checked_mul(1000)?;
    Some(crate::ctime_utc(ms))
}

/// In `exit()`, which waits for what it wrote to a terminal to be read, or a zombie.
pub(crate) fn proc_exiting(pid: i32) -> bool {
    proc_info(pid).is_some_and(|i| i.zombie || i.status == SZOMB || i.flags & PROC_FLAG_INEXIT != 0)
}

pub(crate) fn proc_state(pid: i32) -> ProcState {
    match proc_info(pid) {
        None => ProcState::Gone,
        Some(i) if i.zombie || i.status == SZOMB => ProcState::Zombie,
        Some(_) => ProcState::Alive,
    }
}

pub(crate) fn pgid(pid: i32) -> Option<i32> {
    let info = proc_info(pid).filter(|i| !i.zombie)?;
    i32::try_from(info.pgid).ok().filter(|&g| g > 0)
}

pub(crate) fn ppid(pid: i32) -> Option<i32> {
    let info = proc_info(pid).filter(|i| !i.zombie)?;
    i32::try_from(info.ppid).ok()
}

pub(crate) fn proc_sid(pid: i32) -> Option<i32> {
    proc_info(pid).filter(|i| !i.zombie && i.sid > 0).map(|i| i.sid)
}

fn command_output(program: &str, args: &[&str], timeout: Duration) -> Option<String> {
    let ran = run_within(Command::new(program).args(args), timeout)?;
    (ran.finished && ran.ok).then_some(ran.stdout)
}

pub(crate) fn boot_id() -> io::Result<String> {
    command_output("/usr/sbin/sysctl", &["-n", "kern.bootsessionuuid"], Duration::from_secs(10))
        .map(|out| out.trim().to_owned())
        .ok_or_else(|| io::Error::other("bootId: sysctl kern.bootsessionuuid failed"))
}

/// `IOPlatformUUID`, the hardware's own id, without its dashes, so that it has the shape of Linux's machine-id.
pub(crate) fn machine_id() -> io::Result<String> {
    let out = command_output("/usr/sbin/ioreg", &["-rd1", "-c", "IOPlatformExpertDevice"], Duration::from_secs(10))
        .ok_or_else(|| io::Error::other("machineId: ioreg failed"))?;
    let found = out.lines().find_map(|line| {
        let rest = line.split_once("\"IOPlatformUUID\"")?.1.trim_start().strip_prefix('=')?.trim_start();
        let value = rest.strip_prefix('"')?;
        Some(value[..value.find('"')?].to_owned())
    });
    let uuid = found.ok_or_else(|| io::Error::other("machineId: IOPlatformUUID not found in ioreg output"))?;
    Ok(uuid.to_lowercase().replace('-', ""))
}

/// Never readable here: that would be `KERN_PROCARGS2`, which has never been measured under SIP.
pub(crate) fn read_environ(_pid: i32) -> Option<HashMap<String, String>> {
    None
}

pub(crate) fn read_argv(_pid: i32) -> Option<Vec<String>> {
    None
}

pub(crate) fn command_line(pid: i32) -> Option<String> {
    let out = command_output("/bin/ps", &["-o", "command=", "-p", &pid.to_string()], Duration::from_secs(1))?;
    Some(out.trim().to_owned()).filter(|line| !line.is_empty())
}

pub(crate) fn cwd_of(pid: i32) -> Option<String> {
    let pid = pid.to_string();
    let out = command_output("/usr/sbin/lsof", &["-a", "-d", "cwd", "-p", &pid, "-Fn"], Duration::from_secs(1))?;
    out.split('\n').find_map(|line| line.strip_prefix('n')).map(str::to_owned)
}

pub(crate) fn list_pids() -> Vec<i32> {
    // SAFETY: a null buffer of length 0 asks only for the size the list needs.
    let bytes = unsafe { libc::proc_listpids(PROC_ALL_PIDS, 0, std::ptr::null_mut(), 0) };
    let Ok(bytes) = usize::try_from(bytes) else { return Vec::new() };
    // A few more than it said: processes can start between the two calls, and it would rather cut the list short.
    let mut pids = vec![0i32; bytes / size_of::<i32>() + 64];
    let Ok(capacity) = libc::c_int::try_from(pids.len() * size_of::<i32>()) else { return Vec::new() };
    // SAFETY: the buffer is `capacity` bytes of i32s, which is what proc_listpids writes into.
    let got = unsafe { libc::proc_listpids(PROC_ALL_PIDS, 0, pids.as_mut_ptr().cast::<c_void>(), capacity) };
    let count = usize::try_from(got).unwrap_or(0) / size_of::<i32>();
    pids.truncate(count.min(pids.len()));
    // The kernel pads the end with zeroes.
    pids.retain(|&pid| pid > 0);
    pids
}

/// From one `ps`, as argv cannot be read directly here.
pub(crate) fn list_processes() -> Vec<Process> {
    let Some(text) = command_output("/bin/ps", &["-Ao", "pid=,ppid=,command="], Duration::from_secs(30)) else {
        return Vec::new();
    };
    text.lines()
        .filter_map(|line| {
            let (pid, rest) = line.trim_start().split_once(char::is_whitespace)?;
            let (parent, command) =
                rest.trim_start().split_once(char::is_whitespace).unwrap_or((rest.trim_start(), ""));
            let argv = Some(command.trim_start().to_owned());
            Some(Process { pid: pid.parse().ok()?, ppid: Some(parent.parse().ok()?), argv })
        })
        .collect()
}

/// There are no pid namespaces here: one flat pid space per boot.
pub(crate) fn pid_ns(_pid: i32) -> Option<String> {
    None
}

/// There is no unprivileged way to read another process's terminal here.
pub(crate) fn tty_of(_pid: i32) -> Option<String> {
    None
}

/// ttyname(3) of standard input, which is what `tty` prints.
pub(crate) fn self_tty() -> Option<String> {
    let name = rustix::termios::ttyname(std::io::stdin().as_fd(), Vec::new()).ok()?;
    let name = name.to_string_lossy().into_owned();
    name.starts_with("/dev/").then_some(name)
}

/// `ps` shows every command line to everyone, and there is nothing like hidepid.
pub(crate) fn argv_visible_to_others(_mounts: Option<&Path>) -> bool {
    true
}

/// Always false: the Linux answer comes from systemd, and macOS has nothing cheap and reliable to take its place.
pub(crate) fn shutdown_corroborated(_evidence: &ShutdownEvidence<'_>) -> bool {
    false
}

/// `LOCAL_PEERCRED`, through getpeereid(3).
pub(crate) fn peer_uid(fd: BorrowedFd<'_>) -> io::Result<u32> {
    let mut uid: libc::uid_t = 0;
    let mut gid: libc::gid_t = 0;
    // SAFETY: both pointers are to live locals of the types getpeereid writes, and the fd is borrowed for the call.
    if unsafe { libc::getpeereid(fd.as_raw_fd(), &raw mut uid, &raw mut gid) } != 0 {
        return Err(io::Error::last_os_error());
    }
    Ok(uid)
}

/// Special characters node-pty sets only here.
pub(crate) fn more_special_chars(cc: &mut [libc::cc_t]) {
    cc[libc::VDSUSP] = 25;
    cc[libc::VSTATUS] = 20;
}

/// TIOCSCTTY: the terminal on `fd` becomes this session's controlling terminal.
///
/// # Safety
///
/// For a session leader without a controlling terminal, such as a child just after setsid(2). Async-signal-safe.
pub(crate) unsafe fn set_controlling_terminal(fd: libc::c_int) {
    // SAFETY: the ioctl takes an integer argument and touches no memory of ours.
    unsafe { libc::ioctl(fd, libc::TIOCSCTTY.into(), 0) };
}
