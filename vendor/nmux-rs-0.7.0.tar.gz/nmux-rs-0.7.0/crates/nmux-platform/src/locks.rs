//! Advisory locks on local files only, as `locks.js`: the runtime directory, because flock over NFS is unreliable. A flock
//! belongs to the open file description, so the kernel releases it when the owner dies, which makes "can I take this lock?"
//! a reliable test of whether the owner lives.

use std::io;
use std::os::fd::{AsFd, BorrowedFd, OwnedFd};
use std::path::Path;

use rustix::fs::{FlockOperation, Mode, OFlags};

/// A lock this process holds. It is released by [`Lock::release`], or when it is dropped.
#[derive(Debug)]
pub struct Lock {
    fd: Option<OwnedFd>,
}

impl Lock {
    /// Gives the lock up. Doing it twice is harmless.
    pub fn release(&mut self) {
        // Closing the last descriptor of the open file description drops the flock.
        self.fd = None;
    }

    /// The locked file, while the lock is held.
    pub fn fd(&self) -> Option<BorrowedFd<'_>> {
        self.fd.as_ref().map(AsFd::as_fd)
    }
}

/// Takes `fd`'s lock: exclusive or shared, and waiting for it or not. False only when it does not wait and another open
/// file description holds the lock.
pub fn flock(fd: BorrowedFd<'_>, exclusive: bool, nonblocking: bool) -> io::Result<bool> {
    let operation = match (exclusive, nonblocking) {
        (true, true) => FlockOperation::NonBlockingLockExclusive,
        (true, false) => FlockOperation::LockExclusive,
        (false, true) => FlockOperation::NonBlockingLockShared,
        (false, false) => FlockOperation::LockShared,
    };
    loop {
        match rustix::fs::flock(fd, operation) {
            Ok(()) => return Ok(true),
            Err(rustix::io::Errno::INTR) => {}
            Err(rustix::io::Errno::WOULDBLOCK) if nonblocking => return Ok(false),
            Err(e) => return Err(e.into()),
        }
    }
}

/// An exclusive lock on `path`, which is made with mode 0600 if it is not there, or `None` when someone else has it.
pub fn try_lock(path: &Path) -> io::Result<Option<Lock>> {
    let flags = OFlags::RDWR | OFlags::CREATE | OFlags::CLOEXEC;
    let fd = rustix::fs::open(path, flags, Mode::from_raw_mode(0o600))?;
    Ok(flock(fd.as_fd(), true, true)?.then_some(Lock { fd: Some(fd) }))
}

/// Whether another open file description holds the lock on `path`: a shared lock is tried on a descriptor of its own,
/// which is closed again at once. A file that is not there is not locked.
pub fn is_locked(path: &Path) -> io::Result<bool> {
    let fd = match rustix::fs::open(path, OFlags::RDONLY | OFlags::CLOEXEC, Mode::empty()) {
        Ok(fd) => fd,
        Err(rustix::io::Errno::NOENT) => return Ok(false),
        Err(e) => return Err(e.into()),
    };
    Ok(!flock(fd.as_fd(), false, true)?)
}
