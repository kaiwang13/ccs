//! The `nmux` command. As `nmux __holder …` and `nmux __server …` it is instead a session's holder or server, which is how one
//! binary is all of nmux, and either implementation can run the other's. As `nmux __attach --json SPEC` it is the attach
//! client of a program that embeds nmux, in that program's words.

use std::ffi::OsString;

mod cli;

fn main() {
    let args: Vec<OsString> = std::env::args_os().collect();
    match args.get(1).and_then(|a| a.to_str()) {
        Some("__holder") => std::process::exit(nmux_holder::main(&args[2..])),
        Some("__server") => std::process::exit(nmux_server::run::main(&args[2..])),
        Some("__attach") => std::process::exit(nmux_client::embed::main(&args[2..])),
        _ => {}
    }
    let words: Vec<String> = args.iter().skip(1).map(|a| a.to_string_lossy().into_owned()).collect();
    std::process::exit(cli::main(&words));
}
