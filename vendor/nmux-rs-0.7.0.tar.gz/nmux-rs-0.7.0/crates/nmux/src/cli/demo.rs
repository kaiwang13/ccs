//! What `nmux demo` fills sessions with, to look at how nmux shows things: `src/cli/demo.js`, byte for byte. Files a shell
//! prints, the lines it types to print them, a program that has the whole screen, and a history of three days.

use std::fs;
use std::io;
use std::os::unix::fs::{DirBuilderExt, OpenOptionsExt};
use std::path::Path;

use nmux_history::format::{Line, META, Mark, PREFIX, SCHEMA};
use nmux_time::{Zone, iso, parse_when, stamp};
use serde_json::json;

const ESC: &str = "\x1b";
const HOUR_MS: i64 = 3_600_000;
const MINUTE_MS: i64 = 60_000;
const SAMPLE: &str = "The quick brown fox jumps over the lazy dog";
const NAMES: [&str; 8] = ["black", "red", "green", "yellow", "blue", "magenta", "cyan", "white"];

/// `text` in a style, and the style ended.
fn sgr(codes: &str, text: &str) -> String {
    format!("{ESC}[{codes}m{text}{ESC}[m")
}

/// A link.
fn link(url: &str, text: &str, params: &str) -> String {
    format!("{ESC}]8;{params};{url}{ESC}\\{text}{ESC}]8;;{ESC}\\")
}

/// A label and what it is about, lined up.
fn row(label: &str, rest: &str) -> String {
    format!("  {label:<30}{rest}")
}

/// The sixteen colours one way, joined by `between`.
fn sixteen(base: u32, pad: &str, between: &str) -> String {
    let named = NAMES.iter().zip(0u32..).map(|(n, i)| sgr(&(base + i).to_string(), &format!("{pad}{n}{pad}")));
    format!("  {}", named.collect::<Vec<_>>().join(between))
}

fn colours() -> Vec<String> {
    let mut out = vec!["The sixteen colours, as text and behind it:".to_owned(), String::new()];
    out.extend([sixteen(30, "", " "), sixteen(90, "", " "), sixteen(40, " ", ""), sixteen(100, " ", "")]);
    out.extend([String::new(), "The 256:".to_owned(), String::new()]);
    for r in 0..6 {
        out.push(format!("  {}", (0..36).map(|i| sgr(&format!("48;5;{}", 16 + r * 36 + i), "  ")).collect::<String>()));
    }
    out.push(format!("  {}", (232..256).map(|i| sgr(&format!("48;5;{i}"), "   ")).collect::<String>()));
    out.extend([String::new(), "Any colour at all:".to_owned(), String::new()]);
    out.push(format!(
        "  {}",
        (0..64).map(|i| sgr(&format!("48;2;{};{};128", i * 4, 255 - i * 4), " ")).collect::<String>()
    ));
    out
}

const STYLES: [(&str, &str); 15] = [
    ("bold", "1"),
    ("dim", "2"),
    ("italic", "3"),
    ("underlined", "4"),
    ("underlined twice", "4:2"),
    ("underlined in a curl", "4:3"),
    ("underlined in dots", "4:4"),
    ("underlined in dashes", "4:5"),
    ("underlined in red", "4;58;2;255;0;0"),
    ("blinking", "5"),
    ("inverse", "7"),
    ("hidden", "8"),
    ("struck through", "9"),
    ("overlined", "53"),
    ("all of them", "1;3;4;9;53"),
];

fn styles() -> Vec<String> {
    let mut out = vec!["Styles of text:".to_owned(), String::new()];
    out.extend(STYLES.iter().map(|(name, code)| row(name, &sgr(code, SAMPLE))));
    out
}

fn characters(cols: usize) -> Vec<String> {
    let dec = |s: &str| format!("{ESC}(0{s}{ESC}(B");
    vec![
        "Characters that take two columns, none, or more than one code point:".to_owned(),
        String::new(),
        row("Chinese, Japanese, Korean", "中文 日本語 한국어"),
        row("emoji", "😀 👍🏽 👨\u{200d}👩\u{200d}👧 🇯🇵 ✔\u{fe0f}"),
        row("built from parts", "e\u{301} a\u{308} n\u{303} o\u{302}\u{323}"),
        row("right to left", "עברית العربية"),
        row("box drawing", "┌──┬──┐"),
        row("", "│  │  │"),
        row("", "├──┼──┤"),
        row("", "└──┴──┘"),
        row("blocks and shades", "░▒▓█ ▁▂▃▄▅▆▇█"),
        row("braille", "⠁⠃⠉⠙⠑⠋⠛⠓⠊⠚"),
        row("line drawing, the DEC way", &dec("lqqqqk")),
        row("", &dec("x    x")),
        row("", &dec("mqqqqj")),
        String::new(),
        "A wide character that does not fit at the end of a line starts the next:".to_owned(),
        String::new(),
        format!("{}中", "x".repeat(cols.saturating_sub(1).max(1))),
    ]
}

fn wrapping(cols: usize) -> Vec<String> {
    let mut ruler = String::new();
    let mut i: u8 = 1;
    while ruler.len() < cols * 3 + 5 {
        ruler.push_str(".........");
        ruler.push(char::from(b'0' + i % 10));
        i = i % 10 + 1;
    }
    [
        "A line longer than the screen, which the terminal wraps, and which a narrower or wider one wraps again:",
        "",
        &ruler,
        "",
        "A line exactly as wide as the screen, then the next:",
        "",
        &"x".repeat(cols),
        "the next line",
        "",
        "Tab stops:",
        "",
        "a\tb\tc\td\te",
        "1234567\t12345678\t123456789\tend",
    ]
    .map(str::to_owned)
    .to_vec()
}

fn links() -> Vec<String> {
    let one = |text: &str| link("https://example.com/one", text, "id=demo");
    vec![
        "Links, which a terminal that knows them lets you open:".to_owned(),
        String::new(),
        row("an ordinary link", &link("https://example.com/", "example.com", "")),
        row("one link in two pieces", &format!("{} and {}", one("one link"), one("in two pieces"))),
    ]
}

/// The files of a demo, for a screen `cols` wide: what its shell prints, and the program that has the whole screen.
pub fn samples(cols: usize) -> Vec<(&'static str, String)> {
    let printed = [
        ("colours", colours()),
        ("styles", styles()),
        ("characters", characters(cols)),
        ("wrapping", wrapping(cols)),
        ("links", links()),
    ];
    let mut out: Vec<_> = printed.into_iter().map(|(name, lines)| (name, format!("{}\n", lines.join("\n")))).collect();
    out.push(("screen", SCREEN.to_owned()));
    out
}

/// What the demo session types, one line at a time, each run when the one before has finished.
pub const LINES: [&str; 8] = [
    "cat colours",
    "cat styles",
    "cat characters",
    "cat wrapping",
    "cat links",
    r"printf '\033]2;%s\007' 'nmux demo'",
    "cat missing",
    "seq 1 300",
];

/// A program that has the whole screen: a frame, the time, and colours, drawn again every second.
const SCREEN: &str = r#"# nmux demo: a program that has the whole screen
leave() { printf '\033[?25h\033[?1049l'; exit 0; }
trap leave INT TERM HUP
printf '\033[?1049h\033[?25l'
n=0
while :; do
  size=$(stty size 2>/dev/null) || size='24 80'
  rows=${size% *} cols=${size#* }
  line=''; i=2; while [ $i -lt "$cols" ]; do line="$line─"; i=$((i+1)); done
  printf '\033[H\033[2J┌%s┐' "$line"
  r=2; while [ $r -lt "$rows" ]; do printf '\033[%d;1H│\033[%d;%dH│' $r $r "$cols"; r=$((r+1)); done
  printf '\033[%d;1H└%s┘' "$rows" "$line"
  printf '\033[3;4H\033[1mnmux demo:\033[m a program that has the whole screen, on the other one'
  printf '\033[5;4H%s, drawn %d times' "$(date +%H:%M:%S)" "$n"
  printf '\033[7;4H'; c=0; while [ $c -lt 8 ]; do printf '\033[4%dm    ' $c; c=$((c+1)); done; printf '\033[m'
  printf '\033[9;4HCtrl+\\ d leaves it running; nmux stop ends it.'
  n=$((n+1)); sleep 1
done
"#;

/// The lines of a history of three days, up to `now`, on clocks in `zone`: a build twice a day and more, some of which
/// failed. Each is its time and its text.
pub fn days(now: i64, zone: &Zone) -> Vec<(i64, String)> {
    let at_start = |text: &str| parse_when(text, now, zone).unwrap_or(now);
    let (today, yesterday) = (at_start("today"), at_start("yesterday"));
    let before = at_start(&stamp(yesterday - HOUR_MS, zone)[..10]);
    let mut out = Vec::new();
    let mut n = 0;
    for midnight in [before, yesterday, today] {
        for hour in [1, 6, 9, 13, 17, 22] {
            let at = midnight + hour * HOUR_MS + 17 * MINUTE_MS;
            if at + 3 * MINUTE_MS > now {
                return out;
            }
            n += 1;
            out.push((at, "$ make test".to_owned()));
            out.push((at + MINUTE_MS, format!("build {n}: 120 tests")));
            let last = if n % 3 == 0 {
                format!("ERROR: build {n}: 2 of 120 tests failed")
            } else {
                format!("build {n}: all passed")
            };
            out.push((at + 3 * MINUTE_MS, last));
        }
    }
    out
}

/// Writes the files of a demo for a screen `cols` wide into `dir`, which is made if it is not there.
pub fn write_files(dir: &Path, cols: usize) -> io::Result<()> {
    fs::DirBuilder::new().recursive(true).mode(0o700).create(dir)?;
    samples(cols).iter().try_for_each(|(name, text)| write_private(&dir.join(name), text.as_bytes()))
}

/// Writes a history, as an ended session's is kept, into `dir`: the one of `id`, called `name`, that ran in `cwd`.
pub fn keep(dir: &Path, id: &str, name: &str, cwd: &Path, lines: &[(i64, String)]) -> io::Result<()> {
    fs::DirBuilder::new().recursive(true).mode(0o700).create(dir)?;
    let mut text = String::new();
    for (at, row) in lines {
        Line::Time(*at).write_to(&mut text);
        Line::Row { text: row, continues: false }.write_to(&mut text);
    }
    let offset = lines.iter().map(|(_, row)| row.len() as u64 + 1).sum();
    Line::Mark(Mark { generation: 0, offset, lines: lines.len() as u64 }).write_to(&mut text);
    write_private(&dir.join(format!("{PREFIX}0")), text.as_bytes())?;
    let created_at = iso(lines.first().map_or_else(super::sessions::now_ms, |(at, _)| *at));
    let meta = json!({
        "schema": SCHEMA, "id": id, "name": name, "createdAt": created_at, "cwd": cwd.to_string_lossy(), "argv": ["nmux", "demo"],
    });
    write_private(&dir.join(META), meta.to_string().as_bytes())
}

/// A file only its owner reads.
fn write_private(path: &Path, bytes: &[u8]) -> io::Result<()> {
    use std::io::Write as _;
    let mut f = fs::OpenOptions::new().write(true).create(true).truncate(true).mode(0o600).open(path)?;
    f.write_all(bytes)
}
