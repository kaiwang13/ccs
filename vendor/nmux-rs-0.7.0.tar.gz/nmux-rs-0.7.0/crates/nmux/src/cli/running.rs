//! `nmux run`: a line run in a session's shell, and the command exits as it did. `Cli.running` in `src/cli/main.js`, as a
//! state machine: what the session says goes in, requests and what to print come out.
//!
//! A server can restart at any moment and forget what it was asked. A line it had typed runs anyway: the next time the shell
//! is at a prompt, the last record says how it went, if that is this line. A line it was holding has gone, and sending it again
//! could run it twice if that server got as far as typing it, so that one is reported as not run.

use std::fmt::Write as _;

use nmux_client::control::SessionClient;
use nmux_client::ctl::{CtlError, Reply};
use serde_json::{Map, Value, json};

use super::format::{js_text, printable};
use super::{EXIT_NOT_RUN, Failure, exit_code_of, refusal};

/// A shell that takes longer than this to start a line is more likely to be waiting for the rest of it.
pub const NOT_STARTED_MS: u64 = 5000;
/// What depends on the shell waits for a new server to read everything back, which on a busy machine is not quick.
const READ_BACK_TIMEOUT_MS: u64 = 120_000;

/// How a request is sent: the control connection, or a fake one in a test.
pub trait Ask {
    /// Sends a request and gives its id.
    fn ask(&mut self, op: &str, args: Value, timeout_ms: u64) -> u64;
    /// Sends a request whose answer is text, after any other such request has been answered.
    fn ask_text(&mut self, op: &str, args: Value, timeout_ms: u64) -> u64;
}

impl Ask for SessionClient {
    fn ask(&mut self, op: &str, args: Value, timeout_ms: u64) -> u64 {
        self.request(op, args, timeout_ms)
    }

    fn ask_text(&mut self, op: &str, args: Value, timeout_ms: u64) -> u64 {
        self.request_text(op, args, timeout_ms)
    }
}

/// How far a run got, for what a timeout says.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Progress {
    /// The server is holding it until the shell is at a prompt.
    pub queued: bool,
    /// The shell has started it.
    pub started: bool,
}

/// What a request was for.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Purpose {
    Run,
    Commands,
    /// Its own record, by number.
    Finish {
        unsure: bool,
    },
    /// The last record, after the server restarted.
    CheckLast,
}

/// What `run` prints and how it ends.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Said {
    /// For standard output.
    pub stdout: String,
    /// For standard error.
    pub stderr: String,
}

/// One `nmux run`.
#[derive(Debug)]
#[allow(clippy::struct_excessive_bools)] // the run's flags, and what the Node code keeps, one each
pub struct Running {
    name: String,
    text: String,
    queue: bool,
    ansi: bool,
    json: bool,
    /// How far it got.
    pub progress: Progress,
    run: Option<Value>,
    forgotten: bool,
    pending: Vec<(u64, Purpose)>,
    /// The time to say the shell has not started it, armed while it may not have.
    pub not_started: bool,
    /// What to print.
    pub said: Said,
    /// How it ended, once it has.
    pub outcome: Option<Result<i32, Failure>>,
}

impl Running {
    /// A run of `text` in the session called `name`.
    pub fn new(name: &str, text: &str, queue: bool, ansi: bool, json: bool) -> Self {
        Self {
            name: name.to_owned(),
            text: text.to_owned(),
            queue,
            ansi,
            json,
            progress: Progress::default(),
            run: None,
            forgotten: false,
            pending: Vec::new(),
            not_started: false,
            said: Said::default(),
            outcome: None,
        }
    }

    /// The line.
    pub fn text(&self) -> &str {
        &self.text
    }

    fn fail(&mut self, e: Failure) {
        self.not_started = false;
        if self.outcome.is_none() {
            self.outcome = Some(Err(e));
        }
    }

    fn lost_track(&mut self) {
        let n = &self.name;
        let message =
            format!("the server of '{n}' restarted, and there is no telling what became of this: see nmux last {n}");
        self.fail(Failure::new(message, EXIT_NOT_RUN));
    }

    /// A refusal or failure of a request, as the session's words for it.
    fn refused(&mut self, code: &str, message: &str) {
        let message = refusal(&self.name, code, message);
        self.fail(Failure::new(message, EXIT_NOT_RUN));
    }

    /// Sends the line.
    pub fn start(&mut self, client: &mut impl Ask) {
        let id = client.ask("RUN", json!({ "text": self.text, "queue": self.queue }), READ_BACK_TIMEOUT_MS);
        self.pending.push((id, Purpose::Run));
    }

    fn last(&mut self, client: &mut impl Ask, seq: Option<Value>, purpose: Purpose) {
        let mut args = Map::new();
        if let Some(seq) = seq {
            args.insert("seq".to_owned(), seq);
        }
        args.insert("ansi".to_owned(), Value::from(self.ansi));
        let id = client.ask_text("LAST", Value::Object(args), READ_BACK_TIMEOUT_MS);
        self.pending.push((id, purpose));
    }

    fn show(&mut self, r: &Map<String, Value>, text: &str) {
        let field = |k: &str| r.get(k).cloned().unwrap_or(Value::Null);
        if self.json {
            let shown = json!({
                "command": field("command"), "cwd": field("cwd"), "exit": field("exit"), "durationMs": field("durationMs"),
                "complete": field("complete"), "output": text,
            });
            let _ = writeln!(self.said.stdout, "{shown}");
        } else {
            self.said.stdout.push_str(text);
        }
        if !r.get("complete").is_some_and(nmux_client::config::truthy) {
            self.said.stderr.push_str("nmux: the start of its output has already left the history\n");
        }
        let exit = r.get("exit").filter(|e| !e.is_null());
        if exit.is_none() {
            self.said.stderr.push_str("nmux: it finished, but the shell did not say how\n");
        }
        #[allow(clippy::cast_possible_truncation)] // an exit code
        let code = exit.and_then(Value::as_f64).map_or(EXIT_NOT_RUN, |e| e as i32);
        if self.outcome.is_none() {
            self.outcome = Some(Ok(code));
        }
    }

    /// The answer to a request.
    pub fn on_answer(&mut self, id: u64, result: Result<Reply, CtlError>, client: &mut impl Ask) {
        let Some(at) = self.pending.iter().position(|&(i, _)| i == id) else { return };
        let (_, purpose) = self.pending.remove(at);
        // What a request that must succeed throws: `OP: error`, with the error as its code.
        let op = match purpose {
            Purpose::Run => "RUN",
            Purpose::Commands => "COMMANDS",
            Purpose::Finish { .. } | Purpose::CheckLast => "LAST",
        };
        let data = match result {
            Ok(r) if r.ok => Ok((r.data, String::from_utf8_lossy(&r.output).into_owned())),
            Ok(r) => {
                let code = r.error.unwrap_or_else(|| "null".to_owned());
                Err(CtlError::new(&code, format!("{op}: {code}")))
            }
            Err(e) => Err(e),
        };
        match (purpose, data) {
            (Purpose::Run, Ok((data, _))) => {
                self.run = data.get("run").cloned();
                self.progress.queued = data.get("queued").is_some_and(nmux_client::config::truthy);
                self.not_started = !self.progress.queued;
            }
            (Purpose::Commands, Ok((data, _))) => {
                if data.get("state").and_then(Value::as_str) == Some("prompt") {
                    self.last(client, None, Purpose::CheckLast);
                }
            }
            (Purpose::Finish { unsure }, Ok((data, text))) => {
                let r = data.as_object().cloned().unwrap_or_default();
                if unsure {
                    let command = r
                        .get("command")
                        .filter(|c| nmux_client::config::truthy(c))
                        .map_or_else(|| "?".to_owned(), js_text);
                    let _ = writeln!(self.said.stderr, "nmux: the shell says it ran: {}", printable(&command));
                }
                self.show(&r, &text);
            }
            (Purpose::CheckLast, Ok((data, text))) => {
                let r = data.as_object().cloned().unwrap_or_default();
                match r.get("command") {
                    Some(Value::String(c)) if !same_command(c, &self.text) => self.lost_track(),
                    Some(c) if !c.is_null() && !c.is_string() => self.lost_track(),
                    _ => self.show(&r, &text),
                }
            }
            (Purpose::CheckLast, Err(e)) if e.code == "NONE" => self.lost_track(),
            (_, Err(e)) => self.refused(&e.code, &e.message),
        }
    }

    /// Something the session said happened.
    pub fn on_event(&mut self, e: &Map<String, Value>, client: &mut impl Ask) {
        let event = e.get("event").and_then(Value::as_str).unwrap_or("");
        if event == "stopped" {
            let message = format!("'{}' ended before the command did", self.name);
            self.fail(Failure::new(message, exit_code_of(e.get("lastExit"))));
        } else if self.forgotten && event == "prompt" {
            self.last(client, None, Purpose::CheckLast);
        } else if event == "command" && self.run.as_ref().is_some_and(|run| e.get("run") == Some(run)) {
            match e.get("phase").and_then(Value::as_str) {
                Some("start") => {
                    self.progress.started = true;
                    self.not_started = false;
                }
                Some("refused") => {
                    let error = e.get("error").map(js_text).unwrap_or_default();
                    self.refused(&error, &error);
                }
                Some("end") => {
                    self.not_started = false;
                    let unsure = e.get("unsure").is_some_and(nmux_client::config::truthy);
                    self.last(client, Some(e.get("seq").cloned().unwrap_or(Value::Null)), Purpose::Finish { unsure });
                }
                _ => {}
            }
        }
    }

    /// The control connection is up again, with another server, which has forgotten what it was asked.
    pub fn on_subscribed(&mut self, client: &mut impl Ask) {
        self.forgotten = true;
        // What the last server called it means nothing to this one.
        self.run = None;
        self.not_started = false;
        if self.progress.queued && !self.progress.started {
            let message =
                format!("the server of '{}' restarted before this had its turn, so it has not run", self.name);
            self.fail(Failure::new(message, EXIT_NOT_RUN));
        } else {
            let id = client.ask("COMMANDS", json!({}), READ_BACK_TIMEOUT_MS);
            self.pending.push((id, Purpose::Commands));
        }
    }

    /// The control connection went, and with it any last word: `alive` says whether the session is still there, and
    /// `last_exit` is what its state file says of its end.
    pub fn on_down(&mut self, alive: bool, last_exit: Option<&Value>) {
        if alive {
            return;
        }
        let message = format!("'{}' ended before the command did", self.name);
        self.fail(Failure::new(message, exit_code_of(last_exit)));
    }

    /// The shell has not started it after a while.
    pub fn on_not_started(&mut self) {
        if self.not_started {
            self.not_started = false;
            let n = &self.name;
            let _ = writeln!(
                self.said.stderr,
                "nmux: the shell has not started this yet; it may be waiting for the rest of it (nmux a {n})"
            );
        }
    }
}

/// Whether what a shell said it ran is the line that was typed. A line with newlines in it is said a line at a time.
pub fn same_command(said: &str, typed: &str) -> bool {
    let words =
        |s: &str| -> String { s.replace("\\\n", "").chars().filter(|c| !(c.is_whitespace() || *c == ';')).collect() };
    if typed.contains('\n') { words(typed).starts_with(&words(said)) } else { words(said) == words(typed) }
}
