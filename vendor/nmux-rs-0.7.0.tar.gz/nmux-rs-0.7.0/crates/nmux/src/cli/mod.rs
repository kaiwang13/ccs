//! The `nmux` command: `src/cli/main.js`. Thin on purpose: every decision about a session is made by the session's own
//! server. Every argument, exit code and word is the Node command's.

mod commands;
mod demo;
mod doctor;
pub mod format;
pub mod running;
pub mod sessions;
pub mod shells;
#[cfg(test)]
mod tests;

use std::collections::{BTreeSet, HashMap};
use std::fmt;
use std::path::PathBuf;

use serde_json::Value;

pub use commands::Cli;

/// The environment, as the command reads it.
pub type Env = HashMap<String, String>;

/// As `timeout` does: 124 ran out of time, 125 never got as far as the command.
pub const EXIT_TIMED_OUT: i32 = 124;
/// See [`EXIT_TIMED_OUT`].
pub const EXIT_NOT_RUN: i32 = 125;

const USAGE: &str = "nmux: terminal sessions that survive anything, with your terminal's own scrollback

  nmux                                attach, create or pick
  nmux new [NAME] [-d] [--cwd DIR] [--size CxR] [--no-integration] [--spool SIZE|--keep] [-- CMD…]
  nmux a [NAME] [--view] [--full]     attach; --view is read-only and never affects the size, --full repeats all history
  nmux ls [--json]
  nmux stop NAME|--all
  nmux restart NAME
  nmux rm NAME
  nmux rename [OLD] NEW
  nmux clients [NAME] [--json]        who is attached
  nmux kick [NAME] ID…|--others       detach them
  nmux send NAME [--no-enter] [--] TEXT…   type into a session
  nmux run NAME [--queue] [--timeout T] [--ansi] [--json] -- CMD…   run in its shell; exits as the command did
  nmux last [NAME] [--ansi] [--json]  what the last command printed
  nmux wait NAME --prompt|--exit|--text RE [--new] [--timeout T]
  nmux capture [NAME] [--lines N] [--ansi]
  nmux search PATTERN [NAME…] [--since T] [--until T] [-i] [--json]   every kept history, ended sessions too, or these
  nmux view [NAME] [--at T|--row N|--grep RE] [--times]               a session's history in a pager, kept or still running
  nmux events [NAME]                  what happens in a session, as JSON lines
  nmux demo [NAME]                    sessions full of what nmux shows, to look at: NAME, NAME-screen and NAME-days
  nmux doctor

Inside a session the keys belong to the program, except Ctrl+\\ then: d detach, c who is attached, ? help,
Ctrl+\\ a literal Ctrl+\\. Inside a session NAME defaults to that session.
";

/// A failure with an exit code of its own.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Failure {
    /// For a person.
    pub message: String,
    /// The exit code.
    pub code: i32,
}

impl Failure {
    /// A failure that exits with `code`.
    pub fn new(message: impl Into<String>, code: i32) -> Self {
        Self { message: message.into(), code }
    }
}

/// How a command fails.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum CliError {
    /// It was used wrongly: exit 2, with a hint.
    Usage(String),
    /// Something went wrong: exit 1.
    Error(String),
    /// See [`Failure`].
    Failure(Failure),
}

impl fmt::Display for CliError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Usage(m) | Self::Error(m) => f.write_str(m),
            Self::Failure(e) => f.write_str(&e.message),
        }
    }
}

impl From<Failure> for CliError {
    fn from(f: Failure) -> Self {
        Self::Failure(f)
    }
}

impl From<std::io::Error> for CliError {
    fn from(e: std::io::Error) -> Self {
        Self::Error(e.to_string())
    }
}

/// What a session's refusal means to a person.
pub fn refusal(name: &str, code: &str, message: &str) -> String {
    match code {
        "NO_INTEGRATION" => format!(
            "'{name}' has no shell integration, so its prompts cannot be told from anything else: start it with a bash, zsh or fish shell"
        ),
        "BUSY" => format!("'{name}' is running something: --queue waits for its prompt"),
        "NOT_AT_PROMPT" => format!("'{name}' is not at a prompt: --queue waits for one"),
        "TYPED" => format!("something is already typed at the prompt in '{name}', or has been printed over it"),
        "NO_PASTE" => format!("the shell in '{name}' does not take pastes, so this cannot be typed there safely"),
        "NONE" => format!("'{name}' has not finished a command"),
        "SYNTAX" => "the shell would not run that".to_owned(),
        "RESTARTED" => format!("'{name}' was restarted before the command finished"),
        "UNSUPPORTED" => format!("'{name}' started under an older nmux: nmux restart {name} brings it up to date"),
        "BAD_ARGS" => "that cannot be typed at a prompt".to_owned(),
        _ => message.to_owned(),
    }
}

/// An exit as a shell would report it: `{code, signal}`, or nothing for a clean one.
pub fn exit_code_of(e: Option<&Value>) -> i32 {
    let Some(e) = e.filter(|e| nmux_client::config::truthy(e)) else { return 0 };
    #[allow(clippy::cast_possible_truncation)] // an exit code
    if let Some(code) = e.get("code").filter(|c| !c.is_null()) {
        return code.as_f64().map_or(0, |c| c as i32);
    }
    match e.get("signal").and_then(Value::as_str).filter(|s| !s.is_empty()) {
        Some(signal) => 128 + nmux_platform::signal_number(signal).unwrap_or(0),
        None => 1,
    }
}

/// `30`, `30s`, `5m`, `1h`, `500ms` as milliseconds, or none when not given.
pub fn parse_time(text: Option<&str>) -> Result<Option<u64>, CliError> {
    let Some(text) = text else { return Ok(None) };
    let bad = || CliError::Usage(format!("bad time '{text}': for example 30s, 5m or 1h"));
    let digits = text.bytes().take_while(|b| b.is_ascii_digit() || *b == b'.').count();
    let (number, unit) = text.split_at(digits);
    let well_formed = {
        let (whole, fraction) = number.split_once('.').map_or((number, None), |(w, f)| (w, Some(f)));
        !whole.is_empty()
            && whole.bytes().all(|b| b.is_ascii_digit())
            && fraction.is_none_or(|f| !f.is_empty() && f.bytes().all(|b| b.is_ascii_digit()))
    };
    let scale = match unit {
        "ms" => 1.0,
        "" | "s" => 1000.0,
        "m" => 60_000.0,
        "h" => 3_600_000.0,
        _ => return Err(bad()),
    };
    if !well_formed {
        return Err(bad());
    }
    let n: f64 = number.parse().map_err(|_| bad())?;
    #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)] // a time, rounded up to the millisecond
    Ok(Some((n * scale).ceil() as u64))
}

/// `64M`, `1G`, `500K` as bytes.
pub fn parse_bytes(text: &str) -> Result<u64, CliError> {
    let bad = || CliError::Usage(format!("bad size '{text}': for example 64M or 1G"));
    let digits = text.bytes().take_while(u8::is_ascii_digit).count();
    let (number, unit) = text.split_at(digits);
    let scale = match unit.to_ascii_uppercase().as_str() {
        "" => 1,
        "K" => 1024,
        "M" => 1_048_576,
        "G" => 1_073_741_824,
        _ => return Err(bad()),
    };
    let n: u64 = number.parse().map_err(|_| bad())?;
    Ok(n.saturating_mul(scale))
}

/// What the arguments of a subcommand say.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Args {
    /// Flags given.
    pub flags: BTreeSet<String>,
    /// Options given, with their values.
    pub options: HashMap<String, String>,
    /// Everything else, in order.
    pub rest: Vec<String>,
    /// What came after `--`.
    pub command: Vec<String>,
}

impl Args {
    /// Whether the flag was given.
    pub fn flag(&self, name: &str) -> bool {
        self.flags.contains(name)
    }

    /// An option's value.
    pub fn option(&self, name: &str) -> Option<&str> {
        self.options.get(name).map(String::as_str)
    }
}

/// Reads arguments that know these flags and options.
pub fn parse_args(args: &[String], flags: &[&str], options: &[&str]) -> Result<Args, CliError> {
    let mut out = Args::default();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--" {
            out.command = args[i + 1..].to_vec();
            break;
        }
        if flags.contains(&a.as_str()) {
            out.flags.insert(a.clone());
        } else if options.contains(&a.as_str()) {
            let Some(value) = args.get(i + 1) else { return Err(CliError::Usage(format!("{a} needs a value"))) };
            out.options.insert(a.clone(), value.clone());
            i += 1;
        } else if a.starts_with('-') && a != "-" {
            return Err(CliError::Usage(format!("unknown option {a}")));
        } else {
            out.rest.push(a.clone());
        }
        i += 1;
    }
    Ok(out)
}

/// The directory's project, as a session name.
pub fn name_for_directory(cwd: &std::path::Path) -> String {
    let mut root = cwd.to_owned();
    let mut d = Some(cwd);
    while let Some(dir) = d {
        if dir.join(".git").exists() {
            dir.clone_into(&mut root);
            break;
        }
        d = dir.parent();
    }
    let base = root.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
    let mut name = String::new();
    let mut in_run = false;
    for c in base.chars() {
        if c.is_ascii_alphanumeric() || matches!(c, '.' | '_' | '-') {
            name.push(c);
            in_run = false;
        } else if !in_run {
            name.push('-');
            in_run = true;
        }
    }
    let name = name.trim_start_matches(|c: char| !c.is_ascii_alphanumeric());
    let name: String = name.chars().take(64).collect();
    if name.is_empty() { "shell".to_owned() } else { name }
}

/// What the command is given to work with.
#[derive(Debug)]
pub struct Io {
    /// The environment.
    pub env: Env,
    /// Where it was run.
    pub cwd: PathBuf,
}

/// Runs the command with these arguments, and gives its exit code.
pub fn main(argv: &[String]) -> i32 {
    let cmd = argv.first().map(String::as_str);
    let rest = argv.get(1..).unwrap_or_default();
    match cmd {
        Some("help" | "--help" | "-h") => {
            print!("{USAGE}");
            return 0;
        }
        Some("--version" | "-V") => {
            println!("nmux {}", env!("CARGO_PKG_VERSION"));
            return 0;
        }
        _ => {}
    }
    let env: Env = std::env::vars_os()
        .map(|(k, v)| (k.to_string_lossy().into_owned(), v.to_string_lossy().into_owned()))
        .collect();
    let cwd = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("/"));
    let mut cli = Cli::new(Io { env, cwd });
    match cli.dispatch(cmd, rest) {
        Ok(code) => code,
        Err(e) => {
            eprintln!("nmux: {e}");
            match e {
                CliError::Usage(_) => {
                    eprintln!("try 'nmux help'");
                    2
                }
                CliError::Failure(f) => f.code,
                CliError::Error(_) => 1,
            }
        }
    }
}
