//! Starting a shell so that it says what it is doing: `src/cli/shells.js`. Each one is pointed at nmux's own start-up file,
//! which runs the user's as usual and adds the marks, so nothing is written to a dotfile. This only applies to a shell started
//! as a person would start one: arguments mean someone has something particular in mind.
//!
//! The files are `shell/`, built into this binary, and written out under the runtime directory, which is this user's alone:
//! `run/shell`, as the Node command keeps them in its `shell` directory, and brought up to date the same way, by whatever
//! release runs next.

use std::fs;
use std::io::{self, Write};
use std::os::unix::fs::{DirBuilderExt, OpenOptionsExt};
use std::path::{Path, PathBuf};

use serde_json::{Map, Value, json};

const LOGIN: &str = "-l";

/// `shell/`, by the path each file has in it.
const FILES: [(&str, &str); 6] = [
    ("nmux.bash", include_str!("../../../../shell/nmux.bash")),
    ("nmux.fish", include_str!("../../../../shell/nmux.fish")),
    ("zsh/.zshenv", include_str!("../../../../shell/zsh/.zshenv")),
    ("zsh/.zshrc", include_str!("../../../../shell/zsh/.zshrc")),
    ("zsh/.zprofile", include_str!("../../../../shell/zsh/.zprofile")),
    ("zsh/hooks.zsh", include_str!("../../../../shell/zsh/hooks.zsh")),
];

/// The directory the start-up files are in, written out if they are not there as this release has them. Each is moved into
/// place whole, so that a shell never reads half of one.
pub fn shell_dir(runtime_dir: &Path) -> io::Result<PathBuf> {
    let dir = runtime_dir.join("run").join("shell");
    fs::DirBuilder::new().recursive(true).mode(0o700).create(dir.join("zsh"))?;
    for (name, text) in FILES {
        let file = dir.join(name);
        if fs::read_to_string(&file).is_ok_and(|t| t == text) {
            continue;
        }
        let tmp = dir.join(format!("{name}.{}", nmux_platform::pid()));
        let written = fs::OpenOptions::new()
            .write(true)
            .create(true)
            .truncate(true)
            .mode(0o600)
            .open(&tmp)
            .and_then(|mut f| f.write_all(text.as_bytes()))
            .and_then(|()| fs::rename(&tmp, &file));
        if let Err(e) = written {
            let _ = fs::remove_file(&tmp);
            return Err(e);
        }
    }
    Ok(dir)
}

/// What to start instead of a shell so that it says what it is doing.
#[derive(Clone, Debug, PartialEq)]
pub struct Marked {
    /// The command line.
    pub argv: Vec<String>,
    /// What to add to its environment.
    pub env: Map<String, Value>,
    /// The token that proves a mark came from it: `{token}`.
    pub shell: Value,
}

/// A word fish reads back as `text`.
fn fish_quoted(text: &str) -> String {
    let mut out = String::from("'");
    for c in text.chars() {
        if c == '\\' || c == '\'' {
            out.push('\\');
        }
        out.push(c);
    }
    out.push('\'');
    out
}

/// What to start in place of `argv`, if it is a shell with no arguments, or `-l`. `env` is the environment it would have.
/// `dir` is where the start-up files are, asked for only when it is one.
pub fn with_marks(
    argv: &[String],
    env: &Map<String, Value>,
    dir: impl FnOnce() -> io::Result<PathBuf>,
) -> Option<Marked> {
    let login = argv.get(1).is_some_and(|a| a == LOGIN);
    if argv.len() > if login { 2 } else { 1 } {
        return None;
    }
    let program = argv.first()?;
    let base = Path::new(program).file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
    if !matches!(base.as_str(), "bash" | "zsh" | "fish") {
        return None;
    }
    let dir = dir().ok()?;
    let token = super::sessions::random_hex(8);
    let shell = json!({ "token": token });
    let mut add = Map::new();
    add.insert("NMUX_SHELL_TOKEN".to_owned(), Value::from(token));
    let path = |name: &str| dir.join(name).to_string_lossy().into_owned();
    let argv = match base.as_str() {
        "bash" => {
            if login {
                add.insert("NMUX_SHELL_LOGIN".to_owned(), Value::from("1"));
            }
            vec![program.clone(), "--rcfile".to_owned(), path("nmux.bash")]
        }
        "zsh" => {
            add.insert("ZDOTDIR".to_owned(), Value::from(path("zsh")));
            if let Some(z) = env.get("ZDOTDIR") {
                add.insert("NMUX_ZDOTDIR".to_owned(), z.clone());
            }
            argv.to_vec()
        }
        _ => {
            let mut a = argv.to_vec();
            a.extend(["--init-command".to_owned(), format!("source {}", fish_quoted(&path("nmux.fish")))]);
            a
        }
    };
    Some(Marked { argv, env: add, shell })
}
