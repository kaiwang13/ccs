//! `nmux doctor`: each check says what is wrong and what to do about it. `src/cli/doctor.js`, with this binary's parts in
//! place of Node's: the native addon and node-pty are built in.

use std::fmt::Write as _;
use std::path::PathBuf;

use serde_json::{Map, Value};

use super::Env;
use super::sessions::{Paths, ensure_runtime, list_sessions};
use super::shells::with_marks;

/// Checks what nmux needs, and says how each went. 1 when one failed.
pub fn doctor(paths: &Paths, env: &Env) -> (String, i32) {
    let mut out = String::new();
    let mut failed = 0;
    let mut line = |what: &str, check: Result<String, String>| {
        let _ = match check {
            Ok(ok) => writeln!(out, "ok    {what}: {ok}"),
            Err(why) => {
                failed += 1;
                writeln!(out, "FAIL  {what}: {why}")
            }
        };
    };
    line("nmux", Ok(format!("{} (Rust)", env!("CARGO_PKG_VERSION"))));
    line("process information", Ok(nmux_platform::CAPABILITIES.proc_source.to_owned()));
    line("native addon", Ok("built in".to_owned()));
    line("pty", Ok("built in".to_owned()));
    line(
        "runtime dir",
        ensure_runtime(paths).map(|()| paths.runtime_dir().display().to_string()).map_err(|e| e.to_string()),
    );
    line(
        "TERM",
        env.get("TERM")
            .filter(|t| !t.is_empty())
            .cloned()
            .ok_or_else(|| "not set: sessions will use xterm-256color".to_owned()),
    );
    let shell = env.get("SHELL").filter(|s| !s.is_empty());
    let marks = shell.is_some_and(|s| {
        with_marks(std::slice::from_ref(s), &Map::<String, Value>::new(), || Ok(PathBuf::new())).is_some()
    });
    line(
        "shell integration",
        Ok(match shell {
            Some(s) if marks => format!("{s} can say what it is doing"),
            Some(s) => format!("{s} has none: run, last and wait --prompt will refuse"),
            None => "no $SHELL has none: run, last and wait --prompt will refuse".to_owned(),
        }),
    );
    line("sessions", Ok(format!("{} running", list_sessions(paths).iter().filter(|s| s.alive).count())));
    (out, i32::from(failed > 0))
}
