//! `test/unit/cli-run.test.js`, `test/unit/format.test.js`, and what the command reads from its arguments.

use nmux_client::ctl::{CtlError, Reply};
use serde_json::{Map, Value, json};

use super::format::{duration, is_shell, print_table, printable, state_text};
use super::running::{Ask, Running, same_command};
use super::sessions::locale_compare;
use super::shells::with_marks;
use super::{CliError, EXIT_NOT_RUN, exit_code_of, name_for_directory, parse_args, parse_bytes, parse_time};

// ---- nmux run, when the server under it restarts ---------------------------------------------------------------------

/// A control connection, with a server that does as it is told.
#[derive(Default)]
struct Fake {
    sent: Vec<(u64, String, Value)>,
    next: u64,
}

impl Ask for Fake {
    fn ask(&mut self, op: &str, args: Value, _timeout_ms: u64) -> u64 {
        self.next += 1;
        self.sent.push((self.next, op.to_owned(), args));
        self.next
    }

    fn ask_text(&mut self, op: &str, args: Value, timeout_ms: u64) -> u64 {
        self.ask(op, args, timeout_ms)
    }
}

impl Fake {
    /// The id of the last request for `op`.
    fn last(&self, op: &str) -> u64 {
        self.sent.iter().rev().find(|(_, o, _)| o == op).map(|(id, _, _)| *id).unwrap()
    }

    fn count(&self, op: &str) -> usize {
        self.sent.iter().filter(|(_, o, _)| o == op).count()
    }
}

#[allow(clippy::unnecessary_wraps)] // what an answer is
fn ok(data: Value, text: &str) -> Result<Reply, CtlError> {
    Ok(Reply { ok: true, data, error: None, output: text.as_bytes().to_vec() })
}

#[allow(clippy::unnecessary_wraps)] // what an answer is
fn refused(error: &str) -> Result<Reply, CtlError> {
    Ok(Reply { ok: false, data: Value::Null, error: Some(error.to_owned()), output: Vec::new() })
}

fn event(v: Value) -> Map<String, Value> {
    let Value::Object(map) = v else { panic!("an event is an object") };
    map
}

/// A run the server has, with this answer to RUN.
fn started(text: &str, queue: bool, run_reply: Value) -> (Running, Fake) {
    let mut client = Fake::default();
    let mut r = Running::new("s", text, queue, false, false);
    r.start(&mut client);
    let id = client.last("RUN");
    r.on_answer(id, ok(run_reply, ""), &mut client);
    (r, client)
}

/// Another server comes, and is asked where things stand: at a prompt, and the last record is `last`.
fn restarted(r: &mut Running, client: &mut Fake, last: Result<Reply, CtlError>) {
    r.on_subscribed(client);
    let id = client.last("COMMANDS");
    r.on_answer(id, ok(json!({ "state": "prompt" }), ""), client);
    let id = client.last("LAST");
    r.on_answer(id, last, client);
}

fn not_run(r: &Running) -> bool {
    matches!(&r.outcome, Some(Err(f)) if f.code == EXIT_NOT_RUN)
}

#[test]
fn another_server_and_the_last_thing_to_finish_is_another_command_that_is_not_reported_as_this_one() {
    let (mut r, mut client) = started("make test", false, json!({ "run": 1 }));
    restarted(&mut r, &mut client, ok(json!({ "command": "echo other", "exit": 0, "complete": true }), "other\n"));
    assert!(not_run(&r));
    assert_eq!(r.said.stdout, "");
}

#[test]
fn another_server_and_the_last_thing_to_finish_is_this_one_its_result_stands() {
    let (mut r, mut client) = started("make test", false, json!({ "run": 1 }));
    restarted(&mut r, &mut client, ok(json!({ "command": "make test", "exit": 3, "complete": true }), "failed\n"));
    assert_eq!(r.outcome, Some(Ok(3)));
    assert_eq!(r.said.stdout, "failed\n");
}

#[test]
fn another_server_with_the_command_not_known_by_name_its_result_is_taken_on_trust() {
    let (mut r, mut client) = started("make test", false, json!({ "run": 1 }));
    restarted(&mut r, &mut client, ok(json!({ "command": null, "exit": 1, "complete": false }), ""));
    assert_eq!(r.outcome, Some(Ok(1)));
    assert_eq!(r.said.stderr, "nmux: the start of its output has already left the history\n");
}

#[test]
fn another_server_and_nothing_at_all_has_finished_there_is_no_telling() {
    let (mut r, mut client) = started("make test", false, json!({ "run": 1 }));
    restarted(&mut r, &mut client, refused("NONE"));
    assert!(not_run(&r));
}

#[test]
fn another_server_while_it_was_queued_it_has_not_run_and_is_not_sent_again() {
    let (mut r, mut client) = started("make test", true, json!({ "run": 1, "queued": true }));
    r.on_subscribed(&mut client);
    assert!(matches!(&r.outcome, Some(Err(f)) if f.code == EXIT_NOT_RUN && f.message.contains("has not run")));
    assert_eq!(client.count("RUN"), 1);
}

#[test]
fn events_about_other_commands_mean_nothing_to_a_run_before_or_after_it_has_its_number() {
    let mut client = Fake::default();
    let mut r = Running::new("s", "mine", false, false, false);
    r.start(&mut client);
    r.on_event(&event(json!({ "event": "command", "phase": "end", "run": null, "seq": 1 })), &mut client);
    let id = client.last("RUN");
    r.on_answer(id, ok(json!({ "run": 1 }), ""), &mut client);
    r.on_event(&event(json!({ "event": "command", "phase": "end", "run": 2, "seq": 2 })), &mut client);
    r.on_event(&event(json!({ "event": "command", "phase": "end", "run": null, "seq": 3 })), &mut client);
    assert_eq!(client.count("LAST"), 0);
    assert_eq!(r.outcome, None);
    r.on_event(&event(json!({ "event": "command", "phase": "end", "run": 1, "seq": 4 })), &mut client);
    assert_eq!(
        client.sent.last().map(|(_, op, args)| (op.as_str(), args.clone())),
        Some(("LAST", json!({ "seq": 4, "ansi": false })))
    );
    let id = client.last("LAST");
    r.on_answer(id, ok(json!({ "command": "mine", "exit": 0, "complete": true }), ""), &mut client);
    assert_eq!(r.outcome, Some(Ok(0)));
}

#[test]
fn a_refusal_is_said_in_the_words_for_it_and_a_session_that_ends_takes_the_run_with_it() {
    let mut client = Fake::default();
    let mut r = Running::new("s", "x", false, false, false);
    r.start(&mut client);
    r.on_answer(client.last("RUN"), refused("BUSY"), &mut client);
    assert!(
        matches!(&r.outcome, Some(Err(f)) if f.message == "'s' is running something: --queue waits for its prompt")
    );
    let (mut r, mut client) = started("x", false, json!({ "run": 1 }));
    assert!(r.not_started, "the time to say it has not started is armed");
    r.on_event(&event(json!({ "event": "command", "phase": "start", "run": 1 })), &mut client);
    assert!(!r.not_started);
    r.on_event(&event(json!({ "event": "stopped", "lastExit": { "code": null, "signal": "SIGTERM" } })), &mut client);
    assert!(matches!(&r.outcome, Some(Err(f)) if f.code == 143 && f.message == "'s' ended before the command did"));
}

#[test]
fn json_says_the_record_and_its_output() {
    let mut client = Fake::default();
    let mut r = Running::new("s", "x", false, false, true);
    r.start(&mut client);
    r.on_answer(client.last("RUN"), ok(json!({ "run": 1 }), ""), &mut client);
    r.on_event(&event(json!({ "event": "command", "phase": "end", "run": 1, "seq": 9, "unsure": true })), &mut client);
    let last = json!({ "command": "x\u{1b}", "cwd": "/w", "exit": null, "durationMs": 5, "complete": true, "seq": 9 });
    r.on_answer(client.last("LAST"), ok(last, "out\n"), &mut client);
    assert_eq!(
        r.said.stdout,
        "{\"command\":\"x\\u001b\",\"cwd\":\"/w\",\"exit\":null,\"durationMs\":5,\"complete\":true,\"output\":\"out\\n\"}\n"
    );
    assert_eq!(r.said.stderr, "nmux: the shell says it ran: x?\nnmux: it finished, but the shell did not say how\n");
    assert_eq!(r.outcome, Some(Ok(EXIT_NOT_RUN)));
}

#[test]
fn a_line_is_the_one_typed_whatever_spaces_and_semicolons_a_shell_reports_it_with() {
    assert!(same_command("make  test;", "make test"));
    assert!(!same_command("make", "make test"));
    assert!(same_command("echo a", "echo a\\\n; echo b\n"), "a line of several is said a line at a time");
}

// ---- how the command shows things ------------------------------------------------------------------------------------

#[test]
fn nothing_a_process_or_a_filename_contains_can_drive_the_terminal() {
    let mut out = String::new();
    print_table(&mut out, &["A", "B"], &[vec!["\x1b]52;c;aGk=\x07x".to_owned(), "y\u{9b}31m".to_owned()]]);
    assert!(!out.chars().any(|c| matches!(c, '\0'..='\x09' | '\x0b'..='\x1f' | '\x7f'..='\u{9f}')), "{out:?}");
    assert_eq!(printable("ok text"), "ok text");
}

#[test]
fn a_shell_at_a_prompt_is_idle_a_shell_running_a_script_is_not() {
    assert!(is_shell(Some("-bash")));
    assert!(is_shell(Some("/usr/bin/zsh -l")));
    assert!(!is_shell(Some("/bin/sh -c make test")));
    assert!(!is_shell(Some("vim notes")));
    let status = |v: Value| state_text(true, None, Some(&v), 0);
    assert_eq!(
        status(json!({ "lifecycle": "RUNNING", "idleMs": 120_000, "foreground": { "command": "-bash" } })),
        "idle 2m"
    );
    assert_eq!(
        status(json!({ "lifecycle": "RUNNING", "foreground": { "command": "make test" } })),
        "running: make test"
    );
    assert_eq!(state_text(false, Some(&json!({ "restarts": { "lastExit": { "code": 3 } } })), None, 0), "exited (3)");
    assert_eq!(duration(90 * 60_000), "1h");
    assert_eq!(status(json!({ "lifecycle": "STOPPING" })), "stopping");
    assert_eq!(
        status(json!({ "lifecycle": "RUNNING", "idleMs": null, "shell": { "last": { "exit": 2 } } })),
        "idle · last: exit 2"
    );
    let long =
        json!({ "lifecycle": "RUNNING", "shell": { "current": { "command": "x".repeat(40), "startedAt": -61_000 } } });
    assert_eq!(status(long), format!("running: {}… (1m01s)", "x".repeat(35)));
}

#[test]
fn a_table_is_as_wide_as_what_is_in_it() {
    let mut out = String::new();
    print_table(
        &mut out,
        &["  NAME", "STATE"],
        &[vec!["* api".to_owned(), "idle".to_owned()], vec!["  a".to_owned(), "–".to_owned()]],
    );
    assert_eq!(out, "  NAME  STATE\n* api   idle\n  a     –\n");
}

// ---- arguments ---------------------------------------------------------------------------------------------------------

fn words(s: &[&str]) -> Vec<String> {
    s.iter().map(|w| (*w).to_owned()).collect()
}

#[test]
fn arguments_are_flags_options_names_and_a_command() {
    let a = parse_args(&words(&["x", "-d", "--cwd", "/w", "y", "--", "-z", "--cwd"]), &["-d"], &["--cwd"]).unwrap();
    assert!(a.flag("-d"));
    assert_eq!(a.option("--cwd"), Some("/w"));
    assert_eq!(a.rest, words(&["x", "y"]));
    assert_eq!(a.command, words(&["-z", "--cwd"]));
    assert_eq!(parse_args(&words(&["--what"]), &[], &[]), Err(CliError::Usage("unknown option --what".to_owned())));
    assert_eq!(parse_args(&words(&["--cwd"]), &[], &["--cwd"]), Err(CliError::Usage("--cwd needs a value".to_owned())));
    assert_eq!(parse_args(&words(&["-"]), &[], &[]).unwrap().rest, words(&["-"]));
}

#[test]
fn times_and_sizes_are_written_as_a_person_writes_them() {
    assert_eq!(parse_time(Some("30")), Ok(Some(30_000)));
    assert_eq!(parse_time(Some("1.5m")), Ok(Some(90_000)));
    assert_eq!(parse_time(Some("500ms")), Ok(Some(500)));
    assert_eq!(parse_time(None), Ok(None));
    assert_eq!(parse_time(Some("5 m")), Err(CliError::Usage("bad time '5 m': for example 30s, 5m or 1h".to_owned())));
    assert_eq!(parse_bytes("64M"), Ok(64 << 20));
    assert_eq!(parse_bytes("1g"), Ok(1 << 30));
    assert_eq!(parse_bytes("500"), Ok(500));
    assert_eq!(parse_bytes("5B"), Err(CliError::Usage("bad size '5B': for example 64M or 1G".to_owned())));
}

#[test]
fn an_exit_is_reported_as_a_shell_would() {
    assert_eq!(exit_code_of(None), 0);
    assert_eq!(exit_code_of(Some(&json!({ "code": 3, "signal": null }))), 3);
    assert_eq!(exit_code_of(Some(&json!({ "code": null, "signal": "SIGHUP" }))), 129);
    assert_eq!(exit_code_of(Some(&json!({ "code": null, "signal": null }))), 1);
}

#[test]
fn a_session_is_named_after_its_project() {
    let dir = std::env::temp_dir().join(format!("nmux-names-{}", std::process::id()));
    let project = dir.join("my project!!").join("sub dir");
    std::fs::create_dir_all(&project).unwrap();
    std::fs::create_dir(dir.join("my project!!").join(".git")).unwrap();
    assert_eq!(name_for_directory(&project), "my-project-");
    assert_eq!(name_for_directory(std::path::Path::new("/")), "shell");
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn sessions_are_listed_as_localecompare_orders_them() {
    // What Node's localeCompare said of these.
    let mut names = vec![
        "b", "B", "a_b", "a-b", "a.b", "ab", "A", "10", "9", "a", "Ab", "aB", "a1", "a-", "a_", "s10", "s9", "S-x",
        "s.x",
    ];
    names.sort_by(|a, b| locale_compare(a, b));
    assert_eq!(
        names,
        [
            "10", "9", "a", "A", "a_", "a_b", "a-", "a-b", "a.b", "a1", "ab", "aB", "Ab", "b", "B", "S-x", "s.x",
            "s10", "s9"
        ]
    );
}

#[test]
fn a_shell_started_as_a_person_would_start_one_is_pointed_at_nmuxs_start_up_files() {
    let dir = || Ok(std::path::PathBuf::from("/rt/run/shell"));
    let env = Map::new();
    let bash = with_marks(&words(&["/bin/bash", "-l"]), &env, dir).unwrap();
    assert_eq!(bash.argv, words(&["/bin/bash", "--rcfile", "/rt/run/shell/nmux.bash"]));
    assert_eq!(bash.env.keys().collect::<Vec<_>>(), ["NMUX_SHELL_TOKEN", "NMUX_SHELL_LOGIN"]);
    let mut with_zdotdir = Map::new();
    with_zdotdir.insert("ZDOTDIR".to_owned(), Value::from("/mine"));
    let zsh = with_marks(&words(&["zsh"]), &with_zdotdir, dir).unwrap();
    assert_eq!(zsh.argv, words(&["zsh"]));
    assert_eq!(zsh.env["ZDOTDIR"], "/rt/run/shell/zsh");
    assert_eq!(zsh.env["NMUX_ZDOTDIR"], "/mine");
    let fish = with_marks(&words(&["fish"]), &env, dir).unwrap();
    assert_eq!(fish.argv, words(&["fish", "--init-command", "source '/rt/run/shell/nmux.fish'"]));
    assert_eq!(with_marks(&words(&["bash", "-c", "x"]), &env, dir), None, "arguments mean something particular");
    assert_eq!(with_marks(&words(&["/bin/sh"]), &env, dir), None);
}

#[test]
fn at_once_answers_in_the_order_asked_whichever_comes_first() {
    let slow_first = super::sessions::at_once(vec![30_u64, 0, 10], |ms| {
        std::thread::sleep(std::time::Duration::from_millis(ms));
        ms
    });
    assert_eq!(slow_first, [30, 0, 10]);
}
