//! Which sessions exist: `src/cli/sessions.js`. A session is a directory under the runtime dir, named by a random id that
//! never changes; its name is a field of `session.json`, so a rename moves no socket. The dir is `/tmp/nmux-<uid>` and not
//! `$XDG_RUNTIME_DIR`, because logging out removes the latter while the sessions in it keep running.

use std::cmp::Ordering;
use std::fmt::Write as _;
use std::fs;
use std::io::{self, Read, Write};
use std::os::unix::fs::{DirBuilderExt, OpenOptionsExt};
use std::path::{Component, Path, PathBuf};
use std::time::{Duration, Instant};

use nmux_client::ctl::{control_request, probe_socket};
use nmux_platform::{Lock, is_locked, try_lock};
use nmux_wire::Layout;
use serde_json::{Map, Value, json};

use super::{CliError, Env};

const LOCK_TRIES: usize = 200;
const START_WAIT_MS: u64 = 10_000;
const STATUS_WAIT_MS: u64 = 1500;

/// Where everything is, as `resolvePaths` works it out.
#[derive(Clone, Debug)]
pub struct Paths {
    /// Sockets, locks and logs.
    pub layout: Layout,
    /// The configuration file.
    pub config_file: PathBuf,
    /// Where kept histories go. It outlives sessions and reboots, so it is not under the runtime dir.
    pub history_dir: PathBuf,
    /// Held while a name is chosen.
    pub names_lock: PathBuf,
}

/// `path.resolve`: absolute, with `.` and `..` worked out.
pub fn resolve_path(base: &Path, p: &str) -> PathBuf {
    let joined = base.join(p);
    let mut out = PathBuf::from("/");
    for c in joined.components() {
        match c {
            Component::ParentDir => {
                out.pop();
            }
            Component::Normal(n) => out.push(n),
            Component::RootDir | Component::CurDir | Component::Prefix(_) => {}
        }
    }
    out
}

impl Paths {
    /// The paths for this environment.
    pub fn resolve(env: &Env, cwd: &Path) -> Self {
        let get = |k: &str| env.get(k).filter(|v| !v.is_empty()).cloned();
        let uid = nmux_platform::uid();
        let runtime = get("NMUX_RUNTIME_DIR").unwrap_or_else(|| format!("/tmp/nmux-{uid}"));
        let runtime_dir = resolve_path(cwd, &runtime);
        let home = get("HOME").unwrap_or_else(|| "/".to_owned());
        let config_home = get("XDG_CONFIG_HOME").map_or_else(|| Path::new(&home).join(".config"), PathBuf::from);
        let state_home =
            get("XDG_STATE_HOME").map_or_else(|| Path::new(&home).join(".local").join("state"), PathBuf::from);
        Self {
            config_file: get("NMUX_CONFIG").map_or_else(|| config_home.join("nmux").join("config.json"), PathBuf::from),
            history_dir: get("NMUX_HISTORY_DIR").map_or_else(|| state_home.join("nmux").join("history"), PathBuf::from),
            names_lock: runtime_dir.join("locks").join("names.lock"),
            layout: Layout::new(runtime_dir),
        }
    }

    /// The runtime directory.
    pub fn runtime_dir(&self) -> &Path {
        self.layout.runtime_dir()
    }

    /// `s/<id>`.
    pub fn session_dir(&self, id: &str) -> PathBuf {
        self.layout.session_dir(id).unwrap_or_else(|_| self.runtime_dir().join("s").join(id))
    }

    /// The server's socket.
    pub fn ctl_sock(&self, id: &str) -> PathBuf {
        self.session_dir(id).join("ctl.sock")
    }

    /// The session's spec.
    pub fn spec_file(&self, id: &str) -> PathBuf {
        self.session_dir(id).join("session.json")
    }

    /// What its server writes about it.
    pub fn state_file(&self, id: &str) -> PathBuf {
        self.session_dir(id).join("state.json")
    }

    /// Held while the command that creates it is still at it.
    pub fn starting_lock(&self, id: &str) -> PathBuf {
        self.session_dir(id).join("starting.lock")
    }

    /// Held by its holder.
    pub fn holder_lock(&self, id: &str) -> PathBuf {
        self.session_dir(id).join("holder.lock")
    }

    /// Held by its server.
    pub fn sessiond_lock(&self, id: &str) -> PathBuf {
        self.session_dir(id).join("sessiond.lock")
    }

    /// Where its server logs.
    pub fn log_file(&self, id: &str, component: &str) -> PathBuf {
        self.layout
            .log_file(id, component)
            .unwrap_or_else(|_| self.layout.log_dir().join(id).join(format!("{component}.log")))
    }
}

/// A session as its files say.
#[derive(Clone, Debug)]
pub struct Session {
    /// Its id.
    pub id: String,
    /// Its name.
    pub name: String,
    /// `session.json`.
    pub spec: Value,
    /// `state.json`, if there is one.
    pub state: Option<Value>,
    /// Something holds it: its holder, its server, or the command still creating it.
    pub alive: bool,
}

impl Session {
    /// How its program last ended, from `state.json`.
    pub fn last_exit(&self) -> Option<&Value> {
        self.state.as_ref()?.get("restarts")?.get("lastExit")
    }
}

/// `letters, digits, '.', '_' and '-'`, starting with a letter or digit, up to 64.
pub fn valid_name(name: &str) -> bool {
    nmux_wire::segment("name", name).is_ok()
}

/// A JSON object from a file, or none.
pub fn read_json(file: &Path) -> Option<Value> {
    let mut text = String::new();
    fs::File::open(file).ok()?.read_to_string(&mut text).ok()?;
    serde_json::from_str(&text).ok()
}

fn locked(path: &Path) -> bool {
    is_locked(path).unwrap_or(false)
}

/// Something holds this session: its holder, its server, or the command still creating it.
pub fn is_alive(paths: &Paths, id: &str) -> bool {
    locked(&paths.holder_lock(id)) || locked(&paths.sessiond_lock(id)) || locked(&paths.starting_lock(id))
}

/// Where a character of a session's name sorts, as `localeCompare` sorts them: punctuation, then digits, then letters
/// whatever their case.
fn primary(c: char) -> (u32, u32) {
    match c {
        '_' => (1, 0),
        '-' => (2, 0),
        '.' => (3, 0),
        '0'..='9' => (10, u32::from(c)),
        'a'..='z' | 'A'..='Z' => (20, u32::from(c.to_ascii_lowercase())),
        other => (5, u32::from(other)),
    }
}

/// `a.localeCompare(b)` for the names sessions have: by letter first, and lowercase before uppercase only where nothing
/// else differs.
pub fn locale_compare(a: &str, b: &str) -> Ordering {
    a.chars()
        .map(primary)
        .cmp(b.chars().map(primary))
        .then_with(|| a.chars().map(|c| c.is_ascii_uppercase()).cmp(b.chars().map(|c| c.is_ascii_uppercase())))
}

/// Every session there is, by name.
pub fn list_sessions(paths: &Paths) -> Vec<Session> {
    let Ok(entries) = fs::read_dir(paths.runtime_dir().join("s")) else { return Vec::new() };
    let mut out = Vec::new();
    for entry in entries.flatten() {
        let id = entry.file_name().to_string_lossy().into_owned();
        if paths.layout.session_dir(&id).is_err() {
            continue;
        }
        let Some(spec) = read_json(&paths.spec_file(&id)) else { continue };
        let name = spec.get("name").map(super::format::js_text).unwrap_or_default();
        let state = read_json(&paths.state_file(&id));
        let alive = is_alive(paths, &id);
        out.push(Session { id, name, spec, state, alive });
    }
    out.sort_by(|a, b| locale_compare(&a.name, &b.name));
    out
}

/// The session with this name.
pub fn find_session(paths: &Paths, name: &str) -> Option<Session> {
    list_sessions(paths).into_iter().find(|s| s.name == name)
}

/// Makes the runtime directory, or says why it cannot be used.
pub fn ensure_runtime(paths: &Paths) -> Result<(), CliError> {
    nmux_platform::ensure_runtime(paths.runtime_dir(), nmux_platform::uid()).map_err(|e| CliError::Error(e.to_string()))
}

/// While nobody else is choosing a name.
fn with_names<T>(paths: &Paths, f: impl FnOnce() -> Result<T, CliError>) -> Result<T, CliError> {
    ensure_runtime(paths)?;
    for _ in 0..LOCK_TRIES {
        let lock = try_lock(&paths.names_lock).map_err(|e| CliError::Error(e.to_string()))?;
        if let Some(mut lock) = lock {
            let out = f();
            lock.release();
            return out;
        }
        std::thread::sleep(Duration::from_millis(10));
    }
    Err(CliError::Error("another nmux has held the session list for too long".to_owned()))
}

/// The first of `base`, `base-2`, `base-3`… no session uses.
fn free_name(paths: &Paths, base: &str) -> String {
    let taken: Vec<String> = list_sessions(paths).into_iter().map(|s| s.name).collect();
    if !taken.iter().any(|n| n == base) {
        return base.to_owned();
    }
    // There are only so many sessions, so one of as many names again is free.
    (2..=taken.len() + 2).map(|n| format!("{base}-{n}")).find(|n| !taken.contains(n)).unwrap_or_default()
}

/// Writes JSON as `writeAtomic` does: to a file of its own beside it, synced, then renamed over it.
pub fn write_atomic(file: &Path, value: &Value) -> io::Result<()> {
    let mut data = serde_json::to_string_pretty(value).map_err(io::Error::other)?;
    data.push('\n');
    let tmp = file.with_file_name(format!(
        "{}.tmp.{}.{}",
        file.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default(),
        nmux_platform::pid(),
        random_hex(4)
    ));
    let written = (|| {
        let mut f = fs::OpenOptions::new().write(true).create_new(true).mode(0o600).open(&tmp)?;
        f.write_all(data.as_bytes())?;
        f.sync_all()?;
        drop(f);
        fs::rename(&tmp, file)
    })();
    if written.is_err() {
        let _ = fs::remove_file(&tmp);
    }
    written?;
    if let Some(dir) = file.parent() {
        // Best effort: some filesystems refuse to sync a directory.
        let _ = fs::File::open(dir).and_then(|d| d.sync_all());
    }
    Ok(())
}

/// `n` random bytes, as hex.
pub fn random_hex(n: usize) -> String {
    let mut bytes = vec![0u8; n];
    let read = fs::File::open("/dev/urandom").and_then(|mut f| f.read_exact(&mut bytes));
    if read.is_err() {
        // No randomness to be had: what changes from moment to moment will do for a name.
        let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map_or(0, |d| d.as_nanos());
        let seed = (t ^ (u128::from(nmux_platform::pid().unsigned_abs()) << 64)).to_le_bytes();
        for (i, b) in bytes.iter_mut().enumerate() {
            *b = seed[i % seed.len()];
        }
    }
    bytes.iter().fold(String::new(), |mut s, b| {
        let _ = write!(s, "{b:02x}");
        s
    })
}

/// Starts the server of a session whose spec is on disk, as `startServer` does: this binary as `nmux __server --spec FILE`,
/// or the binary `NMUX_SERVER_BIN` names, the same way.
pub fn start_server(paths: &Paths, env: &Env, id: &str, recover: bool, wait_for_client: bool) -> Result<(), CliError> {
    let bin = match env.get("NMUX_SERVER_BIN").filter(|b| !b.is_empty()) {
        Some(bin) => bin.clone(),
        None => std::env::current_exe().map_err(|e| CliError::Error(e.to_string()))?.to_string_lossy().into_owned(),
    };
    let mut argv =
        vec![bin, "__server".to_owned(), "--spec".to_owned(), paths.spec_file(id).to_string_lossy().into_owned()];
    if recover {
        argv.push("--recover".to_owned());
    }
    if wait_for_client {
        argv.push("--wait-for-client".to_owned());
    }
    nmux_platform::spawn_detached(&argv, Path::new("/")).map_err(|e| CliError::Error(e.to_string()))?;
    Ok(())
}

/// Waits until the session answers that it is running, and gives what it said.
pub fn wait_running(paths: &Paths, id: &str) -> Result<Value, CliError> {
    let deadline = Instant::now() + Duration::from_millis(START_WAIT_MS);
    loop {
        if let Ok(r) = control_request(&paths.ctl_sock(id), "STATUS", json!({}), 1000, "cli") {
            let lifecycle = r.data.get("lifecycle").and_then(Value::as_str);
            if r.ok && !matches!(lifecycle, Some("STARTING" | "RECOVERING")) {
                return Ok(r.data);
            }
        }
        if Instant::now() > deadline {
            return Err(CliError::Error(format!(
                "the session did not start; see {}",
                paths.log_file(id, "sessiond").display()
            )));
        }
        std::thread::sleep(Duration::from_millis(20));
    }
}

/// Waits until the server is listening.
fn wait_listening(paths: &Paths, id: &str) -> Result<(), CliError> {
    let deadline = Instant::now() + Duration::from_millis(START_WAIT_MS);
    while !probe_socket(&paths.ctl_sock(id)) {
        if Instant::now() > deadline {
            return Err(CliError::Error(format!(
                "the session did not start; see {}",
                paths.log_file(id, "sessiond").display()
            )));
        }
        std::thread::sleep(Duration::from_millis(10));
    }
    Ok(())
}

/// What a new session is made of.
#[derive(Debug)]
pub struct NewSession<'a> {
    /// Its name, or none to take one from the directory.
    pub name: Option<&'a str>,
    /// The name it takes when it is given none.
    pub base: &'a str,
    /// Its program.
    pub argv: Vec<String>,
    /// Where it starts.
    pub cwd: &'a Path,
    /// Its program's environment, in order.
    pub env: Map<String, Value>,
    /// Its terminal's size.
    pub cols: u32,
    /// See `cols`.
    pub rows: u32,
    /// `TERM`.
    pub term: &'a str,
    /// A terminal is about to attach, so the program starts when it arrives: nothing it prints, however briefly it runs,
    /// can go unseen.
    pub attaching: bool,
    /// The shell's token, when it says what it is doing.
    pub shell: Option<Value>,
    /// Its spool: `{maxBytes}`, or `{maxBytes: 0, keep: true, root}`.
    pub spool: Option<Spool>,
}

/// Where a session's output goes once it leaves the history.
#[derive(Clone, Debug)]
pub enum Spool {
    /// Up to this many bytes, in the session's directory.
    Bytes(u64),
    /// All of it, kept under this directory after the session has gone.
    Keep(PathBuf),
}

/// Makes a session and starts its server. Its id and name.
pub fn create_session(paths: &Paths, env: &Env, o: &NewSession<'_>) -> Result<(String, String), CliError> {
    let id = random_hex(4);
    let mut starting: Option<Lock> = None;
    let chosen = with_names(paths, || {
        if let Some(name) = o.name {
            if find_session(paths, name).is_some() {
                return Err(CliError::Error(format!("a session named '{name}' already exists")));
            }
        }
        let n = o.name.map_or_else(|| free_name(paths, o.base), str::to_owned);
        let dir = paths.session_dir(&id);
        fs::DirBuilder::new().recursive(true).mode(0o700).create(&dir).map_err(|e| CliError::Error(e.to_string()))?;
        starting = try_lock(&paths.starting_lock(&id)).ok().flatten();
        // A shell keeps the agent it started with long after that connection has gone. So it is given one name for it, which
        // follows whoever attaches.
        let agent = o.env.get("SSH_AUTH_SOCK").and_then(Value::as_str).filter(|s| !s.is_empty()).map(str::to_owned);
        let link = agent.as_ref().map(|_| dir.join("agent.sock"));
        if let (Some(target), Some(link)) = (&agent, &link) {
            std::os::unix::fs::symlink(target, link).map_err(|e| CliError::Error(e.to_string()))?;
        }
        let mut child_env = o.env.clone();
        child_env.insert("NMUX_ID".to_owned(), Value::from(id.clone()));
        child_env.insert("NMUX_SESSION".to_owned(), Value::from(n.clone()));
        let link_text = link.as_ref().map(|l| l.to_string_lossy().into_owned());
        if let Some(l) = &link_text {
            child_env.insert("SSH_AUTH_SOCK".to_owned(), Value::from(l.clone()));
        }
        let spool = match &o.spool {
            Some(Spool::Keep(root)) => json!({ "maxBytes": 0, "keep": true, "dir": root.join(&id).to_string_lossy() }),
            Some(Spool::Bytes(n)) => json!({ "maxBytes": n }),
            None => Value::Null,
        };
        let spec = json!({
            "schema": "nmux.session/1",
            "id": id,
            "name": n,
            "runtimeDir": paths.runtime_dir().to_string_lossy(),
            "stateFile": paths.state_file(&id).to_string_lossy(),
            "configFile": paths.config_file.to_string_lossy(),
            "child": { "argv": o.argv, "env": child_env, "cwd": o.cwd.to_string_lossy() },
            "pty": { "cols": o.cols, "rows": o.rows },
            "term": o.term,
            "nestEnv": "NMUX_ID",
            "shell": o.shell.clone().unwrap_or(Value::Null),
            "agent": link_text,
            "spool": spool,
            "createdAt": nmux_time::iso(now_ms()),
        });
        write_atomic(&paths.spec_file(&id), &spec).map_err(|e| CliError::Error(e.to_string()))?;
        Ok(n)
    })?;
    let started = start_server(paths, env, &id, false, o.attaching)
        .and_then(|()| if o.attaching { wait_listening(paths, &id) } else { wait_running(paths, &id).map(|_| ()) });
    if let Some(mut lock) = starting {
        lock.release();
    }
    started?;
    Ok((id, chosen))
}

/// Renames a session in its spec.
pub fn rename_session(paths: &Paths, id: &str, name: &str) -> Result<(), CliError> {
    with_names(paths, || {
        if find_session(paths, name).is_some() {
            return Err(CliError::Error(format!("a session named '{name}' already exists")));
        }
        let file = paths.spec_file(id);
        let mut spec = read_json(&file).unwrap_or_else(|| json!({}));
        if let Some(obj) = spec.as_object_mut() {
            obj.insert("name".to_owned(), Value::from(name));
        }
        if let Some(env) = spec.get_mut("child").and_then(|c| c.get_mut("env")).and_then(Value::as_object_mut) {
            env.insert("NMUX_SESSION".to_owned(), Value::from(name));
        }
        write_atomic(&file, &spec).map_err(|e| CliError::Error(e.to_string()))
    })
}

/// Removes what is left of a session.
pub fn remove_session(paths: &Paths, id: &str) {
    let _ = fs::remove_dir_all(paths.session_dir(id));
    let _ = fs::remove_dir_all(paths.layout.log_dir().join(id));
}

/// What a live session says about itself, or none when it does not answer in time.
pub fn status_of(paths: &Paths, id: &str) -> Option<Value> {
    let r = control_request(&paths.ctl_sock(id), "STATUS", json!({}), STATUS_WAIT_MS, "cli").ok()?;
    r.ok.then_some(r.data)
}

/// `f` for each item at once, as Node's `Promise.all` asks every session together: one that does not answer costs its wait
/// once, not once for each session after it. The answers are in the items' order.
pub fn at_once<T: Send, R: Send>(items: Vec<T>, f: impl Fn(T) -> R + Sync) -> Vec<R> {
    let f = &f;
    std::thread::scope(|scope| {
        let asked: Vec<_> = items.into_iter().map(|item| scope.spawn(move || f(item))).collect();
        asked.into_iter().map(|a| a.join().unwrap_or_else(|panic| std::panic::resume_unwind(panic))).collect()
    })
}

/// Milliseconds since 1970.
pub fn now_ms() -> i64 {
    let d = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default();
    i64::try_from(d.as_millis()).unwrap_or(i64::MAX)
}
