//! How the command shows things to a person: `src/cli/format.js`, and `span` from `src/server/messages.js`. `--json` never
//! comes through here.

use serde_json::Value;

const SHELLS: [&str; 11] = ["bash", "zsh", "fish", "sh", "dash", "ksh", "tcsh", "csh", "nu", "elvish", "xonsh"];
const COMMAND_WIDTH: usize = 36;

/// How long something took, roughly: `42s`, `5m`, `3h`, `2d`.
pub fn duration(ms: i64) -> String {
    let s = ms.max(0) / 1000;
    if s < 60 {
        return format!("{s}s");
    }
    let m = s / 60;
    if m < 60 {
        return format!("{m}m");
    }
    let h = m / 60;
    if h < 48 { format!("{h}h") } else { format!("{}d", h / 24) }
}

/// To the second, for something still going.
pub fn elapsed(ms: i64) -> String {
    let s = ms.max(0) / 1000;
    if s < 60 {
        return format!("{s}s");
    }
    let m = s / 60;
    if m < 60 { format!("{m}m{:02}s", s % 60) } else { duration(ms) }
}

/// How long ago `at` was: an ISO date, or a time in ms. `–` when there is none.
pub fn age(at: Option<&Value>, now: i64) -> String {
    let t = match at {
        Some(Value::String(s)) => nmux_time::parse_iso(s),
        #[allow(clippy::cast_possible_truncation)] // a time in ms
        Some(Value::Number(n)) => n.as_f64().filter(|f| f.is_finite()).map(|f| f as i64),
        _ => None,
    };
    t.map_or_else(|| "–".to_owned(), |t| duration((now - t).max(0)))
}

/// A path under the home directory as `~/…`.
pub fn short_path(p: Option<&str>, home: Option<&str>) -> String {
    let Some(p) = p.filter(|p| !p.is_empty()) else { return "–".to_owned() };
    match home.filter(|h| !h.is_empty()) {
        Some(home) if p == home || p.starts_with(&format!("{home}/")) => format!("~{}", &p[home.len()..]),
        _ => p.to_owned(),
    }
}

/// Length as JavaScript counts it, in UTF-16 units.
pub fn js_len(s: &str) -> usize {
    s.encode_utf16().count()
}

/// The first `n` UTF-16 units of `s`, or as near as whole characters come.
fn js_slice(s: &str, n: usize) -> &str {
    let mut units = 0;
    for (i, c) in s.char_indices() {
        units += c.len_utf16();
        if units > n {
            return &s[..i];
        }
    }
    s
}

/// A command cut to fit a column.
pub fn brief(command: &str) -> String {
    if js_len(command) > COMMAND_WIDTH {
        format!("{}…", js_slice(command, COMMAND_WIDTH - 1))
    } else {
        command.to_owned()
    }
}

fn js_space(c: char) -> bool {
    c.is_whitespace() || c == '\u{feff}'
}

/// Whether a command line is a shell, and not a shell running something.
pub fn is_shell(command: Option<&str>) -> bool {
    let Some(command) = command.filter(|c| !c.is_empty()) else { return false };
    // `\s-c\s`
    let runs = command.char_indices().any(|(i, c)| {
        js_space(c)
            && command[i + c.len_utf8()..].starts_with("-c")
            && command[i + c.len_utf8() + 2..].starts_with(js_space)
    });
    if runs {
        return false;
    }
    let first = command.trim_matches(js_space).split(js_space).next().unwrap_or("");
    let first = first.strip_prefix('-').unwrap_or(first);
    SHELLS.contains(&first.rsplit('/').next().unwrap_or(first))
}

/// A JSON value as a template literal writes it.
pub fn js_text(v: &Value) -> String {
    match v {
        Value::String(s) => s.clone(),
        Value::Null => "null".to_owned(),
        other => other.to_string(),
    }
}

/// Whether a value is set, as JavaScript tests one.
fn truthy(v: Option<&Value>) -> bool {
    v.is_some_and(nmux_client::config::truthy)
}

/// The STATE column: a session that is not running, or what one says about itself.
pub fn state_text(alive: bool, state: Option<&Value>, status: Option<&Value>, now: i64) -> String {
    if !alive {
        let e = state.and_then(|s| s.get("restarts")).and_then(|r| r.get("lastExit")).filter(|e| truthy(Some(e)));
        let Some(e) = e else { return "gone".to_owned() };
        let how = [e.get("code"), e.get("signal")]
            .into_iter()
            .flatten()
            .find(|v| !v.is_null())
            .map_or_else(|| "?".to_owned(), js_text);
        let ago =
            e.get("at").filter(|a| truthy(Some(a))).map(|a| format!("{} ago", age(Some(a), now))).unwrap_or_default();
        return format!("exited ({how}) {ago}").trim_end().to_owned();
    }
    let Some(status) = status else { return "not answering".to_owned() };
    let lifecycle = status.get("lifecycle").map(js_text).unwrap_or_default();
    if lifecycle != "RUNNING" {
        return lifecycle.to_lowercase();
    }
    let shell = status.get("shell");
    if let Some(current) = shell.and_then(|s| s.get("current")).filter(|c| truthy(Some(c))) {
        let command = current.get("command").filter(|c| truthy(Some(c))).map(|c| format!(": {}", brief(&js_text(c))));
        #[allow(clippy::cast_possible_truncation)] // a time in ms
        let started = current.get("startedAt").and_then(Value::as_f64).filter(|t| *t != 0.0).map(|t| t as i64);
        let took = started.map(|t| format!(" ({})", elapsed((now - t).max(0)))).unwrap_or_default();
        return format!("running{}{took}", command.unwrap_or_default());
    }
    let command =
        status.get("foreground").and_then(|f| f.get("command")).and_then(Value::as_str).filter(|c| !c.is_empty());
    if let Some(command) = command.filter(|c| !is_shell(Some(c))) {
        return format!("running: {}", brief(command));
    }
    #[allow(clippy::cast_possible_truncation)] // a time in ms
    let idle = match status.get("idleMs").and_then(Value::as_f64) {
        Some(ms) => format!("idle {}", duration(ms as i64)),
        None => "idle".to_owned(),
    };
    match shell.and_then(|s| s.get("last")).filter(|l| truthy(Some(l))).and_then(|l| l.get("exit")) {
        Some(exit) if !exit.is_null() => format!("{idle} · last: exit {}", js_text(exit)),
        _ => idle,
    }
}

/// Text from a process or a filename, made safe to print: it must not be able to drive the terminal.
pub fn printable(s: &str) -> String {
    nmux_history::read::printable(s)
}

/// A table, with columns as wide as what is in them, and nothing in it that can drive the terminal.
pub fn print_table(out: &mut String, head: &[&str], rows: &[Vec<String>]) {
    let safe: Vec<Vec<String>> = rows.iter().map(|r| r.iter().map(|c| printable(c)).collect()).collect();
    let widths: Vec<usize> = head
        .iter()
        .enumerate()
        .map(|(i, h)| safe.iter().map(|r| js_len(&r[i])).chain([js_len(h)]).max().unwrap_or(0))
        .collect();
    let line = |r: &[String]| {
        let cells: Vec<String> = r
            .iter()
            .enumerate()
            .map(|(i, c)| {
                if i == r.len() - 1 {
                    c.clone()
                } else {
                    format!("{c}{}", " ".repeat(widths[i].saturating_sub(js_len(c))))
                }
            })
            .collect();
        cells.join("  ")
    };
    let head: Vec<String> = head.iter().map(|h| (*h).to_owned()).collect();
    out.push_str(&line(&head));
    out.push('\n');
    for r in &safe {
        out.push_str(&line(r));
        out.push('\n');
    }
}
