//! The history files, as `src/wire/history.js` describes them.
//!
//! A file is lines of text, named `spool-<n>` for the number of its first row, in a directory of its own with a `meta.json`.
//! Each line starts with one character that says what it is:
//!
//! | Line     | Meaning |
//! |----------|---------|
//! | `.text`  | a row that starts a line |
//! | `+text`  | a row that carries on the line before it |
//! | `@ms`    | the time, in ms since the epoch, of the rows after it, each printed in that same second |
//! | `!n`     | n rows that never reached the disk: it did not keep up, and the numbers go on as if they had |
//! | `=g:o:n` | how far into program g's output the rows before it go, and how many rows there are by then |
//!
//! Rows are written with their colours, as the emulator serializes them: [`plain`] takes them out.

use std::borrow::Cow;

/// What a history file's name starts with.
pub const PREFIX: &str = "spool-";
/// What the session it came from was: its id, name, start, directory and program.
pub const META: &str = "meta.json";
/// The `schema` of [`META`].
pub const SCHEMA: &str = "nmux.history/1";

/// How far into one program's output the rows before it go.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Mark {
    /// The holder generation, which numbers the program.
    pub generation: u64,
    /// The offset in its output.
    pub offset: u64,
    /// How many rows the history has by then.
    pub lines: u64,
}

/// What one line of a history file means.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Line<'a> {
    /// A row, with its colours.
    Row {
        /// The row.
        text: &'a str,
        /// It carries on the line before it.
        continues: bool,
    },
    /// When the rows after it were printed, in ms since the epoch.
    Time(i64),
    /// Rows that never reached the disk.
    Lost(u64),
    /// See [`Mark`].
    Mark(Mark),
}

impl<'a> Line<'a> {
    /// Reads one line, without its newline. `None` for one that is none of these, which a reader skips.
    pub fn parse(line: &'a str) -> Option<Self> {
        let rest = line.get(1..)?;
        match line.as_bytes()[0] {
            b'.' => Some(Self::Row { text: rest, continues: false }),
            b'+' => Some(Self::Row { text: rest, continues: true }),
            b'@' => rest.parse().ok().map(Self::Time),
            b'!' => rest.parse().ok().map(Self::Lost),
            b'=' => {
                let mut parts = rest.split(':').map(str::parse);
                match (parts.next(), parts.next(), parts.next(), parts.next()) {
                    (Some(Ok(generation)), Some(Ok(offset)), Some(Ok(lines)), None) => {
                        Some(Self::Mark(Mark { generation, offset, lines }))
                    }
                    _ => None,
                }
            }
            _ => None,
        }
    }

    /// Appends the line, with its newline.
    pub fn write_to(&self, out: &mut String) {
        use std::fmt::Write as _;
        // Writing to a String cannot fail.
        let _ = match *self {
            Self::Row { text, continues } => writeln!(out, "{}{text}", if continues { '+' } else { '.' }),
            Self::Time(at) => writeln!(out, "@{at}"),
            Self::Lost(rows) => writeln!(out, "!{rows}"),
            Self::Mark(m) => writeln!(out, "={}:{}:{}", m.generation, m.offset, m.lines),
        };
    }
}

/// The number of a history file's first row, if `name` is one.
pub fn first_row_of(name: &str) -> Option<u64> {
    name.strip_prefix(PREFIX)?.parse().ok()
}

/// A row with its colours taken out: a cursor moved forward is that many spaces, and every other `CSI … letter` goes.
pub fn plain(row: &str) -> Cow<'_, str> {
    if !row.contains('\x1b') {
        return Cow::Borrowed(row);
    }
    let mut out = String::with_capacity(row.len());
    let mut rest = row;
    while let Some(at) = rest.find("\x1b[") {
        out.push_str(&rest[..at]);
        let after = &rest[at + 2..];
        let params = after.bytes().take_while(|b| b.is_ascii_digit() || *b == b';').count();
        match after.as_bytes().get(params) {
            Some(b'C') if after[..params].bytes().all(|b| b.is_ascii_digit()) => {
                let n = after[..params].parse::<usize>().ok().filter(|&n| n > 0).unwrap_or(1);
                out.extend(std::iter::repeat_n(' ', n));
                rest = &after[params + 1..];
            }
            Some(b) if b.is_ascii_alphabetic() => rest = &after[params + 1..],
            _ => {
                out.push_str("\x1b[");
                rest = after;
            }
        }
    }
    out.push_str(rest);
    Cow::Owned(out)
}
