//! Writing a kept history: `src/server/output/spool.js`. Rows that have left the screen go to disk in the format of
//! [`crate::format`], which makes `capture`, `last`, `search` and `view` reach back. Terminal output often has secrets in
//! it, so this is off unless asked for, and the files are private.
//!
//! Bounded, two files are kept, each up to half of `max_bytes`, so the newest part is always there. Kept whole (`keep`),
//! every file stays, in a directory that outlives the session.
//!
//! Writing never makes the session wait. A server is one thread, and a home on NFS can hang, so once the files are open,
//! which the caller needs before it can number a row, a thread of the spool's own does the writing and the caller only
//! queues. A disk that does not keep up costs rows, which are counted, and never output. Something going wrong ends the
//! spool, not the session. What the caller has to wait for (`idle`, `close`, `range`, `last_lines`) is a [`Ticket`],
//! answered later by a [`Done`] that it takes with [`Spool::take_done`] once `wake` has been called. How long to wait is
//! the caller's business: [`Spool::give_up`] is what it calls when it stops.

mod carry;
mod scan;
mod writer;

#[cfg(test)]
mod differential;
#[cfg(test)]
mod tests;

use std::collections::VecDeque;
use std::fmt;
use std::fs::{self, OpenOptions};
use std::io::{self, Write as _};
use std::os::unix::fs::{DirBuilderExt, OpenOptionsExt};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Condvar, Mutex, MutexGuard, PoisonError};
use std::time::{SystemTime, UNIX_EPOCH};

use serde::Serialize;
use serde_json::Value;

use crate::format::{Line, META, Mark, SCHEMA};
use scan::Read;
use writer::Writer;

/// A history kept whole is split into files of about this size, none of them ever removed.
pub const SEGMENT_BYTES: u64 = 67_108_864;
/// Past this much not yet written, the disk is not keeping up: rows are counted and dropped rather than held.
pub const QUEUE_BYTES: u64 = 33_554_432;
/// How finely a file says when its rows were printed: a time goes in before a row printed in another second than the last time
/// it said, so that every row reads back in the second it was printed in, as a running session's own rows say.
pub const TIME_GRAIN_MS: i64 = 1000;

/// How much a record matters.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Level {
    /// Something that happened.
    Info,
    /// Something that should not have.
    Warn,
}

/// Where a spool says what happened to it: a code such as `spool.failed`, `spool.cut`, `spool.dropped`,
/// `spool.unwritten` or `spool.meta_failed`, and its fields, in order. It is only ever called on the thread that owns the
/// [`Spool`]: what the spool's own thread has to say waits for [`Spool::take_done`].
pub trait Log {
    /// One record.
    fn log(&mut self, level: Level, code: &'static str, fields: &[(&'static str, Value)]);
}

impl<F: FnMut(Level, &'static str, &[(&'static str, Value)])> Log for F {
    fn log(&mut self, level: Level, code: &'static str, fields: &[(&'static str, Value)]) {
        self(level, code, fields);
    }
}

/// The wall clock, in ms since the epoch.
pub type Clock = Arc<dyn Fn() -> i64 + Send + Sync>;

/// The system's wall clock.
pub fn system_clock() -> Clock {
    Arc::new(|| {
        SystemTime::now().duration_since(UNIX_EPOCH).map_or(0, |d| i64::try_from(d.as_millis()).unwrap_or(i64::MAX))
    })
}

/// What `nmux search` says about the session a history came from: `meta.json`, after its `schema`. A field that is
/// `None` is left out, as the Node code leaves out one that is `undefined`.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize)]
pub struct Meta {
    /// The session's id.
    pub id: String,
    /// Its name.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    /// When it was made, as an ISO 8601 time.
    #[serde(rename = "createdAt", skip_serializing_if = "Option::is_none")]
    pub created_at: Option<String>,
    /// Where its program runs.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub cwd: Option<String>,
    /// Its program.
    pub argv: Vec<String>,
}

impl Meta {
    /// `meta.json` as `JSON.stringify` writes it.
    fn to_json(&self) -> io::Result<String> {
        #[derive(Serialize)]
        struct Described<'a> {
            schema: &'static str,
            #[serde(flatten)]
            meta: &'a Meta,
        }
        serde_json::to_string(&Described { schema: SCHEMA, meta: self }).map_err(io::Error::other)
    }
}

/// How a spool is made.
#[derive(Clone)]
pub struct Options {
    /// The directory of its files, made if it is not there.
    pub dir: PathBuf,
    /// Bounded: two files of up to half of this each. Not used when `keep`.
    pub max_bytes: u64,
    /// Every file is kept, in files of [`SEGMENT_BYTES`].
    pub keep: bool,
    /// What `meta.json` says, written before anything else.
    pub meta: Option<Meta>,
    /// When a row was printed, if it is not said.
    pub wall_now: Clock,
}

impl Options {
    /// A bounded spool in `dir`, with no `meta.json`, on the system's clock.
    pub fn new(dir: impl Into<PathBuf>, max_bytes: u64) -> Self {
        Self { dir: dir.into(), max_bytes, keep: false, meta: None, wall_now: system_clock() }
    }
}

impl fmt::Debug for Options {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Options")
            .field("dir", &self.dir)
            .field("max_bytes", &self.max_bytes)
            .field("keep", &self.keep)
            .field("meta", &self.meta)
            .finish_non_exhaustive()
    }
}

/// Names a request, whose answer comes later as a [`Done`].
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct Ticket(u64);

/// What a request comes to.
#[derive(Debug)]
pub enum Answer {
    /// [`Spool::idle`]: everything given before it is on disk, or has been let go.
    Idle,
    /// [`Spool::close`]: everything given before it is on disk, or has been let go, and the file is closed.
    Closed,
    /// [`Spool::range`]: whole lines, or `None` when some of the rows have gone.
    Range(io::Result<Option<Vec<String>>>),
    /// [`Spool::last_lines`].
    LastLines(io::Result<Vec<String>>),
}

/// A request answered.
#[derive(Debug)]
pub struct Done {
    /// What [`Spool::idle`], [`Spool::close`], [`Spool::range`] or [`Spool::last_lines`] returned.
    pub ticket: Ticket,
    /// The answer.
    pub answer: Answer,
}

/// Rows on their way to the disk. They are made into lines only as they are written, when it is known which file they
/// go into.
#[derive(Debug)]
struct Chunk {
    rows: Vec<String>,
    wrapped: Vec<bool>,
    /// When each row was printed, 0 if that is not known.
    times: Vec<i64>,
    /// The number of the first row.
    first: u64,
    mark: Mark,
    /// About what they take, for the limit on what is queued.
    bytes: u64,
    /// Rows before them that never reached the disk.
    lost: u64,
}

impl Chunk {
    /// The chunk as the lines of the file it goes into, given the time the file last said, and the time it says after
    /// them. A file starts by saying when, and says it again before a row printed at another time.
    fn serialize(&self, said: Option<i64>, wall_now: &Clock) -> (String, i64) {
        let mut text = String::with_capacity(usize::try_from(self.bytes).unwrap_or(0));
        let mut said = said.unwrap_or_else(|| {
            let at = self.times.iter().copied().find(|&t| t > 0).unwrap_or_else(|| wall_now());
            Line::Time(at).write_to(&mut text);
            at
        });
        if self.lost > 0 {
            Line::Lost(self.lost).write_to(&mut text);
        }
        for (i, row) in self.rows.iter().enumerate() {
            let at = self.times.get(i).copied().unwrap_or(0);
            if at > 0 && at.div_euclid(TIME_GRAIN_MS) != said.div_euclid(TIME_GRAIN_MS) {
                Line::Time(at).write_to(&mut text);
                said = at;
            }
            Line::Row { text: row, continues: self.wrapped.get(i).copied().unwrap_or(false) }.write_to(&mut text);
        }
        Line::Mark(self.mark).write_to(&mut text);
        (text, said)
    }
}

/// What the spool's thread is given, in order.
#[derive(Debug)]
enum Job {
    Chunk(Chunk),
    /// `meta.json`, as it is to be.
    Describe(String),
    Idle(Ticket),
    Read(Ticket, Read),
    Close(Ticket),
    /// The next chunk's write stops halfway until it is released: a disk that hangs in the middle of a write.
    #[cfg(test)]
    Hold(tests::Hold),
    /// Writing goes to this file from now on.
    #[cfg(test)]
    Replace(fs::File),
}

/// What is waiting for the spool's thread.
#[derive(Debug, Default)]
struct Queue {
    jobs: VecDeque<Job>,
    /// What the chunks in `jobs` take.
    queued: u64,
    /// The [`Spool`] has gone: the thread ends when it has done what it was given.
    gone: bool,
}

/// What the spool's threads have to tell its owner.
#[derive(Debug)]
enum Event {
    Done(Done),
    Log(Level, &'static str, Vec<(&'static str, Value)>),
}

/// What the owner and the spool's threads share. Nobody holds a lock across anything that waits for the disk.
struct Shared {
    queue: Mutex<Queue>,
    /// The queue has something in it, or the spool has gone.
    work: Condvar,
    failed: AtomicBool,
    /// How many rows the files hold.
    written: AtomicU64,
    events: Mutex<Vec<Event>>,
    wake: Box<dyn Fn() + Send + Sync>,
}

impl Shared {
    fn tell(&self, event: Event) {
        lock(&self.events).push(event);
        (self.wake)();
    }

    fn answer(&self, ticket: Ticket, answer: Answer) {
        self.tell(Event::Done(Done { ticket, answer }));
    }

    /// Nothing more is written: what is queued is let go, so that nobody waits for it. Says so the first time.
    fn fail(&self, error: &io::Error) -> Option<Event> {
        let first = !self.failed.swap(true, Ordering::AcqRel);
        let mut queue = lock(&self.queue);
        queue.jobs.retain(|job| !matches!(job, Job::Chunk(_)));
        queue.queued = 0;
        drop(queue);
        first.then(|| Event::Log(Level::Warn, "spool.failed", vec![("error", error.to_string().into())]))
    }
}

/// A lock that a thread that panicked holding it has not made useless: everything under it is consistent between
/// statements.
fn lock<T>(mutex: &Mutex<T>) -> MutexGuard<'_, T> {
    mutex.lock().unwrap_or_else(PoisonError::into_inner)
}

/// Writes `meta.json` whole, or not at all.
fn write_meta(dir: &Path, json: &str) -> io::Result<()> {
    let file = dir.join(META);
    let new = dir.join(format!("{META}.new"));
    OpenOptions::new().write(true).create(true).truncate(true).mode(0o600).open(&new)?.write_all(json.as_bytes())?;
    fs::rename(&new, &file)
}

/// A session's kept history, being written. See the module's description.
pub struct Spool {
    log: Box<dyn Log>,
    dir: PathBuf,
    wall_now: Clock,
    /// The number the next row gets.
    lines: u64,
    /// The program's output up to here is already written.
    through: Option<u64>,
    generation: u64,
    /// The last mark a server before this one wrote.
    last_mark: Option<Mark>,
    /// Rows counted but not queued, since the disk was behind: the next chunk says so.
    dropped: u64,
    /// [`Spool::close`] was called: nothing more is queued.
    closing: bool,
    next_ticket: u64,
    shared: Arc<Shared>,
    /// The spool's thread is there to take jobs.
    running: bool,
}

impl fmt::Debug for Spool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Spool")
            .field("lines", &self.lines)
            .field("through", &self.through)
            .field("generation", &self.generation)
            .field("failed", &self.failed())
            .field("closing", &self.closing)
            .finish_non_exhaustive()
    }
}

impl Spool {
    /// Carries on from whatever is in `options.dir`, there and then, and starts the thread that writes. What it has to
    /// say goes to `log`, and `wake` is called, on another thread, whenever there is something for [`Spool::take_done`].
    /// Nothing that goes wrong here is the session's problem: the spool is then one that has failed.
    pub fn new(options: Options, mut log: Box<dyn Log>, wake: Box<dyn Fn() + Send + Sync>) -> Self {
        let shared = Arc::new(Shared {
            queue: Mutex::new(Queue::default()),
            work: Condvar::new(),
            failed: AtomicBool::new(false),
            written: AtomicU64::new(0),
            events: Mutex::new(Vec::new()),
            wake,
        });
        let mut writer = Writer::new(&options, Arc::clone(&shared));
        let opened = fs::DirBuilder::new().recursive(true).mode(0o700).create(&options.dir).and_then(|()| {
            if let Some(meta) = &options.meta
                && let Err(e) = meta.to_json().and_then(|json| write_meta(&options.dir, &json))
            {
                log.log(Level::Warn, "spool.meta_failed", &[("error", e.to_string().into())]);
            }
            writer.open(&mut *log)
        });
        let mut spool = Self {
            log,
            dir: options.dir,
            wall_now: options.wall_now,
            lines: 0,
            through: None,
            generation: 0,
            last_mark: None,
            dropped: 0,
            closing: false,
            next_ticket: 0,
            shared,
            running: false,
        };
        match opened {
            Ok((lines, mark)) => {
                spool.lines = lines;
                spool.last_mark = mark;
                spool.shared.written.store(lines, Ordering::Release);
            }
            Err(e) => spool.failed_here(&e),
        }
        match std::thread::Builder::new().name("nmux-spool".into()).spawn(move || writer.run()) {
            Ok(_) => spool.running = true,
            Err(e) => spool.failed_here(&e),
        }
        spool
    }

    fn failed_here(&mut self, error: &io::Error) {
        if let Some(Event::Log(level, code, fields)) = self.shared.fail(error) {
            self.log.log(level, code, &fields);
        }
    }

    /// The number the next row gets.
    pub fn lines(&self) -> u64 {
        self.lines
    }

    /// The program's output up to here is already written, by a server before this one.
    pub fn through(&self) -> Option<u64> {
        self.through
    }

    /// Nothing more is written.
    pub fn failed(&self) -> bool {
        self.shared.failed.load(Ordering::Acquire)
    }

    /// How many rows the files hold: as many as [`Spool::lines`] once everything given is on disk.
    pub fn written(&self) -> u64 {
        self.shared.written.load(Ordering::Acquire)
    }

    /// The program's output from here on is a new stream.
    pub fn stream(&mut self, generation: u64) {
        self.generation = generation;
    }

    /// A new program, whose stream starts again from nothing.
    pub fn new_stream(&mut self, generation: u64) {
        self.generation = generation;
        self.through = None;
    }

    /// The server before this one wrote what it read of this program.
    pub fn resume(&mut self, generation: u64) {
        if let Some(mark) = self.last_mark
            && mark.generation == generation
        {
            self.through = Some(mark.offset);
        }
    }

    /// A row that goes this far into the program's output is already written.
    pub fn already_has(&self, offset: u64) -> bool {
        self.through.is_some_and(|through| offset <= through)
    }

    /// Queues rows, as the emulator serializes them, with whether each carries on from the row before it, how far into
    /// the program's output they go, and when each was printed in ms since the epoch, 0 where that is not known (none:
    /// now). Returns the number of the first: rows are counted whether or not they are written.
    pub fn append(&mut self, rows: Vec<String>, wrapped: Vec<bool>, offset: u64, times: Option<Vec<i64>>) -> u64 {
        let first = self.lines;
        self.lines += rows.len() as u64;
        if self.failed() || self.closing {
            return first;
        }
        let bytes = 64 + rows.iter().map(|row| row.len() as u64 + 2).sum::<u64>();
        let times = times.unwrap_or_else(|| rows.iter().map(|_| (self.wall_now)()).collect());
        let mark = Mark { generation: self.generation, offset, lines: self.lines };
        self.queue(Chunk { rows, wrapped, times, first, mark, bytes, lost: 0 });
        first
    }

    fn queue(&mut self, mut chunk: Chunk) {
        let mut queue = lock(&self.shared.queue);
        if queue.queued > QUEUE_BYTES {
            drop(queue);
            self.dropped += chunk.rows.len() as u64;
            return;
        }
        let lost = std::mem::take(&mut self.dropped);
        chunk.lost = lost;
        queue.queued += chunk.bytes;
        queue.jobs.push_back(Job::Chunk(chunk));
        drop(queue);
        self.shared.work.notify_one();
        if lost > 0 {
            self.log.log(Level::Warn, "spool.dropped", &[("rows", lost.into())]);
        }
    }

    /// What `nmux search` says about the session, written after what is queued.
    pub fn describe(&mut self, meta: &Meta) {
        match meta.to_json() {
            Ok(json) => self.push(Job::Describe(json)),
            Err(e) => self.log.log(Level::Warn, "spool.meta_failed", &[("error", e.to_string().into())]),
        }
    }

    /// Answered with [`Answer::Idle`] once everything given so far is on disk, or has been let go.
    pub fn idle(&mut self) -> Ticket {
        self.request(Job::Idle)
    }

    /// The rows numbered `from` up to `to`, as whole lines, with their colours if `ansi`, once everything given so far is
    /// on disk: [`Answer::Range`], `None` if some of them have gone. The last line is whole: cutting it where a command
    /// ended, as `lastChars` does in the Node code, is the caller's, with the emulator's `cut_line`.
    pub fn range(&mut self, from: u64, to: u64, ansi: bool) -> Ticket {
        self.request(|ticket| Job::Read(ticket, Read::Range { from, to, ansi }))
    }

    /// The last `count` lines, or all of them, of the rows given so far, once they are on disk: [`Answer::LastLines`].
    pub fn last_lines(&mut self, count: Option<usize>, ansi: bool) -> Ticket {
        let to = self.lines;
        self.request(|ticket| Job::Read(ticket, Read::LastLines { to, count, ansi }))
    }

    /// Nothing more is queued, and once what is has been written the file is closed: [`Answer::Closed`]. A disk that has
    /// hung must not keep a server, so how long to wait for that is the caller's, and [`Spool::give_up`] is what it
    /// calls when it stops.
    pub fn close(&mut self) -> Ticket {
        self.closing = true;
        self.request(Job::Close)
    }

    /// Stops waiting for [`Spool::close`]: what is not written yet is let go, and said so. A write under way is never cut
    /// short: the file is closed when it returns, and nothing is written after it.
    pub fn give_up(&mut self) {
        if !self.closing {
            self.close();
        }
        let mut queue = lock(&self.shared.queue);
        let mut rows = 0;
        queue.jobs.retain(|job| match job {
            Job::Chunk(chunk) => {
                rows += chunk.rows.len() as u64;
                false
            }
            _ => true,
        });
        queue.queued = 0;
        drop(queue);
        if rows > 0 {
            self.log.log(Level::Warn, "spool.unwritten", &[("rows", rows.into())]);
        }
    }

    /// The requests answered since the last call, in the order they were answered. What the spool's own thread had to
    /// say goes to the log on the way.
    pub fn take_done(&mut self) -> Vec<Done> {
        let events = std::mem::take(&mut *lock(&self.shared.events));
        let mut done = Vec::new();
        for event in events {
            match event {
                Event::Done(answered) => done.push(answered),
                Event::Log(level, code, fields) => self.log.log(level, code, &fields),
            }
        }
        done
    }

    fn request(&mut self, job: impl FnOnce(Ticket) -> Job) -> Ticket {
        let ticket = Ticket(self.next_ticket);
        self.next_ticket += 1;
        self.push(job(ticket));
        ticket
    }

    fn push(&mut self, job: Job) {
        if self.running {
            lock(&self.shared.queue).jobs.push_back(job);
            self.shared.work.notify_one();
            return;
        }
        // There is no thread to write, so nothing is written: what waits for that has nothing to wait for.
        match job {
            Job::Idle(ticket) => self.shared.answer(ticket, Answer::Idle),
            Job::Close(ticket) => self.shared.answer(ticket, Answer::Closed),
            Job::Read(ticket, read) => scan::spawn(&self.shared, &self.dir, ticket, read),
            _ => {}
        }
    }
}

impl Drop for Spool {
    /// The spool's thread finishes what it was given, closes the file and ends. Nothing waits for it.
    fn drop(&mut self) {
        lock(&self.shared.queue).gone = true;
        self.shared.work.notify_one();
    }
}
