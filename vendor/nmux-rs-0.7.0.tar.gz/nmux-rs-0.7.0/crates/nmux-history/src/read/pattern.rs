//! A pattern as a person gives one to `nmux search` or `nmux wait --text`: JavaScript's regular expressions, which the Node
//! code compiles with `new RegExp(source, flags)`, without the `u` flag. It is read as V8 reads it ([`parse`]), refused
//! with V8's words where V8 refuses it, and written for `fancy-regex` so that it means what it means to JavaScript
//! ([`emit`]): over UTF-16 code units, with JavaScript's case folding, line ends and empty backreferences. Marking every
//! match goes on from an empty one a code unit later, as `String.prototype.replace` does.
//!
//! What still differs, with an example of each in `tests/patterns.rs`: a group repeated by a quantifier keeps what it
//! captured from one time round to the next, where JavaScript forgets it; a repeated group that has matched nothing stops,
//! where JavaScript goes on to its other alternatives; and a lookbehind of more than one length is refused when it has a
//! backreference in it, or `\b` inside a group. A count beyond a thousand is no bound, or one never met.

mod emit;
mod parse;

use std::borrow::Cow;

use fancy_regex::{Regex, RegexBuilder};

/// A compiled pattern.
#[derive(Clone, Debug)]
pub struct Pattern {
    re: Regex,
}

impl Pattern {
    /// Compiles `source` as `new RegExp(source, flags)` would, with `i` as `ignore_case` and `m` as `multi_line`. The error is
    /// for a person, after `bad pattern: `.
    pub fn new(source: &str, ignore_case: bool, multi_line: bool) -> Result<Self, String> {
        let flags = format!("{}{}", if ignore_case { "i" } else { "" }, if multi_line { "m" } else { "" });
        let parsed =
            parse::parse(source).map_err(|why| format!("Invalid regular expression: /{source}/{flags}: {why}"))?;
        let mut translated = String::with_capacity(source.len() * 8);
        let on = if ignore_case { parse::IGNORE_CASE } else { 0 } | if multi_line { parse::MULTI_LINE } else { 0 };
        emit::emit(&parsed.node, on, &mut translated);
        let re = RegexBuilder::new(&translated)
            .build()
            .map_err(|e| format!("/{source}/{flags} is JavaScript that cannot be matched here: {e}"))?;
        debug_assert_eq!(re.captures_len(), parsed.captures + 1, "{translated}");
        Ok(Self { re })
    }

    /// Whether it matches somewhere in `text`. A search that gives up, which only a pathological pattern makes it do, is no
    /// match.
    pub fn is_match(&self, text: &str) -> bool {
        self.re.is_match(units(text).as_ref()).unwrap_or(false)
    }

    /// `text` with every match between `before` and `after`.
    pub fn highlight(&self, text: &str, before: &str, after: &str) -> String {
        let units = units(text);
        let t = units.as_ref();
        let put = |out: &mut String, s: &str| match &units {
            Cow::Borrowed(_) => out.push_str(s),
            Cow::Owned(_) => characters(s, out),
        };
        let mut out = String::with_capacity(text.len() + 16);
        let (mut last, mut from) = (0, 0);
        while let Ok(Some(m)) = self.re.find_from_pos(t, from) {
            put(&mut out, &t[last..m.start()]);
            out.push_str(before);
            put(&mut out, m.as_str());
            out.push_str(after);
            last = m.end();
            from = if m.end() > m.start() {
                m.end()
            } else {
                match t[m.end()..].chars().next() {
                    Some(c) => m.end() + c.len_utf8(),
                    None => break,
                }
            };
        }
        put(&mut out, &t[last..]);
        out
    }
}

/// `text` with a character for each UTF-16 code unit, as the pattern was written for: the same text, unless it has a
/// character beyond U+FFFF or one from U+E000 to U+E7FF.
fn units(text: &str) -> Cow<'_, str> {
    // UTF-8 starts every such character with 0xEE or more
    if text.bytes().all(|b| b < 0xee) {
        return Cow::Borrowed(text);
    }
    let mut out = String::with_capacity(text.len() + 8);
    let mut buf = [0u16; 2];
    for c in text.chars() {
        for &unit in c.encode_utf16(&mut buf).iter() {
            out.push(emit::stand_in(unit));
        }
    }
    Cow::Owned(out)
}

/// The text [`units`] made, as the characters it was made from. A surrogate on its own, where a match ended in the middle
/// of a character, is U+FFFD.
fn characters(t: &str, out: &mut String) {
    let mut chars = t.chars().peekable();
    while let Some(c) = chars.next() {
        let v = u32::from(c);
        let low = |c: &char| (0xe400..=0xe7ff).contains(&u32::from(*c));
        match v {
            0xe000..=0xe3ff if chars.peek().is_some_and(low) => {
                let lo = chars.next().map_or(0, |c| u32::from(c) - 0xe400);
                out.push(char::from_u32(0x10000 + ((v - 0xe000) << 10) + lo).unwrap_or('\u{fffd}'));
            }
            0xe000..=0xe7ff => out.push('\u{fffd}'),
            0xf0000..=0xf07ff => out.push(char::from_u32(v - 0xf0000 + 0xe000).unwrap_or('\u{fffd}')),
            _ => out.push(c),
        }
    }
}
