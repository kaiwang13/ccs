//! JavaScript's pattern syntax as V8 reads it for `new RegExp(source, flags)` without the `u` flag: the legacy grammar of
//! Annex B, in which a pattern is UTF-16 code units and much that is not quite syntax is read as text. This follows V8's
//! parser (`regexp-parser.cc`) step for step, so that it refuses what V8 refuses, at the place V8 would, in V8's words.

/// Code units, as ranges.
pub(super) type Units = Vec<(u16, u16)>;

/// V8's `kInfinity`: a count this large, or one that overflows, is no bound at all.
pub(super) const INFINITY: u32 = i32::MAX.unsigned_abs();
/// The most groups V8 counts a backreference up to.
const MAX_CAPTURES: usize = 1 << 16;

/// The flags a group can set or clear for what is inside it.
pub(super) const IGNORE_CASE: u8 = 1;
pub(super) const MULTI_LINE: u8 = 2;
pub(super) const DOT_ALL: u8 = 4;

/// A pattern, read.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) enum Node {
    /// Nothing: a backreference inside the group it refers to, which can have captured nothing yet.
    Empty,
    /// One code unit.
    Unit(u16),
    /// One of these code units, or with `negated` one not among them.
    Set { units: Units, negated: bool },
    /// `.`
    Dot,
    /// `^`
    Start,
    /// `$`
    End,
    /// `\b`, or `\B` when false.
    Boundary(bool),
    /// Lookahead or lookbehind.
    Look { behind: bool, negative: bool, body: Box<Node> },
    /// A group, capturing as this number or not.
    Group { capture: Option<usize>, body: Box<Node> },
    /// A group that sets flags and clears others for what is in it.
    Modified { on: u8, off: u8, body: Box<Node> },
    /// `body`, `min` to `max` times, as many as can be or as few.
    Repeat { body: Box<Node>, min: u32, max: u32, greedy: bool },
    /// What the first of these groups that took part captured, or nothing.
    Backref(Vec<usize>),
    /// A reference by name, until the names are known.
    Named(String),
    /// One of these.
    Alt(Vec<Node>),
    /// These, one after another.
    Seq(Vec<Node>),
}

/// A pattern and how many groups capture in it.
#[derive(Debug)]
pub(super) struct Parsed {
    pub node: Node,
    pub captures: usize,
}

/// Reads `source`, or says what V8 says is wrong with it.
pub(super) fn parse(source: &str) -> Result<Parsed, &'static str> {
    let src: Vec<u16> = source.encode_utf16().collect();
    let (total, named) = scan(&src);
    let mut p = Parser {
        src,
        at: 0,
        total,
        named,
        started: 0,
        names: Vec::new(),
        states: vec![State { capture: None, name: None, first: 0, interval: None }],
    };
    let mut node = p.disjunction(false)?;
    p.resolve(&mut node)?;
    Ok(Parsed { node, captures: p.started })
}

/// `ScanForCaptures`: how many groups capture, and whether any has a name, from a reading that looks only at brackets.
fn scan(src: &[u16]) -> (usize, bool) {
    let (mut count, mut named, mut in_class) = (0, false, false);
    let at = |i: usize| src.get(i).copied().map(unit_char);
    let mut i = 0;
    while let Some(c) = at(i) {
        i += 1;
        match c {
            '\\' => i += 1,
            '[' => in_class = true,
            ']' => in_class = false,
            '(' if !in_class => {
                if at(i) == Some('?') {
                    i += 1;
                    if at(i) != Some('<') {
                        continue;
                    }
                    i += 1;
                    if matches!(at(i), Some('=' | '!')) {
                        continue;
                    }
                    named = true;
                }
                count += 1;
            }
            _ => {}
        }
    }
    (count, named)
}

/// A code unit as a character to compare with syntax, which is all ASCII: a surrogate is none of it.
fn unit_char(u: u16) -> char {
    char::from_u32(u32::from(u)).unwrap_or('\u{fffd}')
}

/// One disjunction being read: the top of the pattern or a group's inside.
#[derive(Debug)]
struct State {
    capture: Option<usize>,
    name: Option<String>,
    /// The groups started before it began.
    first: usize,
    /// V8's `non_participating_capture_group_interval`, once an alternative has ended: the groups that cannot take part
    /// in a match beside one in a later alternative. It counts from `first` itself, one group too many, as V8 does.
    interval: Option<(usize, usize)>,
}

/// What a class holds before it is read whole: one code unit, or a set from an escape.
enum Atom {
    Unit(u16),
    Set(Units),
}

struct Parser {
    src: Vec<u16>,
    at: usize,
    /// Groups that capture in the whole pattern.
    total: usize,
    /// Whether any has a name, which makes `\k` a reference.
    named: bool,
    /// Groups that capture so far.
    started: usize,
    names: Vec<(String, usize)>,
    states: Vec<State>,
}

impl Parser {
    fn cur(&self) -> Option<char> {
        self.peek(0)
    }

    fn peek(&self, n: usize) -> Option<char> {
        self.src.get(self.at + n).copied().map(unit_char)
    }

    fn digit(&self, n: usize) -> Option<u32> {
        self.peek(n).and_then(|c| c.to_digit(10))
    }

    /// `ParseDisjunction`: alternatives up to the end, or to the `)` that ends a group.
    fn disjunction(&mut self, nested: bool) -> Result<Node, &'static str> {
        let mut alts = Vec::new();
        let mut seq = Vec::new();
        loop {
            let Some(c) = self.cur() else {
                if nested {
                    return Err("Unterminated group");
                }
                break;
            };
            match c {
                ')' if nested => break,
                ')' => return Err("Unmatched ')'"),
                '|' => {
                    self.at += 1;
                    alts.push(sequence(std::mem::take(&mut seq)));
                    let started = self.started;
                    if let Some(s) = self.states.last_mut() {
                        s.interval = Some((s.interval.map_or(s.first, |(f, _)| f), started));
                    }
                    continue;
                }
                '*' | '+' | '?' => return Err("Nothing to repeat"),
                '^' | '$' => {
                    self.at += 1;
                    seq.push(if c == '^' { Node::Start } else { Node::End });
                    continue;
                }
                '.' => {
                    self.at += 1;
                    seq.push(Node::Dot);
                }
                '(' => seq.push(self.group()?),
                '[' => seq.push(self.class()?),
                '\\' => {
                    let (atom, quantifiable) = self.atom_escape()?;
                    seq.push(atom);
                    if !quantifiable {
                        continue;
                    }
                }
                '{' if self.interval().is_some() => return Err("Nothing to repeat"),
                _ => {
                    seq.push(Node::Unit(self.src[self.at]));
                    self.at += 1;
                }
            }
            let Some((min, max, greedy)) = self.quantifier()? else { continue };
            let atom = seq.pop().unwrap_or(Node::Empty);
            seq.push(match atom {
                Node::Empty => Node::Empty,
                Node::Look { behind: true, .. } => return Err("Invalid quantifier"),
                body => Node::Repeat { body: Box::new(body), min, max, greedy },
            });
        }
        let last = sequence(seq);
        Ok(if alts.is_empty() {
            last
        } else {
            alts.push(last);
            Node::Alt(alts)
        })
    }

    /// What follows a `\` outside a class, and whether a quantifier may follow it: `\b` and `\B` take none.
    fn atom_escape(&mut self) -> Result<(Node, bool), &'static str> {
        let atom = match self.peek(1) {
            None => return Err("\\ at end of pattern"),
            Some(b @ ('b' | 'B')) => {
                self.at += 2;
                return Ok((Node::Boundary(b == 'b'), false));
            }
            Some(e @ ('d' | 'D' | 's' | 'S' | 'w' | 'W')) => {
                self.at += 2;
                Node::Set { units: class_escape(e), negated: false }
            }
            Some(d @ '1'..='9') => match self.back_reference() {
                Some(n) if self.states.iter().any(|s| s.capture == Some(n)) => Node::Empty,
                Some(n) => Node::Backref(vec![n]),
                None if d == '8' || d == '9' => {
                    self.at += 2;
                    Node::Unit(self.src[self.at - 1])
                }
                None => {
                    self.at += 1;
                    Node::Unit(self.octal())
                }
            },
            Some('0') => {
                self.at += 1;
                Node::Unit(self.octal())
            }
            Some('k') if self.named => {
                self.at += 2;
                self.named_reference()?
            }
            Some(_) => {
                self.at += 1;
                Node::Unit(self.character_escape(false)?)
            }
        };
        Ok((atom, true))
    }

    /// The quantifier here, and past it, if there is one: its counts and whether it takes as many as it can.
    fn quantifier(&mut self) -> Result<Option<(u32, u32, bool)>, &'static str> {
        let (min, max) = match self.cur() {
            Some('*') => (0, INFINITY),
            Some('+') => (1, INFINITY),
            Some('?') => (0, 1),
            Some('{') => match self.interval() {
                Some((min, max)) if max < min => return Err("numbers out of order in {} quantifier"),
                Some(counts) => counts,
                None => return Ok(None),
            },
            _ => return Ok(None),
        };
        self.at += if self.cur() == Some('{') { self.interval_len().unwrap_or(1) } else { 1 };
        let greedy = self.cur() != Some('?');
        if !greedy {
            self.at += 1;
        }
        Ok(Some((min, max, greedy)))
    }

    /// `ParseOpenParenthesis` and the group up to its `)`.
    fn group(&mut self) -> Result<Node, &'static str> {
        #[derive(PartialEq)]
        enum Kind {
            Capture,
            Plain,
            Look { behind: bool, negative: bool },
        }
        self.at += 1;
        let mut kind = Kind::Capture;
        let mut named = false;
        let (mut on, mut off, mut seen, mut dash) = (0u8, 0u8, 0u8, false);
        if self.cur() == Some('?') {
            loop {
                let mut modifiers = false;
                match self.peek(1) {
                    Some('-') => {
                        self.at += 1;
                        modifiers = true;
                        if dash {
                            return Err("Multiple dashes in flag group");
                        }
                        dash = true;
                    }
                    Some(f @ ('i' | 'm' | 's')) => {
                        self.at += 1;
                        modifiers = true;
                        let bit = match f {
                            'i' => IGNORE_CASE,
                            'm' => MULTI_LINE,
                            _ => DOT_ALL,
                        };
                        if seen & bit != 0 {
                            return Err("Repeated flag in flag group");
                        }
                        seen |= bit;
                        if dash {
                            off |= bit;
                        } else {
                            on |= bit;
                        }
                    }
                    Some(':') => {
                        self.at += 2;
                        kind = Kind::Plain;
                    }
                    Some(c @ ('=' | '!')) if seen == 0 && !dash => {
                        self.at += 2;
                        kind = Kind::Look { behind: false, negative: c == '!' };
                    }
                    Some('<') if seen == 0 && !dash => {
                        self.at += 1;
                        if let Some(c @ ('=' | '!')) = self.peek(1) {
                            self.at += 2;
                            kind = Kind::Look { behind: true, negative: c == '!' };
                        } else {
                            named = true;
                            self.at += 1;
                        }
                    }
                    _ => return Err("Invalid group"),
                }
                if !modifiers {
                    break;
                }
            }
            if dash && seen == 0 {
                return Err("Invalid flag group");
            }
        }
        let capture = (kind == Kind::Capture).then(|| {
            self.started += 1;
            self.started
        });
        let name = if named { Some(self.capture_name()?) } else { None };
        self.states.push(State { capture, name: name.clone(), first: self.started, interval: None });
        let body = Box::new(self.disjunction(true)?);
        self.at += 1;
        if let (Some(name), Some(index)) = (name, capture) {
            self.name_group(name, index)?;
        }
        self.states.pop();
        Ok(match kind {
            Kind::Capture => Node::Group { capture, body },
            Kind::Plain if on | off == 0 => Node::Group { capture: None, body },
            Kind::Plain => Node::Modified { on, off, body },
            Kind::Look { behind, negative } => Node::Look { behind, negative, body },
        })
    }

    /// `CreateNamedCaptureAtIndex`, as a group closes: a name taken already is refused unless every group that has it
    /// lies in an alternative that the disjunctions around this one have ended.
    fn name_group(&mut self, name: String, index: usize) -> Result<(), &'static str> {
        for (_, k) in self.names.iter().filter(|(n, _)| *n == name) {
            let apart = self.states.iter().any(|s| s.interval.is_some_and(|(first, last)| first <= *k && *k <= last));
            if !apart {
                return Err("Duplicate capture group name");
            }
        }
        self.names.push((name, index));
        Ok(())
    }

    /// `ParseCaptureGroupName`, after the `<`, up to and past the `>`.
    fn capture_name(&mut self) -> Result<String, &'static str> {
        let mut name = String::new();
        loop {
            let mut c = self.code_point();
            if c == Some('\\') && self.peek(1) == Some('u') {
                self.at += 2;
                c = Some(self.name_escape().ok_or("Invalid Unicode escape")?);
            } else if c.is_some() {
                self.at += c.map_or(1, char::len_utf16);
            }
            let ok = match c {
                Some('\\') | None => false,
                Some('>') if !name.is_empty() => return Ok(name),
                Some(c) if name.is_empty() => unicode_ident::is_xid_start(c) || c == '$' || c == '_',
                Some(c) => unicode_ident::is_xid_continue(c) || matches!(c, '$' | '\u{200c}' | '\u{200d}'),
            };
            if !ok {
                return Err("Invalid capture group name");
            }
            if let Some(c) = c {
                name.push(c);
            }
        }
    }

    /// The code point here, a surrogate pair read as one, as V8 reads a name.
    fn code_point(&self) -> Option<char> {
        let first = *self.src.get(self.at)?;
        let pair = self.src.get(self.at..self.at + 2).and_then(|p| char::decode_utf16(p.iter().copied()).next());
        match pair {
            Some(Ok(c)) if u32::from(c) > 0xffff => Some(c),
            _ => Some(unit_char(first)),
        }
    }

    /// `\uXXXX`, a pair of them, or `\u{X…}`, in a name, after the `\u`.
    fn name_escape(&mut self) -> Option<char> {
        if self.cur() == Some('{') {
            let end = (self.at + 1..self.src.len()).find(|&i| unit_char(self.src[i]) == '}')?;
            let digits: String = self.src[self.at + 1..end].iter().map(|&u| unit_char(u)).collect();
            let c = u32::from_str_radix(&digits, 16).ok().and_then(char::from_u32)?;
            self.at = end + 1;
            return Some(c);
        }
        let high = self.hex(4)?;
        if (0xd800..0xdc00).contains(&high) && self.cur() == Some('\\') && self.peek(1) == Some('u') {
            let back = self.at;
            self.at += 2;
            match self.hex(4) {
                Some(low) if (0xdc00..0xe000).contains(&low) => {
                    return char::decode_utf16([high, low]).next()?.ok();
                }
                _ => self.at = back,
            }
        }
        char::from_u32(u32::from(high))
    }

    /// `ParseNamedBackReference`, after the `\k`.
    fn named_reference(&mut self) -> Result<Node, &'static str> {
        if self.cur() != Some('<') {
            return Err("Invalid named reference");
        }
        self.at += 1;
        let name = self.capture_name()?;
        Ok(if self.states.iter().any(|s| s.name.as_deref() == Some(name.as_str())) {
            Node::Empty
        } else {
            Node::Named(name)
        })
    }

    /// Names become the groups that have them, once all are known.
    fn resolve(&self, node: &mut Node) -> Result<(), &'static str> {
        match node {
            Node::Named(name) => {
                let groups: Vec<usize> = self.names.iter().filter(|(n, _)| n == name).map(|(_, i)| *i).collect();
                if groups.is_empty() {
                    return Err("Invalid named capture referenced");
                }
                *node = Node::Backref(groups);
            }
            Node::Look { body, .. }
            | Node::Group { body, .. }
            | Node::Modified { body, .. }
            | Node::Repeat { body, .. } => {
                self.resolve(body)?;
            }
            Node::Alt(nodes) | Node::Seq(nodes) => {
                for n in nodes {
                    self.resolve(n)?;
                }
            }
            _ => {}
        }
        Ok(())
    }

    /// `ParseBackReferenceIndex`, at the `\`: a number no greater than the groups there are, and past it, or nothing and
    /// still at the `\`.
    fn back_reference(&mut self) -> Option<usize> {
        let mut value = self.digit(1)? as usize;
        let mut n = 2;
        while let Some(d) = self.digit(n) {
            value = value * 10 + d as usize;
            if value > MAX_CAPTURES {
                return None;
            }
            n += 1;
        }
        if value > self.total {
            return None;
        }
        self.at += n;
        Some(value)
    }

    /// `ParseOctalLiteral`: up to three octal digits, below 256.
    fn octal(&mut self) -> u16 {
        let mut value = self.digit(0).unwrap_or(0);
        self.at += 1;
        if let Some(d) = self.digit(0).filter(|&d| d < 8) {
            value = value * 8 + d;
            self.at += 1;
            if let Some(d) = self.digit(0).filter(|&d| d < 8 && value < 32) {
                value = value * 8 + d;
                self.at += 1;
            }
        }
        u16::try_from(value).unwrap_or(0)
    }

    /// `n` hexadecimal digits, and past them, or nothing.
    fn hex(&mut self, n: usize) -> Option<u16> {
        let digits = self.src.get(self.at..self.at + n)?;
        let mut value = 0u32;
        for &u in digits {
            value = value * 16 + unit_char(u).to_digit(16)?;
        }
        self.at += n;
        u16::try_from(value).ok()
    }

    /// `ParseCharacterEscape`, at what follows the `\`. A `\c` that controls nothing is the backslash itself, and the
    /// `c` is read next as what it is.
    fn character_escape(&mut self, in_class: bool) -> Result<u16, &'static str> {
        let c = self.cur().unwrap_or('\\');
        let unit = self.src[self.at];
        let control = |l: char| u16::try_from(u32::from(l) & 0x1f).unwrap_or(0);
        Ok(match c {
            'f' | 'n' | 'r' | 't' | 'v' => {
                self.at += 1;
                match c {
                    'f' => 0x0c,
                    'n' => 0x0a,
                    'r' => 0x0d,
                    't' => 0x09,
                    _ => 0x0b,
                }
            }
            'c' => match self.peek(1) {
                Some(l) if l.is_ascii_alphabetic() || (in_class && (l.is_ascii_digit() || l == '_')) => {
                    self.at += 2;
                    control(l)
                }
                _ => u16::from(b'\\'),
            },
            '0' if !self.peek(1).is_some_and(|d| d.is_ascii_digit()) => {
                self.at += 1;
                0
            }
            '0'..='7' => self.octal(),
            'x' | 'u' => {
                self.at += 1;
                self.hex(if c == 'x' { 2 } else { 4 }).unwrap_or(unit)
            }
            'k' if self.named => return Err("Invalid escape"),
            _ => {
                self.at += 1;
                unit
            }
        })
    }

    /// `ParseCharacterClass`.
    fn class(&mut self) -> Result<Node, &'static str> {
        self.at += 1;
        let negated = self.cur() == Some('^');
        if negated {
            self.at += 1;
        }
        let mut units = Units::new();
        let dash = u16::from(b'-');
        let add = |units: &mut Units, a: Atom| match a {
            Atom::Unit(u) => units.push((u, u)),
            Atom::Set(s) => units.extend(s),
        };
        while let Some(c) = self.cur() {
            if c == ']' {
                break;
            }
            let first = self.class_atom()?;
            if self.cur() != Some('-') {
                add(&mut units, first);
                continue;
            }
            self.at += 1;
            match self.cur() {
                None => break,
                Some(']') => {
                    add(&mut units, first);
                    units.push((dash, dash));
                    break;
                }
                Some(_) => {}
            }
            match (first, self.class_atom()?) {
                (Atom::Unit(a), Atom::Unit(b)) if a > b => return Err("Range out of order in character class"),
                (Atom::Unit(a), Atom::Unit(b)) => units.push((a, b)),
                (a, b) => {
                    add(&mut units, a);
                    units.push((dash, dash));
                    add(&mut units, b);
                }
            }
        }
        if self.cur().is_none() {
            return Err("Unterminated character class");
        }
        self.at += 1;
        Ok(Node::Set { units: normalize(units), negated })
    }

    /// One code unit of a class, or the set an escape names.
    fn class_atom(&mut self) -> Result<Atom, &'static str> {
        if self.cur() != Some('\\') {
            self.at += 1;
            return Ok(Atom::Unit(self.src[self.at - 1]));
        }
        match self.peek(1) {
            None => Err("\\ at end of pattern"),
            Some('b') => {
                self.at += 2;
                Ok(Atom::Unit(0x08))
            }
            Some(e @ ('d' | 'D' | 's' | 'S' | 'w' | 'W')) => {
                self.at += 2;
                Ok(Atom::Set(class_escape(e)))
            }
            Some(_) => {
                self.at += 1;
                Ok(Atom::Unit(self.character_escape(true)?))
            }
        }
    }

    /// The length of the `{n}`, `{n,}` or `{n,m}` here, if there is one.
    fn interval_len(&self) -> Option<usize> {
        let digits = |from: usize| (from..self.src.len() - self.at).take_while(|&i| self.digit(i).is_some()).count();
        let n = digits(1);
        if n == 0 {
            return None;
        }
        match self.peek(1 + n)? {
            '}' => Some(n + 2),
            ',' => {
                let m = digits(n + 2);
                (self.peek(n + 2 + m)? == '}').then_some(n + m + 3)
            }
            _ => None,
        }
    }

    /// `ParseIntervalQuantifier`, without moving: the counts of the `{…}` here, each at most [`INFINITY`].
    fn interval(&self) -> Option<(u32, u32)> {
        let len = self.interval_len()?;
        let body: String = self.src[self.at + 1..self.at + len - 1].iter().map(|&u| unit_char(u)).collect();
        let count = |s: &str| -> u32 {
            s.bytes()
                .try_fold(0u32, |n, d| n.checked_mul(10)?.checked_add(u32::from(d - b'0')))
                .map_or(INFINITY, |n| n.min(INFINITY))
        };
        Some(match body.split_once(',') {
            None => (count(&body), count(&body)),
            Some((min, "")) => (count(min), INFINITY),
            Some((min, max)) => (count(min), count(max)),
        })
    }
}

/// A sequence, or the one thing in it.
fn sequence(mut seq: Vec<Node>) -> Node {
    if seq.len() == 1 { seq.pop().unwrap_or(Node::Empty) } else { Node::Seq(seq) }
}

/// What `\d`, `\s` and `\w` are, and their opposites, in code units.
fn class_escape(e: char) -> Units {
    let set: Units = match e.to_ascii_lowercase() {
        'd' => vec![(0x30, 0x39)],
        'w' => vec![(0x30, 0x39), (0x41, 0x5a), (0x5f, 0x5f), (0x61, 0x7a)],
        _ => vec![
            (0x09, 0x0d),
            (0x20, 0x20),
            (0xa0, 0xa0),
            (0x1680, 0x1680),
            (0x2000, 0x200a),
            (0x2028, 0x2029),
            (0x202f, 0x202f),
            (0x205f, 0x205f),
            (0x3000, 0x3000),
            (0xfeff, 0xfeff),
        ],
    };
    if e.is_ascii_uppercase() { complement(&set) } else { set }
}

/// Ranges sorted, with those that overlap or touch made one.
pub(super) fn normalize(mut units: Units) -> Units {
    units.sort_unstable();
    let mut out: Units = Vec::with_capacity(units.len());
    for (lo, hi) in units {
        match out.last_mut() {
            Some(last) if u32::from(lo) <= u32::from(last.1) + 1 => last.1 = last.1.max(hi),
            _ => out.push((lo, hi)),
        }
    }
    out
}

/// Every code unit not in `units`, which is normalized.
pub(super) fn complement(units: &Units) -> Units {
    let mut out = Units::new();
    let mut next = 0u32;
    for &(lo, hi) in units {
        if u32::from(lo) > next {
            out.push((u16::try_from(next).unwrap_or(u16::MAX), lo - 1));
        }
        next = u32::from(hi) + 1;
    }
    if next <= 0xffff {
        out.push((u16::try_from(next).unwrap_or(u16::MAX), 0xffff));
    }
    out
}
