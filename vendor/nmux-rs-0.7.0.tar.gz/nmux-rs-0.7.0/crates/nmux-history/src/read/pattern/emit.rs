//! A pattern read as JavaScript reads it, written in `fancy-regex`'s syntax so that it means the same there, over text whose
//! characters are UTF-16 code units (see [`stand_in`]).
//!
//! `fancy-regex` is never asked to fold case or to know line ends: JavaScript does both its own way. A letter matches what
//! JavaScript's `Canonicalize` makes the same as it, `^` and `$` with `m` stop at `\r`, U+2028 and U+2029 too, and `\b` is
//! about ASCII word characters. A backreference to a group that took no part matches nothing, as in JavaScript, and a
//! lookahead may be repeated, which takes it once or not at all.

use std::collections::HashMap;
use std::fmt::Write as _;
use std::sync::OnceLock;

use super::parse::{DOT_ALL, IGNORE_CASE, INFINITY, MULTI_LINE, Node, Units, complement, normalize};

/// The characters text is written in for the engine, one for each UTF-16 code unit: a surrogate is written as one of
/// U+E000 to U+E7FF, which the code units from U+E000 to U+E7FF make way for by being written as U+F0000 to U+F07FF.
pub(super) fn stand_in(unit: u16) -> char {
    let v = u32::from(unit);
    let c = match v {
        0xd800..=0xdfff => v - 0xd800 + 0xe000,
        0xe000..=0xe7ff => v - 0xe000 + 0xf0000,
        _ => v,
    };
    char::from_u32(c).unwrap_or('\u{fffd}')
}

/// The most a count can be and still be counted: past it, a least count can never be met in a line of text, and a most
/// is no bound.
const COUNTED: u32 = 1000;

/// What never matches: a class of nothing, which unlike `(?!)` the engine can put in a lookbehind of more than one length.
const NEVER: &str = r"[^\x{0}-\x{10FFFF}]";

/// The line ends of JavaScript, for `^` and `$` with `m`.
const LINE_ENDS: &str = r"[\n\r\x{2028}\x{2029}]";
/// `\b` between ASCII word characters and the rest.
const BOUNDARY: &str = r"(?:(?<=[0-9A-Za-z_])(?![0-9A-Za-z_])|(?<![0-9A-Za-z_])(?=[0-9A-Za-z_]))";
/// `\B`.
const NOT_BOUNDARY: &str = r"(?:(?<=[0-9A-Za-z_])(?=[0-9A-Za-z_])|(?<![0-9A-Za-z_])(?![0-9A-Za-z_]))";

/// `node` in `fancy-regex`'s syntax, with these flags in force.
pub(super) fn emit(node: &Node, flags: u8, out: &mut String) {
    let fold = flags & IGNORE_CASE != 0;
    match node {
        Node::Empty | Node::Named(_) => {}
        Node::Unit(u) => set(&if fold { closure(&vec![(*u, *u)]) } else { vec![(*u, *u)] }, out),
        Node::Set { units, negated } => {
            let units = if fold { closure(units) } else { units.clone() };
            set(&if *negated { complement(&units) } else { units }, out);
        }
        Node::Dot if flags & DOT_ALL != 0 => out.push_str("(?s:.)"),
        Node::Dot => set(&complement(&vec![(0x0a, 0x0a), (0x0d, 0x0d), (0x2028, 0x2029)]), out),
        Node::Start if flags & MULTI_LINE != 0 => {
            let _ = write!(out, "(?:^|(?<={LINE_ENDS}))");
        }
        Node::End if flags & MULTI_LINE != 0 => {
            let _ = write!(out, "(?:$|(?={LINE_ENDS}))");
        }
        Node::Start => out.push('^'),
        Node::End => out.push('$'),
        Node::Boundary(yes) => out.push_str(if *yes { BOUNDARY } else { NOT_BOUNDARY }),
        Node::Look { behind, negative, body } => {
            out.push_str(match (behind, negative) {
                (false, false) => "(?=",
                (false, true) => "(?!",
                (true, false) => "(?<=",
                (true, true) => "(?<!",
            });
            emit(body, flags, out);
            out.push(')');
        }
        Node::Group { capture, body } => {
            out.push_str(if capture.is_some() { "(" } else { "(?:" });
            emit(body, flags, out);
            out.push(')');
        }
        Node::Modified { on, off, body } => emit(body, (flags | on) & !off, out),
        Node::Repeat { body, min, max, greedy } => repeat(body, *min, *max, *greedy, flags, out),
        Node::Backref(groups) => {
            // what the first group that took part captured, or nothing, as JavaScript has it
            for g in groups {
                let _ = write!(out, "(?({g}){}|", if fold { format!("(?i:\\{g})") } else { format!("\\{g}") });
            }
            out.push_str(&")".repeat(groups.len()));
        }
        Node::Alt(nodes) => {
            for (i, n) in nodes.iter().enumerate() {
                if i > 0 {
                    out.push('|');
                }
                emit(n, flags, out);
            }
        }
        Node::Seq(nodes) => nodes.iter().for_each(|n| emit(n, flags, out)),
    }
}

fn repeat(body: &Node, min: u32, max: u32, greedy: bool, flags: u8, out: &mut String) {
    // What takes no text, as a lookahead, is taken once if it must be and otherwise never: an iteration that takes none
    // is refused once the least count is met.
    let empty = takes_nothing(body);
    if max == 0 || (empty && min == 0) {
        // never taken, but written if it has groups, with a way in that fails, so that they keep their numbers unset
        if captures(body) {
            out.push_str("(?:");
            out.push_str(NEVER);
            emit(body, flags, out);
            out.push_str(")?");
        }
        return;
    }
    if empty {
        emit(body, flags, out);
        return;
    }
    out.push_str("(?:");
    if min > COUNTED {
        out.push_str(NEVER);
    }
    emit(body, flags, out);
    out.push(')');
    let max = if max > COUNTED { INFINITY } else { max };
    let min = min.min(COUNTED);
    match (min, max) {
        (0, INFINITY) => out.push('*'),
        (1, INFINITY) => out.push('+'),
        (0, 1) => out.push('?'),
        (n, INFINITY) => {
            let _ = write!(out, "{{{n},}}");
        }
        (n, m) if n == m => {
            let _ = write!(out, "{{{n}}}");
        }
        (n, m) => {
            let _ = write!(out, "{{{n},{m}}}");
        }
    }
    if !greedy {
        out.push('?');
    }
}

/// Whether `node` can only ever match where it starts, taking no text.
fn takes_nothing(node: &Node) -> bool {
    match node {
        Node::Empty | Node::Named(_) | Node::Start | Node::End | Node::Boundary(_) | Node::Look { .. } => true,
        Node::Group { body, .. } | Node::Modified { body, .. } => takes_nothing(body),
        Node::Repeat { body, max, .. } => *max == 0 || takes_nothing(body),
        Node::Alt(nodes) | Node::Seq(nodes) => nodes.iter().all(takes_nothing),
        Node::Unit(_) | Node::Set { .. } | Node::Dot | Node::Backref(_) => false,
    }
}

/// Whether `node` has a group that captures.
fn captures(node: &Node) -> bool {
    match node {
        Node::Group { capture: Some(_), .. } => true,
        Node::Group { body, .. }
        | Node::Modified { body, .. }
        | Node::Look { body, .. }
        | Node::Repeat { body, .. } => captures(body),
        Node::Alt(nodes) | Node::Seq(nodes) => nodes.iter().any(captures),
        _ => false,
    }
}

/// A class of exactly these code units, as the characters they are written as.
fn set(units: &Units, out: &mut String) {
    let mut ranges: Vec<(char, char)> = Vec::new();
    for &(lo, hi) in units {
        // the code units are written in four stretches, each in order
        for (from, to) in [(0x0000, 0xd7ff), (0xd800, 0xdfff), (0xe000, 0xe7ff), (0xe800, 0xffff)] {
            let (a, b) = (lo.max(from), hi.min(to));
            if a <= b {
                ranges.push((stand_in(a), stand_in(b)));
            }
        }
    }
    match ranges.as_slice() {
        [] => out.push_str(NEVER),
        [(a, b)] if a == b => {
            let _ = write!(out, "\\x{{{:X}}}", u32::from(*a));
        }
        _ => {
            out.push('[');
            for (a, b) in ranges {
                let _ = write!(out, "\\x{{{:X}}}", u32::from(a));
                if a != b {
                    let _ = write!(out, "-\\x{{{:X}}}", u32::from(b));
                }
            }
            out.push(']');
        }
    }
}

/// JavaScript's `Canonicalize` without the `u` flag: a code unit in upper case, unless that takes more than one, or
/// would make a letter beyond ASCII one within it.
fn canonicalize(unit: u16) -> u16 {
    let Some(c) = char::from_u32(u32::from(unit)) else { return unit };
    let mut upper = c.to_uppercase();
    match (upper.next(), upper.next()) {
        (Some(u), None) => match u16::try_from(u32::from(u)) {
            Ok(u) if !(unit >= 128 && u < 128) => u,
            _ => unit,
        },
        _ => unit,
    }
}

/// The code units that have a case, each with the others `Canonicalize` makes the same as it.
fn cased() -> &'static [Vec<u16>] {
    static CASED: OnceLock<Vec<Vec<u16>>> = OnceLock::new();
    CASED.get_or_init(|| {
        let mut alike: HashMap<u16, Vec<u16>> = HashMap::new();
        for unit in 0..=u16::MAX {
            alike.entry(canonicalize(unit)).or_default().push(unit);
        }
        let mut classes: Vec<Vec<u16>> = alike.into_values().filter(|c| c.len() > 1).collect();
        classes.sort_unstable();
        classes
    })
}

/// `units` with every code unit that matches one of them when case is ignored.
fn closure(units: &Units) -> Units {
    let has = |u: u16| {
        let i = units.partition_point(|&(_, hi)| hi < u);
        units.get(i).is_some_and(|&(lo, _)| lo <= u)
    };
    let mut out = units.clone();
    for class in cased() {
        if class.iter().any(|&u| has(u)) {
            out.extend(class.iter().map(|&u| (u, u)));
        }
    }
    normalize(out)
}
