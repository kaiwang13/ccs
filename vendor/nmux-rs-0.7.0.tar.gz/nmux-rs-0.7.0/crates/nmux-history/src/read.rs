//! Reading kept histories back: finding sessions, their lines, searching them, and the lines a pager shows. The reading half of
//! `src/client/history.js`. Nothing here needs a session to be running, so a session that ended long ago is as searchable as
//! one that is still going; what a running one has not written yet comes from it, and is handed in as [`Unwritten`].

use std::cmp::Ordering;
use std::fs::{self, File};
use std::io::{self, BufRead, BufReader};
use std::path::{Path, PathBuf};

use nmux_time::{Zone, day_of, stamp};
use serde::Serialize;
use serde_json::Value;

use crate::format::{self, Line as FileLine, META, first_row_of, plain};

pub mod pattern;

pub use pattern::Pattern;

/// A session that kept a history: its `meta.json`.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Kept {
    /// The session's id, which is its directory's name.
    pub id: String,
    /// What it was called.
    pub name: String,
    /// Where its files are.
    pub dir: PathBuf,
    /// When it started, as an ISO date.
    pub created_at: Option<String>,
    /// Where it started.
    pub cwd: Option<String>,
}

/// One line of a history: whole, however it wrapped, with the number of its first row and the time it was printed.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Line {
    /// The number of its first row.
    pub row: u64,
    /// When it was printed, in ms since 1970.
    pub at: i64,
    /// Its text, with its colours when they were asked for.
    pub text: String,
    /// In place of a line, this many rows were never written: the disk did not keep up.
    pub lost: Option<u64>,
}

/// Every session that kept a history under `root`, oldest first.
pub fn kept_under(root: &Path) -> Vec<Kept> {
    let Ok(entries) = fs::read_dir(root) else { return Vec::new() };
    let mut out = Vec::new();
    for entry in entries.flatten() {
        let id = entry.file_name().to_string_lossy().into_owned();
        let dir = root.join(&id);
        let Some(meta) = fs::read(dir.join(META)).ok().and_then(|b| serde_json::from_slice::<Value>(&b).ok()) else {
            continue;
        };
        let text = |key: &str| meta.get(key).and_then(truthy_text);
        out.push(Kept {
            name: text("name").unwrap_or_else(|| id.clone()),
            created_at: text("createdAt"),
            cwd: text("cwd"),
            id,
            dir,
        });
    }
    out.sort_by(by_start);
    out
}

/// A JSON value as `String(value || fallback)` has it: what JavaScript counts as nothing is none.
fn truthy_text(v: &Value) -> Option<String> {
    match v {
        Value::Null | Value::Bool(false) => None,
        Value::String(s) if s.is_empty() => None,
        Value::Number(n) if n.as_f64() == Some(0.0) => None,
        Value::String(s) => Some(s.clone()),
        Value::Bool(true) => Some("true".to_owned()),
        Value::Number(n) => Some(n.to_string()),
        Value::Array(_) | Value::Object(_) => Some(v.to_string()),
    }
}

/// A history's files, in order.
fn files_of(dir: &Path) -> Vec<(PathBuf, u64)> {
    let Ok(entries) = fs::read_dir(dir) else { return Vec::new() };
    let mut files: Vec<_> =
        entries.flatten().filter_map(|e| Some((e.path(), first_row_of(e.file_name().to_str()?)?))).collect();
    files.sort_by_key(|&(_, first)| first);
    files
}

/// A row as the emulator wrote it keeps a gap as a cursor move, which pagers drop: here it is the spaces it stood for.
pub fn spaced(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    let mut rest = text;
    while let Some(at) = rest.find("\x1b[") {
        let after = &rest[at + 2..];
        let digits = after.bytes().take_while(u8::is_ascii_digit).count();
        if after.as_bytes().get(digits) == Some(&b'C') {
            out.push_str(&rest[..at]);
            let n = after[..digits].parse::<usize>().ok().filter(|&n| n > 0).unwrap_or(1);
            out.extend(std::iter::repeat_n(' ', n));
            rest = &after[digits + 1..];
        } else {
            out.push_str(&rest[..at + 2]);
            rest = after;
        }
    }
    out.push_str(rest);
    out
}

/// The lines of a history, whole however they wrapped, each with its first row's number and its time, in colour with
/// `ansi`. A file that cannot be opened is skipped; one that fails while it is read ends the lines with the error.
pub fn lines_of(dir: &Path, ansi: bool) -> Lines {
    Lines {
        files: files_of(dir).into_iter(),
        reader: None,
        row: 0,
        at: 0,
        line: None,
        lost: None,
        ansi,
        buf: Vec::new(),
    }
}

/// See [`lines_of`].
#[derive(Debug)]
pub struct Lines {
    files: std::vec::IntoIter<(PathBuf, u64)>,
    reader: Option<BufReader<File>>,
    row: u64,
    at: i64,
    /// The line being joined, which goes out when the next one starts.
    line: Option<Line>,
    /// Rows that were never written, which go out after the line before them.
    lost: Option<Line>,
    ansi: bool,
    buf: Vec<u8>,
}

impl Iterator for Lines {
    type Item = io::Result<Line>;

    fn next(&mut self) -> Option<Self::Item> {
        loop {
            if let Some(lost) = self.lost.take() {
                return Some(Ok(lost));
            }
            let Some(reader) = self.reader.as_mut() else {
                let Some((file, first)) = self.files.next() else { return self.line.take().map(Ok) };
                // A file that has gone since the directory was read is skipped, as one that cannot be opened is.
                if let Ok(f) = File::open(file) {
                    self.reader = Some(BufReader::with_capacity(1 << 20, f));
                    self.row = first;
                }
                continue;
            };
            self.buf.clear();
            match reader.read_until(b'\n', &mut self.buf) {
                Err(e) => {
                    self.reader = None;
                    return Some(Err(e));
                }
                // The end, or a last line the writer had not finished: that one is not a line yet.
                Ok(_) if self.buf.last() != Some(&b'\n') => self.reader = None,
                Ok(_) => {
                    self.buf.pop();
                    let buf = std::mem::take(&mut self.buf);
                    let done = self.take(&String::from_utf8_lossy(&buf));
                    self.buf = buf;
                    if let Some(done) = done {
                        return Some(Ok(done));
                    }
                }
            }
        }
    }
}

impl Lines {
    /// Takes in one line of a file, and gives back a line that is complete because of it.
    fn take(&mut self, text: &str) -> Option<Line> {
        match FileLine::parse(text)? {
            FileLine::Time(at) => {
                self.at = at;
                None
            }
            FileLine::Lost(rows) => {
                self.lost = Some(Line { row: self.row, at: self.at, text: String::new(), lost: Some(rows) });
                self.row += rows;
                self.line.take().or_else(|| self.lost.take())
            }
            FileLine::Row { text, continues } => {
                let text = if self.ansi { spaced(text) } else { plain(text).into_owned() };
                self.row += 1;
                match &mut self.line {
                    Some(line) if continues => {
                        line.text.push_str(&text);
                        None
                    }
                    _ => self.line.replace(Line { row: self.row - 1, at: self.at, text, lost: None }),
                }
            }
            FileLine::Mark(_) => None,
        }
    }
}

/// What a running session has not yet written to its history, as its answer to `UNWRITTEN` says: the lines still in its
/// scrollback and on its screen, numbered on from what is written, which is everything before `first`.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Unwritten {
    /// The first row it has not written.
    pub first: u64,
    /// Its lines.
    pub lines: Vec<Line>,
}

impl Unwritten {
    /// Reads the text of an answer: `count` lines of `rows \t at \t text`. A line with no time of its own is given `now`'s.
    pub fn parse(output: &[u8], first: u64, count: usize, ansi: bool, now: i64) -> Self {
        let text = String::from_utf8_lossy(output);
        let mut row = first;
        let mut lines = Vec::new();
        for entry in text.split('\n').take(count) {
            let a = entry.find('\t');
            let b = a.and_then(|a| entry[a + 1..].find('\t').map(|b| a + 1 + b));
            let field = |from: usize, to: Option<usize>| entry.get(from..to.unwrap_or(entry.len())).unwrap_or("");
            let at = js_number(field(a.map_or(0, |a| a + 1), b)).filter(|&at| at > 0.0);
            let line_text = b.map_or(entry, |b| &entry[b + 1..]);
            #[allow(clippy::cast_possible_truncation)] // a time in ms, which a server writes whole
            let at = at.map_or(now, |at| at as i64);
            lines.push(Line { row, at, text: if ansi { spaced(line_text) } else { line_text.to_owned() }, lost: None });
            #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)] // a count of rows
            let rows = js_number(field(0, a)).filter(|&n| n >= 1.0).map_or(1, |n| n as u64);
            row += rows;
        }
        Self { first, lines }
    }
}

/// `Number(text)` for the plain decimals a server writes, and nothing for anything else.
fn js_number(text: &str) -> Option<f64> {
    let t = text.trim();
    if t.is_empty() {
        return Some(0.0);
    }
    t.parse::<f64>().ok().filter(|n| n.is_finite())
}

/// Every line of a history: what is written, then what a running session still has. The running session is asked first, and
/// it answers once what it has given its history is on disk, so each line comes from one place or the other, never both.
pub fn all_lines_of(kept: &Kept, live: Option<Unwritten>, ansi: bool) -> impl Iterator<Item = io::Result<Line>> {
    let unwritten = live.as_ref().map(|l| l.first);
    let written = lines_of(&kept.dir, ansi)
        .take_while(move |l| !matches!((l, unwritten), (Ok(written), Some(first)) if written.row >= first));
    written.chain(live.into_iter().flat_map(|l| l.lines).map(Ok))
}

/// What a search is narrowed to: times in ms since 1970.
#[derive(Clone, Copy, Debug)]
pub struct Window {
    /// Lines printed before this are left out.
    pub since: Option<i64>,
    /// Lines printed after this are left out.
    pub until: Option<i64>,
}

/// Whether a line is one a search for `re` in `window` finds.
pub fn matches(line: &Line, re: &Pattern, window: Window) -> bool {
    line.lost.is_none()
        && window.since.is_none_or(|s| line.at >= s)
        && window.until.is_none_or(|u| line.at <= u)
        && re.is_match(&line.text)
}

/// A match as `search` prints it: the session, the time, the line's number, and the line, which is from a terminal and so is
/// made harmless to print. On a terminal the match stands out.
pub fn match_text(kept: &Kept, line: &Line, zone: &Zone, re: &Pattern, color: bool) -> String {
    let text = printable(&line.text);
    let lit = if color { re.highlight(&text, "\x1b[7m", "\x1b[27m") } else { text };
    let (dim, reset) = if color { ("\x1b[2m", "\x1b[0m") } else { ("", "") };
    format!("{dim}{}  {}  #{}{reset}  {lit}", kept.name, stamp(line.at, zone), line.row)
}

/// Text from a terminal or a file, made safe to print: nothing in it can drive the terminal.
pub fn printable(text: &str) -> String {
    text.chars().map(|c| if matches!(c, '\0'..='\x1f' | '\x7f'..='\u{9f}') { '?' } else { c }).collect()
}

/// A match as one line of JSON.
pub fn match_json(kept: &Kept, line: &Line) -> String {
    #[derive(Serialize)]
    struct Match<'a> {
        session: &'a str,
        name: &'a str,
        row: u64,
        at: String,
        text: &'a str,
    }
    let m = Match { session: &kept.id, name: &kept.name, row: line.row, at: nmux_time::iso(line.at), text: &line.text };
    serde_json::to_string(&m).unwrap_or_default()
}

/// One line as a pager is given it: the day's line above it when it is the first of its day, and the line itself.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Paged {
    /// `── Sunday 1 November 2026 · Europe/Paris · api ──`, or nothing.
    pub head: String,
    /// The line, with its newline.
    pub body: String,
    /// The line it was made from.
    pub line: Line,
}

/// Lines as a pager shows them. Each day starts with a line saying which, in `zone`, so that a search for a date finds it.
/// `times`: each line starts with the time it was printed.
#[derive(Debug)]
pub struct Pages<'z> {
    zone: &'z Zone,
    name: String,
    times: bool,
    day: String,
}

impl<'z> Pages<'z> {
    /// Pages of the history of the session called `name`.
    pub fn new(zone: &'z Zone, name: &str, times: bool) -> Self {
        Self { zone, name: name.to_owned(), times, day: String::new() }
    }

    /// The next line.
    pub fn page(&mut self, line: Line) -> Paged {
        let d = day_of(line.at, self.zone);
        let head = if d.key == self.day {
            String::new()
        } else {
            format!("\x1b[2m── {} · {} · {} ──\x1b[0m\n", d.words, self.zone.name(), self.name)
        };
        self.day = d.key;
        let body = match line.lost {
            Some(n) => {
                let rows = if n == 1 { "row was" } else { "rows were" };
                format!("\x1b[2m── {n} {rows} not kept: the disk did not keep up ──\x1b[0m\n")
            }
            None if self.times => format!("\x1b[2m{}\x1b[0m {}\x1b[0m\n", &stamp(line.at, self.zone)[11..], line.text),
            None => format!("{}\x1b[0m\n", line.text),
        };
        Paged { head, body, line }
    }
}

/// Where a pager opens: at a time, at a row, or else at the end.
#[derive(Clone, Copy, Debug, Default)]
pub struct Target {
    /// The first line printed at or after this, in ms since 1970.
    pub at: Option<i64>,
    /// The first line at or after this row.
    pub row: Option<u64>,
}

/// The pager's line number to open at, under the day's line of the line it opens on, or `None` for the end.
pub fn target_line(paged: impl Iterator<Item = io::Result<Paged>>, target: Target) -> io::Result<Option<u64>> {
    if target.at.is_none() && target.row.is_none() {
        return Ok(None);
    }
    let mut n = 0;
    for p in paged {
        let p = p?;
        let head = u64::from(!p.head.is_empty());
        n += head;
        if target.at.is_some_and(|at| p.line.at >= at) || target.row.is_some_and(|row| p.line.row >= row) {
            return Ok(Some(n + 1 - head));
        }
        n += 1;
    }
    Ok(None)
}

/// The arguments a pager is started with: open at the first match of `grep`, at a line, or at the end.
pub fn pager_args(grep: Option<&str>, target: Option<u64>) -> Vec<String> {
    match (grep, target) {
        (Some(grep), _) => vec!["-p".to_owned(), grep.to_owned()],
        (None, Some(line)) => vec![format!("+{line}g")],
        (None, None) => vec!["+G".to_owned()],
    }
}

/// What a page is when it goes somewhere that is not a terminal: its text, with no colours.
pub fn plain_page(p: &Paged) -> String {
    format::plain(&format!("{}{}", p.head, p.body)).into_owned()
}

/// Oldest first, by `String(createdAt)`: one with none sorts as "null".
fn by_start(a: &Kept, b: &Kept) -> Ordering {
    a.created_at.as_deref().unwrap_or("null").cmp(b.created_at.as_deref().unwrap_or("null"))
}
