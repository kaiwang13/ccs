//! The spool's own thread: it owns the files, and does everything that can wait for the disk, in the order it was given.

use std::fs::{self, File, OpenOptions, Permissions};
use std::io::{self, Write as _};
use std::os::unix::fs::{OpenOptionsExt, PermissionsExt};
use std::path::{Path, PathBuf};
use std::sync::atomic::Ordering;
use std::sync::{Arc, PoisonError};

use super::carry::{READ_BYTES, last_mark, whole_rows};
use super::{Answer, Chunk, Clock, Event, Job, Level, Log, Options, SEGMENT_BYTES, Shared, lock, scan, write_meta};
use crate::format::{Mark, PREFIX};

/// What only the spool's thread touches once the files are open.
pub(super) struct Writer {
    dir: PathBuf,
    max_bytes: u64,
    keep: bool,
    wall_now: Clock,
    file: Option<File>,
    file_bytes: u64,
    /// The time the current file last said, or `None` if it has said none yet.
    file_time: Option<i64>,
    shared: Arc<Shared>,
    #[cfg(test)]
    hold: Option<super::tests::Hold>,
}

impl Writer {
    pub(super) fn new(options: &Options, shared: Arc<Shared>) -> Self {
        Self {
            dir: options.dir.clone(),
            max_bytes: options.max_bytes,
            keep: options.keep,
            wall_now: Arc::clone(&options.wall_now),
            file: None,
            file_bytes: 0,
            file_time: None,
            shared,
            #[cfg(test)]
            hold: None,
        }
    }

    /// Carries on from whatever is there: how many rows there are, and the last mark. Every write ends with a watermark,
    /// but a server can go in the middle of one, when it crashes or a slow disk outlasts its wait, and leave part of a
    /// chunk after the last. That part is cut off: written again after it, its rows would be there twice and its last row
    /// would run into the next. The server carrying on writes them again, from where the mark says. A file started for
    /// a chunk that never got as far as its mark has nothing before it that is not in the file before.
    pub(super) fn open(&mut self, log: &mut dyn Log) -> io::Result<(u64, Option<Mark>)> {
        let mut files = scan::files(&self.dir);
        loop {
            let Some(last) = files.pop() else {
                self.start_file(0)?;
                return Ok((0, None));
            };
            let file = File::open(&last.path)?;
            let size = file.metadata()?.len();
            let found = last_mark(&file, size, READ_BYTES)?;
            let counted =
                if found.is_none() && files.is_empty() { whole_rows(&file, size, READ_BYTES)? } else { (0, 0) };
            drop(file);
            let name = last.path.display().to_string();
            if found.is_none() && !files.is_empty() {
                if size > 0 {
                    log.log(Level::Warn, "spool.cut", &[("file", name.into()), ("bytes", size.into())]);
                }
                remove(&last.path)?;
                continue;
            }
            let (carried, end) = match found {
                Some((mark, end)) => ((mark.lines, Some(mark)), end),
                // Nothing says how far it went: as far as it has rows.
                None => ((last.first + counted.0, None), counted.1),
            };
            if end < size {
                log.log(Level::Warn, "spool.cut", &[("file", name.into()), ("bytes", (size - end).into())]);
                OpenOptions::new().write(true).open(&last.path)?.set_len(end)?;
            }
            self.file = Some(OpenOptions::new().append(true).create(true).mode(0o600).open(&last.path)?);
            self.file_bytes = end;
            return Ok(carried);
        }
    }

    /// Does what it is given until the spool has gone and there is nothing left.
    pub(super) fn run(mut self) {
        while let Some(job) = self.next() {
            match job {
                Job::Chunk(chunk) => {
                    if !self.shared.failed.load(Ordering::Acquire)
                        && let Err(e) = self.write(&chunk)
                        && let Some(event) = self.shared.fail(&e)
                    {
                        self.shared.tell(event);
                    }
                }
                Job::Describe(json) => {
                    if let Err(e) = write_meta(&self.dir, &json) {
                        let fields = vec![("error", e.to_string().into())];
                        self.shared.tell(Event::Log(Level::Warn, "spool.meta_failed", fields));
                    }
                }
                Job::Idle(ticket) => self.shared.answer(ticket, Answer::Idle),
                Job::Read(ticket, read) => scan::spawn(&self.shared, &self.dir, ticket, read),
                Job::Close(ticket) => {
                    self.file = None;
                    self.shared.answer(ticket, Answer::Closed);
                }
                #[cfg(test)]
                Job::Hold(hold) => self.hold = Some(hold),
                #[cfg(test)]
                Job::Replace(file) => self.file = Some(file),
            }
        }
    }

    fn next(&self) -> Option<Job> {
        let mut queue = lock(&self.shared.queue);
        loop {
            if let Some(job) = queue.jobs.pop_front() {
                if let Job::Chunk(chunk) = &job {
                    queue.queued = queue.queued.saturating_sub(chunk.bytes);
                }
                return Some(job);
            }
            if queue.gone {
                return None;
            }
            queue = self.shared.work.wait(queue).unwrap_or_else(PoisonError::into_inner);
        }
    }

    /// Adding this much to the current file takes it past its limit.
    fn full(&self, adding: u64) -> bool {
        let bytes = self.file_bytes + adding;
        if self.keep { bytes > SEGMENT_BYTES } else { bytes.saturating_mul(2) > self.max_bytes }
    }

    fn write(&mut self, chunk: &Chunk) -> io::Result<()> {
        let (mut text, mut said) = chunk.serialize(self.file_time, &self.wall_now);
        if self.full(text.len() as u64) && self.file_bytes > 0 {
            // The rows it says were lost are the file's first.
            self.start_file(chunk.first.saturating_sub(chunk.lost))?;
            (text, said) = chunk.serialize(self.file_time, &self.wall_now);
        }
        self.put(text.as_bytes())?;
        self.file_bytes += text.len() as u64;
        self.file_time = Some(said);
        self.shared.written.store(chunk.mark.lines, Ordering::Release);
        Ok(())
    }

    #[cfg(not(test))]
    fn put(&mut self, bytes: &[u8]) -> io::Result<()> {
        self.file.as_mut().ok_or_else(|| io::Error::other("no file is open"))?.write_all(bytes)
    }

    #[cfg(test)]
    fn put(&mut self, bytes: &[u8]) -> io::Result<()> {
        let file = self.file.as_mut().ok_or_else(|| io::Error::other("no file is open"))?;
        let Some(hold) = self.hold.take() else { return file.write_all(bytes) };
        let half = bytes.len() / 2;
        file.write_all(&bytes[..half])?;
        hold.holding();
        file.write_all(&bytes[half..])
    }

    /// `first`: the number of the file's first row.
    fn start_file(&mut self, first: u64) -> io::Result<()> {
        self.file = None;
        let file =
            OpenOptions::new().append(true).create(true).mode(0o600).open(self.dir.join(format!("{PREFIX}{first}")))?;
        file.set_permissions(Permissions::from_mode(0o600))?;
        self.file = Some(file);
        self.file_bytes = 0;
        // Each file says when it starts.
        self.file_time = None;
        if !self.keep {
            let files = scan::files(&self.dir);
            for old in &files[..files.len().saturating_sub(2)] {
                remove(&old.path)?;
            }
        }
        Ok(())
    }
}

/// Removes a file that may have gone already.
fn remove(path: &Path) -> io::Result<()> {
    match fs::remove_file(path) {
        Err(e) if e.kind() != io::ErrorKind::NotFound => Err(e),
        _ => Ok(()),
    }
}
