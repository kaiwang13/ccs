//! Reading a spool's rows back, as whole lines. A read runs on a thread of its own, started once everything queued before
//! it is on disk, so that a long one holds no write up: what the writer adds meanwhile is numbered past where the read
//! stops, and a file the writer removes meanwhile is one whose rows have gone.

use std::borrow::Cow;
use std::fs::{self, File};
use std::io::{self, Read as _};
use std::path::{Path, PathBuf};
use std::sync::Arc;

use super::carry::READ_BYTES;
use super::{Answer, Shared, Ticket};
use crate::format::{Line, first_row_of, plain};

/// A history file, and the number of its first row.
#[derive(Debug)]
pub(super) struct HistoryFile {
    pub(super) path: PathBuf,
    pub(super) first: u64,
}

/// The history files in `dir`, oldest first: none if it cannot be read.
pub(super) fn files(dir: &Path) -> Vec<HistoryFile> {
    let Ok(entries) = fs::read_dir(dir) else { return Vec::new() };
    let mut files: Vec<_> = entries
        .filter_map(|entry| {
            let entry = entry.ok()?;
            let first = first_row_of(entry.file_name().to_str()?)?;
            Some(HistoryFile { path: entry.path(), first })
        })
        .collect();
    files.sort_by_key(|f| f.first);
    files
}

/// What is to be read.
#[derive(Clone, Copy, Debug)]
pub(super) enum Read {
    /// The rows numbered `from` up to `to`.
    Range { from: u64, to: u64, ansi: bool },
    /// The last `count` lines, or all of them, of the rows before `to`.
    LastLines { to: u64, count: Option<usize>, ansi: bool },
}

impl Read {
    fn run(self, dir: &Path) -> Answer {
        match self {
            Self::Range { from, to, ansi } => Answer::Range(range(dir, from, to, ansi)),
            Self::LastLines { to, count, ansi } => Answer::LastLines(last_lines(dir, to, count, ansi)),
        }
    }

    fn failed(self, e: io::Error) -> Answer {
        match self {
            Self::Range { .. } => Answer::Range(Err(e)),
            Self::LastLines { .. } => Answer::LastLines(Err(e)),
        }
    }
}

/// Reads on a thread of its own, and answers `ticket` with what it found.
pub(super) fn spawn(shared: &Arc<Shared>, dir: &Path, ticket: Ticket, read: Read) {
    let answers = Arc::clone(shared);
    let dir = dir.to_owned();
    let started = std::thread::Builder::new()
        .name("nmux-spool-read".into())
        .spawn(move || answers.answer(ticket, read.run(&dir)));
    if let Err(e) = started {
        shared.answer(ticket, read.failed(e));
    }
}

/// Adds a row to whole lines, however they wrapped.
fn add(lines: &mut Vec<String>, row: &str, continues: bool, ansi: bool) {
    let text = if ansi { Cow::Borrowed(row) } else { plain(row) };
    match lines.last_mut() {
        Some(last) if continues => last.push_str(&text),
        _ => lines.push(text.into_owned()),
    }
}

/// The rows with these numbers, as whole lines, or `None` if some of them have gone.
fn range(dir: &Path, from: u64, to: u64, ansi: bool) -> io::Result<Option<Vec<String>>> {
    let files = files(dir);
    if files.first().is_none_or(|f| f.first > from) {
        return Ok(None);
    }
    let mut lines = Vec::new();
    let mut seen = false;
    let whole = scan(&files, from, to, &mut |row, continues| {
        add(&mut lines, row, continues, ansi);
        seen = true;
    })?;
    Ok((whole && (seen || to <= from)).then_some(lines))
}

/// The last lines there are before row `to`: all of them, or the last `count`.
fn last_lines(dir: &Path, to: u64, count: Option<usize>, ansi: bool) -> io::Result<Vec<String>> {
    let mut lines = Vec::new();
    scan(&files(dir), 0, to, &mut |row, continues| {
        add(&mut lines, row, continues, ansi);
        // The last may yet be added to.
        if let Some(count) = count
            && lines.len() > count.saturating_mul(2).saturating_add(1)
        {
            lines.drain(..lines.len() - count - 1);
        }
    })?;
    if let Some(count) = count {
        lines.drain(..lines.len().saturating_sub(count));
    }
    Ok(lines)
}

/// Hands over the rows numbered `from` up to `to`, a piece at a time. Whether every file it needed was still there.
pub(super) fn scan(files: &[HistoryFile], from: u64, to: u64, visit: &mut dyn FnMut(&str, bool)) -> io::Result<bool> {
    let mut whole = true;
    for (i, file) in files.iter().enumerate() {
        if files.get(i + 1).is_some_and(|next| next.first <= from) || file.first >= to {
            continue;
        }
        match scan_file(file, from, to, visit) {
            // Rotated away just now.
            Err(e) if e.kind() == io::ErrorKind::NotFound => whole = false,
            done => done?,
        }
    }
    Ok(whole)
}

/// The rows of one file, numbered from its first.
fn scan_file(file: &HistoryFile, from: u64, to: u64, visit: &mut dyn FnMut(&str, bool)) -> io::Result<()> {
    let mut handle = File::open(&file.path)?;
    let mut buf = vec![0; READ_BYTES];
    let mut number = file.first;
    // A line that one read divides: its start, until the read that ends it.
    let mut rest = Vec::new();
    // Whether to go on.
    let mut line = |line: &[u8]| -> bool {
        match line.first() {
            Some(b'!') => {
                if let Some(Line::Lost(rows)) = std::str::from_utf8(line).ok().and_then(Line::parse) {
                    number += rows;
                }
            }
            Some(&kind @ (b'.' | b'+')) => {
                if number >= to {
                    return false;
                }
                if number >= from {
                    visit(&String::from_utf8_lossy(&line[1..]), kind == b'+');
                }
                number += 1;
            }
            _ => {}
        }
        true
    };
    loop {
        let n = match handle.read(&mut buf) {
            Ok(0) => return Ok(()),
            Ok(n) => n,
            Err(e) if e.kind() == io::ErrorKind::Interrupted => continue,
            Err(e) => return Err(e),
        };
        let mut start = 0;
        while let Some(nl) = buf[start..n].iter().position(|&b| b == b'\n').map(|i| start + i) {
            let going = if rest.is_empty() {
                line(&buf[start..nl])
            } else {
                rest.extend_from_slice(&buf[start..nl]);
                let going = line(&rest);
                rest.clear();
                going
            };
            if !going {
                return Ok(());
            }
            start = nl + 1;
        }
        rest.extend_from_slice(&buf[start..n]);
    }
}
