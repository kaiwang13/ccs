//! Replays `tests/data/spool.golden`, which `tests/data/spool.js` made by driving the Node spool: the same steps here must
//! give the same answers, the same files and the same logs, byte for byte.

use std::fmt::Write as _;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::Path;
use std::sync::Arc;
use std::sync::atomic::{AtomicI64, Ordering};

use serde_json::{Map, Value, json};

use super::tests::{Harness, TempDir};
use super::{Meta, Options};

const GOLDEN: &str = include_str!("../../tests/data/spool.golden");

fn text(value: &Value) -> String {
    value.as_str().expect("a string").to_owned()
}

fn number(value: &Value) -> u64 {
    value.as_u64().expect("a number")
}

fn texts(value: &Value) -> Vec<String> {
    value.as_array().expect("an array").iter().map(text).collect()
}

fn meta(value: &Value) -> Meta {
    let optional = |key: &str| value.get(key).map(text);
    Meta {
        id: text(&value["id"]),
        name: optional("name"),
        created_at: optional("createdAt"),
        cwd: optional("cwd"),
        argv: texts(&value["argv"]),
    }
}

/// Every file in `dir`, as `files` in the Node script says it.
fn files(dir: &Path) -> Value {
    let mut names: Vec<_> = fs::read_dir(dir)
        .expect("the directory")
        .map(|e| e.expect("an entry").file_name().into_string().expect("a name"))
        .collect();
    names.sort();
    names
        .into_iter()
        .map(|name| {
            let path = dir.join(&name);
            let bytes = fs::read(&path).expect("the file");
            let mode = fs::metadata(&path).expect("the file").permissions().mode() & 0o777;
            match String::from_utf8(bytes) {
                Ok(text) => json!({ "name": name, "mode": mode, "text": text }),
                Err(e) => {
                    let hex = e.as_bytes().iter().fold(String::new(), |mut hex, b| {
                        let _ = write!(hex, "{b:02x}");
                        hex
                    });
                    json!({ "name": name, "mode": mode, "hex": hex })
                }
            }
        })
        .collect()
}

/// What was logged, as the Node script records it: the file a record names by its name alone.
fn logs(logged: Vec<(&'static str, Vec<(&'static str, Value)>)>) -> Vec<Value> {
    logged
        .into_iter()
        .map(|(code, fields)| {
            let fields: Map<String, Value> = fields
                .into_iter()
                .map(|(key, value)| match (key, &value) {
                    ("file", Value::String(file)) => {
                        let name = Path::new(file).file_name().and_then(|n| n.to_str()).unwrap_or_default();
                        (key.to_owned(), Value::from(name))
                    }
                    _ => (key.to_owned(), value),
                })
                .collect();
            json!([code, fields])
        })
        .collect()
}

fn replay(sequence: &Value) {
    let name = text(&sequence["name"]);
    let dir = TempDir::new();
    let now = Arc::new(AtomicI64::new(0));
    let mut open: Option<Harness> = None;
    let mut logged = Vec::new();
    for (i, step) in sequence["steps"].as_array().expect("steps").iter().enumerate() {
        let op = step["op"].as_str().expect("an op");
        let what = format!("{name}, step {i}: {op}");
        let got = match op {
            "now" => {
                now.store(step["at"].as_i64().expect("a time"), Ordering::Release);
                None
            }
            "open" => {
                assert!(open.is_none(), "{what}");
                let clock = Arc::clone(&now);
                let options = Options {
                    keep: step.get("keep").and_then(Value::as_bool).unwrap_or(false),
                    meta: step.get("meta").map(meta),
                    wall_now: Arc::new(move || clock.load(Ordering::Acquire)),
                    ..Options::new(dir.path(), number(&step["maxBytes"]))
                };
                let s = Harness::new(options);
                let opened = json!({ "lines": s.lines(), "failed": s.failed() });
                open = Some(s);
                Some(opened)
            }
            "files" => Some(files(dir.path())),
            "put" => {
                let path = dir.join(&text(&step["file"]));
                fs::write(&path, text(&step["text"])).expect("put");
                fs::set_permissions(&path, fs::Permissions::from_mode(0o644)).expect("chmod");
                None
            }
            "tear" => {
                let path = dir.join(&text(&step["file"]));
                fs::File::options()
                    .write(true)
                    .open(&path)
                    .and_then(|f| f.set_len(number(&step["size"])))
                    .expect("tear");
                None
            }
            "close" => {
                let mut s = open.take().expect("open");
                s.close();
                logged.extend(s.logs());
                None
            }
            _ => {
                let s = open.as_mut().unwrap_or_else(|| panic!("{what}: nothing is open"));
                match op {
                    "stream" => s.stream(number(&step["gen"])),
                    "newStream" => s.new_stream(number(&step["gen"])),
                    "resume" => s.resume(number(&step["gen"])),
                    "idle" => s.idle(),
                    "behind" => s.behind(step["on"].as_bool().expect("on")),
                    "describe" => s.describe(&meta(&step["meta"])),
                    _ => {}
                }
                match op {
                    "alreadyHas" => Some(json!(s.already_has(number(&step["offset"])))),
                    "lines" => Some(json!(s.lines())),
                    "append" => {
                        let wrapped = step["wrapped"].as_array().expect("wrapped").iter();
                        let times = step["times"].as_array().map(|t| t.iter().map(|t| t.as_i64().expect("a time")));
                        Some(json!(s.append(
                            texts(&step["rows"]),
                            wrapped.map(|w| w.as_bool().expect("a flag")).collect(),
                            number(&step["offset"]),
                            times.map(Iterator::collect),
                        )))
                    }
                    "range" => {
                        let ansi = step.get("ansi").and_then(Value::as_bool).unwrap_or(false);
                        Some(json!(s.range(number(&step["from"]), number(&step["to"]), ansi)))
                    }
                    "lastLines" => {
                        let ansi = step.get("ansi").and_then(Value::as_bool).unwrap_or(false);
                        let count = step["count"].as_u64().map(|n| usize::try_from(n).expect("a count"));
                        Some(json!(s.last_lines(count, ansi)))
                    }
                    "stream" | "newStream" | "resume" | "idle" | "behind" | "describe" => None,
                    _ => panic!("{what}: an op the Node script does not have"),
                }
            }
        };
        match (step.get("result"), got) {
            (Some(expected), Some(got)) => assert_eq!(&got, expected, "{what}"),
            (None, None) => {}
            (expected, got) => panic!("{what}: Node answered {expected:?}, this {got:?}"),
        }
    }
    assert!(open.is_none(), "{name} ends closed");
    assert_eq!(Value::Array(logs(logged)), sequence["logs"], "{name}: logged");
}

#[test]
fn the_files_are_the_ones_the_node_spool_writes() {
    let mut replayed = 0;
    for line in GOLDEN.lines() {
        replay(&serde_json::from_str(line).expect("a sequence"));
        replayed += 1;
    }
    assert_eq!(replayed, 7);
}
