//! `test/unit/spool.test.js`, every case, and what only a spool with a thread of its own could get wrong. Nothing here
//! sleeps: a test waits for the answer it asserts, or for the writer to say it is in the middle of a write.

use std::cell::RefCell;
use std::fs::{self, File};
use std::ops::{Deref, DerefMut};
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::rc::Rc;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, mpsc};

use serde_json::Value;

use super::carry::{last_mark, whole_rows};
use super::*;
use crate::format::plain;

/// A write that stops halfway until the test lets it go on, as one to a disk that has hung.
#[derive(Debug)]
pub(super) struct Hold {
    holding: mpsc::Sender<()>,
    release: mpsc::Receiver<()>,
}

impl Hold {
    /// Says it is holding, and waits to be let go.
    pub(super) fn holding(self) {
        let _ = self.holding.send(());
        let _ = self.release.recv();
    }
}

/// A directory of its own, removed afterwards.
pub(super) struct TempDir(PathBuf);

impl TempDir {
    pub(super) fn new() -> Self {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let n = NEXT.fetch_add(1, Ordering::Relaxed);
        let dir = std::env::temp_dir().join(format!("nmux-spool-{}-{n}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(&dir).expect("a directory for the test");
        Self(dir)
    }

    pub(super) fn path(&self) -> &Path {
        &self.0
    }

    pub(super) fn join(&self, name: &str) -> PathBuf {
        self.0.join(name)
    }
}

impl Drop for TempDir {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

type Logged = Rc<RefCell<Vec<(&'static str, Vec<(&'static str, Value)>)>>>;

/// A spool, with what it has answered and what it has logged.
pub(super) struct Harness {
    spool: Spool,
    woken: mpsc::Receiver<()>,
    answered: Vec<Done>,
    logged: Logged,
}

impl Deref for Harness {
    type Target = Spool;
    fn deref(&self) -> &Spool {
        &self.spool
    }
}

impl DerefMut for Harness {
    fn deref_mut(&mut self) -> &mut Spool {
        &mut self.spool
    }
}

impl Harness {
    pub(super) fn new(options: Options) -> Self {
        let logged = Logged::default();
        let into = Rc::clone(&logged);
        let log = move |_: Level, code: &'static str, fields: &[(&'static str, Value)]| {
            into.borrow_mut().push((code, fields.to_vec()));
        };
        let (wake, woken) = mpsc::channel();
        let spool = Spool::new(
            options,
            Box::new(log),
            Box::new(move || {
                let _ = wake.send(());
            }),
        );
        Self { spool, woken, answered: Vec::new(), logged }
    }

    pub(super) fn wait(&mut self, ticket: Ticket) -> Answer {
        loop {
            self.answered.extend(self.spool.take_done());
            if let Some(at) = self.answered.iter().position(|done| done.ticket == ticket) {
                return self.answered.remove(at).answer;
            }
            self.woken.recv().expect("the spool wakes its owner");
        }
    }

    pub(super) fn idle(&mut self) {
        let ticket = self.spool.idle();
        assert!(matches!(self.wait(ticket), Answer::Idle));
    }

    pub(super) fn close(&mut self) {
        let ticket = self.spool.close();
        assert!(matches!(self.wait(ticket), Answer::Closed));
    }

    pub(super) fn range(&mut self, from: u64, to: u64, ansi: bool) -> Option<Vec<String>> {
        let ticket = self.spool.range(from, to, ansi);
        match self.wait(ticket) {
            Answer::Range(lines) => lines.expect("the files can be read"),
            other => panic!("{other:?}"),
        }
    }

    pub(super) fn last_lines(&mut self, count: Option<usize>, ansi: bool) -> Vec<String> {
        let ticket = self.spool.last_lines(count, ansi);
        match self.wait(ticket) {
            Answer::LastLines(lines) => lines.expect("the files can be read"),
            other => panic!("{other:?}"),
        }
    }

    /// Everything logged so far, with what the spool's thread said.
    pub(super) fn logs(&mut self) -> Vec<(&'static str, Vec<(&'static str, Value)>)> {
        self.answered.extend(self.spool.take_done());
        self.logged.borrow().clone()
    }

    fn codes(&mut self) -> Vec<&'static str> {
        self.logs().into_iter().map(|(code, _)| code).collect()
    }

    /// The disk has fallen behind, or caught up: rows given meanwhile are counted, not written. Only while nothing is
    /// queued, as the Node test does it by setting `queued`.
    pub(super) fn behind(&mut self, on: bool) {
        lock(&self.spool.shared.queue).queued = if on { QUEUE_BYTES + 1 } else { 0 };
    }

    /// The next chunk's write stops halfway: the writer says when it is there, and goes on when it is told.
    fn hold(&mut self) -> (mpsc::Receiver<()>, mpsc::Sender<()>) {
        let (holding, held) = mpsc::channel();
        let (release, released) = mpsc::channel();
        self.spool.push(Job::Hold(Hold { holding, release: released }));
        (held, release)
    }

    /// Writing goes to `file` from now on.
    fn replace_file(&mut self, file: File) {
        self.spool.push(Job::Replace(file));
    }

    fn chunks_queued(&self) -> usize {
        lock(&self.spool.shared.queue).jobs.iter().filter(|job| matches!(job, Job::Chunk(_))).count()
    }
}

pub(super) fn fixed(at: i64) -> Clock {
    Arc::new(move || at)
}

fn bounded(dir: &TempDir, max_bytes: u64) -> Options {
    Options::new(dir.path(), max_bytes)
}

fn kept(dir: &TempDir) -> Options {
    Options { keep: true, ..Options::new(dir.path(), 0) }
}

fn rows(from: usize, n: usize) -> Vec<String> {
    (from..from + n).map(|i| format!("row {i}")).collect()
}

fn flat(n: usize) -> Vec<bool> {
    vec![false; n]
}

fn strings<const N: usize>(texts: [&str; N]) -> Vec<String> {
    texts.into_iter().map(String::from).collect()
}

/// The history files in `dir`, by name.
fn names(dir: &TempDir) -> Vec<String> {
    let mut names: Vec<_> = fs::read_dir(dir.path())
        .expect("the directory")
        .map(|e| e.expect("an entry").file_name().into_string().expect("a name"))
        .filter(|name| name.starts_with("spool-"))
        .collect();
    names.sort();
    names
}

fn read(path: &Path) -> String {
    fs::read_to_string(path).expect("the file")
}

#[test]
fn rows_come_back_in_order_by_number_and_from_the_end() {
    let dir = TempDir::new();
    let mut s = Harness::new(bounded(&dir, 1_048_576));
    assert_eq!(s.append(rows(0, 3), flat(3), 10, None), 0);
    assert_eq!(s.append(rows(3, 3), flat(3), 20, None), 3);
    assert_eq!(s.range(1, 4, false), Some(strings(["row 1", "row 2", "row 3"])));
    assert_eq!(s.last_lines(Some(2), false), ["row 4", "row 5"]);
    assert_eq!(s.last_lines(None, false).len(), 6);
    s.close();
}

#[test]
fn a_wrapped_row_is_part_of_the_line_before_it() {
    let dir = TempDir::new();
    let mut s = Harness::new(bounded(&dir, 1_048_576));
    s.append(strings(["aaa", "bbb", "c"]), vec![false, true, false], 1, None);
    assert_eq!(s.last_lines(None, false), ["aaabbb", "c"]);
    s.close();
}

#[test]
fn plain_text_has_no_colours_and_keeps_its_gaps() {
    assert_eq!(plain("\x1b[0;31mred\x1b[0m\x1b[3Cgap\x1b[C."), "red   gap .");
    let dir = TempDir::new();
    let mut s = Harness::new(bounded(&dir, 1_048_576));
    s.append(strings(["\x1b[0;31mred\x1b[0m"]), flat(1), 1, None);
    assert_eq!(s.last_lines(None, false), ["red"]);
    assert_eq!(s.last_lines(None, true), ["\x1b[0;31mred\x1b[0m"]);
    s.close();
}

#[test]
fn two_files_private_within_the_limit_and_the_numbers_go_on() {
    let dir = TempDir::new();
    let mut s = Harness::new(bounded(&dir, 4096));
    for i in 0..100 {
        s.append(rows(i * 10, 10), flat(10), i as u64, None);
    }
    s.idle();
    let names = names(&dir);
    assert!(names.len() <= 2, "{names:?}");
    let mut total = 0;
    for name in &names {
        let meta = fs::metadata(dir.join(name)).expect("the file");
        assert_eq!(meta.permissions().mode() & 0o777, 0o600, "{name}");
        total += meta.len();
    }
    assert!(total <= 4096 + 200, "{total}");
    assert_eq!(s.last_lines(Some(1), false), ["row 999"]);
    assert_eq!(s.range(990, 992, false), Some(strings(["row 990", "row 991"])));
    assert_eq!(s.range(0, 5, false), None, "those have gone");
    s.close();
}

#[test]
fn another_spool_over_the_same_files_carries_on_and_knows_how_far_they_went() {
    let dir = TempDir::new();
    let mut a = Harness::new(bounded(&dir, 1_048_576));
    a.stream(4);
    a.append(rows(0, 5), flat(5), 500, None);
    a.close();
    let mut b = Harness::new(bounded(&dir, 1_048_576));
    assert_eq!(b.lines(), 5);
    b.resume(4);
    assert!(b.already_has(500));
    assert!(!b.already_has(501));
    b.close();
    let mut c = Harness::new(bounded(&dir, 1_048_576));
    c.resume(5); // another program: those offsets were not its
    assert!(!c.already_has(1));
    c.close();
}

#[test]
fn a_disk_that_fails_ends_the_spool_not_the_session() {
    let dir = TempDir::new();
    let mut s = Harness::new(bounded(&dir, 1_048_576));
    s.replace_file(File::open(dir.join("spool-0")).expect("the file")); // writing is refused from now on
    assert_eq!(s.append(strings(["x"]), vec![false], 1, None), 0);
    s.idle();
    assert_eq!(s.append(strings(["y"]), vec![false], 2, None), 1);
    s.idle();
    assert_eq!(s.codes(), ["spool.failed"]);
    assert!(s.failed());
    s.close();
}

#[test]
fn what_was_queued_behind_a_write_that_failed_is_not_waited_for() {
    let dir = TempDir::new();
    let mut s = Harness::new(bounded(&dir, 1_048_576));
    let (holding, release) = s.hold();
    s.append(rows(0, 1), flat(1), 1, None);
    holding.recv().expect("a write under way");
    s.replace_file(File::open(dir.join("spool-0")).expect("the file")); // the next write fails
    for i in 1..4 {
        s.append(rows(i, 1), flat(1), i as u64 + 1, None);
    }
    assert_eq!(s.chunks_queued(), 3);
    release.send(()).expect("the writer");
    s.idle();
    assert!(s.failed());
    assert_eq!(s.chunks_queued(), 0, "let go");
    s.close(); // with nothing to wait for
    assert_eq!(s.codes(), ["spool.failed"]);
    assert_eq!(read(&dir.join("spool-0")), format!("@{}\n.row 0\n=0:1:1\n", read_time(&dir.join("spool-0"))));
}

/// The time a file starts by saying.
fn read_time(path: &Path) -> String {
    read(path).lines().next().and_then(|l| l.strip_prefix('@')).expect("a time first").to_owned()
}

#[test]
fn more_rows_than_one_call_can_take_come_back_all_the_same() {
    let dir = TempDir::new();
    let mut s = Harness::new(bounded(&dir, 1024 * 1_048_576));
    let n = 300_000;
    for i in (0..n).step_by(10_000) {
        s.append(rows(i, 10_000), flat(10_000), i as u64, None);
    }
    assert_eq!(s.last_lines(None, false).len(), n);
    assert_eq!(s.range(5, n as u64 - 5, false).map(|lines| lines.len()), Some(n - 10));
    s.close();
}

#[test]
fn the_last_few_lines_take_no_longer_than_a_scan_and_keep_a_wrapped_last_line_whole() {
    let dir = TempDir::new();
    let mut s = Harness::new(bounded(&dir, 1_048_576));
    for i in 0..100 {
        s.append(strings(["x", "y"]), vec![false, true], i, None);
    }
    assert_eq!(s.last_lines(Some(2), false), ["xy", "xy"]);
    s.close();
}

/// Part of the last chunk of a file, as a server leaves it that went in the middle of a write: `bytes` past its last
/// whole one, which ends where this returns.
fn cut_into(file: &Path, bytes: u64) -> u64 {
    let text = fs::read(file).expect("the file");
    let mut ends = Vec::new();
    let mut start = 0;
    for (i, &b) in text.iter().enumerate() {
        if b == b'\n' {
            if text[start] == b'=' {
                ends.push(i as u64 + 1);
            }
            start = i + 1;
        }
    }
    let whole = ends[ends.len() - 2];
    File::options().write(true).open(file).and_then(|f| f.set_len(whole + bytes)).expect("cut");
    whole
}

fn a_server_that_went_in_the_middle_of_a_write_left_part_of_a_chunk(n: usize, bytes: u64) {
    let dir = TempDir::new();
    let mut a = Harness::new(kept(&dir));
    a.stream(1);
    a.append(rows(0, 10), flat(10), 100, None);
    a.append(rows(10, n), flat(n), 200, None);
    a.close();
    let whole = cut_into(&dir.join("spool-0"), bytes);
    let mut b = Harness::new(kept(&dir));
    assert!(!b.failed());
    assert_eq!(b.codes(), ["spool.cut"]);
    assert_eq!(fs::metadata(dir.join("spool-0")).expect("the file").len(), whole, "cut back to the last whole chunk");
    assert_eq!(b.lines(), 10);
    b.stream(1);
    b.resume(1);
    assert!(b.already_has(100));
    assert!(!b.already_has(101), "what it wrote after that is written again");
    b.append(rows(10, 3), flat(3), 130, None);
    assert_eq!(b.last_lines(None, false), rows(0, 13));
    b.close();
}

#[test]
fn a_server_that_went_in_the_middle_of_a_write_left_a_little_of_a_chunk_which_the_next_one_cuts_off_and_writes_again() {
    a_server_that_went_in_the_middle_of_a_write_left_part_of_a_chunk(4, 20);
}

#[test]
fn a_server_that_went_in_the_middle_of_a_write_left_more_than_a_read_of_the_end_which_the_next_one_cuts_off() {
    a_server_that_went_in_the_middle_of_a_write_left_part_of_a_chunk(20_000, 70_000);
}

#[test]
fn a_server_that_went_in_the_middle_of_a_write_left_more_than_a_read_of_the_end_of_a_long_chunk() {
    // Past one piece of the search back, which the Node test no longer reaches since a piece is 1 MiB.
    a_server_that_went_in_the_middle_of_a_write_left_part_of_a_chunk(300_000, 2_500_000);
}

#[test]
fn a_file_started_for_a_chunk_that_never_got_as_far_as_its_mark_leaves_the_mark_before_it_to_carry_on_from() {
    let dir = TempDir::new();
    fs::write(dir.join("spool-0"), "@1\n.row 0\n.row 1\n=3:100:2\n").expect("write");
    for partial in ["", "@2\n.row 2\n.ro"] {
        fs::write(dir.join("spool-2"), partial).expect("write");
        let mut s = Harness::new(kept(&dir));
        assert_eq!(s.lines(), 2);
        s.resume(3);
        assert!(s.already_has(100), "with {partial:?} after it");
        s.stream(3);
        s.append(rows(2, 2), flat(2), 120, None);
        assert_eq!(s.last_lines(None, false), rows(0, 4));
        s.close();
        fs::write(dir.join("spool-0"), "@1\n.row 0\n.row 1\n=3:100:2\n").expect("write");
    }
}

#[test]
fn a_file_with_no_mark_at_all_is_carried_on_from_its_last_whole_row() {
    let dir = TempDir::new();
    fs::write(dir.join("spool-5"), "@1\n.row 5\n!2\n+row 8\n.row 9\n.row").expect("write");
    let mut s = Harness::new(kept(&dir));
    assert_eq!(s.lines(), 10);
    assert_eq!(read(&dir.join("spool-5")), "@1\n.row 5\n!2\n+row 8\n.row 9\n");
    s.append(strings(["row 10"]), flat(1), 1, None);
    assert_eq!(s.range(9, 11, false), Some(strings(["row 9", "row 10"])));
    s.close();
}

#[test]
fn a_file_whose_end_is_not_whole_is_cut_back_to_its_last_mark_however_far_back_that_is() {
    let dir = TempDir::new();
    let mut a = Harness::new(bounded(&dir, 1_048_576));
    a.append(rows(0, 5), flat(5), 500, None);
    a.close();
    let name = dir.join("spool-0");
    let whole = fs::metadata(&name).expect("the file").len();
    File::options().write(true).open(&name).and_then(|f| f.set_len(600 * 1_048_576)).expect("grow"); // too big to read whole
    let mut b = Harness::new(bounded(&dir, 2048 * 1_048_576));
    assert!(!b.failed(), "that is no reason to stop keeping a history");
    assert_eq!(fs::metadata(&name).expect("the file").len(), whole);
    b.append(strings(["x"]), vec![false], 501, None);
    let mut expected = rows(0, 5);
    expected.push("x".into());
    assert_eq!(b.last_lines(None, false), expected);
    b.close();
}

#[test]
fn rows_ending_in_a_character_that_a_read_divides_still_come_back_whole() {
    let dir = TempDir::new();
    let mut s = Harness::new(bounded(&dir, 64 * 1_048_576));
    let row = "中".repeat(100_000);
    for i in 0..8 {
        s.append(vec![row.clone()], flat(1), i, None);
    }
    let lines = s.last_lines(None, false);
    assert_eq!(lines.len(), 8);
    assert!(lines.iter().all(|l| *l == row));
    s.close();
}

#[test]
fn a_range_ends_where_a_command_did_without_what_came_after_it_on_that_row() {
    // The spool hands the last line over whole: cutting it is the caller's, with the emulator's `cut_line`.
    let dir = TempDir::new();
    let mut s = Harness::new(bounded(&dir, 1_048_576));
    s.append(strings(["one", "partial$ "]), flat(2), 1, None);
    let mut lines = s.range(0, 2, false).expect("the rows");
    assert_eq!(lines, ["one", "partial$ "]);
    if let Some(last) = lines.last_mut() {
        *last = nmux_term::cells::cut_line(last, 7);
    }
    assert_eq!(lines, ["one", "partial"]);
    s.close();
}

#[test]
fn every_file_starts_by_saying_when_a_file_started_when_the_last_one_was_full_too() {
    let dir = TempDir::new();
    // Two files of 200 bytes, all in one second.
    let mut s = Harness::new(Options { wall_now: fixed(1_793_600_000_000), ..bounded(&dir, 400) });
    for i in 0..8 {
        s.append(rows(i * 6, 6), flat(6), (i as u64 + 1) * 6, None);
        s.idle();
    }
    let names = names(&dir);
    assert!(names.len() == 2 && !names.contains(&"spool-0".to_owned()), "the first file has gone: {names:?}");
    for name in &names {
        assert_eq!(read(&dir.join(name)).lines().next(), Some("@1793600000000"), "{name}");
    }
    s.close();
}

#[test]
fn a_file_that_starts_with_rows_that_were_lost_is_numbered_from_the_first_of_them() {
    let dir = TempDir::new();
    let mut s = Harness::new(bounded(&dir, 600)); // files of 300 bytes
    s.append(rows(0, 10), flat(10), 10, None);
    s.append(rows(10, 10), flat(10), 20, None);
    s.idle();
    s.behind(true); // the disk has fallen behind: these are counted, not written
    s.append(rows(20, 5), flat(5), 25, None);
    s.behind(false);
    s.append(rows(25, 20), flat(20), 45, None); // says so, in a file of its own
    s.idle();
    assert_eq!(names(&dir), ["spool-0", "spool-20"]);
    assert_eq!(s.range(25, 30, false), Some(rows(25, 5)));
    assert_eq!(s.range(44, 45, false), Some(strings(["row 44"])));
    s.close();
}

#[test]
fn closing_never_cuts_a_write_short_and_nothing_is_written_once_it_has_stopped_waiting() {
    let dir = TempDir::new();
    let mut s = Harness::new(bounded(&dir, 4096));
    for i in 0..10 {
        s.append(rows(i * 10, 10), flat(10), (i as u64 + 1) * 10, None);
    }
    let (holding, release) = s.hold();
    for i in 10..2000 {
        s.append(rows(i * 10, 10), flat(10), (i as u64 + 1) * 10, None); // many files' worth, still queued
    }
    holding.recv().expect("a write under way");
    let ticket = s.spool.close();
    s.give_up(); // stops waiting at once, with a write under way
    let files = names(&dir);
    release.send(()).expect("the writer");
    assert!(matches!(s.wait(ticket), Answer::Closed), "closed once the write returned");
    assert_eq!(names(&dir), files, "no file was started after closing");
    assert_eq!(s.codes(), ["spool.unwritten"]);
    assert_eq!(s.logs()[0].1, [("rows", Value::from(19_890))]);
    for name in &files {
        let text = read(&dir.join(name));
        let last = text.trim_end_matches('\n').rsplit('\n').next().unwrap_or_default();
        assert!(text.ends_with('\n') && last.starts_with("=0:"), "{name} ends with a whole chunk: {last:?}");
    }
    assert_eq!(s.written(), 110, "the write under way, and none after it");
    assert_eq!(
        s.append(rows(0, 1), flat(1), 1, None),
        20_000,
        "rows given it after closing are counted, and go nowhere"
    );
    s.idle();
    assert_eq!(s.written(), 110);
}

#[test]
fn a_file_says_the_time_again_before_a_row_printed_in_another_second_than_the_last_it_said() {
    let dir = TempDir::new();
    let t0 = 1_793_600_000_000;
    let mut s = Harness::new(Options { wall_now: fixed(t0 + 99_999), ..kept(&dir) });
    s.append(rows(0, 5), flat(5), 5, Some(vec![0, t0, t0 + 999, t0 + 1500, 0]));
    s.append(rows(5, 1), flat(1), 6, Some(vec![t0]));
    // under a second apart, but in another second; then earlier, in the same one
    s.append(rows(6, 3), flat(3), 9, Some(vec![t0 + 2800, t0 + 3100, t0 + 3050]));
    s.close();
    assert_eq!(
        read(&dir.join("spool-0")),
        format!(
            "@{t0}\n.row 0\n.row 1\n.row 2\n@{}\n.row 3\n.row 4\n=0:5:5\n@{t0}\n.row 5\n=0:6:6\n@{}\n.row 6\n@{}\n.row 7\n.row 8\n=0:9:9\n",
            t0 + 1500,
            t0 + 2800,
            t0 + 3100
        )
    );
}

// ---- What only a spool with a thread of its own could get wrong ----

#[test]
fn a_disk_that_hangs_costs_rows_and_never_holds_up_whoever_gives_them() {
    let dir = TempDir::new();
    let mut s = Harness::new(Options { wall_now: fixed(1_793_600_000_000), ..kept(&dir) });
    let row = "x".repeat(1000);
    let (holding, release) = s.hold();
    s.append(vec![row.clone()], flat(1), 1, None);
    holding.recv().expect("a write that hangs");
    let mut offset = 1;
    while lock(&s.spool.shared.queue).queued <= QUEUE_BYTES {
        offset += 1;
        s.append(vec![row.clone(); 100], flat(100), offset, None);
    }
    let before = s.lines();
    assert_eq!(s.append(rows(0, 5), flat(5), offset + 1, None), before);
    assert_eq!(s.append(rows(5, 3), flat(3), offset + 2, None), before + 5, "counted all the same");
    assert_eq!(s.written(), 0);
    release.send(()).expect("the writer");
    s.idle();
    assert_eq!(s.written(), before);
    let first = s.append(strings(["after"]), flat(1), offset + 3, None);
    assert_eq!(first, before + 8);
    s.idle();
    assert_eq!(s.logs(), [("spool.dropped", vec![("rows", Value::from(8))])]);
    assert!(read(&dir.join("spool-0")).ends_with(&format!("!8\n.after\n={}:{}:{}\n", 0, offset + 3, first + 1)));
    assert_eq!(s.range(before, first + 1, false), Some(strings(["after"])), "numbered past the rows that were lost");
    s.close();
}

#[test]
fn a_request_is_answered_once_what_was_given_before_it_is_on_disk() {
    let dir = TempDir::new();
    let mut s = Harness::new(kept(&dir));
    let (holding, release) = s.hold();
    s.append(rows(0, 3), flat(3), 3, None);
    holding.recv().expect("a write under way");
    let idle = s.spool.idle();
    let last = s.spool.last_lines(None, false);
    s.append(rows(3, 2), flat(2), 5, None);
    assert!(s.take_done().is_empty(), "nothing is answered while the write hangs");
    release.send(()).expect("the writer");
    assert!(matches!(s.wait(idle), Answer::Idle));
    match s.wait(last) {
        Answer::LastLines(lines) => {
            assert_eq!(lines.expect("read"), rows(0, 3), "the rows given before it, and no more");
        }
        other => panic!("{other:?}"),
    }
    s.close();
}

#[test]
fn a_spool_let_go_without_closing_writes_what_it_was_given() {
    let dir = TempDir::new();
    let mut s = Harness::new(kept(&dir));
    let (holding, release) = s.hold();
    s.append(rows(0, 2), flat(2), 2, None);
    holding.recv().expect("a write under way");
    s.append(rows(2, 2), flat(2), 4, None);
    let idle = s.spool.idle();
    let shared = Arc::clone(&s.spool.shared);
    let woken = std::mem::replace(&mut s.woken, mpsc::channel().1);
    drop(s);
    release.send(()).expect("the writer");
    loop {
        woken.recv().expect("the writer is still there");
        if lock(&shared.events).iter().any(|e| matches!(e, Event::Done(Done { ticket, .. }) if *ticket == idle)) {
            break;
        }
    }
    assert!(read(&dir.join("spool-0")).ends_with(".row 2\n.row 3\n=0:4:4\n"));
}

#[test]
fn the_meta_is_written_when_the_spool_is_made_and_after_what_is_queued_when_it_is_said_again() {
    let dir = TempDir::new();
    let meta = Meta {
        id: "abc".into(),
        name: Some("w\"o\\r\nk\u{1}".into()),
        created_at: Some("2026-11-02T10:00:00.000Z".into()),
        cwd: Some("/home/me".into()),
        argv: vec!["bash".into(), "-l".into()],
    };
    let mut s = Harness::new(Options { meta: Some(meta.clone()), ..kept(&dir) });
    assert_eq!(
        read(&dir.join("meta.json")),
        r#"{"schema":"nmux.history/1","id":"abc","name":"w\"o\\r\nk\u0001","createdAt":"2026-11-02T10:00:00.000Z","cwd":"/home/me","argv":["bash","-l"]}"#
    );
    assert_eq!(fs::metadata(dir.join("meta.json")).expect("meta").permissions().mode() & 0o777, 0o600);
    s.describe(&Meta { name: Some("new".into()), created_at: None, ..meta });
    s.close();
    assert_eq!(
        read(&dir.join("meta.json")),
        r#"{"schema":"nmux.history/1","id":"abc","name":"new","cwd":"/home/me","argv":["bash","-l"]}"#
    );
    assert!(!dir.join("meta.json.new").exists());
}

#[test]
fn a_directory_that_cannot_be_made_fails_the_spool_and_still_answers() {
    let dir = TempDir::new();
    fs::write(dir.join("file"), "").expect("write");
    let mut s = Harness::new(Options { dir: dir.join("file").join("history"), ..kept(&dir) });
    assert!(s.failed());
    assert_eq!(s.append(rows(0, 2), flat(2), 1, None), 0);
    assert_eq!(s.lines(), 2);
    s.idle();
    assert_eq!(s.range(0, 2, false), None);
    assert_eq!(s.last_lines(None, false), Vec::<String>::new());
    s.close();
    assert_eq!(s.codes(), ["spool.failed"]);
}

#[test]
fn a_read_that_finds_a_file_gone_says_some_rows_have_gone() {
    let dir = TempDir::new();
    fs::write(dir.join("spool-0"), "@1\n.row 0\n.row 1\n=0:1:2\n").expect("write");
    let files = vec![
        scan::HistoryFile { path: dir.join("spool-0"), first: 0 },
        scan::HistoryFile { path: dir.join("spool-2"), first: 2 },
    ];
    let mut seen = Vec::new();
    let whole = scan::scan(&files, 0, 4, &mut |row, _| seen.push(row.to_owned())).expect("read");
    assert!(!whole);
    assert_eq!(seen, ["row 0", "row 1"]);
}

/// A small generator, so that a failure can be run again.
struct Lcg(u64);

impl Lcg {
    fn next(&mut self, below: u64) -> u64 {
        self.0 = self.0.wrapping_mul(6_364_136_223_846_793_005).wrapping_add(1_442_695_040_888_963_407);
        (self.0 >> 33) % below
    }
}

/// Lines of every kind, whole marks and broken ones among them, and perhaps a line with no end.
fn history_like(rng: &mut Lcg) -> Vec<u8> {
    let mut text = Vec::new();
    for _ in 0..rng.next(30) {
        let line = match rng.next(9) {
            0 => format!("={}:{}:{}", rng.next(1000), rng.next(100_000), rng.next(1000)),
            1 => format!("={}:{}", rng.next(10), rng.next(10)),
            2 => format!("=+{}:1:2", rng.next(10)),
            3 => format!("@{}", rng.next(1 << 40)),
            4 => format!("!{}", rng.next(20)),
            5 => "=".repeat(usize::try_from(rng.next(3)).unwrap_or(0)),
            6 => format!("+{}", "y".repeat(usize::try_from(rng.next(90)).unwrap_or(0))),
            _ => format!(".{}", "x".repeat(usize::try_from(rng.next(90)).unwrap_or(0))),
        };
        text.extend_from_slice(line.as_bytes());
        text.push(b'\n');
    }
    if rng.next(2) == 0 {
        let cut = usize::try_from(rng.next(text.len() as u64 + 1)).unwrap_or(0);
        text.truncate(cut);
    }
    text
}

/// The last whole line that is a mark, the plain way.
fn last_mark_plainly(text: &[u8]) -> Option<(Mark, u64)> {
    let mut found = None;
    let mut start = 0;
    for (i, &b) in text.iter().enumerate() {
        if b == b'\n' {
            if let Some(Line::Mark(mark)) = std::str::from_utf8(&text[start..i]).ok().and_then(Line::parse)
                && !text[start..i].contains(&b'+')
            {
                found = Some((mark, i as u64 + 1));
            }
            start = i + 1;
        }
    }
    found
}

/// Rows and where the last whole line ends, the plain way.
fn whole_rows_plainly(text: &[u8]) -> (u64, u64) {
    let (mut rows, mut end, mut start) = (0, 0, 0);
    for (i, &b) in text.iter().enumerate() {
        if b == b'\n' {
            rows += match std::str::from_utf8(&text[start..i]).ok().and_then(Line::parse) {
                Some(Line::Row { .. }) => 1,
                Some(Line::Lost(n)) => n,
                _ => 0,
            };
            end = i as u64 + 1;
            start = i + 1;
        }
    }
    (rows, end)
}

#[test]
fn the_last_mark_is_found_however_the_reads_divide_the_file() {
    let dir = TempDir::new();
    let path = dir.join("spool-0");
    let mut rng = Lcg(7);
    for _ in 0..300 {
        let text = history_like(&mut rng);
        fs::write(&path, &text).expect("write");
        let file = File::open(&path).expect("open");
        let expected = last_mark_plainly(&text);
        for piece in 1..=80 {
            assert_eq!(
                last_mark(&file, text.len() as u64, piece).expect("read"),
                expected,
                "piece {piece} of {:?}",
                String::from_utf8_lossy(&text)
            );
        }
        let rows = whole_rows_plainly(&text);
        for piece in 1..=80 {
            assert_eq!(whole_rows(&file, text.len() as u64, piece).expect("read"), rows, "piece {piece}");
        }
    }
}
