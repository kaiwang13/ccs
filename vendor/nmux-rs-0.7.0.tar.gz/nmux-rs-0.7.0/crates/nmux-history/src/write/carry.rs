//! Where a new server carries on a history from: the last whole watermark in its last file, or, in a file with none, its
//! last whole row. Both are looked for a piece at a time, so a file of any size costs one piece of memory.

use std::fs::File;
use std::io;
use std::os::unix::fs::FileExt;

use crate::format::{Line, Mark};

/// Reading goes this far at a time.
pub(super) const READ_BYTES: usize = 1_048_576;
/// Longer than any watermark's line, so that one two reads divide is whole in one of them.
const MARK_BYTES: usize = 64;

/// Reads as much of `buf` as the file has from `position`.
fn read_at(file: &File, buf: &mut [u8], position: u64) -> io::Result<usize> {
    let mut got = 0;
    while got < buf.len() {
        match file.read_at(&mut buf[got..], position + got as u64) {
            Ok(0) => break,
            Ok(n) => got += n,
            Err(e) if e.kind() == io::ErrorKind::Interrupted => {}
            Err(e) => return Err(e),
        }
    }
    Ok(got)
}

/// `=g:o:n`, in digits and nothing else.
fn parse_mark(line: &[u8]) -> Option<Mark> {
    let mut parts = line.strip_prefix(b"=")?.split(|&b| b == b':');
    let mut number = || -> Option<u64> {
        let digits = parts.next().filter(|p| !p.is_empty() && p.iter().all(u8::is_ascii_digit))?;
        std::str::from_utf8(digits).ok()?.parse().ok()
    };
    let mark = Mark { generation: number()?, offset: number()?, lines: number()? };
    parts.next().is_none().then_some(mark)
}

/// The mark on the line that starts at `start` in `data`, if it is one and is whole, and where in `data` its line ends.
fn mark_at(data: &[u8], start: usize) -> Option<(Mark, usize)> {
    let nl = start + data[start..].iter().position(|&b| b == b'\n')?;
    Some((parse_mark(&data[start..nl])?, nl + 1))
}

/// The last whole watermark in a file of `size`, and where its line ends. Looked for from the end back, as far as it
/// takes, `piece` bytes at a time.
pub(super) fn last_mark(file: &File, size: u64, piece: usize) -> io::Result<Option<(Mark, u64)>> {
    let mut buf = vec![0; piece + MARK_BYTES];
    let mut hi = size;
    while hi > 0 {
        let lo = hi.saturating_sub(piece as u64);
        // What lies in [lo, hi), and enough after it to finish a mark that starts there.
        let want = usize::try_from(size.min(hi + MARK_BYTES as u64) - lo).unwrap_or(buf.len()).min(buf.len());
        let got = read_at(file, &mut buf[..want], lo)?;
        let data = &buf[..got];
        // Lines that start after a line feed in [lo, hi), the last first.
        let span = usize::try_from(hi - lo).unwrap_or(usize::MAX).min(got.saturating_sub(1));
        let mut before = span;
        while let Some(nl) = data[..before].iter().rposition(|&b| b == b'\n') {
            if data[nl + 1] == b'='
                && let Some((mark, end)) = mark_at(data, nl + 1)
            {
                return Ok(Some((mark, lo + end as u64)));
            }
            before = nl;
        }
        if lo == 0
            && data.first() == Some(&b'=')
            && let Some((mark, end)) = mark_at(data, 0)
        {
            return Ok(Some((mark, end as u64)));
        }
        hi = lo;
    }
    Ok(None)
}

/// How many rows a line stands for, from as much of its start as says what it is.
fn rows_in(head: &[u8]) -> u64 {
    match head.first() {
        Some(b'.' | b'+') => 1,
        Some(b'!') => match std::str::from_utf8(head).ok().and_then(Line::parse) {
            Some(Line::Lost(rows)) => rows,
            _ => 0,
        },
        _ => 0,
    }
}

/// How many rows a file of `size` with no watermark has, as far as its last whole line, and where that ends. Read
/// `piece` bytes at a time.
pub(super) fn whole_rows(file: &File, size: u64, piece: usize) -> io::Result<(u64, u64)> {
    let mut buf = vec![0; piece];
    let (mut rows, mut end) = (0, 0);
    // The start of a line, as much as says what it is.
    let mut head = Vec::with_capacity(MARK_BYTES);
    let mut pos = 0;
    while pos < size {
        let want = usize::try_from(size - pos).unwrap_or(piece).min(piece);
        let n = read_at(file, &mut buf[..want], pos)?;
        if n == 0 {
            break;
        }
        let data = &buf[..n];
        let mut start = 0;
        loop {
            let take = MARK_BYTES.saturating_sub(head.len());
            let Some(nl) = data[start..].iter().position(|&b| b == b'\n').map(|i| start + i) else {
                head.extend_from_slice(&data[start..n.min(start + take)]);
                break;
            };
            head.extend_from_slice(&data[start..nl.min(start + take)]);
            rows += rows_in(&head);
            head.clear();
            end = pos + nl as u64 + 1;
            start = nl + 1;
        }
        pos += n as u64;
    }
    Ok((rows, end))
}
