//! A session's kept history: what it printed, as whole lines, on disk. A server writes it, and `nmux search` and `nmux view`
//! read it, here and in the Node code alike, so [`format`] is the one description of the files both make.

pub mod format;
pub mod read;
pub mod write;
