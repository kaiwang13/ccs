#!/bin/sh
# Installs nmux: one binary, put in ~/.local/bin (or NMUX_INSTALL_DIR). No root, no compiler, nothing written elsewhere.
#
#   curl -fsSL https://github.com/kaiwang13/nmux-rs/releases/latest/download/install.sh | sh
#   gh release download --repo kaiwang13/nmux-rs --pattern install.sh -O - | sh    # while the repository is private
#   NMUX_VERSION=v0.5.2 sh install.sh                                                  # a given release
#   NMUX_INSTALL_DIR=/opt/bin sh install.sh                                            # somewhere else
#   NMUX_BASE_URL=https://mirror.example/nmux sh install.sh                            # the assets from a mirror
#
# It fetches the release asset for this machine (Linux or macOS, x86_64 or arm64), checks it against its .sha256, and puts
# the binary in place by a rename, so sessions running on the old one carry on. A release the public cannot see is fetched
# with gh, signed in to an account that can.
set -eu

REPO=${NMUX_REPO:-kaiwang13/nmux-rs}
VERSION=${NMUX_VERSION:-latest}
DIR=${NMUX_INSTALL_DIR:-$HOME/.local/bin}

say() { printf '\033[1mnmux:\033[0m %s\n' "$*"; }
die() { printf '\033[31mnmux: %s\033[0m\n' "$*" >&2; exit 1; }

case "$(uname -s)" in
  Linux) os=linux ;;
  Darwin) os=darwin ;;
  *) die "nmux runs on Linux and macOS; this is $(uname -s)" ;;
esac
case "$(uname -m)" in
  x86_64|amd64) arch=x64 ;;
  aarch64|arm64) arch=arm64 ;;
  *) die "there is no nmux for $(uname -m)" ;;
esac
ASSET="nmux-$os-$arch.tar.gz"

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

# A public release by URL, with curl or wget; then gh, which can also see a private one.
if [ -n "${NMUX_BASE_URL:-}" ]; then BASE=$NMUX_BASE_URL
elif [ "$VERSION" = latest ]; then BASE="https://github.com/$REPO/releases/latest/download"
else BASE="https://github.com/$REPO/releases/download/$VERSION"; fi
fetch() {
  if command -v curl >/dev/null 2>&1; then curl -fsSL -o "$TMP/$1" "$BASE/$1" 2>/dev/null
  elif command -v wget >/dev/null 2>&1; then wget -q -O "$TMP/$1" "$BASE/$1"
  else return 1; fi
}
if fetch "$ASSET" && fetch "$ASSET.sha256"; then
  :
elif command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
  if [ "$VERSION" = latest ]; then set --; else set -- "$VERSION"; fi
  gh release download "$@" --repo "$REPO" --pattern "$ASSET" --pattern "$ASSET.sha256" --dir "$TMP" --clobber \
    || die "could not download $ASSET from $REPO with gh"
else
  die "could not download $ASSET from $REPO: if the repository is private, install gh and run 'gh auth login' first"
fi

want=$(cut -d' ' -f1 < "$TMP/$ASSET.sha256")
if command -v sha256sum >/dev/null 2>&1; then got=$(sha256sum "$TMP/$ASSET" | cut -d' ' -f1)
else got=$(shasum -a 256 "$TMP/$ASSET" | cut -d' ' -f1); fi
[ -n "$want" ] && [ "$want" = "$got" ] || die "$ASSET does not match its checksum (want $want, got $got)"

tar -xzf "$TMP/$ASSET" -C "$TMP"
NEW="$TMP/nmux-$os-$arch/nmux"
[ -x "$NEW" ] || die "$ASSET has no nmux in it"
"$NEW" --version >/dev/null 2>&1 || die "the nmux in $ASSET does not run here"

mkdir -p "$DIR"
cp "$NEW" "$DIR/.nmux.new"
chmod 0755 "$DIR/.nmux.new"
mv -f "$DIR/.nmux.new" "$DIR/nmux"
say "installed $("$DIR/nmux" --version) at $DIR/nmux"
case ":$PATH:" in *":$DIR:"*) ;; *) say "$DIR is not on your PATH: add it to your shell's profile" ;; esac
say "next: nmux new work, then Ctrl+\\ d to detach and 'nmux a work' to come back"
