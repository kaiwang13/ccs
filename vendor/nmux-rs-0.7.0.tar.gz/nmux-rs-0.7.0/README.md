# nmux-rs

`nmux` in Rust: the same tool, with the same commands, wire protocol and files, at a fraction of the cost. See `../nmux` for what it does, and `docs/ROUTE.md` for why this exists.

## Install

One binary, with nothing beside it: Linux on any distribution (it is static), and macOS, on x86_64 or arm64.

```sh
gh release download --repo kaiwang13/nmux-rs --pattern install.sh -O - | sh          # while this repository is private
curl -fsSL https://github.com/kaiwang13/nmux-rs/releases/latest/download/install.sh | sh   # once it is public
```

It goes in `~/.local/bin`, checked against its checksum; `NMUX_INSTALL_DIR` puts it elsewhere and `NMUX_VERSION=v0.5.2` picks a
release. Installing again replaces it without stopping the sessions running on the old one. Or take `nmux-<os>-<arch>.tar.gz`
from a release by hand: it holds `nmux`, which needs nothing else.

A release is made by pushing a tag `vX.Y.Z`: `.github/workflows/release.yml` builds each binary on its own system, runs the
workspace's tests and `tools/smoke.sh` there, and publishes them with `install.sh`.

## Status

nmux is made here from 0.5.0 on. Everything was ported: the holder, the server, the emulator, the kept history, the attach client and every
subcommand. The Node implementation stopped at 0.5.0, level with this one except for what `docs/LEVEL.md` lists, and stays as the SDK for programs
written in Node.

One session costs about 4.5 MB in its server and 3.7 MB in its holder, where Node's costs about 115 MB. The emulator parses output 6 to 30 times faster than
`@xterm/headless` (numbers in `docs/ROUTE.md` and the commit that measured them).

The two implementations run each other's parts. `NMUX_SERVER_BIN` and `NMUX_HOLDER_BIN` name the binary that serves or holds a session, run as `BIN __server`
or `BIN __holder`, and Node's `bin/nmux.js` answers both too. A session started by one can be taken over by the other. A program that embeds nmux
attaches with `nmux __attach --json SPEC`, in its own words and with its own configuration (`crates/nmux-client/src/embed.rs`).

## Building and checking

```sh
cargo build --release -p nmux          # target/release/nmux
cargo fmt --check
cargo clippy --workspace --all-targets -- -D warnings
TMPDIR=/tmp cargo test --workspace     # tests make unix sockets, whose paths must stay short
sh tools/conformance.sh                # Node's suites in ../nmux that take another implementation, against this binary
```

`tools/conformance.sh` runs Node's conformance suite and the integration suites that start sessions through the SDK or run a
holder of their own (`cli`, `history`, `managed`, `flow` and `plain-session`), with this binary as the command, the server and
the holder. Its arguments go to `node --test`, for example `--test-name-pattern`.
