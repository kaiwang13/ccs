# Working on nmux-rs

This is `nmux`, made in Rust from 0.5.0 on: a change of behaviour is made here only. `../nmux` is the Node implementation it was
ported from, which stopped at 0.5.0 and stays as the SDK programs written in Node use, and as a fallback host; it changes only for
a fix those need. `tools/conformance.sh` runs Node's suites against this binary, and they must go on passing, or be changed where
this binary is meant to differ (`docs/LEVEL.md`). ccs carries this source in its `vendor/`: after a change, bump the version,
commit, and run `npm run nmux:vendor-rs` there; ccs's suite has to pass on the new binary too.

Read `docs/DESIGN.md` before changing anything: what may not differ, the layers, and how it is judged. `docs/ROUTE.md` says why it is built this way.

`shell/` started as `../nmux/shell`; it is changed here now.

Build with `CARGO_TARGET_DIR` on a local disk: this repository is on NFS.
