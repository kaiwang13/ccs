# nmux

Terminal sessions that outlive your connection and your upgrades, shown in your terminal's own scrollback.

> This is the Node implementation, which stopped at 0.5.0 (0.5.1 and 0.5.2 fix its bar, and 0.5.3 reads the links in the
> history of nmux-rs 0.8.0). nmux is made in Rust now, in `nmux-rs`, which reads the same files and speaks the same
> protocol. This package stays as the library a program written in Node reaches sessions with (`nmux/sdk`), and as a host
> for one that cannot build the Rust binary.

`nmux` keeps shells and other programs running on a machine and lets any number of terminals attach to them. It stays out
of the way: scrolling, search, selection, links and images are your terminal's, with no prefix to scroll and no copy mode.
Every key belongs to the program except one.

"mux" here means several terminals sharing one session. `nmux` has no split panes, because a terminal has one scrollback
and two panes cannot both have it. Use your terminal's own splits and tabs, with an `nmux a` in each.

```console
$ nmux                      # no sessions: starts one named after this repo or directory, and attaches
$ nmux new api              # a named shell, in this directory
$ nmux new logs -- tail -F /var/log/app.log    # any program, not only a shell
$ nmux new build -d -- make # start it and stay here
$ nmux a api                # attach; another terminal can attach at the same time
$ nmux a api --view         # read-only, and never affects the size

$ nmux ls
  NAME   STATE                         CLIENTS  AGE  CWD
  api    running: make test (3m12s)    2        1d   ~/src/api
  docs   idle 2h · last: exit 0        –        3d   ~/src/docs
  old    exited (1) 40m ago            –        2d   ~/src/old

$ nmux run api -- make test  # in that shell, where you left it; exits as the command did
$ nmux last api              # what the last command printed
$ nmux wait api --prompt     # until it is done

$ nmux new deploy --keep     # every line it ever prints, kept after it ends
$ nmux search 'ERROR|panic' --since yesterday
  deploy  2026-10-31 23:58:02  #48113  ERROR: disk full on /var
$ nmux view deploy --at '2026-10-31 23:50'    # its history in a pager, opened at that minute
```

When a program exits its session ends and attached terminals return to their own shell, as from a plain ssh login. A
session that ends cleanly leaves nothing behind; one that failed stays listed until `nmux rm` or `nmux restart`. Its output
goes with it, unless it was started with `--keep`.

## What it does that others do not combine

- **Sessions survive `nmux` itself.** The program's pty lives in a tiny holder process, so a crash or upgrade of everything
  else loses nothing. A terminal attached at the time reconnects by itself.
- **It knows what your shell is doing.** `nmux ls` says what is running and how the last command ended, `nmux run` types into
  the live shell and exits with the command's own code, and `nmux last` gives back what it printed.
- **Coming back repeats nothing.** Reattach in the window you left and only what is new arrives, with a line saying what happened
  while you were away. A terminal attached while `nmux` itself restarts sees nothing happen at all.
- **No output is lost.** A program printing faster than `nmux` can parse is slowed down, as it would be by a slow terminal.
  A slow terminal slows nobody: it skips ahead in place and is told what it missed.
- **Joining shows what a terminal attached throughout would show.** The screen, colours, modes and cursor. Long lines stay
  one line, so your terminal can reflow them.
- **Terminals share a session properly.** The size follows the smallest, viewers do not count, `nmux clients` shows who is
  there and `nmux kick` detaches them.

## Commands

| Command | Does |
|---|---|
| `nmux` | Attach, create or pick |
| `nmux new [NAME] [-d] [--cwd DIR] [--size CxR] [--no-integration] [--spool SIZE\|--keep] [-- CMD…]` | Create and attach; `-d` stays detached, `--keep` keeps its history |
| `nmux a [NAME] [--view] [--full]` | Attach; `--full` repeats the history, for a terminal that has lost it |
| `nmux ls [--json]` | List sessions |
| `nmux stop NAME\|--all` | End a session |
| `nmux restart NAME` | A new program in the same session; attached terminals stay |
| `nmux rm NAME` | Forget a session that has ended |
| `nmux rename [OLD] NEW` | Rename |
| `nmux clients [NAME] [--json]` | Who is attached |
| `nmux kick [NAME] ID…\|--others` | Detach them |
| `nmux send NAME [--no-enter] [--] TEXT…` | Type into a session; several lines go in as one paste when the program supports it |
| `nmux run NAME [--queue] [--timeout T] [--ansi] [--json] -- CMD…` | Run a line in the session's shell; exits as the command did |
| `nmux last [NAME] [--ansi] [--json]` | What the last command printed |
| `nmux wait NAME --prompt\|--exit\|--text RE [--new] [--timeout T]` | Block until the shell is at a prompt, the session ends, or text appears |
| `nmux capture [NAME] [--lines N] [--ansi]` | The screen and history as text |
| `nmux search PATTERN [NAME…] [--since T] [--until T] [-i] [--json]` | Lines that match, in every kept history or these sessions' |
| `nmux view [NAME] [--at T\|--row N\|--grep RE] [--times]` | A history in a pager, opened at a time, a row or a match |
| `nmux events [NAME]` | What happens in a session, as JSON lines, until it ends |
| `nmux doctor` | Check the environment |
| `nmux demo [NAME]` | Sessions full of what nmux shows, to look at: a shell that has printed every kind of text, a program on the other screen, and a history of three days |

Inside a session, `NAME` defaults to that session.

## Your shell

A bash, zsh or fish session started by `nmux` runs your usual start-up files, then adds [OSC 133] marks saying where each prompt
and command starts and how it ended. Nothing is written to your dotfiles. Terminals that understand these marks get prompt jumping
as well. A shell given arguments of its own, or `--no-integration`, is left alone. Other shells, bash before 4.4 and a read-only
`PS1` or `PROMPT_COMMAND` work as sessions, but `run`, `last` and `wait --prompt` refuse rather than guess.

A mark only counts if it carries the session's token, which the shell keeps to itself, so printing a file that looks like a mark
cannot end a `run`. `run` only starts at an empty prompt: otherwise it is refused, or with `--queue` waits its turn. It exits with
the command's own code, 124 if `--timeout` ran out (a started command keeps running) and 125 if it never got to run or nmux lost
track of it, as when a server restarts with the run still queued. `wait --text` counts what is on the screen, in case it arrived
first; `--new` is only what comes next.

[OSC 133]: https://gitlab.freedesktop.org/Per_Bothner/specifications/blob/master/proposals/semantic-prompts.md

## Coming back

A window that left cleanly is remembered for as long as the session's server runs, and gets only what is new, with a line saying
what happened. That line lands just above the screen, so the title says it for a few seconds too:

```text
── nmux · api · make test finished: exit 0 after 14m · 3,120 new lines ──
```

Anywhere else, or if it cannot be sure the terminal received everything, a join sends all the history: a line repeated is better
than a line missing. So does a server that crashed; one that restarts cleanly carries its terminals across with nothing repeated.

Output is kept for 10,000 lines. `--spool 64M`, or `history.spoolBytes` in the configuration, also keeps what scrolls past that on disk,
which `capture` and `last` then reach back into. It is off by default, because terminal output often contains secrets, and
the files are private to you and go when the session does.

If a session starts with an ssh agent, its `SSH_AUTH_SOCK` becomes a link that follows the newest terminal attached with an agent,
so a long-lived shell keeps working after you reconnect. A `--view` terminal lends nothing.

## Keeping everything

A session started with `--keep`, or every session with `history.keep` in the configuration, writes each line that leaves its screen
to `~/.local/state/nmux/history/<id>/` (`NMUX_HISTORY_DIR` or `history.dir` move it), with the time it was printed. Nothing is
ever dropped from it, and it stays after the session ends, until you delete it. Writing never makes a session wait: a disk that
cannot keep up costs lines, which are counted where they would have been.

`nmux search` reads every kept history at once, or the sessions named, the running ones up to their last line. A pattern is a
regular expression; `--since` and `--until` take `2026-11-01`, `'2026-11-01 14:00'`, `14:00`, `today`, `yesterday` or `90m`,
`2h`, `3d` ago, on your clock (`TZ`, or `--zone`). Each match says the session, the time and the line's number.

`nmux view` opens a history in your pager (`NMUX_PAGER`, or `less -R`) with its colours, a line where each day begins, and with
`--times` the time of every line. `--at` opens it at a time, `--row` at a number `search` gave, `--grep` at the first match. A
session that is not kept can be viewed too, as far back as it still has. Inside a session, `Ctrl+\ h` does the same: the terminal
detaches, the pager has it until you quit, and it comes back the way a window does, with the screen as it was and whatever the
program printed meanwhile below it, each line once. Until the pager starts, `Ctrl+\ d` still detaches.

## The bar

The last row of a terminal attached to a session is nmux's: a bar saying it is nmux, which session this is, what it is running and
who else is on it, the keys to leave and for help, and the date, the time and the time zone. The session has every row above it.

```text
▐ nmux ▌ api · make · 2 attached          ^\ d detach  ^\ ? help          Mon 2 Nov · 19:42 PST
```

Your terminal's own scrollback works as it always does: the scroll region runs from the top row to the one above the bar, so what
scrolls off the top goes into the scrollback, and the bar never does. It is drawn again when what it says changes, when the program
clears the screen or goes to its other one, and when the terminal changes size, with the cursor and everything the program had set
put back as they were. On a narrow terminal the help key goes first, then the weekday, then the rest; how to leave is the last of the
keys to go. `Ctrl+\ s` takes it off a terminal and gives the session the row back, and puts it back again. To start without it:

```json
{ "overlay": { "bar": false } }
```

When a new day begins, a line can go into the scrollback above the screen, which is then drawn again under it, so the screen looks
as it did. It is off unless the configuration asks for it; the bar and the line keep time where `timeZone` says, or `TZ`:

```text
── Monday 2 November 2026 · America/Los_Angeles · api ──
```

```json
{ "overlay": { "dayLines": true, "timeZone": "America/Los_Angeles" } }
```

To see all of this at once, `nmux demo` makes `demo`, a shell that has printed colours, styles, wide and combined characters,
lines that wrap, links and a command that failed; `demo-screen`, a program that has the whole screen; and `demo-days`, a history of
three days with errors in it, for `nmux view demo-days --times` and `nmux search ERROR`. It makes them under other names with
`nmux demo NAME`, and touches nothing that is there already.

## Keys

Ctrl+C, Ctrl+Z and every other key go to the program. `nmux` takes one leader, `Ctrl+\`:

| Keys | Action |
|---|---|
| `Ctrl+\ d` | Detach |
| `Ctrl+\ c` | Who is attached |
| `Ctrl+\ s` | The bar at the bottom, on or off |
| `Ctrl+\ h` | The session's history, in a pager |
| `Ctrl+\ ?` | Help |
| `Ctrl+\ Ctrl+\` | Send a literal `Ctrl+\` |

Detaching is handled in the client, so it works even if the session's server has hung.

## Configuration

`~/.config/nmux/config.json`, every key optional. For example, to use another leader and keep more history:

```json
{ "keys": { "leader": "C-b" }, "snapshot": { "scrollback": 50000 } }
```

`src/server/config.js` lists everything. Sessions live in `/tmp/nmux-<uid>` (`NMUX_RUNTIME_DIR` overrides it): sockets are
`0600` in a `0700` directory, and there are no TCP listeners. `$XDG_RUNTIME_DIR` is not used because logging out removes it
while the sessions in it keep running.

## Building on it

`require('nmux/sdk')` is the way in, and `src/sdk/` says what it offers: start a session, attach a terminal, or connect and
watch. A program that understands what a session is running can be its controller: it subscribes to what happens, and answers
with phases, gates, attributes, a new program, and its share of a stop. What must happen on every keystroke is declared in the
session spec instead (`managed`, see `src/server/session/remote.js`), so it holds whether the controller is there or not.
`nmux/internal/*` exists for tests and is not a promise.

## Status

Early, and not yet published. It runs on Node 24.14.1 and costs about 115 MB of memory per session. `nmux-rs`, beside this
repository, is the same tool in Rust, kept level with this one and judged by this repository's conformance suite. The two run each other's
parts: `NMUX_SERVER_BIN` and `NMUX_HOLDER_BIN` name the binary that serves or holds a session, run as `BIN __server` or `BIN __holder`.
It is tested on Linux. macOS code exists and CI will run it once this is pushed, but it has
not been run yet.

```sh
npm install
npm test
npm link      # puts `nmux` on your PATH
```

`npm test` includes the conformance suite, which plays real shell, `vim` and `less` sessions through `nmux` and through a plain
terminal and requires the same screen, colours, cursor, modes and scrollback. Tests of zsh and fish are skipped where they are
not installed.
