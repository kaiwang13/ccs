# Where nmux-rs stands beside the Node nmux

nmux is made here from 0.5.0 on. The Node implementation in `../nmux` stopped at 0.5.0, level with this one but for what is
listed below, and stays as the SDK that programs written in Node reach sessions with, and as a host for one that cannot build
this binary. A change of behaviour is made here only; `tools/conformance.sh` still runs Node's suites against this binary, and
they must go on passing, or be changed where this binary is meant to differ.

Level with nmux 0.5.0 in what is not listed: nmux-vt, nmux-wire, the holder, the emulator, the kept history's writer, and the
server. All of them pass Node's conformance suite and its integration suites `cli`, `history`, `managed`, `flow` and
`plain-session`, with this binary as the command, the server and the holder. What the end of `plain-session.test.js` checks
inside Node's server is checked here in `crates/nmux-server/tests/core.rs` and `input.rs`; `drained.test.js` checks when Node's
sockets say they have drained, which the run loop here says itself.

Only here: `nmux __attach --json SPEC` (`crates/nmux-client/src/embed.rs`), the attach client in the words of a program that
embeds nmux and runs this binary. Node's client takes such words as functions, through its SDK.

Only here: the terminal's colour scheme and colours. A program that sets mode 2031 hears a terminal's reports of a new scheme
(`CSI ? 997 ; n n`), and one that asks with `CSI ? 996 n` is answered by a terminal (`Scheme` in
`crates/nmux-server/src/output/tracker.rs`); a terminal that attaches is asked for its scheme when the program wants it. The
holder answers OSC 10 and 11 with the colours of the terminal that attached last, and a terminal whose scheme changes is asked
its colours again. The server tells a holder that says `colors` among its caps with `COLORS` on pty.sock, and the attach client
passes on the colours its terminal says once it is attached. Node's server drops every report, and its holder answers with the
colours the session started with.

Only here: the kitty keyboard protocol (`crates/nmux-vt/src/kitty.rs`). The holder answers `CSI ? u` with the flags the
program has set on the screen it is on, which Node's holder leaves unanswered, so a program that asks for the protocol gets
it. The program's pushes, pops and sets never reach a terminal: each terminal is told the flags in force as one entry of
nmux's own, taken off before the screen changes, before RIS and when a new program starts. A join says them; a join in place
first takes off what the terminal held, and an attach client coming back says in its HELLO (`keyboard`) what it still holds.
The attach client asks its terminal `CSI ? u` along with its colours, and puts the keys of one that does not answer in the
form the flags ask for. Node's server passes a program's pushes and pops on as they are.

Only here: what a program set that a terminal attaching later should still show. The colours a program sets (OSC 4, 10, 11
and 12, and their resets) and a task's progress (OSC 9;4) are kept with its other settings and said in a join; a terminal
that leaves, or a new program, takes the progress off, and the colours stay, as they would after the program had run there
(`crates/nmux-vt/src/osc.rs`). A cell keeps the hyperlink it is in (OSC 8) and the prompt marks printed just before it
(OSC 133), through the history, a reflow and a compaction (`crates/nmux-term/src/attr.rs`): a join writes both, and the kept
history the links, which `plain` takes out again. Node's emulator keeps neither, and its join and history show a link as
underlined text.

Only here: a program's clipboard writes (OSC 52). An attach client says in its HELLO (`clipboard`) which of them its
terminal takes, from `clients.osc52`: `last-typist`, those written while it is the terminal that typed last, or `all`. The
default, `none`, takes none, where Node's default says `last-typist` and its server passes on none at all. A write goes to a
terminal as the program makes it, never in a join or in output sent again; a read is a query nobody answers; and a write
the pipeline cannot hold whole, longer than the lexer holds or stalled half way, reaches no terminal.

Only here: commands a key runs with the terminal lent to them. The configuration's `actions` names each (`{ "notes": ["vim",
"notes.md"] }`), a key is bound to that name as to `history`, and the command runs on the cooked terminal, on the alternate
screen, told `NMUX_SESSION` and `NMUX_SOCK`; the terminal joins the session again when it ends
(`crates/nmux-client/src/command.rs`). `nmux __attach` takes them in its spec's `config`, so a program that embeds nmux can
show a screen of its own over a session. Node's client runs actions only as functions its SDK is given.

## For the server

- Output is lexed twice: once by the pipeline, and again by the emulator from the chunk's bytes. One parse, as `docs/DESIGN.md`
  has it, needs the chunk to carry its tokens, through the edits the emulator makes to them and the places it divides them.
  The second lex is about a tenth of the emulator's time on plain lines and a quarter on coloured ones (0.3 and 1.4 ms of
  CPU a MB, of 2.8 and 5.5).

## For the client and the command

The client and every subcommand are ported, and pass Node's conformance suite and `test/integration/cli.test.js` and
`history.test.js`, with this binary's server and with Node's (`NMUX_SERVER_BIN`). What still differs, and where it is in Node:

- `nmux doctor` (`src/cli/doctor.js`) has no `node` and `node-pty` lines: it says `nmux`, `native addon: built in` and
  `pty: built in`.
- A pattern for `search` or `wait --text` (`new RegExp` in `src/cli/main.js`) is read as V8 reads it, refused in V8's words,
  and matches what V8 matches, over 2,000 patterns V8 was asked about and 30,000 more at random. Three rare forms still
  differ, which `crates/nmux-history/src/read/pattern.rs` names.
- The shell start-up files are built into the binary and written to `run/shell` in the runtime directory, where Node uses its
  own `shell/` (`src/cli/shells.js`).
